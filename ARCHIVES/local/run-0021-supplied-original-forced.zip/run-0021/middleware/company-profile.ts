export default defineNuxtRouteMiddleware(async () => {
  const { can, refreshAccountContext } = useAccount()
  await refreshAccountContext().catch(() => undefined)
  if (!can("editCompanyProfile")) return navigateTo("/account")
})
