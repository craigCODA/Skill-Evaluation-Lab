export default defineNuxtRouteMiddleware((to) => {
  const { isAuthenticated, isConfigured } = useAuth()

  if (!isConfigured.value) return
  if (to.path === "/login" || to.path === "/auth/callback") return
  if (!isAuthenticated.value) return navigateTo("/login")
})
