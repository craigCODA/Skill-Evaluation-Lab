# ShingleFile.com

Roofing estimate and proposal software.

## Repository

Hosted on our self-hosted Gitea server.

- Clone: `git clone git@github.com:mrecom-ai/ShingleFile.git`
- Web UI: `https://github.com/mrecom-ai/ShingleFile`

## Goals

- Keep business logic in `shared/` so Vue components, Nuxt server routes, and future Lambda handlers can reuse the same code.
- Keep page files small by moving layout, tables, forms, totals, and catalog display into focused components.
- Keep AWS assumptions visible without coupling the UI to AWS too early.

## Structure

- `pages/` maps the main workflow routes: dashboard, estimates, estimate detail, contracts, and catalog.
- `components/` contains layout and UI pieces.
- `composables/` contains estimate state, catalog access, calculation access, and formatting.
- `shared/` contains job types, constructors, estimate calculation (`calculator/`), estimator option modules (`options/`), and contract document DTO builders (`contracts/`).
- `shared/pricebook/` contains the typed catalog shape and a temporary sample catalog.
- `server/api/` is reserved for Nuxt/Nitro API endpoints that can later move to AWS Lambda handlers.

## AWS Direction

The intended AWS shape is CloudFront in front of an S3-hosted Nuxt build and API Gateway/Lambda routes, with Cognito for auth and PostgreSQL for data. Keep AWS resources in `us-west-1`.

## Commands

```bash
npm run dev        # http://localhost:6767
npm run typecheck
npm run build
```
