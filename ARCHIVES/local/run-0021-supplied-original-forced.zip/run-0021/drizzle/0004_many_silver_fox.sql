CREATE TABLE "roof_probe_measurements" (
	"address_key" text PRIMARY KEY NOT NULL,
	"display_address" text NOT NULL,
	"latitude" double precision NOT NULL,
	"longitude" double precision NOT NULL,
	"imagery_date" text,
	"imagery_quality" text DEFAULT 'UNKNOWN' NOT NULL,
	"provider" text DEFAULT 'unknown' NOT NULL,
	"preview_image_key" text,
	"mask_image_key" text,
	"body_json" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"refreshed_at" timestamp with time zone DEFAULT now() NOT NULL,
	"last_requested_at" timestamp with time zone DEFAULT now() NOT NULL
);
