CREATE TABLE "job_assets" (
	"id" text PRIMARY KEY NOT NULL,
	"customer_account_id" text DEFAULT '' NOT NULL,
	"created_by_sub_account_id" text DEFAULT '' NOT NULL,
	"customer_id" text DEFAULT '' NOT NULL,
	"job_id" text DEFAULT '' NOT NULL,
	"kind" text DEFAULT 'image' NOT NULL,
	"label" text DEFAULT '' NOT NULL,
	"content_type" text DEFAULT 'image/png' NOT NULL,
	"image_key" text DEFAULT '' NOT NULL,
	"body_json" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
