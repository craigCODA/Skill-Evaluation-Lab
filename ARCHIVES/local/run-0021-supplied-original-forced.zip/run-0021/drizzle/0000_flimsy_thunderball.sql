CREATE TABLE "jobs" (
	"id" text PRIMARY KEY NOT NULL,
	"status" text NOT NULL,
	"customer_name" text DEFAULT '' NOT NULL,
	"body_json" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
