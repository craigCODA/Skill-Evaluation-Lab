CREATE TABLE "company_profile" (
	"id" text PRIMARY KEY NOT NULL,
	"body_json" jsonb NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
