CREATE TABLE "customer_accounts" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text DEFAULT '' NOT NULL,
	"admin_user_id" text DEFAULT '' NOT NULL,
	"body_json" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "customers" (
	"id" text PRIMARY KEY NOT NULL,
	"customer_account_id" text DEFAULT '' NOT NULL,
	"created_by_sub_account_id" text DEFAULT '' NOT NULL,
	"display_name" text DEFAULT '' NOT NULL,
	"address" text DEFAULT '' NOT NULL,
	"body_json" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sub_accounts" (
	"id" text PRIMARY KEY NOT NULL,
	"customer_account_id" text DEFAULT '' NOT NULL,
	"user_id" text DEFAULT '' NOT NULL,
	"email" text DEFAULT '' NOT NULL,
	"name" text DEFAULT '' NOT NULL,
	"role" text DEFAULT 'sub-account' NOT NULL,
	"body_json" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "jobs" ADD COLUMN "customer_account_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "jobs" ADD COLUMN "created_by_sub_account_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "jobs" ADD COLUMN "customer_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
UPDATE "jobs"
SET
	"customer_account_id" = 'customer-account:' || "owner_id",
	"created_by_sub_account_id" = 'sub-account:' || "owner_id",
	"customer_id" = COALESCE(NULLIF("body_json"->'customer'->>'id', ''), "id")
WHERE "customer_account_id" = '';--> statement-breakpoint
UPDATE "jobs"
SET "body_json" = jsonb_set(
	jsonb_set(
		jsonb_set("body_json", '{customerAccountId}', to_jsonb("customer_account_id")),
		'{createdBySubAccountId}',
		to_jsonb("created_by_sub_account_id")
	),
	'{customerId}',
	to_jsonb("customer_id")
);--> statement-breakpoint
INSERT INTO "customer_accounts" ("id", "name", "admin_user_id", "body_json", "created_at", "updated_at")
SELECT DISTINCT ON ("owner_id")
	'customer-account:' || "owner_id",
	'Customer Account',
	"owner_id",
	jsonb_build_object(
		'id', 'customer-account:' || "owner_id",
		'name', 'Customer Account',
		'adminUserId', "owner_id",
		'createdAt', MIN("created_at") OVER (PARTITION BY "owner_id"),
		'updatedAt', MAX("updated_at") OVER (PARTITION BY "owner_id")
	),
	MIN("created_at") OVER (PARTITION BY "owner_id"),
	MAX("updated_at") OVER (PARTITION BY "owner_id")
FROM "jobs"
WHERE "owner_id" <> ''
ON CONFLICT ("id") DO NOTHING;--> statement-breakpoint
INSERT INTO "sub_accounts" ("id", "customer_account_id", "user_id", "email", "name", "role", "body_json", "created_at", "updated_at")
SELECT DISTINCT ON ("owner_id")
	'sub-account:' || "owner_id",
	'customer-account:' || "owner_id",
	"owner_id",
	'',
	'',
	'customer-account-admin',
	jsonb_build_object(
		'id', 'sub-account:' || "owner_id",
		'customerAccountId', 'customer-account:' || "owner_id",
		'userId', "owner_id",
		'email', '',
		'name', '',
		'role', 'customer-account-admin',
		'createdAt', MIN("created_at") OVER (PARTITION BY "owner_id"),
		'updatedAt', MAX("updated_at") OVER (PARTITION BY "owner_id")
	),
	MIN("created_at") OVER (PARTITION BY "owner_id"),
	MAX("updated_at") OVER (PARTITION BY "owner_id")
FROM "jobs"
WHERE "owner_id" <> ''
ON CONFLICT ("id") DO NOTHING;--> statement-breakpoint
INSERT INTO "customers" ("id", "customer_account_id", "created_by_sub_account_id", "display_name", "address", "body_json", "created_at", "updated_at")
SELECT DISTINCT ON ("customer_id")
	"customer_id",
	"customer_account_id",
	"created_by_sub_account_id",
	COALESCE(
		NULLIF("body_json"->'customer'->>'companyName', ''),
		NULLIF(CONCAT_WS(' ', NULLIF("body_json"->'customer'->>'firstName', ''), NULLIF("body_json"->'customer'->>'lastName', '')), ''),
		NULLIF("body_json"->'customer'->>'name', ''),
		'Unnamed customer'
	),
	CONCAT_WS(', ',
		NULLIF("body_json"->'customer'->>'address1', ''),
		NULLIF("body_json"->'customer'->>'address2', ''),
		NULLIF(CONCAT_WS(', ',
			NULLIF("body_json"->'customer'->>'city', ''),
			NULLIF(CONCAT_WS(' ', NULLIF("body_json"->'customer'->>'state', ''), NULLIF("body_json"->'customer'->>'zip', '')), '')
		), '')
	),
	jsonb_build_object(
		'id', "customer_id",
		'customerAccountId', "customer_account_id",
		'createdBySubAccountId', "created_by_sub_account_id",
		'customer', jsonb_set("body_json"->'customer', '{id}', to_jsonb("customer_id")),
		'displayName', COALESCE(
			NULLIF("body_json"->'customer'->>'companyName', ''),
			NULLIF(CONCAT_WS(' ', NULLIF("body_json"->'customer'->>'firstName', ''), NULLIF("body_json"->'customer'->>'lastName', '')), ''),
			NULLIF("body_json"->'customer'->>'name', ''),
			'Unnamed customer'
		),
		'address', CONCAT_WS(', ',
			NULLIF("body_json"->'customer'->>'address1', ''),
			NULLIF("body_json"->'customer'->>'address2', ''),
			NULLIF(CONCAT_WS(', ',
				NULLIF("body_json"->'customer'->>'city', ''),
				NULLIF(CONCAT_WS(' ', NULLIF("body_json"->'customer'->>'state', ''), NULLIF("body_json"->'customer'->>'zip', '')), '')
			), '')
		),
		'createdAt', "created_at",
		'updatedAt', "updated_at"
	),
	"created_at",
	"updated_at"
FROM "jobs"
WHERE "customer_id" <> ''
ORDER BY "customer_id", "updated_at" DESC
ON CONFLICT ("id") DO NOTHING;