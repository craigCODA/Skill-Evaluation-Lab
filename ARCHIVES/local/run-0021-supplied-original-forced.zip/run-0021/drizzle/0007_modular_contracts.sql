CREATE TABLE "contract_configs" (
	"customer_account_id" text PRIMARY KEY NOT NULL,
	"body_json" jsonb NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "job_contracts" (
	"id" text PRIMARY KEY NOT NULL,
	"job_id" text DEFAULT '' NOT NULL,
	"customer_account_id" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'unsigned' NOT NULL,
	"body_json" jsonb NOT NULL,
	"generated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"signed_at" timestamp with time zone,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
