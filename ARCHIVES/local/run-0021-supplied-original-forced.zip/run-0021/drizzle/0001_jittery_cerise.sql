CREATE TABLE "catalog_items" (
	"section" text NOT NULL,
	"item_key" text NOT NULL,
	"body_json" jsonb NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "catalog_items_section_item_key_pk" PRIMARY KEY("section","item_key")
);
