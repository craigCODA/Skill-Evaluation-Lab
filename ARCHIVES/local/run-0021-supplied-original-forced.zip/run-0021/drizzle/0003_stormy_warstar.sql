ALTER TABLE "catalog_items" ADD COLUMN "owner_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "catalog_items" DROP CONSTRAINT "catalog_items_section_item_key_pk";--> statement-breakpoint
ALTER TABLE "catalog_items" ADD CONSTRAINT "catalog_items_owner_id_section_item_key_pk" PRIMARY KEY("owner_id","section","item_key");--> statement-breakpoint
ALTER TABLE "jobs" ADD COLUMN "owner_id" text DEFAULT '' NOT NULL;
