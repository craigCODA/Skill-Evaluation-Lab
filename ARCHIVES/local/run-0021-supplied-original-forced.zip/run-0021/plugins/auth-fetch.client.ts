/**
 * Redirect to /login on expired sessions instead of surfacing raw 401 errors.
 */
export default defineNuxtPlugin(() => {
  if (import.meta.server) return

  const auth = useAuth()

  globalThis.$fetch = $fetch.create({
    onResponseError({ response, request }) {
      if (response.status !== 401) return
      const url = String(request)
      if (url.includes("amazoncognito.com")) return
      void auth.handleSessionExpired()
    }
  })
})
