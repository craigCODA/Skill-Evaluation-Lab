# User Permissions — ShingleFile

How access control works in the app today. Capability **defaults** live in code; each company may **override** assignable roles in the UI.

## 1. Two Layers (Keep Separate)

| Layer | Question | Where | Values |
|-------|----------|-------|--------|
| **Platform** | Can they manage the whole product? | Cognito group → `isAdmin` / `requireAdmin` | `admin` \| `customer` (`AccountRole`) |
| **Company account** | What can they do inside their roofing company? | `sub_accounts.role` + ownership + role capabilities | `customer-account-admin` \| `estimator` \| `installer` \| `sub-account` (legacy) |

Never put estimator/installer in Cognito groups. Never merge platform Admin into company roles.

### Platform

- `server/utils/auth.ts` — JWT / dev user → `CurrentUser.isAdmin`
- Admin routes call `requireAdmin(event)`
- UI: `useAuth().isAdmin`, `middleware/admin.ts`

### Company account

- `getCustomerAccountContext(user)` in `server/utils/customerAccountAccess.ts` returns:
  - `customerAccount` (may include `roleCapabilities` overrides), `subAccount` (role normalized)
  - `isPlatformAdmin`
  - `canSeeAllCustomerAccountWork` — platform admin **or** `seesAllAccountWork(role)` (role-based scope, not override-based)
  - `capabilities` — defaults from `ROLE_CAPABILITIES`, replaced by company overrides when present
- Row scope: `customerAccountId` + `createdBySubAccountId` when not “see all”

There is **no** per-user permissions JSON. Overrides are **per role on the company account** (`customer_accounts.body_json.roleCapabilities`).

---

## 2. Roles And Capabilities

| Role | Who | Data scope |
|------|-----|------------|
| `customer-account-admin` | Office lead / account owner | All account rows |
| `estimator` | Sales / estimating | Own rows only |
| `installer` | Field crew | Own rows only |
| `sub-account` | Legacy | Same as estimator at runtime (uses estimator overrides) |

### Default capability matrix

`✓` allowed · `—` denied (defaults; companies may change via `/account/roles`)

| Capability | Admin | Estimator | Installer |
|------------|:-----:|:---------:|:---------:|
| Manage sub-accounts / assign roles | ✓ (locked) | — | — |
| Edit company profile | ✓ | — | — |
| Edit catalog / pricebook | ✓ | — | — |
| Create / edit customers | ✓ | ✓ | — |
| Create / edit estimates | ✓ | ✓ | — |
| View estimates | ✓ | ✓ | — |
| View / open contracts | ✓ | ✓ | — |
| Manage job assets (photos, drawings) | ✓ | ✓ | ✓ |
| Use ShingleScope / roof-probe | ✓ | ✓ | ✓ |
| View account statistics | ✓ | ✓ | — |

Calculator reference page is open to signed-in users (docs only).

**Installer note:** no estimate access by default. Job assets use `resolveAccountJob` (ownership only), not `getEstimate` (requires `viewEstimates`).

**Lockout protection:** Account admin always keeps `manageSubAccounts` even if an override omits it.

### Who manages what

| Actor | Manages |
|-------|---------|
| Cognito `admin` | Tenant logins (`admin` \| `customer`) |
| `customer-account-admin` | People on **their** account (`/account/team`) and **role capability overrides** (`/account/roles`) |

---

## 3. Code Map

| Concern | File |
|---------|------|
| Capability type + defaults + resolve | `shared/accountPermissions.ts` |
| Role type + `CustomerAccount.roleCapabilities` | `shared/types.ts` |
| Context + scope + save overrides | `server/utils/customerAccountAccess.ts` |
| Server assert helpers | `server/utils/accountPermissions.ts` |
| Role capabilities API | `server/api/customer-account/role-capabilities.{get,put}.ts` |
| Estimate / job authz | `server/utils/estimateStore.ts` |
| Customer authz | `server/utils/customerStore.ts` |
| Job asset authz | `server/utils/jobAssetStore.ts` |
| Catalog mutate | `server/utils/catalogStore.ts` |
| Company mutate | `server/api/company.put.ts` |
| Contracts | `server/api/jobs/[jobId]/contracts.get.ts` |
| Roof-probe | `server/api/roof-probe*.ts` |
| Client `can()` + save overrides | `composables/useAccount.ts` |
| Account context API | `server/api/customer-account/index.get.ts` |
| Roles UI | `pages/account/roles.vue` |

### Request flow

```
API route (thin)
  → getCustomerAccountContext(user)   // loads company overrides
  → assertAccountCapability(context, "…")   // action allowed?
  → filter by ownership / canSeeAll…         // which rows?
```

### Frontend

- Load context: `useAccount().refreshAccountContext()`
- Gate UI: `can("viewEstimates")`, etc.
- Edit matrix: `/account/roles` (`manageSubAccounts`)
- **UI hide is not security** — server must assert.

---

## 4. How To Extend

1. Add to `AccountCapability` in `shared/accountPermissions.ts`
2. Grant it on the right roles in `ROLE_CAPABILITIES` (defaults) and `ACCOUNT_CAPABILITY_LABELS`
3. Assert in the **store or route** with `assertAccountCapability`
4. Optionally gate UI with `useAccount().can("…")`
5. Update this doc’s default matrix

Companies can then grant/revoke that capability on `/account/roles` without another deploy.

To add a **role**: extend `CustomerAccountRole`, add a `ROLE_CAPABILITIES` entry, add to `ASSIGNABLE_CUSTOMER_ACCOUNT_ROLES` if assignable, keep Cognito unchanged.

---

## 5. What Not To Build

- Per-user / free-form permission bags on `sub_accounts`
- Amazon Verified Permissions / IAM for app roles (wrong layer for now)
- Cognito groups for estimator/installer
- A second authz path that bypasses `customerAccountAccess`

---

## 6. Still Open

1. Backfill DB `sub-account` → `estimator` (and sync `bodyJson.role`)

### Team members and role permissions (implemented)

Account admins (`manageSubAccounts`) can:

- `POST /api/customer-account/sub-accounts` — create Cognito login (`customer` group) + `sub_accounts` row on **their** company account with role `customer-account-admin` | `estimator` | `installer`
- `PATCH /api/customer-account/sub-accounts/:id` — change role (not own role; cannot remove last account admin)
- `GET` / `PUT /api/customer-account/role-capabilities` — read/save per-company role capability matrix
- UI: `/account/team`, `/account/roles`

On first sign-in, the new user resolves via existing `sub_accounts.userId` and does **not** get a separate auto-created company account.

---

## 7. Quick Tests

- Platform admin → admin routes; full company capabilities while in-app
- Account admin → all rows; catalog/company/sub-accounts; can open `/account/roles`
- Save estimator override (e.g. grant `editCatalog`) → estimator `can("editCatalog")` and catalog PATCH allowed
- Save installer override removing `useRoofProbe` → installer 403 on roof-probe
- Cannot uncheck Account admin “Manage team members and roles”
- Estimator (defaults) → own customers/estimates/contracts/assets; **403** on catalog PATCH / company PUT / manage sub-accounts
- Installer (defaults) → assets + ShingleScope; **403** on estimate read/write and contracts
