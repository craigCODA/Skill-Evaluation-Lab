import type { RoofMeasurement } from "~~/shared/types"
import type { RoofAreaShape, RoofIconMarker, RoofLineMeasurement } from "~~/shared/roofLineMeasurements"
import { computeOrderSquares } from "~~/shared/roofMeasurement"
import { normalizeRoofProbeAddress } from "~~/shared/roofProbeAddress"

export type RoofProbeQuality = "HIGH" | "MEDIUM" | "LOW"
export type RoofProbeHistoryEntry = {
  id: string
  userKey: string
  addressKey: string
  address: string
  measurementId: string
  searchedAt: string
  lines: RoofLineMeasurement[]
  markers?: RoofIconMarker[]
  areaShapes?: RoofAreaShape[]
  wasteFactor?: number
}

type RoofProbeResponse = {
  measurement: RoofMeasurement
  cacheStatus: "hit" | "miss" | "refreshed"
  refreshedAt: string
}

export type StreetViewAvailability = {
  available: boolean
  status: string
  panoId?: string
  imageDate?: string
  copyright?: string
}

const HISTORY_DB_NAME = "shinglefile-roof-probe"
const HISTORY_DB_VERSION = 1
const HISTORY_STORE_NAME = "searches"
const HISTORY_LIMIT = 30

export function useRoofMeasurements() {
  const { authHeaders, currentUser } = useAuth()
  const latestMeasurement = useState<RoofMeasurement | null>(
    "roof-probe-latest-measurement",
    () => null
  )
  const latestMeasuredLines = useState<RoofLineMeasurement[]>(
    "roof-probe-latest-lines",
    () => []
  )
  const latestIconMarkers = useState<RoofIconMarker[]>(
    "roof-probe-latest-icon-markers",
    () => []
  )
  const latestAreaShapes = useState<RoofAreaShape[]>(
    "roof-probe-latest-area-shapes",
    () => []
  )
  const latestWasteFactor = useState<number>(
    "roof-probe-waste-factor",
    () => 1.1
  )
  const historyEntries = useState<RoofProbeHistoryEntry[]>(
    "roof-probe-history",
    () => []
  )
  const streetViewAvailability = useState<StreetViewAvailability | null>(
    "roof-probe-street-view-availability",
    () => null
  )
  const isCheckingStreetView = useState<boolean>(
    "roof-probe-street-view-checking",
    () => false
  )

  const userKey = computed(() => currentUser.value.email || "anonymous")

  async function probeAddress(input: {
    address: string
    requiredQuality: RoofProbeQuality
  }): Promise<RoofMeasurement> {
    if (!input.address.replace(/!/g, " ").trim()) {
      throw new Error("Enter an address before running ShingleScope")
    }

    await refreshHistory()
    const response = await $fetch<RoofProbeResponse>("/api/roof-probe", {
      method: "POST",
      body: {
        address: input.address,
        requiredQuality: input.requiredQuality,
      },
      headers: authHeaders()
    })

    const existingEntry = findHistoryEntryByAddress(response.measurement.address)
    const measurement = existingEntry?.wasteFactor
      ? applyWasteFactor(response.measurement, existingEntry.wasteFactor)
      : response.measurement
    latestMeasurement.value = measurement
    latestMeasuredLines.value = existingEntry?.lines ?? []
    latestIconMarkers.value = existingEntry?.markers ?? []
    latestAreaShapes.value = existingEntry?.areaShapes ?? []
    syncWasteFactorFromMeasurement(measurement)
    await saveCurrentToHistory().catch(() => undefined)
    return measurement
  }

  async function hydrateHistory(): Promise<void> {
    if (!import.meta.client) return
    await refreshHistory()
  }

  function clearLatestMeasurement(): void {
    latestMeasurement.value = null
    latestMeasuredLines.value = []
    latestIconMarkers.value = []
    latestAreaShapes.value = []
    latestWasteFactor.value = 1.1
  }

  async function refreshHistory(): Promise<void> {
    if (!import.meta.client) return
    const db = await openHistoryDb()
    const entries = await readAllHistoryEntries(db)
    historyEntries.value = (await normalizeHistoryEntries(db, userKey.value, entries))
      .sort((left, right) => Date.parse(right.searchedAt) - Date.parse(left.searchedAt))
      .slice(0, HISTORY_LIMIT)
  }

  async function saveCurrentToHistory(): Promise<void> {
    const measurement = latestMeasurement.value
    if (!import.meta.client || !measurement) return
    const db = await openHistoryDb()
    const addressKey = normalizeRoofProbeAddress(measurement.address)
    if (!addressKey) return
    const existing = await getHistoryEntry(db, historyEntryId(userKey.value, addressKey))
    const entry: RoofProbeHistoryEntry = {
      id: existing?.id ?? historyEntryId(userKey.value, addressKey),
      userKey: userKey.value,
      addressKey,
      address: measurement.address,
      measurementId: measurement.id,
      searchedAt: new Date().toISOString(),
      lines: plainClone(latestMeasuredLines.value),
      markers: plainClone(latestIconMarkers.value),
      areaShapes: plainClone(latestAreaShapes.value),
      wasteFactor: latestWasteFactor.value,
    }
    await putHistoryEntry(db, entry)
    await trimHistory(db, userKey.value)
    await refreshHistory()
  }

  async function saveCurrentLinesToHistory(): Promise<void> {
    const measurement = latestMeasurement.value
    if (!import.meta.client || !measurement) return
    await saveMeasurementSnapshotToHistory(measurement, latestMeasuredLines.value, latestIconMarkers.value, latestAreaShapes.value)
  }

  async function saveCurrentMeasurementToHistory(): Promise<void> {
    const measurement = latestMeasurement.value
    if (!import.meta.client || !measurement) return
    await saveMeasurementSnapshotToHistory(measurement, latestMeasuredLines.value, latestIconMarkers.value, latestAreaShapes.value)
  }

  async function checkStreetViewAvailability(measurement: RoofMeasurement): Promise<void> {
    streetViewAvailability.value = null
    isCheckingStreetView.value = true
    try {
      streetViewAvailability.value = await $fetch<StreetViewAvailability>(
        "/api/roof-probe/street-view",
        {
          query: {
            latitude: measurement.latitude,
            longitude: measurement.longitude,
          },
          headers: authHeaders(),
        }
      )
    } finally {
      isCheckingStreetView.value = false
    }
  }

  async function saveMeasurementSnapshotToHistory(
    measurement: RoofMeasurement,
    lines: RoofLineMeasurement[],
    markers: RoofIconMarker[],
    areaShapes: RoofAreaShape[]
  ): Promise<void> {
    const db = await openHistoryDb()
    const addressKey = normalizeRoofProbeAddress(measurement.address)
    if (!addressKey) return
    const existing = await getHistoryEntry(db, historyEntryId(userKey.value, addressKey))
    await putHistoryEntry(db, {
      id: existing?.id ?? historyEntryId(userKey.value, addressKey),
      userKey: userKey.value,
      addressKey,
      address: measurement.address,
      measurementId: measurement.id,
      searchedAt: existing?.searchedAt ?? new Date().toISOString(),
      lines: plainClone(lines),
      markers: plainClone(markers),
      areaShapes: plainClone(areaShapes),
      wasteFactor: latestWasteFactor.value,
    })
    await refreshHistory()
  }

  async function restoreHistoryEntry(entryId: string): Promise<void> {
    const entry = historyEntries.value.find((item) => item.id === entryId)
    if (!entry) return
    const measurement = await probeAddress({
      address: entry.address,
      requiredQuality: "LOW",
    })
    latestMeasurement.value = entry.wasteFactor ? applyWasteFactor(measurement, entry.wasteFactor) : measurement
    latestMeasuredLines.value = entry.lines
    latestIconMarkers.value = entry.markers ?? []
    latestAreaShapes.value = entry.areaShapes ?? []
    syncWasteFactorFromMeasurement(latestMeasurement.value)
  }

  function setWasteFactor(factor: number): void {
    const measurement = latestMeasurement.value
    if (!measurement) return
    const current = measurement.manualOverrides?.wasteFactor ?? measurement.wasteFactor
    if (factor === current) return
    latestMeasurement.value = applyWasteFactor(measurement, factor)
    void saveCurrentMeasurementToHistory().catch(() => undefined)
  }

  return {
    clearLatestMeasurement,
    historyEntries,
    hydrateHistory,
    checkStreetViewAvailability,
    isCheckingStreetView,
    latestAreaShapes,
    latestIconMarkers,
    latestMeasurement,
    latestMeasuredLines,
    latestWasteFactor,
    refreshHistory,
    restoreHistoryEntry,
    saveCurrentLinesToHistory,
    streetViewAvailability,
    setWasteFactor,
    probeAddress
  }

  function syncWasteFactorFromMeasurement(measurement: RoofMeasurement): void {
    latestWasteFactor.value = measurement.manualOverrides?.wasteFactor ?? measurement.wasteFactor
  }

  function applyWasteFactor(measurement: RoofMeasurement, factor: number): RoofMeasurement {
    return {
      ...measurement,
      manualOverrides: {
        ...measurement.manualOverrides,
        wasteFactor: factor,
        orderSquares: computeOrderSquares(measurement.measuredSquares, factor),
      },
      orderSquares: computeOrderSquares(measurement.measuredSquares, factor),
      updatedAt: new Date().toISOString(),
    }
  }

  function findHistoryEntryByAddress(address: string): RoofProbeHistoryEntry | undefined {
    const normalizedAddress = normalizeRoofProbeAddress(address)
    if (!normalizedAddress) return undefined
    return historyEntries.value.find((entry) => (
      entry.addressKey === normalizedAddress ||
      normalizeRoofProbeAddress(entry.address) === normalizedAddress
    ))
  }
}

function historyEntryId(userKey: string, addressKey: string): string {
  return `${encodeURIComponent(userKey)}:${encodeURIComponent(addressKey)}`
}

function plainClone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T
}

async function normalizeHistoryEntries(
  db: IDBDatabase,
  userKey: string,
  entries: RoofProbeHistoryEntry[]
): Promise<RoofProbeHistoryEntry[]> {
  const byAddress = new Map<string, RoofProbeHistoryEntry>()
  const staleIds = new Set<string>()

  for (const entry of entries) {
    if (entry.userKey !== userKey) continue
    const legacy = entry as RoofProbeHistoryEntry & { measurement?: RoofMeasurement }
    const address = entry.address || legacy.measurement?.address || ""
    const addressKey = entry.addressKey || normalizeRoofProbeAddress(address)
    if (!addressKey) {
      staleIds.add(entry.id)
      continue
    }

    const normalized: RoofProbeHistoryEntry = {
      id: historyEntryId(userKey, addressKey),
      userKey,
      addressKey,
      address,
      measurementId: entry.measurementId || legacy.measurement?.id || addressKey,
      searchedAt: entry.searchedAt,
      lines: entry.lines ?? [],
      markers: entry.markers ?? [],
      areaShapes: entry.areaShapes ?? [],
      wasteFactor: entry.wasteFactor,
    }
    if (entry.id !== normalized.id) staleIds.add(entry.id)

    const existing = byAddress.get(addressKey)
    if (!existing || Date.parse(normalized.searchedAt) >= Date.parse(existing.searchedAt)) {
      if (existing) staleIds.add(existing.id)
      byAddress.set(addressKey, normalized)
    } else {
      staleIds.add(normalized.id)
    }
  }

  const normalizedEntries = Array.from(byAddress.values())
  await Promise.all([
    ...normalizedEntries.map((entry) => putHistoryEntry(db, entry)),
    ...Array.from(staleIds)
      .filter((entryId) => !normalizedEntries.some((entry) => entry.id === entryId))
      .map((entryId) => deleteHistoryEntry(db, entryId)),
  ])
  return normalizedEntries
}

function openHistoryDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(HISTORY_DB_NAME, HISTORY_DB_VERSION)
    request.onupgradeneeded = () => {
      const db = request.result
      if (!db.objectStoreNames.contains(HISTORY_STORE_NAME)) {
        db.createObjectStore(HISTORY_STORE_NAME, { keyPath: "id" })
      }
    }
    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve(request.result)
  })
}

function readAllHistoryEntries(db: IDBDatabase): Promise<RoofProbeHistoryEntry[]> {
  return new Promise((resolve, reject) => {
    const request = db
      .transaction(HISTORY_STORE_NAME, "readonly")
      .objectStore(HISTORY_STORE_NAME)
      .getAll()
    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve(request.result as RoofProbeHistoryEntry[])
  })
}

function getHistoryEntry(
  db: IDBDatabase,
  entryId: string
): Promise<RoofProbeHistoryEntry | undefined> {
  return new Promise((resolve, reject) => {
    const request = db
      .transaction(HISTORY_STORE_NAME, "readonly")
      .objectStore(HISTORY_STORE_NAME)
      .get(entryId)
    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve(request.result as RoofProbeHistoryEntry | undefined)
  })
}

function putHistoryEntry(db: IDBDatabase, entry: RoofProbeHistoryEntry): Promise<void> {
  return new Promise((resolve, reject) => {
    const request = db
      .transaction(HISTORY_STORE_NAME, "readwrite")
      .objectStore(HISTORY_STORE_NAME)
      .put(entry)
    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve()
  })
}

async function trimHistory(db: IDBDatabase, userKey: string): Promise<void> {
  const entries = (await readAllHistoryEntries(db))
    .filter((entry) => entry.userKey === userKey)
    .sort((left, right) => Date.parse(right.searchedAt) - Date.parse(left.searchedAt))

  await Promise.all(entries.slice(HISTORY_LIMIT).map((entry) => deleteHistoryEntry(db, entry.id)))
}

function deleteHistoryEntry(db: IDBDatabase, entryId: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const request = db
      .transaction(HISTORY_STORE_NAME, "readwrite")
      .objectStore(HISTORY_STORE_NAME)
      .delete(entryId)
    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve()
  })
}
