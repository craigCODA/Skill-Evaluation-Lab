import type { Job } from "~~/shared/types"
import { calculateRoofingEstimate } from "~~/shared/calculator/calculateEstimate"

export function useEstimateTotals(job: Ref<Job | undefined>) {
  const { catalog } = useCatalog()

  const totals = computed(() => {
    if (!job.value?.scope.roofing) return null

    return calculateRoofingEstimate({
      roofing: job.value.scope.roofing,
      catalog: catalog.value,
      permit: job.value.permit,
      extras: job.value.extras
    })
  })

  return {
    totals
  }
}
