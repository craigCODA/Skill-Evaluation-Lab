import type { CompanyProfile } from "~~/shared/types"
import { newCompanyProfile } from "~~/shared/company"

export function useCompanyProfile() {
  const profile = useState<CompanyProfile>("company-profile", () => newCompanyProfile())
  const { authHeaders } = useAuth()

  async function refreshCompanyProfile() {
    profile.value = await $fetch<CompanyProfile>("/api/company", {
      headers: authHeaders()
    })
  }

  async function saveCompanyProfile(next: CompanyProfile) {
    profile.value = await $fetch<CompanyProfile>("/api/company", {
      method: "PUT",
      body: next,
      headers: authHeaders()
    })
    return profile.value
  }

  return {
    profile,
    refreshCompanyProfile,
    saveCompanyProfile
  }
}
