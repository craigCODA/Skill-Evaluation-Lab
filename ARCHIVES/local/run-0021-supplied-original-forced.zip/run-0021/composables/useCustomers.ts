import type { Customer, CustomerFile, CustomerRecord } from "~~/shared/types"

export function useCustomers() {
  const { authHeaders } = useAuth()
  const customers = useState<CustomerRecord[]>("customer-list", () => [])
  const customerFiles = useState<Record<string, CustomerFile>>("customer-files", () => ({}))

  async function refreshCustomers(): Promise<void> {
    customers.value = await apiFetch<CustomerRecord[]>("/api/customers")
  }

  async function createCustomer(input: Partial<Customer>): Promise<CustomerRecord> {
    const customer = await apiFetch<CustomerRecord>("/api/customers", {
      method: "POST",
      body: input
    })
    customers.value = [customer, ...customers.value.filter((item) => item.id !== customer.id)]
    return customer
  }

  async function loadCustomer(customerId: string): Promise<CustomerFile | null> {
    const customer = await apiFetch<CustomerFile>(`/api/customers/${customerId}`).catch(() => null)
    if (customer) {
      customerFiles.value = { ...customerFiles.value, [customer.id]: customer }
    }
    return customer
  }

  async function updateCustomer(customerId: string, input: Partial<Customer>): Promise<CustomerRecord> {
    const customer = await apiFetch<CustomerRecord>(`/api/customers/${customerId}`, {
      method: "PUT",
      body: input
    })
    customers.value = customers.value.map((item) => item.id === customer.id ? customer : item)
    const existingFile = customerFiles.value[customer.id]
    if (existingFile) {
      customerFiles.value = { ...customerFiles.value, [customer.id]: { ...customer, jobs: existingFile.jobs } }
    }
    return customer
  }

  return {
    customers,
    customerFiles,
    createCustomer,
    loadCustomer,
    refreshCustomers,
    updateCustomer
  }

  function apiFetch<T>(url: string, options: Parameters<typeof $fetch<T>>[1] = {}) {
    return $fetch<T>(url, {
      ...options,
      headers: {
        ...authHeaders(),
        ...options?.headers
      }
    })
  }
}
