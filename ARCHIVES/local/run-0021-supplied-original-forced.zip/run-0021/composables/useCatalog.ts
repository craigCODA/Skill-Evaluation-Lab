import { loadCatalog } from "~~/shared/pricebook"
import type { Catalog } from "~~/shared/pricebook/types"

export function useCatalog() {
  const catalog = useState("catalog", () => loadCatalog())
  const { authHeaders } = useAuth()

  async function refreshCatalog() {
    catalog.value = await $fetch<Catalog>("/api/catalog", {
      headers: authHeaders()
    })
  }

  async function updateCatalogItem(
    section: keyof Catalog,
    itemKey: string,
    patch: Record<string, unknown>
  ) {
    const updated = await $fetch<Catalog[keyof Catalog][number]>(
      `/api/catalog/${String(section)}/${encodeURIComponent(itemKey)}`,
      {
        method: "PATCH",
        body: patch,
        headers: authHeaders()
      }
    )
    await refreshCatalog()
    return updated
  }

  return {
    catalog,
    refreshCatalog,
    updateCatalogItem
  }
}
