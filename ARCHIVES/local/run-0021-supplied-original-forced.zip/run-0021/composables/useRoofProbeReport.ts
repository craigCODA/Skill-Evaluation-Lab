import type { Ref } from "vue";
import type { RoofLineMeasurement } from "~~/shared/roofLineMeasurements";
import type { RoofMeasurement } from "~~/shared/types";
import {
  buildRoofProbeReport,
} from "~~/shared/roofProbeReport";
import { ROOF_PROBE_WASTE_OPTIONS } from "~~/shared/roofMeasurement";

export function useRoofProbeReport(input: {
  measurement: Ref<RoofMeasurement | null>;
  measuredLines: Ref<RoofLineMeasurement[]>;
  wasteFactor: Ref<number>;
}) {
  const ridgeVentNfaPerFt = useState<number>(
    "roof-probe-ridge-vent-nfa-per-ft",
    () => 18
  );

  const report = computed(() => {
    const measurement = input.measurement.value;
    if (!measurement) return null;
    return buildRoofProbeReport({
      measurement,
      measuredLines: input.measuredLines.value,
      wasteFactor: input.wasteFactor.value,
      ridgeVentNfaPerFt: ridgeVentNfaPerFt.value,
    });
  });

  return {
    report,
    ridgeVentNfaPerFt,
    wasteOptions: ROOF_PROBE_WASTE_OPTIONS,
  };
}
