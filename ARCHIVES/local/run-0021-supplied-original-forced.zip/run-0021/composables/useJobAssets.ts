import type { DrawingScreenshotAssetMetadata, JobAsset } from "~~/shared/types"

export function useJobAssets() {
  const { authHeaders } = useAuth()
  const jobAssets = useState<Record<string, JobAsset[]>>("job-assets", () => ({}))
  const assetImages = useState<Record<string, string>>("job-asset-images", () => ({}))

  async function refreshJobAssets(jobId: string): Promise<JobAsset[]> {
    const assets = await apiFetch<JobAsset[]>(`/api/jobs/${jobId}/assets`)
    jobAssets.value = { ...jobAssets.value, [jobId]: assets }
    return assets
  }

  async function saveDrawingScreenshot(input: {
    jobId: string
    label: string
    imageDataUrl: string
    metadata?: DrawingScreenshotAssetMetadata
  }): Promise<JobAsset> {
    const asset = await apiFetch<JobAsset>(`/api/jobs/${input.jobId}/assets`, {
      method: "POST",
      body: {
        label: input.label,
        kind: "drawing-screenshot",
        imageDataUrl: input.imageDataUrl,
        metadata: input.metadata
      }
    })
    jobAssets.value = {
      ...jobAssets.value,
      [input.jobId]: [asset, ...(jobAssets.value[input.jobId] ?? [])]
    }
    assetImages.value = { ...assetImages.value, [asset.id]: input.imageDataUrl }
    return asset
  }

  async function saveJobsiteMedia(input: {
    jobId: string
    label: string
    description: string
    mediaDataUrl: string
  }): Promise<JobAsset> {
    const asset = await apiFetch<JobAsset>(`/api/jobs/${input.jobId}/assets`, {
      method: "POST",
      body: {
        label: input.label,
        description: input.description,
        kind: "image",
        imageDataUrl: input.mediaDataUrl
      }
    })
    jobAssets.value = {
      ...jobAssets.value,
      [input.jobId]: [asset, ...(jobAssets.value[input.jobId] ?? [])]
    }
    assetImages.value = { ...assetImages.value, [asset.id]: input.mediaDataUrl }
    return asset
  }

  async function loadAssetImage(assetId: string): Promise<string | null> {
    if (assetImages.value[assetId]) return assetImages.value[assetId]
    const image = await apiFetch<{ dataUrl: string }>(`/api/job-assets/${assetId}`).catch(() => null)
    if (!image) return null
    assetImages.value = { ...assetImages.value, [assetId]: image.dataUrl }
    return image.dataUrl
  }

  async function deleteAsset(asset: JobAsset): Promise<void> {
    await apiFetch(`/api/job-assets/${asset.id}`, { method: "DELETE" })
    jobAssets.value = {
      ...jobAssets.value,
      [asset.jobId]: (jobAssets.value[asset.jobId] ?? []).filter((item) => item.id !== asset.id)
    }
    const nextImages = { ...assetImages.value }
    delete nextImages[asset.id]
    assetImages.value = nextImages
  }

  async function updateAssetDescription(asset: JobAsset, description: string): Promise<JobAsset> {
    const updatedAsset = await apiFetch<JobAsset>(`/api/job-assets/${asset.id}`, {
      method: "PATCH",
      body: { description }
    })
    jobAssets.value = {
      ...jobAssets.value,
      [asset.jobId]: (jobAssets.value[asset.jobId] ?? []).map((item) =>
        item.id === updatedAsset.id ? updatedAsset : item
      )
    }
    return updatedAsset
  }

  return {
    assetImages,
    deleteAsset,
    jobAssets,
    loadAssetImage,
    refreshJobAssets,
    saveDrawingScreenshot,
    saveJobsiteMedia,
    updateAssetDescription
  }

  function apiFetch<T>(url: string, options: Parameters<typeof $fetch<T>>[1] = {}) {
    return $fetch<T>(url, {
      ...options,
      headers: {
        ...authHeaders(),
        ...options?.headers
      }
    })
  }
}
