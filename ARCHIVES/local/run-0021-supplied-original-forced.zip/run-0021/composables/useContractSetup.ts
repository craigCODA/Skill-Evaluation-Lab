import type {
  CompanyContractConfig,
  ContractRecipeKind,
  JobContractBundle,
  JobContractSnapshot
} from "~~/shared/contracts/modules"

export function useContractSetup() {
  const { authHeaders } = useAuth()

  async function loadContractConfig(): Promise<CompanyContractConfig> {
    return apiFetch<CompanyContractConfig>("/api/customer-account/contract-config")
  }

  async function saveContractConfig(
    input: Partial<CompanyContractConfig>
  ): Promise<CompanyContractConfig> {
    return apiFetch<CompanyContractConfig>("/api/customer-account/contract-config", {
      method: "PUT",
      body: input
    })
  }

  async function loadJobContract(jobId: string): Promise<{
    bundle: JobContractBundle
    enabledRecipes: Record<ContractRecipeKind, boolean>
    activeRecipeKinds: ContractRecipeKind[]
  }> {
    return apiFetch(`/api/jobs/${encodeURIComponent(jobId)}/contract`)
  }

  async function regenerateJobContract(
    jobId: string,
    recipeKind: ContractRecipeKind = "roofing"
  ): Promise<JobContractSnapshot> {
    return apiFetch(`/api/jobs/${encodeURIComponent(jobId)}/contract/regenerate`, {
      method: "POST",
      body: { recipeKind }
    })
  }

  async function markJobContractSigned(
    jobId: string,
    recipeKind: ContractRecipeKind = "roofing"
  ): Promise<JobContractSnapshot> {
    return apiFetch(`/api/jobs/${encodeURIComponent(jobId)}/contract/mark-signed`, {
      method: "POST",
      body: { recipeKind }
    })
  }

  async function uploadSignedPdf(
    jobId: string,
    input: { recipeKind: ContractRecipeKind, fileName: string, dataUrl: string }
  ): Promise<JobContractSnapshot> {
    return apiFetch(`/api/jobs/${encodeURIComponent(jobId)}/contract/signed-pdf`, {
      method: "POST",
      body: input
    })
  }

  async function downloadSignedPdf(
    jobId: string,
    recipeKind: ContractRecipeKind
  ): Promise<{ snapshot: JobContractSnapshot, dataUrl: string }> {
    return apiFetch(
      `/api/jobs/${encodeURIComponent(jobId)}/contract/signed-pdf?recipeKind=${encodeURIComponent(recipeKind)}`
    )
  }

  return {
    loadContractConfig,
    saveContractConfig,
    loadJobContract,
    regenerateJobContract,
    markJobContractSigned,
    uploadSignedPdf,
    downloadSignedPdf
  }

  function apiFetch<T>(url: string, options: Parameters<typeof $fetch<T>>[1] = {}) {
    return $fetch<T>(url, {
      ...options,
      headers: {
        ...authHeaders(),
        ...options?.headers
      }
    })
  }
}
