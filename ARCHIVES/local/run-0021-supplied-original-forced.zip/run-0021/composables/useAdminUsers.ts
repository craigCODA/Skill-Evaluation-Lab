import type { AccountRole, AccountSummary, CompanyProfile } from "~~/shared/types"

export type NewAccountInput = {
  email: string
  name: string
  password: string
  role: AccountRole
}

export function useAdminUsers() {
  const { authHeaders } = useAuth()

  async function listUsers() {
    return $fetch<AccountSummary[]>("/api/admin/users", { headers: authHeaders() })
  }

  async function createUser(input: NewAccountInput) {
    return $fetch("/api/admin/users", {
      method: "POST",
      body: input,
      headers: authHeaders()
    })
  }

  async function deleteUser(userId: string) {
    return $fetch(`/api/admin/users/${encodeURIComponent(userId)}`, {
      method: "DELETE",
      headers: authHeaders()
    })
  }

  async function getUserCompany(userId: string) {
    return $fetch<CompanyProfile>(`/api/admin/users/${encodeURIComponent(userId)}/company`, {
      headers: authHeaders()
    })
  }

  async function getPlatformProfile() {
    return $fetch<CompanyProfile>("/api/admin/platform", { headers: authHeaders() })
  }

  async function savePlatformProfile(next: CompanyProfile) {
    return $fetch<CompanyProfile>("/api/admin/platform", {
      method: "PUT",
      body: next,
      headers: authHeaders()
    })
  }

  return {
    listUsers,
    createUser,
    deleteUser,
    getUserCompany,
    getPlatformProfile,
    savePlatformProfile
  }
}
