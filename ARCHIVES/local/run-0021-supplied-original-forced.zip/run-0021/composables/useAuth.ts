type TokenResponse = {
  id_token: string
  access_token: string
  refresh_token?: string
  expires_in: number
  token_type: string
}

const TOKEN_KEY = "roofcalc.idToken"
const VERIFIER_KEY = "roofcalc.pkceVerifier"

export function useAuth() {
  const config = useRuntimeConfig()
  const idToken = useState<string | null>("id-token", () => null)
  const isConfigured = computed(() =>
    Boolean(config.public.cognitoDomain && config.public.cognitoClientId)
  )
  const isAuthenticated = computed(() => {
    if (!isConfigured.value) return true
    if (!idToken.value) return false
    return !isTokenExpired(idToken.value)
  })

  if (import.meta.client && idToken.value === null) {
    idToken.value = localStorage.getItem(TOKEN_KEY)
  }

  const claims = computed<Record<string, unknown> | null>(() =>
    idToken.value ? decodeJwt(idToken.value) : null
  )
  const groups = computed<string[]>(() => {
    const value = claims.value?.["cognito:groups"]
    if (Array.isArray(value)) return value.map(String)
    if (typeof value === "string" && value) return [value]
    return []
  })
  const currentUser = computed(() => {
    if (claims.value) {
      return {
        email: String(claims.value.email ?? ""),
        name: String(claims.value.name ?? claims.value.email ?? "")
      }
    }
    // Dev (Cognito not configured): act as the admin account locally.
    if (!isConfigured.value) return { email: "admin@example.com", name: "Admin (dev)" }
    return { email: "", name: "" }
  })
  const isAdmin = computed(() => (isConfigured.value ? groups.value.includes("admin") : true))

  function authHeaders(): HeadersInit {
    return idToken.value ? { Authorization: `Bearer ${idToken.value}` } : {}
  }

  async function login() {
    if (!isConfigured.value) return

    const verifier = randomString()
    const challenge = await pkceChallenge(verifier)
    localStorage.setItem(VERIFIER_KEY, verifier)

    const params = new URLSearchParams({
      client_id: String(config.public.cognitoClientId),
      code_challenge: challenge,
      code_challenge_method: "S256",
      redirect_uri: `${window.location.origin}/auth/callback`,
      response_type: "code",
      scope: "openid email profile"
    })

    window.location.href = `${config.public.cognitoDomain}/oauth2/authorize?${params}`
  }

  async function completeLogin(code: string) {
    const verifier = localStorage.getItem(VERIFIER_KEY)
    if (!isConfigured.value || !verifier) {
      throw new Error("Missing Cognito login state.")
    }

    const body = new URLSearchParams({
      client_id: String(config.public.cognitoClientId),
      code,
      code_verifier: verifier,
      grant_type: "authorization_code",
      redirect_uri: `${window.location.origin}/auth/callback`
    })

    const tokens = await $fetch<TokenResponse>(
      `${config.public.cognitoDomain}/oauth2/token`,
      {
        method: "POST",
        body,
        headers: { "Content-Type": "application/x-www-form-urlencoded" }
      }
    )

    idToken.value = tokens.id_token
    localStorage.setItem(TOKEN_KEY, tokens.id_token)
    localStorage.removeItem(VERIFIER_KEY)
  }

  function clearSession() {
    idToken.value = null
    localStorage.removeItem(TOKEN_KEY)
  }

  async function handleSessionExpired() {
    clearSession()
    if (import.meta.client && window.location.pathname !== "/login") {
      await navigateTo("/login")
    }
  }

  function logout() {
    clearSession()

    if (!isConfigured.value) return navigateTo("/login")

    // Cognito requires an exact Logout URL match (including path). Use /login so
    // users land on the sign-in page after the hosted UI clears the session.
    const logoutUri = `${window.location.origin}/login`
    const params = new URLSearchParams({
      client_id: String(config.public.cognitoClientId),
      logout_uri: logoutUri
    })
    window.location.assign(`${config.public.cognitoDomain}/logout?${params}`)
  }

  return {
    authHeaders,
    clearSession,
    completeLogin,
    currentUser,
    groups,
    handleSessionExpired,
    idToken,
    isAdmin,
    isAuthenticated,
    isConfigured,
    login,
    logout
  }
}

function isTokenExpired(token: string): boolean {
  const claims = decodeJwt(token)
  const exp = claims?.exp
  if (typeof exp !== "number") return false
  return exp * 1000 <= Date.now()
}

function decodeJwt(token: string): Record<string, unknown> | null {
  const segment = token.split(".")[1]
  if (!segment) return null
  try {
    const payload = segment.replace(/-/g, "+").replace(/_/g, "/")
    const json = decodeURIComponent(
      atob(payload)
        .split("")
        .map((char) => `%${`00${char.charCodeAt(0).toString(16)}`.slice(-2)}`)
        .join("")
    )
    return JSON.parse(json) as Record<string, unknown>
  } catch {
    return null
  }
}

function randomString(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(32))
  return base64Url(bytes)
}

async function pkceChallenge(verifier: string): Promise<string> {
  const data = new TextEncoder().encode(verifier)
  const digest = await crypto.subtle.digest("SHA-256", data)
  return base64Url(new Uint8Array(digest))
}

function base64Url(bytes: Uint8Array): string {
  return btoa(String.fromCharCode(...bytes))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "")
}
