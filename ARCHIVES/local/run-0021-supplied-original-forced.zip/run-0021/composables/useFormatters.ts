import type { Money } from "~~/shared/types"
import { estimateStatusStyle } from "~~/shared/estimateStatus"

export function useFormatters() {
  const money = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0
  })

  function formatMoney(value: Money): string {
    return money.format(value)
  }

  function formatDate(value: string): string {
    return new Date(value).toLocaleString()
  }

  function formatStatus(value: string): string {
    return estimateStatusStyle(value).label
  }

  return {
    formatDate,
    formatMoney,
    formatStatus
  }
}
