import type { Job } from "~~/shared/types"
import { sortEstimatesByRecent } from "~~/shared/estimateStatus"
import { newDraftJob } from "~~/shared/job"
import { estimateValidationIssues } from "~~/shared/validation"

export type EstimateListItem = {
  id: string
  displayName: string
  address: string
  status: string
  contractKind?: string
  contractLabel?: string
  createdAt: string
  updatedAt: string
}

export type EstimateDashboard = {
  totalJobs: number
  draftJobs: number
  roofProposalJobs: number
  temporaryRepairJobs: number
  proposedJobs: number
  signedJobs: number
  completeJobs: number
  recentJobs: EstimateListItem[]
}

export function useEstimates() {
  const { authHeaders } = useAuth()
  const estimates = useState<Record<string, Job>>("estimate-cache", () => ({}))
  const listItems = useState<EstimateListItem[]>("estimate-list", () => [])
  const dashboard = useState<EstimateDashboard>("estimate-dashboard", emptyDashboard)
  const localDraftIds = useState<string[]>("local-draft-ids", () => [])

  function isLocalDraft(estimateId: string): boolean {
    return localDraftIds.value.includes(estimateId)
  }

  function markDraftPersisted(estimateId: string) {
    localDraftIds.value = localDraftIds.value.filter((id) => id !== estimateId)
  }

  async function refreshEstimates(): Promise<void> {
    const items = await apiFetch<EstimateListItem[]>("/api/jobs")
    listItems.value = sortEstimatesByRecent(items)
  }

  async function refreshDashboard(): Promise<void> {
    dashboard.value = await apiFetch<EstimateDashboard>("/api/jobs/dashboard")
  }

  /** Client-only until the user saves with required fields filled in. */
  async function createDraft(): Promise<Job> {
    const draft = newDraftJob()
    localDraftIds.value = [...localDraftIds.value, draft.id]
    estimates.value = { ...estimates.value, [draft.id]: draft }
    return draft
  }

  function getEstimate(estimateId: string): Ref<Job | undefined> {
    return computed(() => estimates.value[estimateId])
  }

  async function loadEstimate(estimateId: string): Promise<Job | null> {
    if (isLocalDraft(estimateId)) {
      return estimates.value[estimateId] ?? null
    }

    const estimate = await apiFetch<Job>(`/api/jobs/${estimateId}`).catch(() => null)
    if (estimate) {
      estimates.value = { ...estimates.value, [estimate.id]: estimate }
    }
    return estimate
  }

  async function saveEstimate(job: Job): Promise<Job> {
    const issues = estimateValidationIssues(job)
    if (issues.length > 0) {
      throw new Error(issues.map((issue) => issue.message).join(", "))
    }

    const persist = isLocalDraft(job.id)
      ? apiFetch<Job>("/api/jobs", { method: "POST", body: job })
      : apiFetch<Job>(`/api/jobs/${job.id}`, { method: "PUT", body: job })

    const next = await persist
    markDraftPersisted(job.id)
    estimates.value = { ...estimates.value, [next.id]: next }
    await Promise.all([refreshEstimates(), refreshDashboard()])
    return next
  }

  async function removeDraft(estimateId: string): Promise<void> {
    if (isLocalDraft(estimateId)) {
      markDraftPersisted(estimateId)
      const next = { ...estimates.value }
      delete next[estimateId]
      estimates.value = next
      return
    }

    await apiFetch(`/api/jobs/${estimateId}`, { method: "DELETE" })
    markDraftPersisted(estimateId)
    const next = { ...estimates.value }
    delete next[estimateId]
    estimates.value = next
    await Promise.all([refreshEstimates(), refreshDashboard()])
  }

  return {
    dashboard,
    estimates,
    isLocalDraft,
    listItems,
    createDraft,
    getEstimate,
    loadEstimate,
    refreshDashboard,
    refreshEstimates,
    removeDraft,
    saveEstimate
  }

  function apiFetch<T>(url: string, options: Parameters<typeof $fetch<T>>[1] = {}) {
    return $fetch<T>(url, {
      ...options,
      headers: {
        ...authHeaders(),
        ...options?.headers
      }
    })
  }
}

function emptyDashboard(): EstimateDashboard {
  return {
    totalJobs: 0,
    draftJobs: 0,
    roofProposalJobs: 0,
    temporaryRepairJobs: 0,
    proposedJobs: 0,
    signedJobs: 0,
    completeJobs: 0,
    recentJobs: []
  }
}
