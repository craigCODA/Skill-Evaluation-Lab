import type {
  AccountCapability,
  AssignableCustomerAccountRole,
  RoleCapabilityMatrixRow
} from "~~/shared/accountPermissions"
import type { AccountDashboard, CustomerAccount, CustomerAccountRole, SubAccount } from "~~/shared/types"

type CustomerAccountContextResponse = {
  customerAccount: CustomerAccount
  subAccount: SubAccount
  canSeeAllCustomerAccountWork: boolean
  capabilities: AccountCapability[]
  role: CustomerAccountRole
}

type RoleCapabilitiesResponse = {
  capabilities: { id: AccountCapability, label: string }[]
  roles: RoleCapabilityMatrixRow[]
  roleCapabilities: Partial<Record<AssignableCustomerAccountRole, AccountCapability[]>> | null
}

function emptyAccountDashboard(): AccountDashboard {
  return {
    customerAccountId: "",
    customerAccountName: "",
    subAccountId: "",
    canSeeAllCustomerAccountWork: false,
    totalSubAccounts: 0,
    totalCustomers: 0,
    totalEstimates: 0,
    totalContracts: 0,
    draftEstimates: 0,
    signedEstimates: 0,
    completeEstimates: 0
  }
}

export function useAccount() {
  const { authHeaders } = useAuth()
  const accountContext = useState<CustomerAccountContextResponse | null>("customer-account-context", () => null)
  const accountDashboard = useState<AccountDashboard>("customer-account-dashboard", emptyAccountDashboard)
  const subAccounts = useState<SubAccount[]>("customer-account-sub-accounts", () => [])

  const capabilities = computed(() => accountContext.value?.capabilities ?? [])
  const role = computed(() => accountContext.value?.role ?? accountContext.value?.subAccount.role)

  function can(capability: AccountCapability): boolean {
    return capabilities.value.includes(capability)
  }

  async function refreshAccountContext(): Promise<void> {
    accountContext.value = await apiFetch<CustomerAccountContextResponse>("/api/customer-account")
  }

  async function refreshAccountDashboard(): Promise<void> {
    if (accountContext.value && !can("viewAccountStatistics")) {
      accountDashboard.value = emptyAccountDashboard()
      return
    }
    accountDashboard.value = await apiFetch<AccountDashboard>("/api/customer-account/dashboard")
  }

  async function refreshSubAccounts(): Promise<void> {
    if (accountContext.value && !can("manageSubAccounts")) {
      subAccounts.value = accountContext.value.subAccount ? [accountContext.value.subAccount] : []
      return
    }
    subAccounts.value = await apiFetch<SubAccount[]>("/api/customer-account/sub-accounts")
      .catch(() => accountContext.value?.subAccount ? [accountContext.value.subAccount] : [])
  }

  async function saveCurrentUser(input: { name?: string, title?: string }): Promise<SubAccount> {
    const subAccount = await apiFetch<SubAccount>("/api/customer-account/me", {
      method: "PUT",
      body: input
    })
    if (accountContext.value) {
      accountContext.value = { ...accountContext.value, subAccount }
    }
    subAccounts.value = subAccounts.value.map((item) => item.id === subAccount.id ? subAccount : item)
    return subAccount
  }

  async function createSubAccount(input: {
    email: string
    name: string
    password: string
    role: CustomerAccountRole
    title?: string
  }): Promise<SubAccount> {
    const subAccount = await apiFetch<SubAccount>("/api/customer-account/sub-accounts", {
      method: "POST",
      body: input
    })
    subAccounts.value = [...subAccounts.value.filter((item) => item.id !== subAccount.id), subAccount]
    return subAccount
  }

  async function updateSubAccountRole(
    subAccountId: string,
    role: CustomerAccountRole
  ): Promise<SubAccount> {
    const subAccount = await apiFetch<SubAccount>(
      `/api/customer-account/sub-accounts/${encodeURIComponent(subAccountId)}`,
      {
        method: "PATCH",
        body: { role }
      }
    )
    subAccounts.value = subAccounts.value.map((item) => item.id === subAccount.id ? subAccount : item)
    return subAccount
  }

  async function loadRoleCapabilities(): Promise<RoleCapabilitiesResponse> {
    return apiFetch<RoleCapabilitiesResponse>("/api/customer-account/role-capabilities")
  }

  async function saveRoleCapabilities(
    roleCapabilities: Record<AssignableCustomerAccountRole, AccountCapability[]>
  ): Promise<RoleCapabilitiesResponse> {
    const response = await apiFetch<RoleCapabilitiesResponse>("/api/customer-account/role-capabilities", {
      method: "PUT",
      body: roleCapabilities
    })
    await refreshAccountContext()
    return response
  }

  return {
    accountContext,
    accountDashboard,
    subAccounts,
    capabilities,
    role,
    can,
    refreshAccountContext,
    refreshAccountDashboard,
    refreshSubAccounts,
    saveCurrentUser,
    createSubAccount,
    updateSubAccountRole,
    loadRoleCapabilities,
    saveRoleCapabilities
  }

  function apiFetch<T>(url: string, options: Parameters<typeof $fetch<T>>[1] = {}) {
    return $fetch<T>(url, {
      ...options,
      headers: {
        ...authHeaders(),
        ...options?.headers
      }
    })
  }
}
