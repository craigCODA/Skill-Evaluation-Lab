<script setup lang="ts">
import type { Catalog } from "~~/shared/pricebook/types"

const { can, refreshAccountContext } = useAccount()
const { catalog, refreshCatalog, updateCatalogItem } = useCatalog()

await refreshAccountContext()
if (!can("editCatalog")) {
  await navigateTo("/account")
}

await refreshCatalog()

const shingleRows = computed(() =>
  catalog.value.shingles.map((shingle) => ({
    id: shingle.id,
    type: shingle.type,
    manufacturer: shingle.manufacturer,
    variety: shingle.variety,
    pricePerSquare: shingle.pricePerSquare,
    unpriced: shingle.unpriced ?? false,
    colors: shingle.colors.length
  }))
)

const catalogSections = computed(() => [
  { section: "shingles", title: "Shingles", rows: shingleRows.value },
  { section: "warrantyUpcharges", title: "Warranty Upcharges", rows: catalog.value.warrantyUpcharges },
  { section: "storyRates", title: "Story Rates", rows: catalog.value.storyRates },
  { section: "pitchRates", title: "Pitch Rates", rows: catalog.value.pitchRates },
  { section: "tearoffRates", title: "Tearoff Rates", rows: catalog.value.tearoffRates },
  { section: "redeckRates", title: "Redeck Rates", rows: catalog.value.redeckRates },
  { section: "dripEdgeStyles", title: "Drip Edge Styles", rows: catalog.value.dripEdgeStyles },
  { section: "underlayments", title: "Underlayments", rows: catalog.value.underlayments },
  { section: "ridgeRates", title: "Ridge Rates", rows: catalog.value.ridgeRates },
  { section: "flashingRates", title: "Flashing Rates", rows: catalog.value.flashingRates },
  { section: "chimneyRemovalOptions", title: "Chimney Removal", rows: catalog.value.chimneyRemovalOptions },
  { section: "chimneyKitOptions", title: "Chimney Kits", rows: catalog.value.chimneyKitOptions },
  { section: "accessoryRates", title: "Accessories", rows: catalog.value.accessoryRates },
  { section: "satelliteOptions", title: "Satellite", rows: catalog.value.satelliteOptions },
  { section: "antennaOptions", title: "Antenna", rows: catalog.value.antennaOptions },
  { section: "lightningRodOptions", title: "Lightning Rods", rows: catalog.value.lightningRodOptions },
  { section: "skylightOptions", title: "Skylights", rows: catalog.value.skylightOptions },
  { section: "lowSlopeOptions", title: "Low Slope", rows: catalog.value.lowSlopeOptions },
  { section: "valleyMetalRates", title: "Valley Metal", rows: catalog.value.valleyMetalRates },
  { section: "noAccessRates", title: "No Access", rows: catalog.value.noAccessRates },
  { section: "gutterRemovalRates", title: "Gutter Removal", rows: catalog.value.gutterRemovalRates },
  { section: "iceWaterOptions", title: "Ice & Water Options", rows: catalog.value.iceWaterOptions },
  { section: "iceWaterRates", title: "Ice & Water Rates", rows: catalog.value.iceWaterRates },
  { section: "iceWaterOverhangs", title: "Ice & Water Overhangs", rows: catalog.value.iceWaterOverhangs },
  { section: "materialsRates", title: "Materials Rates", rows: catalog.value.materialsRates }
])

async function handleCatalogUpdate(section: string, itemKey: string, patch: Record<string, unknown>) {
  await updateCatalogItem(section as keyof Catalog, itemKey, patch)
}
</script>

<template>
  <div class="page">
    <PageHeader
      eyebrow="Catalog"
      title="Pricing Catalog"
      description="Editable pricing catalog backed by PostgreSQL and shared by the editor and contract generation."
    />

    <CatalogSection
      v-for="section in catalogSections"
      :key="section.title"
      :section="section.section"
      :title="section.title"
      :rows="section.rows"
      @update="handleCatalogUpdate"
    />
  </div>
</template>
