<script setup lang="ts">
import { calcOptions } from "~~/shared/options"

const specs = calcOptions
</script>

<template>
  <div class="page">
    <PageHeader
      eyebrow="Reference"
      title="Calculator Reference"
      description="How each estimator option works: its math, the catalog rates it reads, and what it produces in the contract."
    />

    <section v-for="spec in specs" :key="spec.id" class="card calc-spec">
      <header class="calc-spec-header">
        <h2>{{ spec.title }}</h2>
        <span class="calc-spec-badge" :class="{ unbilled: !spec.billed }">
          {{ spec.billed ? "Billed" : "Not billed" }}
        </span>
      </header>
      <p class="lead">{{ spec.summary }}</p>
      <p class="calc-spec-plain"><strong>In plain terms:</strong> {{ spec.pricingPlain }}</p>
      <p class="calc-spec-plain"><strong>Example:</strong> {{ spec.example }}</p>

      <div class="calc-spec-grid">
        <div>
          <h3>Inputs</h3>
          <ul class="calc-spec-list">
            <li v-for="input in spec.inputs" :key="input.name">
              <strong>{{ input.name }}</strong> — {{ input.description }}
            </li>
          </ul>
        </div>

        <div>
          <h3>Math</h3>
          <pre class="calc-spec-formula">{{ spec.formula }}</pre>
        </div>
      </div>

      <div class="calc-spec-grid">
        <div>
          <h3>Contract effect</h3>
          <p class="muted">{{ spec.contractEffect }}</p>
        </div>
        <div>
          <h3>Catalog tables</h3>
          <p class="muted">{{ spec.catalogTables.join(", ") || "None" }}</p>
        </div>
      </div>

      <p v-if="spec.notes" class="calc-spec-notes muted">
        <strong>Notes:</strong> {{ spec.notes }}
      </p>
    </section>
  </div>
</template>

<style scoped>
.calc-spec {
  margin-bottom: 1.5rem;
}

.calc-spec-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}

.calc-spec-badge {
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  padding: 0.2rem 0.6rem;
  border-radius: 999px;
  background: var(--sf-success);
  color: white;
}

.calc-spec-badge.unbilled {
  background: var(--sf-text-muted);
}

.calc-spec-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
  margin-top: 1rem;
}

@media (max-width: 860px) {
  .calc-spec-header {
    align-items: flex-start;
    flex-direction: column;
  }

  .calc-spec-grid {
    grid-template-columns: 1fr;
  }
}

.calc-spec-list {
  margin: 0;
  padding-left: 1.1rem;
}

.calc-spec-formula {
  white-space: pre-wrap;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.85rem;
  background: color-mix(in oklab, var(--sf-text) 4%, transparent);
  padding: 0.75rem;
  border-radius: 0.5rem;
  margin: 0;
}

.calc-spec-notes {
  margin-top: 1rem;
}
</style>
