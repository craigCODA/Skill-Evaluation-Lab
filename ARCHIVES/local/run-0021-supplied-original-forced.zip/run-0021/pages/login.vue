<script setup lang="ts">
import { APP_LOGO_PATH } from "~~/shared/branding"

definePageMeta({
  layout: false
})

const { isConfigured, login } = useAuth()
</script>

<template>
  <main class="login-screen">
    <aside class="login-showcase" aria-hidden="true">
      <div class="login-showcase-inner">
        <p class="login-showcase-eyebrow">For roofing contractors</p>
        <h1>Estimates, proposals, and contracts in one workspace.</h1>
        <p class="login-showcase-lead">
          Build roof scopes, price the job, and generate customer-ready contracts without
          jumping between spreadsheets and Word docs.
        </p>
        <ul class="login-feature-list">
          <li>Live pricing from your catalog and roof geometry</li>
          <li>Print-ready proposals that match what you priced</li>
          <li>Company branding on every contract you send</li>
        </ul>
      </div>
    </aside>

    <section class="login-panel">
      <div class="login-panel-inner">
        <img
          :src="APP_LOGO_PATH"
          alt="ShingleFile"
          class="login-wordmark"
          width="240"
          height="240"
        >
        <h2>Sign in to your account</h2>
        <p class="login-subtitle">
          Pick up where you left off on estimates, your pricebook, and customer documents.
        </p>

        <p v-if="!isConfigured" class="login-error">
          Sign-in is not configured for this environment yet.
        </p>

        <button
          class="button login-submit"
          type="button"
          :disabled="!isConfigured"
          @click="login"
        >
          Continue to sign in
        </button>

        <p class="login-footnote muted">
          Secure access for your team. Your company profile appears on proposals and contracts.
        </p>
      </div>
    </section>
  </main>
</template>
