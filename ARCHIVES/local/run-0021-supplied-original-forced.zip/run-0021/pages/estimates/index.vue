<script setup lang="ts">
const { createDraft, listItems, refreshEstimates, removeDraft } = useEstimates()

await refreshEstimates()

const estimateStats = computed(() => [
  {
    id: "total",
    label: "Total jobs",
    value: listItems.value.length,
    tone: "blue" as const,
  },
  {
    id: "drafts",
    label: "Drafts",
    value: countByStatus("draft"),
    tone: "tan" as const,
  },
  {
    id: "contracts",
    label: "With contracts",
    value: listItems.value.filter((estimate) => estimate.contractKind).length,
    tone: "green" as const,
  },
  {
    id: "active",
    label: "Active proposals",
    value: countByStatus("roof-proposal") + countByStatus("proposed") + countByStatus("signed"),
    tone: "neutral" as const,
  },
])

async function startEstimate() {
  const draft = await createDraft()
  await navigateTo(`/estimates/${draft.id}`)
}

async function handleRemoveDraft(estimateId: string) {
  if (!window.confirm("Remove this draft? This cannot be undone.")) return
  await removeDraft(estimateId)
}

function countByStatus(status: string): number {
  return listItems.value.filter((estimate) => estimate.status === status).length
}
</script>

<template>
  <div class="page estimates-page">
    <EstimateDashboardHero
      :stats="estimateStats"
      @create="startEstimate"
    />

    <EstimateListSection
      :estimates="listItems"
      @create="startEstimate"
      @remove-draft="handleRemoveDraft"
    />
  </div>
</template>

<style scoped>
.estimates-page {
  display: grid;
  gap: 1rem;
}
</style>
