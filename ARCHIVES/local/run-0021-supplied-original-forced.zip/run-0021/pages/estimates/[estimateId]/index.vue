<script setup lang="ts">
import type { CompanyProfile, CustomerRecord, EstimateType, Job } from "~~/shared/types"
import { APP_NAME } from "~~/shared/branding"
import { formatCustomerName, ensureCustomerInsurance } from "~~/shared/customer"
import { estimateStatusStyle } from "~~/shared/estimateStatus"
import { normalizeRoofingScope } from "~~/shared/roofArea"
import {
  estimateValidationIssues,
  formatUsPhoneInput,
  normalizeUsPhoneNumber,
  type EstimateValidationField,
} from "~~/shared/validation"

const estimateTypeOptions: { value: EstimateType, label: string }[] = [
  { value: "roof-proposal", label: "Roof Proposal" },
  { value: "temporary-repair", label: "Temporary Repair" }
]

const estimateTypeLabels = Object.fromEntries(
  estimateTypeOptions.map((option) => [option.value, option.label])
) as Record<EstimateType, string>

const estimateTradeTabs = [
  { key: "roofing", label: "Roofing" },
  { key: "gutters", label: "Gutters" },
  { key: "siding", label: "Siding" }
] as const

const route = useRoute("estimates-estimateId")
const estimateId = computed(() => String(route.params.estimateId))
const { isAdmin } = useAuth()
const { profile, refreshCompanyProfile } = useCompanyProfile()
const { getPlatformProfile } = useAdminUsers()
const { catalog, refreshCatalog } = useCatalog()
const { getEstimate, loadEstimate, saveEstimate, isLocalDraft } = useEstimates()
const { customers, refreshCustomers } = useCustomers()
await loadEstimate(estimateId.value)
await Promise.all([
  refreshCustomers().catch(() => undefined),
  refreshCatalog().catch(() => undefined)
])
const sourceEstimate = getEstimate(estimateId.value)
const draft = ref<Job | null>(hydrateDraft(sourceEstimate.value))
const { totals } = useEstimateTotals(computed(() => draft.value ?? undefined))
const selectedEstimateType = computed({
  get: () => draft.value?.estimateType ?? "",
  set: (value: EstimateType | "") => {
    if (!draft.value) return
    draft.value.estimateType = value || undefined
  }
})
const estimateTitle = computed(() => {
  const title = customerTitle.value
  if (!draft.value?.estimateType) return title
  return `${estimateTypeLabels[draft.value.estimateType]}: ${title}`
})
const customerTitle = computed(() => {
  const customer = draft.value?.customer
  if (!customer) return "Draft Job"
  const contactName = [customer.firstName?.trim(), customer.lastName?.trim()].filter(Boolean).join(" ")
  return customer.companyName?.trim() || contactName || "Draft Job"
})
const statusLine = computed(() => {
  if (!draft.value) return ""
  return `Status: ${formatStatus(draft.value.status)} · Created ${new Date(draft.value.createdAt).toLocaleString()}`
})
const isRoofProposal = computed(() => draft.value?.estimateType === "roof-proposal")
const isTemporaryRepair = computed(() => draft.value?.estimateType === "temporary-repair")
const activeEstimateTrade = ref<(typeof estimateTradeTabs)[number]["key"]>("roofing")
const activeEstimateTradeLabel = computed(() =>
  estimateTradeTabs.find((tab) => tab.key === activeEstimateTrade.value)?.label ?? "Roofing"
)
const contractsHref = computed(() => `/estimates/${estimateId.value}/contracts`)
const branding = ref<CompanyProfile | null>(null)

if (isAdmin.value) {
  branding.value = await getPlatformProfile()
} else {
  await refreshCompanyProfile()
  branding.value = profile.value
}

const contractorCompanyName = computed(() =>
  branding.value?.companyName?.trim()
  || branding.value?.legalName?.trim()
  || APP_NAME
)

const grandTotalSummary = computed(() => {
  if (!draft.value) return ""
  const status = estimateStatusStyle(draft.value.status).label
  const salesman = draft.value.estimator?.trim() || "unspecified"
  const companyName = contractorCompanyName.value
  const customer = formatCustomerInfo(draft.value)
  const date = new Date(draft.value.updatedAt).toLocaleDateString()
  return `This is a ${status} done by ${salesman} at ${companyName} for ${customer} on ${date}.`
})
const isSaving = ref(false)
const saveStatus = ref(
  isLocalDraft(estimateId.value) ? "Not saved — fill required fields" : "Saved"
)

watch(sourceEstimate, (next) => {
  draft.value = hydrateDraft(next)
})

const validationIssues = computed(() => (draft.value ? estimateValidationIssues(draft.value) : []))
const canSave = computed(() => validationIssues.value.length === 0)
const validationSummary = computed(() => validationIssues.value.map((issue) => issue.message).join(", "))
const sectionNavOpen = ref(false)

function closeSectionNav() {
  sectionNavOpen.value = false
}

async function save() {
  if (!draft.value) return
  if (validationIssues.value.length > 0) {
    saveStatus.value = validationIssues.value.map((issue) => issue.message).join(", ")
    return
  }
  draft.value.customer.phone = normalizeUsPhoneNumber(draft.value.customer.phone)
  isSaving.value = true
  saveStatus.value = "Saving..."
  try {
    if (draft.value.status === "draft" && draft.value.estimateType) {
      draft.value.status = draft.value.estimateType
    }
    await saveEstimate(draft.value)
    saveStatus.value = "Saved"
  } catch (error) {
    saveStatus.value = error instanceof Error ? error.message : "Save failed"
  } finally {
    isSaving.value = false
  }
}

function cloneJob(job: Job): Job {
  return JSON.parse(JSON.stringify(job)) as Job
}

function hydrateDraft(job: Job | undefined | null): Job | null {
  if (!job) return null
  const next = cloneJob(job)
  if (!next.estimateType && (next.status === "roof-proposal" || next.status === "temporary-repair")) {
    next.estimateType = next.status
  }
  if (next.scope.roofing) {
    next.scope.roofing = normalizeRoofingScope(next.scope.roofing)
  }
  ensureCustomerInsurance(next.customer)
  return next
}

function formatStatus(status: string) {
  if (status in estimateTypeLabels) return estimateTypeLabels[status as EstimateType]
  return status.replace("-", " ")
}

function formatCustomerInfo(job: Job): string {
  const name = formatCustomerName(job.customer)
  const cityState = [job.customer.city?.trim(), job.customer.state?.trim()]
    .filter(Boolean)
    .join(", ")
  return cityState ? `${name} in ${cityState}` : name
}

function customerFieldIssue(field: EstimateValidationField): string {
  return validationIssues.value.find((issue) => issue.field === field)?.message ?? ""
}

function hasCustomerFieldIssue(field: EstimateValidationField): boolean {
  return customerFieldIssue(field) !== ""
}

function formatCustomerPhone() {
  if (!draft.value) return
  draft.value.customer.phone = formatUsPhoneInput(draft.value.customer.phone)
}

function normalizeCustomerPhone() {
  if (!draft.value) return
  draft.value.customer.phone = normalizeUsPhoneNumber(draft.value.customer.phone) || draft.value.customer.phone
}

function formatCustomerZip() {
  if (!draft.value) return
  draft.value.customer.zip = draft.value.customer.zip.replace(/\D/g, "").slice(0, 5)
}

function selectExistingCustomer(customerId: string) {
  if (!draft.value || !customerId) return
  const customerRecord = customers.value.find((customer) => customer.id === customerId)
  if (!customerRecord) return
  draft.value.customerId = customerRecord.id
  draft.value.customer = {
    ...customerRecord.customer,
    id: customerRecord.id
  }
  ensureCustomerInsurance(draft.value.customer)
}

function handleExistingCustomerChange(event: Event) {
  selectExistingCustomer((event.target as HTMLSelectElement).value)
}

function customerOptionLabel(customer: CustomerRecord) {
  const address = customer.address ? ` - ${customer.address}` : ""
  return `${formatCustomerName(customer.customer)}${address}`
}
</script>

<template>
  <div class="estimate-v2-page">
    <section v-if="!draft" class="card v2-card">
      <h2>Estimate not found</h2>
      <p class="v2-muted">Choose an existing estimate or create a new draft.</p>
      <NuxtLink class="button" to="/estimates">Back to estimates</NuxtLink>
    </section>

    <template v-else>
      <div class="v2-breadcrumb">
        <NuxtLink to="/estimates">Estimates</NuxtLink> / <span>{{ estimateId.slice(0, 8) }}</span>
      </div>
      <h1>{{ estimateTitle }}</h1>
      <p class="v2-muted">{{ statusLine }}</p>

      <div class="v2-header-field">
        <label class="field">
          <span>Company Contact <EstimateHelp label="Company Contact" /></span>
          <input v-model="draft.estimator" class="input">
        </label>
      </div>

      <div class="v2-section-nav-wrap">
        <button
          type="button"
          class="v2-section-nav-toggle"
          :aria-expanded="sectionNavOpen"
          @click="sectionNavOpen = !sectionNavOpen"
        >
          Jump to section
          <span aria-hidden="true">{{ sectionNavOpen ? "▴" : "▾" }}</span>
        </button>
        <nav
          class="v2-section-nav"
          :class="{ 'is-open': sectionNavOpen }"
          aria-label="Estimate sections"
        >
          <a href="#estimate-info" @click="closeSectionNav">Estimate info</a>
          <a v-if="isRoofProposal && activeEstimateTrade === 'roofing'" href="#roof-areas" @click="closeSectionNav">Roof areas</a>
          <a v-if="isRoofProposal && activeEstimateTrade === 'roofing'" href="#roofing-addons" @click="closeSectionNav">Add-ons</a>
          <a v-if="isRoofProposal && activeEstimateTrade === 'roofing'" href="#permit-extras" @click="closeSectionNav">Permit &amp; extras</a>
          <a v-if="isRoofProposal && activeEstimateTrade === 'roofing'" href="#materials" @click="closeSectionNav">Materials</a>
          <a v-if="isTemporaryRepair" href="#temporary-repair" @click="closeSectionNav">Temporary repair</a>
          <a v-if="isRoofProposal && activeEstimateTrade === 'roofing'" href="#review-total" @click="closeSectionNav">Review total</a>
          <NuxtLink
            v-if="draft.estimateType && (!isRoofProposal || activeEstimateTrade === 'roofing')"
            :to="contractsHref"
            @click="closeSectionNav"
          >
            Open contracts
          </NuxtLink>
        </nav>
      </div>

      <section id="estimate-info" class="card v2-card v2-section-customer">
        <h2>{{ draft.estimateType ? "Customer Information" : "New Estimate" }}</h2>
        <div class="form-grid">
          <label class="field">
            <span>Estimate type <span class="req" aria-hidden="true">*</span> <EstimateHelp label="Estimate type" /></span>
            <select
              v-model="selectedEstimateType"
              class="input"
              :class="{ 'is-invalid': hasCustomerFieldIssue('Estimate type') }"
              :aria-invalid="hasCustomerFieldIssue('Estimate type')"
              required
            >
              <option value="">Select estimate type...</option>
              <option
                v-for="option in estimateTypeOptions"
                :key="option.value"
                :value="option.value"
              >
                {{ option.label }}
              </option>
            </select>
            <small v-if="hasCustomerFieldIssue('Estimate type')" class="field-error">
              {{ customerFieldIssue("Estimate type") }}
            </small>
          </label>

          <template v-if="draft.estimateType">
            <label class="field form-grid-wide">
              <span>Existing customer</span>
              <select
                class="input"
                :value="draft.customerId || draft.customer.id"
                @change="handleExistingCustomerChange"
              >
                <option value="">Create from customer information below</option>
                <option
                  v-for="customer in customers"
                  :key="customer.id"
                  :value="customer.id"
                >
                  {{ customerOptionLabel(customer) }}
                </option>
              </select>
            </label>

            <label class="field">
              <span>Company name <EstimateHelp label="Company name" /></span>
              <input v-model="draft.customer.companyName" class="input">
            </label>
            <label class="field">
              <span>First name <span class="req" aria-hidden="true">*</span> <EstimateHelp label="First name" /></span>
              <input
                v-model="draft.customer.firstName"
                class="input"
                :class="{ 'is-invalid': hasCustomerFieldIssue('First name') }"
                :aria-invalid="hasCustomerFieldIssue('First name')"
                required
              >
              <small v-if="hasCustomerFieldIssue('First name')" class="field-error">
                {{ customerFieldIssue("First name") }}
              </small>
            </label>
            <label class="field">
              <span>Last name <span class="req" aria-hidden="true">*</span> <EstimateHelp label="Last name" /></span>
              <input
                v-model="draft.customer.lastName"
                class="input"
                :class="{ 'is-invalid': hasCustomerFieldIssue('Last name') }"
                :aria-invalid="hasCustomerFieldIssue('Last name')"
                required
              >
              <small v-if="hasCustomerFieldIssue('Last name')" class="field-error">
                {{ customerFieldIssue("Last name") }}
              </small>
            </label>
            <label class="field">
              <span>Phone <span class="req" aria-hidden="true">*</span> <EstimateHelp label="Phone" /></span>
              <input
                v-model="draft.customer.phone"
                class="input"
                :class="{ 'is-invalid': hasCustomerFieldIssue('Phone') }"
                :aria-invalid="hasCustomerFieldIssue('Phone')"
                placeholder="+1-555-123-4567"
                type="tel"
                required
                @input="formatCustomerPhone"
                @blur="normalizeCustomerPhone"
              >
              <small v-if="hasCustomerFieldIssue('Phone')" class="field-error">
                {{ customerFieldIssue("Phone") }}
              </small>
            </label>
            <label class="field">
              <span>Email <EstimateHelp label="Email" /></span>
              <input
                v-model="draft.customer.email"
                class="input"
                :class="{ 'is-invalid': hasCustomerFieldIssue('Email') }"
                :aria-invalid="hasCustomerFieldIssue('Email')"
                type="email"
                placeholder="name@example.com"
              >
              <small v-if="hasCustomerFieldIssue('Email')" class="field-error">
                {{ customerFieldIssue("Email") }}
              </small>
            </label>
            <label class="field">
              <span>Address 1 <EstimateHelp label="Address" /></span>
              <input v-model="draft.customer.address1" class="input">
            </label>
            <label class="field">
              <span>Address 2 <EstimateHelp label="Address 2" /></span>
              <input v-model="draft.customer.address2" class="input">
            </label>
            <label class="field">
              <span>City <EstimateHelp label="City" /></span>
              <input v-model="draft.customer.city" class="input">
            </label>
            <label class="field">
              <span>State <EstimateHelp label="State" /></span>
              <select v-model="draft.customer.state" class="input">
                <option value="IA">Iowa</option>
                <option value="LA">Louisiana</option>
              </select>
            </label>
            <label class="field">
              <span>ZIP <EstimateHelp label="Zip" /></span>
              <input
                v-model="draft.customer.zip"
                class="input"
                :class="{ 'is-invalid': hasCustomerFieldIssue('ZIP') }"
                :aria-invalid="hasCustomerFieldIssue('ZIP')"
                inputmode="numeric"
                maxlength="5"
                @input="formatCustomerZip"
              >
              <small v-if="hasCustomerFieldIssue('ZIP')" class="field-error">
                {{ customerFieldIssue("ZIP") }}
              </small>
            </label>
          </template>
        </div>

        <div v-if="isRoofProposal && draft.estimateType" class="v2-customer-insurance">
          <h3 class="v2-subhead">Insurance</h3>
          <div class="form-grid">
            <label class="field">
              <span>Insurance company <EstimateHelp label="Insurance company" /></span>
              <input v-model="draft.customer.insurance!.company" class="input" type="text">
            </label>
            <label class="field">
              <span>Claim number <EstimateHelp label="Claim number" /></span>
              <input v-model="draft.customer.insurance!.claimNumber" class="input" type="text">
            </label>
            <label class="field">
              <span>Insurance contact <EstimateHelp label="Insurance contact" /></span>
              <input v-model="draft.customer.insurance!.contact" class="input" type="text" placeholder="Name and phone">
            </label>
          </div>
        </div>

        <p v-if="!draft.estimateType" class="v2-note">
          Choose the estimate type first. Customer information and the related questions will appear after a type is selected.
        </p>
        <div v-if="draft.estimateType" class="v2-actions">
          <button class="button" type="button" :disabled="isSaving || !canSave" @click="save">
            {{ isSaving ? "Saving..." : "Save customer info" }}
          </button>
          <span v-if="!canSave" class="v2-save-status">{{ validationSummary }}</span>
          <span v-else class="v2-save-status">{{ saveStatus }}</span>
        </div>
      </section>

      <template v-if="isRoofProposal">
        <section class="card v2-card v2-section-product v2-trade-switcher">
          <div class="v2-product-tabs" role="tablist" aria-label="Estimate category">
            <button
              v-for="tab in estimateTradeTabs"
              :key="tab.key"
              class="v2-product-tab"
              :class="{ 'is-active': activeEstimateTrade === tab.key }"
              type="button"
              role="tab"
              :aria-selected="activeEstimateTrade === tab.key"
              @click="activeEstimateTrade = tab.key"
            >
              {{ tab.label }}
            </button>
          </div>
        </section>

        <template v-if="activeEstimateTrade === 'roofing'">
          <div id="roof-areas" class="v2-anchor" />
          <RoofingScopeForm
            v-if="draft.scope.roofing"
            v-model="draft.scope.roofing"
            :catalog="catalog"
            :totals="totals"
          />

          <section id="permit-extras" class="card v2-card v2-section-permit">
            <h2>Permit &amp; extras</h2>
            <div class="form-grid estimate-details-grid">
              <label class="field">
                <span>Permit ($) <EstimateHelp label="Permit" /></span>
                <input v-model.number="draft.permit" class="input" type="number" min="0">
              </label>
              <label class="field">
                <span>Extra ($) <EstimateHelp label="Extras" /></span>
                <input v-model.number="draft.extras.amount" class="input" type="number" min="0">
              </label>
              <label class="field">
                <span>Extra description <EstimateHelp label="Extras description" /></span>
                <input v-model="draft.extras.description" class="input" type="text">
              </label>
            </div>
          </section>

          <section id="materials" class="card v2-card v2-section-addon">
            <h2>Materials take-off</h2>
            <p class="v2-note">
              Order list derived from the geometry above. Updates live in the contract preview and is not part of the customer total.
            </p>
          </section>

          <section id="review-total" class="card v2-card v2-section-total">
            <h2>Grand total</h2>
            <EstimateSummaryCard :totals="totals" />
            <p class="v2-grand-total-summary">{{ grandTotalSummary }}</p>
            <div class="v2-actions v2-actions-split">
              <div class="v2-action-group">
                <button class="button" type="button" :disabled="isSaving || !canSave" @click="save">
                  {{ isSaving ? "Saving..." : "Save" }}
                </button>
                <span v-if="!canSave" class="v2-save-status">{{ validationSummary }}</span>
                <span v-else class="v2-save-status">{{ saveStatus }}</span>
              </div>
              <NuxtLink v-if="draft.estimateType" class="button secondary" :to="contractsHref">
                Generate Contract(s)
              </NuxtLink>
            </div>
          </section>
        </template>

        <section v-else class="card v2-card v2-section-product v2-trade-placeholder">
          <h2>{{ activeEstimateTradeLabel }} estimate mockup</h2>
          <p class="v2-note">
            {{ activeEstimateTradeLabel }} estimating will be built out later. For now this tab confirms the roof workflow stays isolated to Roofing.
          </p>
        </section>
      </template>

      <section v-if="isTemporaryRepair" id="temporary-repair" class="card v2-card">
        <h2>Temporary Repair</h2>
        <p class="v2-muted">
          Enter the temporary repair description and charge, then save to turn this draft into a Temporary Repair.
        </p>
        <div class="form-grid">
          <label class="field">
            <span>Extra description <EstimateHelp label="Extras description" /></span>
            <input v-model="draft.extras.description" class="input" type="text">
          </label>
          <label class="field">
            <span>Extra ($) <EstimateHelp label="Extras" /></span>
            <input v-model.number="draft.extras.amount" class="input" type="number" min="0">
          </label>
        </div>
        <div class="v2-actions">
          <button class="button" type="button" :disabled="isSaving || !canSave" @click="save">
            {{ isSaving ? "Saving..." : "Save" }}
          </button>
          <span v-if="!canSave" class="v2-save-status">{{ validationSummary }}</span>
          <span v-else class="v2-save-status">{{ saveStatus }}</span>
        </div>
      </section>

    </template>
  </div>
</template>
