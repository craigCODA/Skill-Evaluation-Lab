<script setup lang="ts">
import type { ContractDocument, ContractLine, ContractSection } from "~~/shared/contracts/types"

const route = useRoute("estimates-estimateId-contracts-contractKind")
const estimateId = computed(() => String(route.params.estimateId))
const contractKind = computed(() => String(route.params.contractKind))
const { authHeaders } = useAuth()
const { formatMoney } = useFormatters()
const loadError = ref("")
const documents = ref<ContractDocument[]>([])

try {
  documents.value = await $fetch<ContractDocument[]>(`/api/jobs/${estimateId.value}/contracts`, {
    headers: authHeaders()
  })
  if (documents.value.length === 0) {
    loadError.value = "No contracts were returned for this estimate."
  }
} catch (error) {
  loadError.value = error instanceof Error ? error.message : "Contracts could not be loaded."
}

const document = computed(() => {
  return documents.value.find((item) => item.kind === contractKind.value) ?? documents.value[0] ?? null
})

const isContract = computed(() => document.value?.kind === "roof-proposal")

function printContract() {
  window.print()
}

function firstHeaderValue(lines: ContractLine[], label: string) {
  return lines.find((line) => line.label === label)?.value?.trim() ?? ""
}

function visibleLines(lines: string[]) {
  return lines.filter((line) => line.trim() !== "")
}

function hasStructuredValue(line: ContractLine) {
  return line.amount !== undefined || Boolean(line.value?.trim())
}

function isParagraphLine(line: ContractLine) {
  return !hasStructuredValue(line) && line.label.trim() !== ""
}

function isSpecLine(section: ContractSection, line: ContractLine) {
  return section.kind !== "pricing"
    && section.kind !== "signatures"
    && section.kind !== "bullets"
    && hasStructuredValue(line)
}

function isBulletLine(line: ContractLine) {
  return line.label.trim() !== ""
}

function companyName(doc: ContractDocument) {
  return doc.meta?.companyName || firstHeaderValue(doc.header, "Company") || "Contractor"
}

</script>

<template>
  <div class="page" :class="{ 'contract-shell': isContract }">
    <PageHeader
      eyebrow="Preview"
      :title="document?.title ?? 'Contract Not Found'"
      :description="isContract ? 'Print-ready roofing contract generated from this estimate.' : 'Document preview.'"
    >
      <template #actions>
        <button class="button" type="button" @click="printContract">
          Print
        </button>
        <NuxtLink class="button secondary" :to="`/estimates/${estimateId}/contracts`">
          Back to contracts
        </NuxtLink>
      </template>
    </PageHeader>

    <section v-if="loadError" class="card">
      <h2>Contracts unavailable</h2>
      <p class="muted">{{ loadError }}</p>
    </section>

    <section v-else class="card contract-tabs">
      <NuxtLink
        v-for="item in documents"
        :key="item.kind"
        class="button"
        :class="{ secondary: item.kind !== document?.kind }"
        :to="`/estimates/${estimateId}/contracts/${item.kind}`"
      >
        {{ item.title }}
      </NuxtLink>
    </section>

    <article
      v-if="document"
      class="card contract-preview-document"
      :class="{ 'contract-document': isContract }"
    >
      <header class="contract-letterhead" v-if="isContract">
        <div class="contract-brand">
          <BrandLogo
            :src="document.meta?.logoUrl"
            :alt="`${companyName(document)} logo`"
            size="md"
          />
          <div>
            <div class="contract-company-name">{{ companyName(document) }}</div>
            <div class="contract-company-meta">
              <div v-if="firstHeaderValue(document.header, 'Office')">
                {{ firstHeaderValue(document.header, "Office") }}
              </div>
              <div v-if="firstHeaderValue(document.header, 'Phone')">
                Phone: {{ firstHeaderValue(document.header, "Phone") }}
              </div>
              <div v-if="document.meta?.supportEmail">
                {{ document.meta.supportEmail }}
              </div>
            </div>
          </div>
        </div>
        <div class="contract-doc-meta">
          <div class="contract-doc-title">{{ document.title }}</div>
          <div class="contract-doc-date">
            Date: {{ document.meta?.documentDate || firstHeaderValue(document.header, "Date") || new Date().toLocaleDateString() }}
          </div>
          <div v-if="document.meta?.license" class="contract-doc-license">
            License: {{ document.meta.license }}
          </div>
          <div v-if="firstHeaderValue(document.header, 'Estimator')" class="contract-doc-license">
            Estimator: {{ firstHeaderValue(document.header, "Estimator") }}
          </div>
        </div>
      </header>

      <header v-else class="contract-preview-letterhead">
        <div>
          <div class="contract-preview-company">{{ companyName(document) }}</div>
          <div class="muted">
            {{ firstHeaderValue(document.header, "Office") || firstHeaderValue(document.header, "Company") }}
          </div>
          <div class="muted">{{ firstHeaderValue(document.header, "Phone") }}</div>
        </div>
        <div class="contract-preview-doc-meta">
          <div class="contract-preview-doc-title">{{ document.title }}</div>
          <div>{{ firstHeaderValue(document.header, "Date") || new Date().toLocaleDateString() }}</div>
        </div>
      </header>

      <section :class="isContract ? 'contract-parties' : 'contract-preview-parties'">
        <div :class="isContract ? 'contract-party-block' : ''">
          <h2 v-if="!isContract">Customer</h2>
          <h3 v-else>Owner / Customer</h3>
          <p v-for="line in visibleLines([
            firstHeaderValue(document.header, 'Name'),
            firstHeaderValue(document.header, 'Street'),
            firstHeaderValue(document.header, 'City & State'),
            firstHeaderValue(document.header, 'Customer Phone') ? `Phone: ${firstHeaderValue(document.header, 'Customer Phone')}` : ''
          ])" :key="line">
            {{ line }}
          </p>
        </div>
        <div :class="isContract ? 'contract-party-block' : ''">
          <h2 v-if="!isContract">Project</h2>
          <h3 v-else>Job Site</h3>
          <p v-for="line in visibleLines([
            firstHeaderValue(document.header, 'Job Street'),
            firstHeaderValue(document.header, 'Job City & State')
          ])" :key="line">
            {{ line }}
          </p>
        </div>
      </section>

      <section
        v-for="section in document.sections"
        :key="section.title"
        :class="isContract ? 'contract-section' : 'contract-preview-section'"
      >
        <h2>{{ section.title }}</h2>

        <div v-if="section.kind === 'signatures'" :class="isContract ? 'contract-signatures' : 'contract-preview-signatures'">
          <div
            v-for="line in section.lines"
            :key="line.label"
            :class="isContract ? 'contract-signature-line' : 'contract-preview-signature-line'"
          >
            <div class="signature-pad" aria-hidden="true" />
            <div class="signature-rule" aria-hidden="true" />
            <span class="signature-label">{{ line.label }}</span>
          </div>
        </div>

        <div v-else-if="section.kind === 'pricing'" class="contract-pricing-table">
          <div
            v-for="line in section.lines"
            :key="line.label"
            class="contract-pricing-row"
            :class="{ 'has-detail': Boolean(line.value?.trim()) }"
          >
            <span class="contract-pricing-label">{{ line.label }}</span>
            <span v-if="line.value?.trim()" class="contract-pricing-detail">{{ line.value }}</span>
            <strong v-if="line.amount !== undefined" class="contract-pricing-amount">
              {{ formatMoney(line.amount) }}
            </strong>
          </div>
        </div>

        <ul
          v-else-if="section.kind === 'bullets'"
          :class="isContract ? 'contract-bullet-list' : 'contract-preview-bullet-list'"
        >
          <li
            v-for="line in section.lines.filter(isBulletLine)"
            :key="line.label"
          >
            {{ line.label }}
          </li>
        </ul>

        <template v-else>
          <p
            v-for="line in section.lines.filter(isParagraphLine)"
            :key="`p-${line.label}`"
            :class="{ 'contract-paragraph': isContract }"
          >
            <template v-if="line.amount !== undefined">
              {{ line.label }}
              <strong>{{ formatMoney(line.amount) }}</strong>
            </template>
            <template v-else>
              {{ line.label }}
            </template>
          </p>

          <div
            v-for="line in section.lines.filter((item) => isSpecLine(section, item))"
            :key="`spec-${line.label}`"
            :class="isContract ? 'contract-spec-row' : 'summary-row'"
          >
            <span :class="isContract ? 'contract-spec-label' : ''">{{ line.label }}</span>
            <span>{{ line.amount !== undefined ? formatMoney(line.amount) : line.value }}</span>
          </div>
        </template>
      </section>

      <div
        v-if="document.total !== undefined"
        :class="isContract ? 'contract-total-row' : 'summary-row total'"
      >
        <span>Contract Total</span>
        <strong>{{ formatMoney(document.total) }}</strong>
      </div>
    </article>
  </div>
</template>
