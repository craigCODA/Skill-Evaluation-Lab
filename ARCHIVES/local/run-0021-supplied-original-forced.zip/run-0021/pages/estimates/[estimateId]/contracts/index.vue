<script setup lang="ts">
import {
  CONTRACT_RECIPE_LABELS,
  type ContractRecipeKind,
  type JobContractBundle,
  type JobContractSnapshot
} from "~~/shared/contracts/modules"

const route = useRoute("estimates-estimateId-contracts")
const estimateId = computed(() => String(route.params.estimateId))
const {
  loadJobContract,
  regenerateJobContract,
  markJobContractSigned,
  uploadSignedPdf,
  downloadSignedPdf
} = useContractSetup()

const loadError = ref("")
const status = ref("")
const isBusy = ref(false)
const bundle = ref<JobContractBundle>({
  roofing: { unsigned: null, signed: null },
  gutters: { unsigned: null, signed: null },
  siding: { unsigned: null, signed: null }
})
const activeRecipeKinds = ref<ContractRecipeKind[]>(["roofing"])
const recipeKind = ref<ContractRecipeKind>("roofing")
const activeTab = ref<"unsigned" | "signed">("unsigned")
const fileInput = ref<HTMLInputElement | null>(null)

async function refresh() {
  const response = await loadJobContract(estimateId.value)
  bundle.value = response.bundle
  activeRecipeKinds.value = response.activeRecipeKinds
  if (!activeRecipeKinds.value.includes(recipeKind.value)) {
    recipeKind.value = activeRecipeKinds.value[0] ?? "roofing"
  }
}

function pairFor(kind: ContractRecipeKind) {
  return bundle.value[kind]
}

const unsigned = computed(() => pairFor(recipeKind.value).unsigned)
const signed = computed(() => pairFor(recipeKind.value).signed)
const activeContract = computed(() =>
  activeTab.value === "signed" ? signed.value : unsigned.value
)

try {
  await refresh()
  if (!unsigned.value && recipeKind.value === "roofing") {
    const snapshot = await regenerateJobContract(estimateId.value, recipeKind.value)
    bundle.value = {
      ...bundle.value,
      [recipeKind.value]: {
        ...pairFor(recipeKind.value),
        unsigned: snapshot
      }
    }
  }
} catch (error) {
  loadError.value = error instanceof Error ? error.message : "Contracts could not be loaded."
}

watch(recipeKind, () => {
  activeTab.value = unsigned.value ? "unsigned" : signed.value ? "signed" : "unsigned"
})

function printContract() {
  window.print()
}

async function regenerate() {
  isBusy.value = true
  status.value = `Regenerating ${CONTRACT_RECIPE_LABELS[recipeKind.value].toLowerCase()} contract...`
  try {
    const snapshot = await regenerateJobContract(estimateId.value, recipeKind.value)
    bundle.value = {
      ...bundle.value,
      [recipeKind.value]: {
        ...pairFor(recipeKind.value),
        unsigned: snapshot
      }
    }
    activeTab.value = "unsigned"
    status.value = "Unsigned contract regenerated."
  } catch (error) {
    status.value = error instanceof Error ? error.message : "Could not regenerate contract"
  } finally {
    isBusy.value = false
  }
}

async function markSigned() {
  if (!window.confirm("Mark the current unsigned contract as the last signed copy for this trade?")) {
    return
  }
  isBusy.value = true
  status.value = "Saving signed copy..."
  try {
    const snapshot = await markJobContractSigned(estimateId.value, recipeKind.value)
    bundle.value = {
      ...bundle.value,
      [recipeKind.value]: {
        ...pairFor(recipeKind.value),
        signed: snapshot
      }
    }
    activeTab.value = "signed"
    status.value = "Signed copy saved."
  } catch (error) {
    status.value = error instanceof Error ? error.message : "Could not mark contract signed"
  } finally {
    isBusy.value = false
  }
}

function openPdfPicker() {
  fileInput.value?.click()
}

async function onPdfSelected(event: Event) {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  input.value = ""
  if (!file) return
  if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) {
    status.value = "Please choose a PDF file."
    return
  }

  isBusy.value = true
  status.value = "Uploading signed PDF..."
  try {
    const dataUrl = await readFileAsDataUrl(file)
    const snapshot = await uploadSignedPdf(estimateId.value, {
      recipeKind: recipeKind.value,
      fileName: file.name,
      dataUrl
    })
    bundle.value = {
      ...bundle.value,
      [recipeKind.value]: {
        ...pairFor(recipeKind.value),
        signed: snapshot
      }
    }
    activeTab.value = "signed"
    status.value = `Uploaded ${file.name}.`
  } catch (error) {
    status.value = error instanceof Error ? error.message : "Could not upload signed PDF"
  } finally {
    isBusy.value = false
  }
}

async function downloadPdf() {
  isBusy.value = true
  status.value = "Preparing download..."
  try {
    const response = await downloadSignedPdf(estimateId.value, recipeKind.value)
    const link = document.createElement("a")
    link.href = response.dataUrl
    link.download = response.snapshot.signedPdf?.fileName || "signed-contract.pdf"
    link.click()
    status.value = "Download started."
  } catch (error) {
    status.value = error instanceof Error ? error.message : "Could not download signed PDF"
  } finally {
    isBusy.value = false
  }
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result || ""))
    reader.onerror = () => reject(new Error("Could not read file"))
    reader.readAsDataURL(file)
  })
}
</script>

<template>
  <div class="page contracts-page">
    <PageHeader
      eyebrow="Estimate"
      :title="`${CONTRACT_RECIPE_LABELS[recipeKind]} contract`"
      description="Composed from your company modules. Regenerate to refresh from the estimate. Upload the wet-ink signed PDF on the signed tab."
    >
      <template #actions>
        <button class="button" type="button" :disabled="isBusy || !activeContract" @click="printContract">
          Print / PDF
        </button>
        <button class="button secondary" type="button" :disabled="isBusy" @click="regenerate">
          Regenerate
        </button>
        <button class="button secondary" type="button" :disabled="isBusy || !unsigned" @click="markSigned">
          Mark signed
        </button>
        <NuxtLink class="button secondary" :to="`/estimates/${estimateId}`">
          Back to estimate
        </NuxtLink>
      </template>
    </PageHeader>

    <section v-if="loadError" class="contracts-empty">
      <h2>Contract unavailable</h2>
      <p class="muted">{{ loadError }}</p>
    </section>

    <template v-else>
      <section class="contract-tabs no-print">
        <button
          v-for="kind in activeRecipeKinds"
          :key="kind"
          class="button"
          type="button"
          :class="{ secondary: recipeKind !== kind }"
          @click="recipeKind = kind"
        >
          {{ CONTRACT_RECIPE_LABELS[kind] }}
        </button>
      </section>

      <section class="contract-tabs no-print">
        <button
          class="button"
          type="button"
          :class="{ secondary: activeTab !== 'unsigned' }"
          :disabled="!unsigned"
          @click="activeTab = 'unsigned'"
        >
          Unsigned draft
        </button>
        <button
          class="button"
          type="button"
          :class="{ secondary: activeTab !== 'signed' }"
          :disabled="!signed"
          @click="activeTab = 'signed'"
        >
          Last signed
        </button>
      </section>

      <section v-if="activeTab === 'signed'" class="signed-pdf-panel no-print card">
        <div>
          <h2>Signed PDF</h2>
          <p class="muted">
            Upload the customer-signed wet-ink scan. This stays with the last signed snapshot for CRM.
          </p>
          <p v-if="signed?.signedPdf" class="signed-pdf-meta">
            Current file: {{ signed.signedPdf.fileName }}
            ({{ Math.round(signed.signedPdf.size / 1024) }} KB)
          </p>
        </div>
        <div class="signed-pdf-actions">
          <input
            ref="fileInput"
            class="sr-only"
            type="file"
            accept="application/pdf,.pdf"
            @change="onPdfSelected"
          >
          <button class="button" type="button" :disabled="isBusy" @click="openPdfPicker">
            {{ signed?.signedPdf ? "Replace PDF" : "Upload signed PDF" }}
          </button>
          <button
            class="button secondary"
            type="button"
            :disabled="isBusy || !signed?.signedPdf"
            @click="downloadPdf"
          >
            Download PDF
          </button>
        </div>
      </section>

      <p v-if="status" class="muted no-print">{{ status }}</p>

      <ComposedContractDocument
        v-if="activeContract"
        :contract="activeContract.composed"
        :variant="activeTab"
      />

      <section v-else class="contracts-empty">
        <h2>No contract yet</h2>
        <p class="muted">Regenerate to build this trade contract from the estimate and company setup.</p>
      </section>
    </template>
  </div>
</template>

<style scoped>
.contracts-page {
  display: grid;
  gap: 1rem;
}

.contract-tabs,
.signed-pdf-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.signed-pdf-panel {
  align-items: end;
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  justify-content: space-between;
}

.signed-pdf-panel h2 {
  margin: 0 0 0.35rem;
}

.signed-pdf-meta {
  margin: 0.5rem 0 0;
}

.contracts-empty {
  border: 1px dashed var(--sf-border);
  border-radius: 16px;
  display: grid;
  gap: 0.35rem;
  padding: 1.25rem;
}

.sr-only {
  border: 0;
  clip: rect(0, 0, 0, 0);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

@media print {
  .no-print {
    display: none !important;
  }
}
</style>
