<script setup lang="ts">
import type { CompanyProfile } from "~~/shared/types"
import { APP_NAME, resolveLogoUrl } from "~~/shared/branding"

const { isAdmin } = useAuth()
const { profile, refreshCompanyProfile } = useCompanyProfile()
const { getPlatformProfile } = useAdminUsers()
const { dashboard, refreshDashboard } = useEstimates()
const {
  accountDashboard,
  can,
  refreshAccountContext,
  refreshAccountDashboard
} = useAccount()

await refreshAccountContext()

await Promise.all([
  can("viewEstimates") ? refreshDashboard() : Promise.resolve(),
  can("viewAccountStatistics") ? refreshAccountDashboard() : Promise.resolve()
])

const branding = ref<CompanyProfile | null>(null)
if (isAdmin.value) {
  branding.value = await getPlatformProfile()
} else {
  await refreshCompanyProfile()
  branding.value = profile.value
}

const companyName = computed(() => {
  const name = branding.value?.companyName?.trim()
    || branding.value?.legalName?.trim()
  if (name) return name
  return isAdmin.value ? APP_NAME : "Your company"
})
const companyLogo = computed(() => {
  const custom = branding.value?.logoUrl?.trim()
  if (custom) return custom
  return isAdmin.value ? resolveLogoUrl(null, true) : ""
})

const showEstimateStats = computed(() => can("viewEstimates") || can("viewAccountStatistics"))
</script>

<template>
  <div class="page">
    <header class="page-header company-brand-header">
      <div class="company-brand">
        <BrandLogo
          v-if="companyLogo"
          :src="companyLogo"
          :alt="`${companyName} logo`"
          size="md"
          fallback="none"
        />
        <h1 class="company-dashboard-title">{{ companyName }} Dashboard</h1>
        <p
          v-if="!isAdmin && !branding?.companyName?.trim() && !branding?.legalName?.trim()"
          class="muted company-brand-hint"
        >
          <NuxtLink to="/account">Add your company name</NuxtLink> to show it here.
        </p>
      </div>
      <div class="actions">
        <NuxtLink v-if="can('editCustomers') || can('manageJobAssets')" class="button" to="/customers">
          Customers
        </NuxtLink>
        <NuxtLink v-if="can('useRoofProbe')" class="button secondary" to="/roof-probe">
          ShingleScope
        </NuxtLink>
        <NuxtLink
          v-if="can('viewAccountStatistics')"
          class="button secondary"
          to="/account/statistics"
        >
          Statistics
        </NuxtLink>
      </div>
    </header>

    <section v-if="showEstimateStats" class="grid stats">
      <StatCard
        v-if="can('viewAccountStatistics')"
        label="Sub-accounts"
        :value="accountDashboard.totalSubAccounts"
      />
      <StatCard
        v-if="can('viewAccountStatistics')"
        label="Total clients"
        :value="accountDashboard.totalCustomers"
      />
      <StatCard
        v-if="can('viewAccountStatistics')"
        label="Total estimates"
        :value="accountDashboard.totalEstimates"
      />
      <StatCard
        v-if="can('viewAccountStatistics')"
        label="Total contracts"
        :value="accountDashboard.totalContracts"
      />
      <StatCard v-if="can('viewEstimates')" label="Drafts" :value="dashboard.draftJobs" />
      <StatCard v-if="can('viewEstimates')" label="Signed" :value="dashboard.signedJobs" />
      <StatCard v-if="can('viewEstimates')" label="Complete" :value="dashboard.completeJobs" />
    </section>

    <section v-if="can('viewEstimates')" class="card card-table-section">
      <div class="card-header">
        <h2>Recent customer work</h2>
        <NuxtLink to="/customers">Open customers</NuxtLink>
      </div>
      <EstimateTable embedded :estimates="dashboard.recentJobs" />
    </section>

    <section v-else-if="can('manageJobAssets')" class="card">
      <h2>Field workspace</h2>
      <p class="muted">
        Open Customers to manage job photos and drawings, or use ShingleScope to capture a roof.
      </p>
    </section>
  </div>
</template>
