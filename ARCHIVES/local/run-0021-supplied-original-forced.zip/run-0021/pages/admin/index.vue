<script setup lang="ts">
import type { AccountRole, AccountSummary, CompanyProfile } from "~~/shared/types"
import { PASSWORD_POLICY_DESCRIPTION, passwordPolicyError } from "~~/shared/passwordPolicy"

definePageMeta({
  middleware: "admin"
})

const { listUsers, createUser, deleteUser, getUserCompany, getPlatformProfile, savePlatformProfile } = useAdminUsers()

const users = ref<AccountSummary[]>([])
const status = ref("")
const isBusy = ref(false)
const platformDraft = ref<CompanyProfile | null>(null)
const platformStatus = ref("")
const isSavingPlatform = ref(false)

function cloneProfile(value: CompanyProfile): CompanyProfile {
  return JSON.parse(JSON.stringify(value)) as CompanyProfile
}

async function loadPlatformProfile() {
  try {
    platformDraft.value = cloneProfile(await getPlatformProfile())
  } catch (error) {
    platformStatus.value = error instanceof Error ? error.message : "Failed to load platform profile"
  }
}

await loadPlatformProfile()

const form = reactive<{ email: string, name: string, password: string, role: AccountRole }>({
  email: "",
  name: "",
  password: "",
  role: "customer"
})

const viewing = ref<{ user: AccountSummary, profile: CompanyProfile } | null>(null)

async function refresh() {
  try {
    users.value = await listUsers()
  } catch (error) {
    status.value = error instanceof Error ? error.message : "Failed to load accounts"
  }
}

await refresh()

async function addAccount() {
  if (!form.email || !form.password) {
    status.value = "Email and password are required"
    return
  }
  const policyError = passwordPolicyError(form.password)
  if (policyError) {
    status.value = policyError
    return
  }
  isBusy.value = true
  status.value = "Creating..."
  try {
    await createUser({ ...form })
    form.email = ""
    form.name = ""
    form.password = ""
    form.role = "customer"
    await refresh()
    status.value = "Account created"
  } catch (error) {
    status.value = error instanceof Error ? error.message : "Create failed"
  } finally {
    isBusy.value = false
  }
}

async function removeAccount(user: AccountSummary) {
  if (!confirm(`Delete ${user.email}? This also removes their company profile.`)) return
  isBusy.value = true
  status.value = "Deleting..."
  try {
    await deleteUser(user.userId)
    if (viewing.value?.user.userId === user.userId) viewing.value = null
    await refresh()
    status.value = "Account deleted"
  } catch (error) {
    status.value = error instanceof Error ? error.message : "Delete failed"
  } finally {
    isBusy.value = false
  }
}

async function viewCompany(user: AccountSummary) {
  const profile = await getUserCompany(user.userId)
  viewing.value = { user, profile }
}

async function savePlatform() {
  if (!platformDraft.value) return
  isSavingPlatform.value = true
  platformStatus.value = "Saving..."
  try {
    platformDraft.value = cloneProfile(await savePlatformProfile(platformDraft.value))
    platformStatus.value = "Platform profile saved"
  } catch (error) {
    platformStatus.value = error instanceof Error ? error.message : "Save failed"
  } finally {
    isSavingPlatform.value = false
  }
}
</script>

<template>
  <div class="page">
    <PageHeader
      eyebrow="Admin"
      title="Accounts"
      description="Manage customer accounts. ShingleFile platform branding is configured below and used only when a customer has not set up their own company profile."
    />

    <details id="platform" class="card platform-section">
      <summary class="platform-summary">
        <span>
          <strong>ShingleFile platform</strong>
          <span class="muted platform-note">Default contract branding — rarely needs changes</span>
        </span>
      </summary>
      <p class="muted platform-intro">
        ShingleFile contact information and logo used on contracts when a customer has not filled in their
        company profile. Customer roofing companies manage their own branding under the Company page.
      </p>
      <CompanyProfileForm v-if="platformDraft" v-model="platformDraft" />
      <div class="save-bar">
        <button
          class="button"
          type="button"
          :disabled="isSavingPlatform || !platformDraft"
          @click="savePlatform"
        >
          {{ isSavingPlatform ? "Saving..." : "Save platform profile" }}
        </button>
        <span class="muted">{{ platformStatus }}</span>
      </div>
    </details>

    <section class="card">
      <h2>Add account</h2>
      <div class="form-grid">
        <label class="field">
          <span>Email</span>
          <input v-model="form.email" class="input" type="email">
        </label>
        <label class="field">
          <span>Name</span>
          <input v-model="form.name" class="input" type="text">
        </label>
        <label class="field">
          <span>Password</span>
          <input v-model="form.password" class="input" type="text">
          <small class="muted">{{ PASSWORD_POLICY_DESCRIPTION }}</small>
        </label>
        <label class="field">
          <span>Role</span>
          <select v-model="form.role" class="input">
            <option value="customer">Customer</option>
            <option value="admin">Admin</option>
          </select>
        </label>
      </div>
      <div class="save-bar">
        <button class="button" type="button" :disabled="isBusy" @click="addAccount">Add account</button>
        <span class="muted">{{ status }}</span>
      </div>
    </section>

    <section class="card card-table-section">
      <h2>Accounts</h2>
      <div class="table-wrap">
      <table class="accounts-table">
        <thead>
          <tr>
            <th>Email</th>
            <th>Name</th>
            <th>Role</th>
            <th>Company</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="user in users" :key="user.userId">
            <td>{{ user.email }}</td>
            <td>{{ user.name }}</td>
            <td>{{ user.role }}</td>
            <td>{{ user.companyName || "—" }}</td>
            <td class="row-actions">
              <button class="button secondary" type="button" @click="viewCompany(user)">View</button>
              <button class="button secondary" type="button" :disabled="isBusy" @click="removeAccount(user)">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
      </div>
    </section>

    <section v-if="viewing" class="card">
      <div class="section-head">
        <h2>{{ viewing.user.email }} — Company profile</h2>
        <button class="button secondary" type="button" @click="viewing = null">Close</button>
      </div>
      <dl class="profile-grid">
        <div><dt>Company</dt><dd>{{ viewing.profile.companyName || "—" }}</dd></div>
        <div><dt>Legal name</dt><dd>{{ viewing.profile.legalName || "—" }}</dd></div>
        <div><dt>Website</dt><dd>{{ viewing.profile.website || "—" }}</dd></div>
        <div><dt>Email</dt><dd>{{ viewing.profile.email || "—" }}</dd></div>
        <div><dt>Phone</dt><dd>{{ viewing.profile.phone || "—" }}</dd></div>
        <div><dt>Address</dt><dd>{{ [viewing.profile.address1, viewing.profile.city, viewing.profile.state, viewing.profile.zip].filter(Boolean).join(", ") || "—" }}</dd></div>
        <div><dt>Licenses</dt><dd>{{ viewing.profile.licenses.map((l) => `${l.state}: ${l.licenseId}`).join("; ") || "—" }}</dd></div>
        <div><dt>Contacts</dt><dd>{{ viewing.profile.contacts.map((c) => `${c.name} (${c.role})`).join("; ") || "—" }}</dd></div>
      </dl>
    </section>
  </div>
</template>

<style scoped>
.form-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 1rem;
}

.save-bar {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-top: 1rem;
}

.accounts-table {
  min-width: 36rem;
  width: 100%;
  border-collapse: collapse;
}

.accounts-table th,
.accounts-table td {
  text-align: left;
  padding: 0.6rem 0.5rem;
  border-bottom: 1px solid var(--sf-border);
}

.row-actions {
  display: flex;
  gap: 0.5rem;
  justify-content: flex-end;
}

.section-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}

.profile-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 0.75rem 1.5rem;
}

.profile-grid dt {
  font-size: 0.78rem;
  font-weight: 800;
  color: var(--sf-text-muted);
}

.profile-grid dd {
  margin: 0;
}

.platform-section {
  margin-bottom: 1.25rem;
}

.platform-summary {
  cursor: pointer;
  list-style: none;
}

.platform-summary::-webkit-details-marker {
  display: none;
}

.platform-summary strong {
  display: block;
  font-size: 1.05rem;
}

.platform-note {
  display: block;
  font-size: 0.88rem;
  font-weight: 400;
  margin-top: 0.2rem;
}

.platform-intro {
  margin: 1rem 0;
}
</style>
