<script setup lang="ts">
definePageMeta({
  layout: false
})

const route = useRoute()
const { completeLogin } = useAuth()
const errorMessage = ref("")

onMounted(async () => {
  const code = typeof route.query.code === "string" ? route.query.code : ""
  if (!code) {
    errorMessage.value = "Missing authorization code. Please try signing in again."
    return
  }

  try {
    await completeLogin(code)
    await navigateTo("/")
  } catch (error) {
    errorMessage.value = error instanceof Error ? error.message : "Login failed."
  }
})
</script>

<template>
  <main class="login-screen">
    <section class="login-panel login-panel--solo">
      <div class="login-panel-inner">
        <h2>Signing you in</h2>
        <p v-if="errorMessage" class="login-error">{{ errorMessage }}</p>
        <p v-else class="login-subtitle">Please wait while we finish connecting your account.</p>
      </div>
    </section>
  </main>
</template>

<style scoped>
.login-panel--solo {
  grid-column: 1 / -1;
  min-height: 100vh;
}
</style>
