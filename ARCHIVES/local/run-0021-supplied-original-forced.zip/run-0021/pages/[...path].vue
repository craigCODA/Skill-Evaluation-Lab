<template>
  <div class="page">
    <section class="card">
      <h1>Page not found</h1>
      <p class="muted">The Nuxt route does not exist yet.</p>
      <NuxtLink class="button" to="/">Go home</NuxtLink>
    </section>
  </div>
</template>
