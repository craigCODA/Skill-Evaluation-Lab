<script setup lang="ts">
import {
  ASSIGNABLE_CUSTOMER_ACCOUNT_ROLES,
  CUSTOMER_ACCOUNT_ROLE_LABELS,
  normalizeCustomerAccountRole,
  type AssignableCustomerAccountRole
} from "~~/shared/accountPermissions"
import { passwordPolicyError } from "~~/shared/passwordPolicy"
import type { SubAccount } from "~~/shared/types"
import type { AccountTeamGroupView, AccountTeamMemberView } from "~~/components/AccountTeamRoster.vue"

const {
  accountContext,
  can,
  createSubAccount,
  refreshAccountContext,
  refreshSubAccounts,
  subAccounts,
  updateSubAccountRole
} = useAccount()

await refreshAccountContext()
if (!can("manageSubAccounts")) {
  await navigateTo("/account")
}
await refreshSubAccounts()

const form = reactive({
  email: "",
  name: "",
  password: "",
  title: "",
  role: "estimator" as AssignableCustomerAccountRole
})
const status = ref("")
const isBusy = ref(false)
const roleDrafts = ref<Record<string, AssignableCustomerAccountRole>>({})

watch(subAccounts, (members) => {
  const next: Record<string, AssignableCustomerAccountRole> = { ...roleDrafts.value }
  for (const member of members) {
    next[member.id] = assignableRole(member.role)
  }
  roleDrafts.value = next
}, { immediate: true })

const roleOptions = ASSIGNABLE_CUSTOMER_ACCOUNT_ROLES.map((value) => ({
  value,
  label: CUSTOMER_ACCOUNT_ROLE_LABELS[value],
  hint: roleHint(value)
}))

const summaryStats = computed(() => [
  { label: "Total people", value: subAccounts.value.length },
  { label: "Admins", value: countRole("customer-account-admin") },
  { label: "Estimators", value: countRole("estimator") + countRole("sub-account") },
  { label: "Installers", value: countRole("installer") }
])

const memberViews = computed((): AccountTeamMemberView[] => {
  const currentId = accountContext.value?.subAccount.id
  return [...subAccounts.value]
    .sort(compareMembers)
    .map((member) => {
      const role = normalizeCustomerAccountRole(member.role)
      const roleDraft = roleDrafts.value[member.id] ?? assignableRole(role)
      return {
        id: member.id,
        name: member.name?.trim() || member.email || "Unnamed user",
        email: member.email,
        title: member.title?.trim() || "",
        roleLabel: CUSTOMER_ACCOUNT_ROLE_LABELS[role],
        roleTone: roleTone(role),
        initials: initialsFor(member),
        isCurrentUser: member.id === currentId,
        roleDraft,
        canEditRole: member.id !== currentId,
        roleDirty: roleDraft !== assignableRole(role)
      }
    })
})

const groups = computed((): AccountTeamGroupView[] => {
  const admins = memberViews.value.filter((member) => member.roleTone === "admin")
  const estimators = memberViews.value.filter((member) =>
    member.roleTone === "estimator" || member.roleTone === "legacy"
  )
  const installers = memberViews.value.filter((member) => member.roleTone === "installer")

  return [
    {
      key: "admins",
      title: "Account admins",
      description: "Full company access: team, catalog, branding, and all customer work.",
      tone: "admin",
      members: admins
    },
    {
      key: "estimators",
      title: "Estimators",
      description: "Sales path: customers, estimates, contracts, and job files they own.",
      tone: "estimator",
      members: estimators
    },
    {
      key: "installers",
      title: "Installers",
      description: "Field access: ShingleScope and jobsite photos/drawings only.",
      tone: "installer",
      members: installers
    }
  ]
})

const accountName = computed(() =>
  accountContext.value?.customerAccount.name?.trim() || "Your company"
)

function countRole(role: SubAccount["role"]): number {
  return subAccounts.value.filter((member) => normalizeCustomerAccountRole(member.role) === role).length
}

function assignableRole(role: SubAccount["role"]): AssignableCustomerAccountRole {
  const normalized = normalizeCustomerAccountRole(role)
  if (normalized === "sub-account") return "estimator"
  return normalized
}

function roleTone(role: SubAccount["role"]): AccountTeamMemberView["roleTone"] {
  const normalized = normalizeCustomerAccountRole(role)
  if (normalized === "customer-account-admin") return "admin"
  if (normalized === "installer") return "installer"
  if (normalized === "sub-account") return "legacy"
  return "estimator"
}

function roleHint(role: AssignableCustomerAccountRole): string {
  if (role === "customer-account-admin") {
    return "Manage team, catalog, company profile, and all account work."
  }
  if (role === "installer") {
    return "Capture drawings and jobsite media. No estimate or contract access."
  }
  return "Create and edit customers, estimates, and contracts for their own work."
}

function initialsFor(member: SubAccount): string {
  const source = member.name?.trim() || member.email || "?"
  const parts = source.split(/[\s@.]+/).filter(Boolean)
  if (parts.length >= 2) return `${parts[0]![0] ?? ""}${parts[1]![0] ?? ""}`.toUpperCase()
  return source.slice(0, 2).toUpperCase()
}

function compareMembers(a: SubAccount, b: SubAccount): number {
  const nameA = (a.name || a.email || "").toLowerCase()
  const nameB = (b.name || b.email || "").toLowerCase()
  return nameA.localeCompare(nameB)
}

function updateRoleDraft(subAccountId: string, role: AssignableCustomerAccountRole) {
  roleDrafts.value = { ...roleDrafts.value, [subAccountId]: role }
}

async function addTeamMember() {
  if (!form.email || !form.password) {
    status.value = "Email and password are required"
    return
  }
  const policyError = passwordPolicyError(form.password)
  if (policyError) {
    status.value = policyError
    return
  }
  isBusy.value = true
  status.value = "Creating team member..."
  try {
    await createSubAccount({ ...form })
    form.email = ""
    form.name = ""
    form.password = ""
    form.title = ""
    form.role = "estimator"
    await refreshSubAccounts()
    status.value = "Team member created. They can sign in with that email and password."
  } catch (error) {
    status.value = error instanceof Error ? error.message : "Could not create team member"
  } finally {
    isBusy.value = false
  }
}

async function saveRole(subAccountId: string) {
  const member = subAccounts.value.find((item) => item.id === subAccountId)
  const role = roleDrafts.value[subAccountId]
  if (!member || !role || role === assignableRole(member.role)) return

  isBusy.value = true
  status.value = "Updating role..."
  try {
    await updateSubAccountRole(subAccountId, role)
    status.value = `Updated role for ${member.email}`
  } catch (error) {
    status.value = error instanceof Error ? error.message : "Could not update role"
    roleDrafts.value = {
      ...roleDrafts.value,
      [subAccountId]: assignableRole(member.role)
    }
  } finally {
    isBusy.value = false
  }
}
</script>

<template>
  <main class="page account-team-page">
    <PageHeader
      eyebrow="Account"
      :title="`${accountName} team`"
      description="See who has access, grouped by role, and invite new people to your company account."
    />

    <section class="grid stats team-summary">
      <StatCard
        v-for="stat in summaryStats"
        :key="stat.label"
        :label="stat.label"
        :value="stat.value"
      />
    </section>

    <div class="team-layout">
      <AccountTeamInviteForm
        v-model:form="form"
        :role-options="roleOptions"
        :is-busy="isBusy"
        :status="status"
        @submit="addTeamMember"
      />

      <AccountTeamRoster
        :groups="groups"
        :role-options="roleOptions"
        :is-busy="isBusy"
        @update-role-draft="updateRoleDraft"
        @save-role="saveRole"
      />
    </div>
  </main>
</template>

<style scoped>
.account-team-page {
  display: grid;
  gap: 1.5rem;
}

.team-summary {
  grid-template-columns: repeat(4, minmax(0, 1fr));
}

.team-layout {
  align-items: start;
  display: grid;
  gap: 1.25rem;
  grid-template-columns: minmax(280px, 360px) minmax(0, 1fr);
}

@media (max-width: 980px) {
  .team-summary {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .team-layout {
    grid-template-columns: 1fr;
  }
}
</style>
