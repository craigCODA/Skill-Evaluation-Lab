<script setup lang="ts">
import {
  defaultCompanyRoleCapabilities,
  type AccountCapability,
  type AssignableCustomerAccountRole
} from "~~/shared/accountPermissions"

const {
  can,
  loadRoleCapabilities,
  refreshAccountContext,
  saveRoleCapabilities
} = useAccount()

await refreshAccountContext()
if (!can("manageSubAccounts")) {
  await navigateTo("/account")
}

const capabilityOptions = ref<{ id: AccountCapability, label: string }[]>([])
const roles = ref<{
  role: AssignableCustomerAccountRole
  label: string
  locked: AccountCapability[]
}[]>([])
const draft = ref<Record<AssignableCustomerAccountRole, AccountCapability[]>>(
  defaultCompanyRoleCapabilities()
)
const status = ref("")
const isBusy = ref(false)

async function load() {
  const response = await loadRoleCapabilities()
  capabilityOptions.value = response.capabilities
  roles.value = response.roles.map((role) => ({
    role: role.role,
    label: role.label,
    locked: role.locked
  }))
  draft.value = {
    "customer-account-admin": [...(response.roles.find((role) => role.role === "customer-account-admin")?.capabilities ?? [])],
    estimator: [...(response.roles.find((role) => role.role === "estimator")?.capabilities ?? [])],
    installer: [...(response.roles.find((role) => role.role === "installer")?.capabilities ?? [])]
  }
}

await load()

async function save() {
  isBusy.value = true
  status.value = "Saving permissions..."
  try {
    await saveRoleCapabilities(draft.value)
    await load()
    status.value = "Role permissions saved."
  } catch (error) {
    status.value = error instanceof Error ? error.message : "Could not save permissions"
  } finally {
    isBusy.value = false
  }
}

function resetToDefaults() {
  const defaults = defaultCompanyRoleCapabilities()
  draft.value = {
    "customer-account-admin": [...defaults["customer-account-admin"]],
    estimator: [...defaults.estimator],
    installer: [...defaults.installer]
  }
  status.value = "Draft reset to defaults. Save to apply."
}
</script>

<template>
  <main class="page account-roles-page">
    <PageHeader
      eyebrow="Company"
      title="Role permissions"
      description="Adjust what Account admins, Estimators, and Installers can do on this company account."
    />

    <AccountRolePermissionsEditor
      v-model:draft="draft"
      :capability-options="capabilityOptions"
      :roles="roles"
      :is-busy="isBusy"
      :status="status"
      @save="save"
      @reset="resetToDefaults"
    />
  </main>
</template>

<style scoped>
.account-roles-page {
  display: grid;
  gap: 1.25rem;
}
</style>
