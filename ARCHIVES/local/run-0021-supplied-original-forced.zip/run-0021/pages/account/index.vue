<script setup lang="ts">
const { accountContext, can, refreshAccountContext } = useAccount()
await refreshAccountContext()
</script>

<template>
  <main class="page account-home-page">
    <PageHeader
      eyebrow="Account"
      title="Account"
      description="Account overview and reference tools. Company setup lives under Company in the sidebar."
    />

    <section class="account-link-grid">
      <NuxtLink
        v-if="can('editCompanyProfile')"
        class="card account-link-card"
        to="/account/company"
      >
        <p class="eyebrow">Company</p>
        <h2>Company Information</h2>
        <p class="muted">Business identity, office locations, and contract branding.</p>
      </NuxtLink>
      <NuxtLink class="card account-link-card" to="/account/user">
        <p class="eyebrow">User</p>
        <h2>User Settings</h2>
        <p class="muted">Name, title, and account identity for the signed-in user.</p>
      </NuxtLink>
      <NuxtLink
        v-if="can('manageSubAccounts')"
        class="card account-link-card"
        to="/account/team"
      >
        <p class="eyebrow">Team</p>
        <h2>Team Members</h2>
        <p class="muted">Add estimators and installers and assign their roles.</p>
      </NuxtLink>
      <NuxtLink
        v-if="can('manageSubAccounts')"
        class="card account-link-card"
        to="/account/roles"
      >
        <p class="eyebrow">Team</p>
        <h2>Role Permissions</h2>
        <p class="muted">Choose what each company role can access.</p>
      </NuxtLink>
      <NuxtLink
        v-if="can('editContractSetup')"
        class="card account-link-card"
        to="/account/contracts"
      >
        <p class="eyebrow">Contracts</p>
        <h2>Contract Setup</h2>
        <p class="muted">Modular roofing recipe and company/state contract wording.</p>
      </NuxtLink>
      <NuxtLink
        v-if="can('viewAccountStatistics')"
        class="card account-link-card"
        to="/account/statistics"
      >
        <p class="eyebrow">Stats</p>
        <h2>Statistics</h2>
        <p class="muted">Sub-account, customer, estimate, and contract totals.</p>
      </NuxtLink>
      <NuxtLink
        v-if="can('editCatalog')"
        class="card account-link-card"
        to="/catalog"
      >
        <p class="eyebrow">Reference</p>
        <h2>Catalog</h2>
        <p class="muted">Materials and pricing catalog.</p>
      </NuxtLink>
      <NuxtLink class="card account-link-card" to="/calculator">
        <p class="eyebrow">Reference</p>
        <h2>Calculator Reference</h2>
        <p class="muted">Estimate calculator reference tools.</p>
      </NuxtLink>
      <p v-if="accountContext" class="muted account-role-note">
        Role: {{ accountContext.role || accountContext.subAccount.role }}
      </p>
    </section>
  </main>
</template>

<style scoped>
.account-home-page {
  display: grid;
  gap: 1.25rem;
}

.account-link-grid {
  display: grid;
  gap: 1rem;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
}

.account-link-card {
  display: grid;
  gap: 0.35rem;
  text-decoration: none;
  color: inherit;
}

.account-role-note {
  grid-column: 1 / -1;
}
</style>
