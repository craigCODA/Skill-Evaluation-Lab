<script setup lang="ts">
import {
  CONTRACT_MODULE_CATALOG,
  CONTRACT_RECIPE_KINDS,
  CONTRACT_RECIPE_LABELS,
  defaultEnabledRecipes,
  defaultModuleContents,
  defaultRecipes,
  type CompanyContractConfig,
  type ContractModuleContent,
  type ContractRecipeKind,
  type ContractRecipeSlot
} from "~~/shared/contracts/modules"
import { SUPPORTED_STATE_OPTIONS } from "~~/shared/companyLocation"

const { can, refreshAccountContext } = useAccount()
const { loadContractConfig, saveContractConfig } = useContractSetup()

await refreshAccountContext()
if (!can("editContractSetup")) {
  await navigateTo("/account")
}

const recipes = ref<Record<ContractRecipeKind, ContractRecipeSlot[]>>(defaultRecipes())
const enabledRecipes = ref(defaultEnabledRecipes())
const modules = ref<ContractModuleContent[]>(defaultModuleContents())
const activeRecipe = ref<ContractRecipeKind>("roofing")
const selectedState = ref("DEFAULT")
const status = ref("")
const isBusy = ref(false)

const catalog = CONTRACT_MODULE_CATALOG.map((entry) => ({
  key: entry.key,
  kind: entry.kind,
  label: entry.label,
  description: entry.description,
  editable: entry.editable,
  recipes: [...entry.recipes]
}))

const recipeOptions = CONTRACT_RECIPE_KINDS.map((kind) => ({
  kind,
  label: CONTRACT_RECIPE_LABELS[kind]
}))

async function load() {
  const config = await loadContractConfig()
  recipes.value = config.recipes
  enabledRecipes.value = config.enabledRecipes
  modules.value = config.modules
}

await load()

async function save() {
  isBusy.value = true
  status.value = "Saving contract setup..."
  try {
    const saved = await saveContractConfig({
      recipes: recipes.value,
      enabledRecipes: enabledRecipes.value,
      modules: modules.value
    } satisfies Partial<CompanyContractConfig>)
    recipes.value = saved.recipes
    enabledRecipes.value = saved.enabledRecipes
    modules.value = saved.modules
    status.value = "Contract setup saved. Regenerate job contracts to see changes."
  } catch (error) {
    status.value = error instanceof Error ? error.message : "Could not save contract setup"
  } finally {
    isBusy.value = false
  }
}

function reset() {
  recipes.value = defaultRecipes()
  enabledRecipes.value = defaultEnabledRecipes()
  modules.value = defaultModuleContents()
  status.value = "Draft reset to defaults. Save to apply."
}
</script>

<template>
  <main class="page account-contracts-page">
    <PageHeader
      eyebrow="Company"
      title="Contract setup"
      description="Configure modular recipes for roofing, gutters, and siding, plus company/state wording. Estimators generate contracts from this setup."
    />

    <ContractSetupEditor
      v-model:recipes="recipes"
      v-model:enabled-recipes="enabledRecipes"
      v-model:modules="modules"
      v-model:active-recipe="activeRecipe"
      :catalog="catalog"
      :recipe-options="recipeOptions"
      :state-options="[...SUPPORTED_STATE_OPTIONS]"
      :selected-state="selectedState"
      :is-busy="isBusy"
      :status="status"
      @update:selected-state="selectedState = $event"
      @save="save"
      @reset="reset"
    />
  </main>
</template>

<style scoped>
.account-contracts-page {
  display: grid;
  gap: 1.25rem;
}
</style>
