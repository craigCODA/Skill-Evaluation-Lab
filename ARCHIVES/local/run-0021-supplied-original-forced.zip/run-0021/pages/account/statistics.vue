<script setup lang="ts">
const { accountDashboard, can, refreshAccountContext, refreshAccountDashboard, refreshSubAccounts, subAccounts } = useAccount()

await refreshAccountContext()
if (!can("viewAccountStatistics")) {
  await navigateTo("/account")
}

await Promise.all([
  refreshAccountDashboard(),
  refreshSubAccounts()
])

const stats = computed(() => [
  { label: "Sub-accounts", value: accountDashboard.value.totalSubAccounts },
  { label: "Customers", value: accountDashboard.value.totalCustomers },
  { label: "Estimates", value: accountDashboard.value.totalEstimates },
  { label: "Contracts", value: accountDashboard.value.totalContracts },
  { label: "Draft estimates", value: accountDashboard.value.draftEstimates },
  { label: "Signed estimates", value: accountDashboard.value.signedEstimates },
  { label: "Complete estimates", value: accountDashboard.value.completeEstimates }
])
</script>

<template>
  <main class="page account-statistics-page">
    <PageHeader
      eyebrow="Account"
      title="Statistics"
      description="Account-level counts for the customer account and the work this user can see."
    />

    <section class="grid stats">
      <StatCard
        v-for="stat in stats"
        :key="stat.label"
        :label="stat.label"
        :value="stat.value"
      />
    </section>

    <section class="card">
      <div class="card-header">
        <div>
          <p class="eyebrow">Sub-accounts</p>
          <h2>Users</h2>
        </div>
        <p class="muted">{{ accountDashboard.canSeeAllCustomerAccountWork ? "All visible" : "Current user only" }}</p>
      </div>

      <div class="sub-account-list">
        <div v-for="subAccount in subAccounts" :key="subAccount.id" class="sub-account-row">
          <div>
            <strong>{{ subAccount.name || subAccount.email || "Unnamed user" }}</strong>
            <p class="muted">{{ subAccount.title || subAccount.role }}</p>
          </div>
          <span>{{ subAccount.email }}</span>
        </div>
      </div>
    </section>
  </main>
</template>

<style scoped>
.account-statistics-page,
.sub-account-list {
  display: grid;
  gap: 1.5rem;
}

.sub-account-row {
  align-items: center;
  border: 1px solid rgba(15, 23, 42, 0.12);
  border-radius: 16px;
  display: flex;
  gap: 1rem;
  justify-content: space-between;
  padding: 1rem;
}

@media (max-width: 760px) {
  .sub-account-row {
    align-items: flex-start;
    display: grid;
  }
}
</style>
