<script setup lang="ts">
import type { CompanyProfile } from "~~/shared/types"
import { seedLocationsFromLegacyProfile } from "~~/shared/companyLocation"

definePageMeta({
  middleware: ["customer-only", "company-profile"]
})

const { profile, refreshCompanyProfile, saveCompanyProfile } = useCompanyProfile()
await refreshCompanyProfile()

const draft = ref<CompanyProfile>(clone(seedLocationsFromLegacyProfile(profile.value)))
const isSaving = ref(false)
const saveStatus = ref("")

watch(profile, (next) => {
  draft.value = clone(seedLocationsFromLegacyProfile(next))
})

function clone(value: CompanyProfile): CompanyProfile {
  return JSON.parse(JSON.stringify(value)) as CompanyProfile
}

async function save() {
  isSaving.value = true
  saveStatus.value = "Saving..."
  try {
    await saveCompanyProfile(draft.value)
    saveStatus.value = "Saved"
  } catch (error) {
    saveStatus.value = error instanceof Error ? error.message : "Save failed"
  } finally {
    isSaving.value = false
  }
}
</script>

<template>
  <div class="page">
    <PageHeader
      eyebrow="Account"
      title="Company Information"
      description="Your roofing business identity and office locations. Contracts use the office that matches each estimate's job state."
    />

    <CompanyProfileForm v-model="draft" manage-locations />

    <div class="save-bar">
      <button class="button" type="button" :disabled="isSaving" @click="save">
        {{ isSaving ? "Saving..." : "Save company profile" }}
      </button>
      <span class="muted">{{ saveStatus }}</span>
    </div>
  </div>
</template>

<style scoped>
.save-bar {
  align-items: center;
  display: flex;
  gap: 1rem;
}
</style>
