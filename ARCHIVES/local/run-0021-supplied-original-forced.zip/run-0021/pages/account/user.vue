<script setup lang="ts">
const { currentUser } = useAuth()
const { accountContext, refreshAccountContext, saveCurrentUser } = useAccount()

await refreshAccountContext()

const form = reactive({
  name: accountContext.value?.subAccount.name || currentUser.value.name || "",
  title: accountContext.value?.subAccount.title || ""
})
const isSaving = ref(false)
const saveStatus = ref("")

async function save() {
  isSaving.value = true
  saveStatus.value = "Saving..."
  try {
    await saveCurrentUser({ ...form })
    saveStatus.value = "Saved"
  } catch (error) {
    saveStatus.value = error instanceof Error ? error.message : "Save failed"
  } finally {
    isSaving.value = false
  }
}
</script>

<template>
  <main class="page account-user-page">
    <PageHeader
      eyebrow="Account"
      title="User Settings"
      description="Manage the signed-in user's name, title, and account identity."
    />

    <section class="card account-user-card">
      <div>
        <p class="eyebrow">Identity</p>
        <h2>User information</h2>
      </div>

      <form class="account-user-form" @submit.prevent="save">
        <label class="field">
          <span>Name</span>
          <input v-model="form.name" class="input" type="text" autocomplete="name">
        </label>
        <label class="field">
          <span>Title</span>
          <input v-model="form.title" class="input" type="text" placeholder="Estimator, Sales Manager, Owner">
        </label>
        <label class="field">
          <span>Email</span>
          <input class="input" type="email" :value="currentUser.email" disabled>
        </label>
        <label class="field">
          <span>Role</span>
          <input class="input" type="text" :value="accountContext?.subAccount.role || ''" disabled>
        </label>

        <div class="save-bar">
          <button class="button" type="submit" :disabled="isSaving">
            {{ isSaving ? "Saving..." : "Save user settings" }}
          </button>
          <span class="muted">{{ saveStatus }}</span>
        </div>
      </form>
    </section>
  </main>
</template>

<style scoped>
.account-user-page,
.account-user-form {
  display: grid;
  gap: 1.5rem;
}

.account-user-card {
  display: grid;
  gap: 1rem;
}

.account-user-form {
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
}

.save-bar {
  align-items: center;
  display: flex;
  gap: 1rem;
  grid-column: 1 / -1;
}
</style>
