<script setup lang="ts">
import type { CompanyProfile, CustomerRecord } from "~~/shared/types"
import { APP_NAME, resolveLogoUrl } from "~~/shared/branding"
import { formatCustomerName } from "~~/shared/customer"

const router = useRouter()
const { isAdmin } = useAuth()
const { profile, refreshCompanyProfile } = useCompanyProfile()
const { getPlatformProfile } = useAdminUsers()
const { customers, createCustomer, refreshCustomers } = useCustomers()
const { createDraft, listItems, refreshEstimates } = useEstimates()
const { can, refreshAccountContext } = useAccount()

await refreshAccountContext()

const customerTabs = computed(() => {
  const tabs: { key: CustomerTab, label: string, description: string }[] = [
    { key: "current", label: "Current Customers", description: "Open recent customers and active work." },
    { key: "search", label: "Search Customers", description: "Find an existing customer by name, address, phone, or email." }
  ]
  if (can("editCustomers")) {
    tabs.push({ key: "add", label: "Add Customer", description: "Create a new customer file." })
  }
  return tabs
})

type CustomerTab = "current" | "search" | "add"

const activeTab = ref<CustomerTab>("current")
const isLoading = ref(true)
const isSaving = ref(false)
const errorMessage = ref("")
const searchQuery = ref("")
const form = reactive({
  firstName: "",
  lastName: "",
  companyName: "",
  phone: "",
  email: "",
  address1: "",
  address2: "",
  city: "",
  state: "",
  zip: ""
})

await Promise.all([
  refreshCustomers(),
  can("viewEstimates") ? refreshEstimates() : Promise.resolve()
])
isLoading.value = false

const branding = ref<CompanyProfile | null>(null)
if (isAdmin.value) {
  branding.value = await getPlatformProfile()
} else {
  await refreshCompanyProfile()
  branding.value = profile.value
}

const currentCustomers = computed(() => customers.value.slice(0, 12))
const recentJobs = computed(() => listItems.value.slice(0, 6))
const normalizedSearchQuery = computed(() => searchQuery.value.trim().toLowerCase())
const searchedCustomers = computed(() => {
  const query = normalizedSearchQuery.value
  if (!query) return []
  return customers.value.filter((customer) => customerSearchText(customer).includes(query)).slice(0, 20)
})

const customerStats = computed(() => {
  const stats = [
    { id: "customers", label: "Visible customers", value: customers.value.length }
  ]
  if (can("viewEstimates")) {
    stats.push(
      { id: "estimates", label: "Visible estimates", value: listItems.value.length },
      { id: "contracts", label: "Contracts", value: listItems.value.filter((estimate) => estimate.contractKind).length },
      { id: "drafts", label: "Draft estimates", value: listItems.value.filter((estimate) => estimate.status === "draft").length }
    )
  }
  return stats
})

const activeTabDescription = computed(() =>
  customerTabs.value.find((tab) => tab.key === activeTab.value)?.description ?? ""
)
const companyName = computed(() => {
  const name = branding.value?.companyName?.trim()
    || branding.value?.legalName?.trim()
  if (name) return name
  return isAdmin.value ? APP_NAME : "Your company"
})
const companyLogo = computed(() => {
  const custom = branding.value?.logoUrl?.trim()
  if (custom) return custom
  return isAdmin.value ? resolveLogoUrl(null, true) : ""
})

async function submitCustomer() {
  errorMessage.value = ""
  isSaving.value = true
  try {
    const customer = await createCustomer({ ...form })
    resetForm()
    await router.push(`/customers/${customer.id}`)
  } catch {
    errorMessage.value = "Unable to save customer."
  } finally {
    isSaving.value = false
  }
}

async function startEstimate() {
  const draft = await createDraft()
  await navigateTo(`/estimates/${draft.id}`)
}

function customerSearchText(customer: CustomerRecord): string {
  return [
    formatCustomerName(customer.customer),
    customer.displayName,
    customer.address,
    customer.customer.phone,
    customer.customer.email,
    customer.customer.companyName,
    customer.customer.firstName,
    customer.customer.lastName
  ].filter(Boolean).join(" ").toLowerCase()
}

function resetForm() {
  Object.assign(form, {
    firstName: "",
    lastName: "",
    companyName: "",
    phone: "",
    email: "",
    address1: "",
    address2: "",
    city: "",
    state: "",
    zip: ""
  })
}
</script>

<template>
  <main class="page customers-page">
    <header class="page-header company-brand-header customers-brand-header">
      <div class="company-brand">
        <BrandLogo
          v-if="companyLogo"
          :src="companyLogo"
          :alt="`${companyName} logo`"
          size="md"
          fallback="none"
        />
        <div>
          <h1 class="company-dashboard-title">{{ companyName }} Customers Dashboard</h1>
          <p
            v-if="!isAdmin && !branding?.companyName?.trim() && !branding?.legalName?.trim()"
            class="muted company-brand-hint"
          >
            <NuxtLink to="/account/company">Add your company name</NuxtLink> to show it here.
          </p>
        </div>
      </div>
      <div class="actions">
        <button
          v-if="can('editCustomers')"
          class="button"
          type="button"
          @click="activeTab = 'add'"
        >
          Add Customer
        </button>
      </div>
    </header>

    <section class="grid stats customers-stats">
      <StatCard
        v-for="stat in customerStats"
        :key="stat.id"
        :label="stat.label"
        :value="stat.value"
      />
    </section>

    <section class="card customer-workflow-card">
      <div class="customer-tabs" role="tablist" aria-label="Customer workflow">
        <button
          v-for="tab in customerTabs"
          :key="tab.key"
          type="button"
          class="customer-tab"
          :class="{ 'is-active': activeTab === tab.key }"
          role="tab"
          :aria-selected="activeTab === tab.key"
          @click="activeTab = tab.key"
        >
          {{ tab.label }}
        </button>
      </div>

      <p class="muted customer-tab-description">{{ activeTabDescription }}</p>

      <section v-if="activeTab === 'current'" class="customer-tab-panel">
        <div class="customer-panel-heading">
          <div>
            <p class="eyebrow">Current</p>
            <h2>Recent customer files</h2>
          </div>
          <button
            v-if="can('editEstimates')"
            class="button secondary"
            type="button"
            @click="startEstimate"
          >
            New Estimate
          </button>
        </div>

        <p v-if="isLoading" class="muted">Loading customers...</p>
        <div v-else-if="currentCustomers.length" class="customer-dashboard-grid">
          <div class="customer-list">
            <NuxtLink
              v-for="customer in currentCustomers"
              :key="customer.id"
              class="customer-row"
              :to="`/customers/${customer.id}`"
            >
              <div>
                <strong>{{ formatCustomerName(customer.customer) }}</strong>
                <p class="muted">{{ customer.address || "No address yet" }}</p>
              </div>
              <span>Open file</span>
            </NuxtLink>
          </div>

          <aside class="customer-jobs-card">
            <p class="eyebrow">Jobs</p>
            <h3>Recent customer jobs</h3>
            <div v-if="recentJobs.length" class="customer-job-list">
              <NuxtLink
                v-for="job in recentJobs"
                :key="job.id"
                class="customer-job-link"
                :to="`/estimates/${job.id}`"
              >
                <strong>{{ job.displayName }}</strong>
                <span>{{ job.status }}</span>
              </NuxtLink>
            </div>
            <p v-else class="muted">No customer jobs yet.</p>
          </aside>
        </div>
        <p v-else class="muted">No customers yet. Add the first customer to get started.</p>
      </section>

      <section v-else-if="activeTab === 'search'" class="customer-tab-panel">
        <div class="customer-panel-heading">
          <div>
            <p class="eyebrow">Search</p>
            <h2>Find an existing customer</h2>
          </div>
        </div>

        <label class="customer-search-field">
          <span>Search by name, company, address, phone, or email</span>
          <input
            v-model="searchQuery"
            class="input customer-search-input"
            type="search"
            placeholder="Start typing a customer name or address..."
            autocomplete="off"
          >
        </label>

        <div v-if="normalizedSearchQuery && searchedCustomers.length" class="customer-list">
          <NuxtLink
            v-for="customer in searchedCustomers"
            :key="customer.id"
            class="customer-row"
            :to="`/customers/${customer.id}`"
          >
            <div>
              <strong>{{ formatCustomerName(customer.customer) }}</strong>
              <p class="muted">{{ customer.address || customer.customer.phone || "No details yet" }}</p>
            </div>
            <span>Open file</span>
          </NuxtLink>
        </div>
        <p v-else-if="normalizedSearchQuery" class="muted">
          No customers match that search. Try a different detail or add a new customer.
        </p>
        <p v-else class="muted">Enter at least one customer detail to search existing files.</p>
      </section>

      <section v-else class="customer-tab-panel">
        <div class="customer-panel-heading">
          <div>
            <p class="eyebrow">New Customer</p>
            <h2>Add a customer</h2>
          </div>
        </div>

        <form class="customer-form" @submit.prevent="submitCustomer">
          <label>
            First name
            <input v-model="form.firstName" class="input" type="text" autocomplete="given-name">
          </label>
          <label>
            Last name
            <input v-model="form.lastName" class="input" type="text" autocomplete="family-name">
          </label>
          <label>
            Company
            <input v-model="form.companyName" class="input" type="text" autocomplete="organization">
          </label>
          <label>
            Phone
            <input v-model="form.phone" class="input" type="tel" autocomplete="tel">
          </label>
          <label>
            Email
            <input v-model="form.email" class="input" type="email" autocomplete="email">
          </label>
          <label class="customer-form-wide">
            Address
            <input v-model="form.address1" class="input" type="text" autocomplete="address-line1">
          </label>
          <label>
            City
            <input v-model="form.city" class="input" type="text" autocomplete="address-level2">
          </label>
          <label>
            State
            <input v-model="form.state" class="input" type="text" autocomplete="address-level1">
          </label>
          <label>
            Zip
            <input v-model="form.zip" class="input" type="text" autocomplete="postal-code">
          </label>

          <p v-if="errorMessage" class="form-error">{{ errorMessage }}</p>
          <button class="button primary customer-form-submit" type="submit" :disabled="isSaving">
            {{ isSaving ? "Saving..." : "Add Customer" }}
          </button>
        </form>
      </section>
    </section>
  </main>
</template>

<style scoped>
.customers-page,
.customer-tab-panel {
  display: grid;
  gap: 1.5rem;
}

.customers-stats {
  margin-bottom: -0.25rem;
}

.customer-workflow-card {
  display: grid;
  gap: 1.25rem;
}

.customer-tabs {
  background: color-mix(in oklab, var(--sf-section-sand) 74%, white);
  border: 1px solid var(--sf-border);
  border-radius: 999px;
  display: grid;
  gap: 0.35rem;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  padding: 0.35rem;
}

.customer-tab {
  background: transparent;
  border: 0;
  border-radius: 999px;
  color: var(--sf-text-muted);
  cursor: pointer;
  font-weight: 900;
  padding: 0.8rem 1rem;
}

.customer-tab.is-active {
  background: var(--sf-action);
  color: white;
  box-shadow: 0 10px 22px rgb(23 33 58 / 12%);
}

.customer-tab-description {
  margin: -0.35rem 0 0;
}

.customer-panel-heading,
.customer-row,
.customer-job-link {
  align-items: center;
  display: flex;
  gap: 1rem;
  justify-content: space-between;
}

.customer-panel-heading h2,
.customer-jobs-card h3 {
  margin: 0;
}

.customer-dashboard-grid {
  align-items: start;
  display: grid;
  gap: 1rem;
  grid-template-columns: minmax(0, 1.4fr) minmax(280px, 0.7fr);
}

.customer-list,
.customer-job-list {
  display: grid;
  gap: 0.75rem;
}

.customer-row,
.customer-job-link {
  border: 1px solid rgba(15, 23, 42, 0.12);
  border-radius: 16px;
  color: inherit;
  padding: 1rem;
  text-decoration: none;
}

.customer-row:hover,
.customer-job-link:hover {
  border-color: var(--sf-action);
}

.customer-jobs-card {
  background: var(--sf-section-green);
  border: 1px solid color-mix(in oklab, var(--sf-border) 70%, white);
  border-radius: 18px;
  display: grid;
  gap: 0.85rem;
  padding: 1rem;
}

.customer-job-link {
  background: white;
}

.customer-job-link span {
  color: var(--sf-text-muted);
  font-size: 0.85rem;
  font-weight: 800;
  text-transform: capitalize;
}

.customer-search-field {
  display: grid;
  gap: 0.5rem;
}

.customer-search-field span,
.customer-form label {
  color: var(--sf-text-muted);
  font-size: 0.86rem;
  font-weight: 800;
}

.customer-search-input {
  font-size: 1.05rem;
}

.customer-form {
  display: grid;
  gap: 0.9rem;
  grid-template-columns: repeat(3, minmax(0, 1fr));
}

.customer-form label {
  display: grid;
  gap: 0.45rem;
}

.customer-form-wide,
.customer-form-submit,
.form-error {
  grid-column: 1 / -1;
}

.form-error {
  color: #b42318;
  margin: 0;
}

@media (max-width: 860px) {
  .customer-dashboard-grid,
  .customer-form {
    grid-template-columns: 1fr;
  }

  .customer-tabs {
    border-radius: 18px;
    grid-template-columns: 1fr;
  }

  .customer-tab {
    border-radius: 14px;
  }

  .customer-panel-heading,
  .customer-row,
  .customer-job-link {
    align-items: flex-start;
    display: grid;
  }
}
</style>
