<script setup lang="ts">
import type { Customer, CustomerJobSummary } from "~~/shared/types"
import { formatCustomerName } from "~~/shared/customer"

const route = useRoute("customers-customerId")
const customerId = computed(() => String(route.params.customerId || ""))
const { customerFiles, loadCustomer, updateCustomer } = useCustomers()

const isLoading = ref(true)
const isSavingCustomer = ref(false)
const errorMessage = ref("")
const editingCustomer = ref(false)
const editableCustomer = ref<Partial<Customer>>({})

const customerFile = computed(() => customerFiles.value[customerId.value] ?? null)
const customerAddressLines = computed(() => {
  const customer = customerFile.value?.customer
  if (!customer) return []
  const cityStateZip = [
    [customer.city, customer.state].filter(Boolean).join(", "),
    customer.zip
  ].filter(Boolean).join(" ")
  return [
    formatCustomerName(customer),
    customer.address1,
    customer.address2,
    cityStateZip
  ].map((line) => line?.trim()).filter(Boolean)
})

await loadCustomerFile()

async function loadCustomerFile() {
  isLoading.value = true
  errorMessage.value = ""
  try {
    const customer = await loadCustomer(customerId.value)
    if (!customer) errorMessage.value = "Customer not found."
  } catch {
    errorMessage.value = "Unable to load customer."
  } finally {
    isLoading.value = false
  }
}

function startCustomerEdit() {
  const customer = customerFile.value?.customer
  if (!customer) return
  editableCustomer.value = {
    firstName: customer.firstName,
    lastName: customer.lastName,
    companyName: customer.companyName,
    address1: customer.address1,
    address2: customer.address2,
    city: customer.city,
    state: customer.state,
    zip: customer.zip,
    phone: customer.phone,
    email: customer.email
  }
  editingCustomer.value = true
}

async function saveCustomerInfo() {
  isSavingCustomer.value = true
  try {
    await updateCustomer(customerId.value, editableCustomer.value)
    editingCustomer.value = false
  } finally {
    isSavingCustomer.value = false
  }
}

function cancelCustomerEdit() {
  editingCustomer.value = false
  editableCustomer.value = {}
}

function formatDate(value?: string): string {
  if (!value) return "Not set"
  return new Date(value).toLocaleDateString()
}

function statusLabel(status: string): string {
  return status.replace(/-/g, " ")
}

function jobWorkLabel(job: CustomerJobSummary): string {
  if (job.estimateType === "temporary-repair") return "Temporary repair"
  if (job.estimateType === "roof-proposal" || job.status === "roof-proposal") return "Roof proposal"
  return statusLabel(job.status)
}

function jobPrimaryDate(job: CustomerJobSummary): string {
  if (job.signedAt) return `Signed ${formatDate(job.signedAt)}`
  if (job.proposedAt) return `Proposed ${formatDate(job.proposedAt)}`
  return `Updated ${formatDate(job.updatedAt)}`
}

function jobAssetSummary(job: CustomerJobSummary): string {
  const drawings = job.assets.filter((asset) => asset.kind === "drawing-screenshot").length
  const media = job.assets.filter((asset) => asset.kind === "image").length
  return [
    drawings ? `${drawings} drawings` : "",
    media ? `${media} jobsite photos` : ""
  ].filter(Boolean).join(", ") || "No assets yet"
}

function shingleScopeRoute(job: CustomerJobSummary) {
  return {
    path: "/roof-probe",
    query: {
      address: job.address || customerFile.value?.address || "",
      customerId: customerFile.value?.id || "",
      jobId: job.id
    }
  }
}
</script>

<template>
  <main class="page customer-file-page">
    <NuxtLink class="back-link" to="/customers">Back to Customers</NuxtLink>

    <p v-if="isLoading" class="muted">Loading customer...</p>
    <p v-else-if="errorMessage" class="form-error">{{ errorMessage }}</p>

    <template v-else-if="customerFile">
      <section class="customer-file-overview">
        <div class="customer-name-hero">
          <p class="eyebrow">Customer File</p>
          <h1>{{ formatCustomerName(customerFile.customer) }}</h1>
        </div>

        <section class="card customer-info-summary-card">
          <header class="customer-section-heading">
            <div>
              <p class="eyebrow">Customer Information</p>
              <h2>Contact and address</h2>
            </div>
            <button v-if="!editingCustomer" class="icon-edit-button" type="button" @click="startCustomerEdit">
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M4 17.5V20h2.5L17.8 8.7l-2.5-2.5L4 17.5Zm15.7-11.7a1 1 0 0 0 0-1.4l-1.1-1.1a1 1 0 0 0-1.4 0l-.9.9 2.5 2.5.9-.9Z" />
              </svg>
              Edit
            </button>
          </header>

          <form v-if="editingCustomer" class="customer-edit-form" @submit.prevent="saveCustomerInfo">
            <label>
              First name
              <input v-model="editableCustomer.firstName" class="input" type="text">
            </label>
            <label>
              Last name
              <input v-model="editableCustomer.lastName" class="input" type="text">
            </label>
            <label>
              Company
              <input v-model="editableCustomer.companyName" class="input" type="text">
            </label>
            <label>
              Phone
              <input v-model="editableCustomer.phone" class="input" type="tel">
            </label>
            <label>
              Email
              <input v-model="editableCustomer.email" class="input" type="email">
            </label>
            <label>
              Address 1
              <input v-model="editableCustomer.address1" class="input" type="text">
            </label>
            <label>
              Address 2
              <input v-model="editableCustomer.address2" class="input" type="text">
            </label>
            <label>
              City
              <input v-model="editableCustomer.city" class="input" type="text">
            </label>
            <label>
              State
              <input v-model="editableCustomer.state" class="input" type="text">
            </label>
            <label>
              Zip
              <input v-model="editableCustomer.zip" class="input" type="text">
            </label>
            <div class="customer-edit-actions">
              <button class="button" type="submit" :disabled="isSavingCustomer">
                {{ isSavingCustomer ? "Saving..." : "Save customer" }}
              </button>
              <button class="button secondary" type="button" @click="cancelCustomerEdit">Cancel</button>
            </div>
          </form>

          <div v-else class="customer-details-layout">
            <address class="customer-address-block">
              <span v-for="line in customerAddressLines" :key="line">{{ line }}</span>
              <span v-if="!customerAddressLines.length">No address added</span>
            </address>
            <dl class="customer-contact-list">
              <div>
                <dt>Phone</dt>
                <dd>{{ customerFile.customer.phone || "Not added" }}</dd>
              </div>
              <div>
                <dt>Email</dt>
                <dd>{{ customerFile.customer.email || "Not added" }}</dd>
              </div>
              <div>
                <dt>Customer file</dt>
                <dd>{{ customerFile.id }}</dd>
              </div>
            </dl>
          </div>
        </section>
      </section>

      <section class="card customer-tab-panel">
        <header class="customer-section-heading">
          <div>
            <p class="eyebrow">Jobs</p>
            <h2>Customer jobs</h2>
            <p class="muted">Open a job to manage estimates, ShingleScope drawings, jobsite photos, and contracts.</p>
          </div>
        </header>

        <div v-if="customerFile.jobs.length" class="customer-job-card-list">
          <article v-for="job in customerFile.jobs" :key="job.id" class="customer-job-card">
            <header class="customer-job-card-header">
              <div>
                <p class="eyebrow">{{ job.number || "Job" }}</p>
                <h3>{{ jobWorkLabel(job) }}</h3>
                <p class="muted">{{ job.address || "No job address saved" }}</p>
              </div>
              <span class="job-status-pill">{{ statusLabel(job.status) }}</span>
            </header>

            <dl class="job-detail-grid">
              <div>
                <dt>Job date</dt>
                <dd>{{ jobPrimaryDate(job) }}</dd>
              </div>
              <div>
                <dt>Estimator</dt>
                <dd>{{ job.estimator || "Not assigned" }}</dd>
              </div>
              <div>
                <dt>Contract</dt>
                <dd>{{ job.contractLabel || "Not generated" }}</dd>
              </div>
              <div>
                <dt>Assets</dt>
                <dd>{{ jobAssetSummary(job) }}</dd>
              </div>
            </dl>

            <div class="job-action-row">
              <NuxtLink class="button" :to="`/customers/${customerFile.id}/jobs/${job.id}`">Open job file</NuxtLink>
              <NuxtLink class="button secondary" :to="`/estimates/${job.id}`">Open estimate</NuxtLink>
              <NuxtLink class="button secondary" :to="shingleScopeRoute(job)">Open ShingleScope</NuxtLink>
            </div>
          </article>
        </div>
        <p v-else class="muted">
          No jobs are linked to this customer yet. New estimates will attach here once saved with this customer.
        </p>
      </section>
    </template>
  </main>
</template>

