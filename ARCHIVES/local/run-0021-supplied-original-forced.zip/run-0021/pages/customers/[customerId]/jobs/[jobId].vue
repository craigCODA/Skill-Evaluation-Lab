<script setup lang="ts">
import type { CustomerJobSummary, JobAsset } from "~~/shared/types"
import { formatCustomerName } from "~~/shared/customer"

type JobFileTab = "drawings" | "photos" | "estimate" | "contracts"
type JobsiteUploadDraft = {
  id: string
  fileName: string
  contentType: string
  dataUrl: string
  description: string
}

const route = useRoute("customers-customerId-jobs-jobId")
const customerId = computed(() => String(route.params.customerId || ""))
const jobId = computed(() => String(route.params.jobId || ""))
const { customerFiles, loadCustomer } = useCustomers()
const { assetImages, deleteAsset, loadAssetImage, saveJobsiteMedia, updateAssetDescription } = useJobAssets()
const { can, refreshAccountContext } = useAccount()

await refreshAccountContext()

const activeTab = ref<JobFileTab>("drawings")
const isLoading = ref(true)
const errorMessage = ref("")
const activeAssetId = ref("")
const descriptionDrafts = ref<Record<string, string>>({})
const thumbnailImages = ref<Record<string, string>>({})
const jobsiteUploadDrafts = ref<JobsiteUploadDraft[]>([])
const uploadingDraftId = ref("")
const savingDescriptionId = ref("")

const customerFile = computed(() => customerFiles.value[customerId.value] ?? null)
const job = computed(() => customerFile.value?.jobs.find((item) => item.id === jobId.value) ?? null)
const jobFileTabs = computed(() => {
  const tabs: { id: JobFileTab, label: string }[] = [
    { id: "drawings", label: "ShingleScope Drawings" },
    { id: "photos", label: "Jobsite Photos" }
  ]
  if (can("viewEstimates")) tabs.push({ id: "estimate", label: "Estimate" })
  if (can("viewContracts")) tabs.push({ id: "contracts", label: "Contracts" })
  return tabs
})
const activeAssetImage = computed(() => activeAssetId.value ? assetImages.value[activeAssetId.value] ?? "" : "")
const activeAsset = computed(() => job.value?.assets.find((asset) => asset.id === activeAssetId.value) ?? null)
const activeAssetIsVideo = computed(() => isVideoAsset(activeAsset.value))
const drawingAssets = computed(() => job.value?.assets.filter((asset) => asset.kind === "drawing-screenshot") ?? [])
const jobsiteAssets = computed(() => job.value?.assets.filter((asset) => asset.kind === "image") ?? [])

await loadJobFile()

async function loadJobFile() {
  isLoading.value = true
  errorMessage.value = ""
  try {
    const customer = await loadCustomer(customerId.value)
    if (!customer) {
      errorMessage.value = "Customer not found."
      return
    }
    if (!customer.jobs.some((item) => item.id === jobId.value)) {
      errorMessage.value = "Job not found."
      return
    }
    syncDescriptionDrafts()
    await loadAssetThumbnails()
  } catch {
    errorMessage.value = "Unable to load job."
  } finally {
    isLoading.value = false
  }
}

function formatDate(value?: string): string {
  if (!value) return "Not set"
  return new Date(value).toLocaleDateString()
}

function statusLabel(status: string): string {
  return status.replace(/-/g, " ")
}

function jobWorkLabel(item: CustomerJobSummary): string {
  if (item.estimateType === "temporary-repair") return "Temporary repair"
  if (item.estimateType === "roof-proposal" || item.status === "roof-proposal") return "Roof proposal"
  return statusLabel(item.status)
}

function jobPrimaryDate(item: CustomerJobSummary): string {
  if (item.signedAt) return `Signed ${formatDate(item.signedAt)}`
  if (item.proposedAt) return `Proposed ${formatDate(item.proposedAt)}`
  return `Updated ${formatDate(item.updatedAt)}`
}

function shingleScopeRoute(item: CustomerJobSummary) {
  return {
    path: "/roof-probe",
    query: {
      address: item.address || customerFile.value?.address || "",
      customerId: customerFile.value?.id || "",
      jobId: item.id
    }
  }
}

async function viewAsset(assetId: string) {
  activeAssetId.value = assetId
  await loadAssetImage(assetId)
}

function closeAssetViewer() {
  activeAssetId.value = ""
}

async function removeActiveAsset() {
  const asset = activeAsset.value
  if (!asset) return
  await removeAsset(asset)
  closeAssetViewer()
}

async function removeAsset(asset: JobAsset) {
  if (!window.confirm(`Remove "${asset.label}"? This cannot be undone.`)) return
  await deleteAsset(asset)
  removeLocalAsset(asset)
}

async function saveAssetDescription(asset: JobAsset) {
  savingDescriptionId.value = asset.id
  try {
    const updatedAsset = await updateAssetDescription(asset, descriptionDrafts.value[asset.id] ?? "")
    replaceLocalAsset(updatedAsset)
  } finally {
    savingDescriptionId.value = ""
  }
}

async function handleJobsiteFiles(event: Event) {
  const input = event.target as HTMLInputElement
  const files = Array.from(input.files ?? [])
  if (!files.length) return
  const drafts = await Promise.all(files.map(async (file) => ({
    id: `${file.name}-${file.lastModified}-${file.size}`,
    fileName: file.name,
    contentType: file.type,
    dataUrl: await readFileAsDataUrl(file),
    description: ""
  })))
  jobsiteUploadDrafts.value = [...jobsiteUploadDrafts.value, ...drafts]
  input.value = ""
}

async function uploadJobsiteDraft(draft: JobsiteUploadDraft) {
  const currentJob = job.value
  if (!currentJob) return
  uploadingDraftId.value = draft.id
  try {
    const asset = await saveJobsiteMedia({
      jobId: currentJob.id,
      label: draft.fileName,
      description: draft.description,
      mediaDataUrl: draft.dataUrl
    })
    replaceLocalAsset(asset)
    descriptionDrafts.value = { ...descriptionDrafts.value, [asset.id]: asset.description ?? "" }
    if (!isVideoAsset(asset)) {
      thumbnailImages.value = { ...thumbnailImages.value, [asset.id]: await createImageThumbnail(draft.dataUrl) }
    }
    removeJobsiteDraft(draft.id)
  } finally {
    uploadingDraftId.value = ""
  }
}

function updateJobsiteDraftDescription(draftId: string, event: Event) {
  const description = (event.target as HTMLTextAreaElement).value
  jobsiteUploadDrafts.value = jobsiteUploadDrafts.value.map((draft) =>
    draft.id === draftId ? { ...draft, description } : draft
  )
}

function removeJobsiteDraft(draftId: string) {
  jobsiteUploadDrafts.value = jobsiteUploadDrafts.value.filter((draft) => draft.id !== draftId)
}

function replaceLocalAsset(asset: JobAsset) {
  const file = customerFile.value
  if (!file) return
  customerFiles.value = {
    ...customerFiles.value,
    [file.id]: {
      ...file,
      jobs: file.jobs.map((item) =>
        item.id === asset.jobId
          ? {
              ...item,
              assets: item.assets.some((existing) => existing.id === asset.id)
                ? item.assets.map((existing) => existing.id === asset.id ? asset : existing)
                : [asset, ...item.assets]
            }
          : item
      )
    }
  }
}

function removeLocalAsset(asset: JobAsset) {
  const file = customerFile.value
  if (!file) return
  customerFiles.value = {
    ...customerFiles.value,
    [file.id]: {
      ...file,
      jobs: file.jobs.map((item) =>
        item.id === asset.jobId
          ? { ...item, assets: item.assets.filter((existing) => existing.id !== asset.id) }
          : item
      )
    }
  }
  const nextDescriptions = { ...descriptionDrafts.value }
  delete nextDescriptions[asset.id]
  descriptionDrafts.value = nextDescriptions
  const nextThumbnails = { ...thumbnailImages.value }
  delete nextThumbnails[asset.id]
  thumbnailImages.value = nextThumbnails
}

function syncDescriptionDrafts() {
  descriptionDrafts.value = Object.fromEntries(
    (job.value?.assets ?? []).map((asset) => [asset.id, asset.description ?? ""])
  )
}

async function loadAssetThumbnails() {
  await Promise.all((job.value?.assets ?? []).map((asset) => loadAssetThumbnail(asset)))
}

async function loadAssetThumbnail(asset: JobAsset) {
  if (thumbnailImages.value[asset.id]) return
  const dataUrl = await loadAssetImage(asset.id)
  if (!dataUrl || isVideoAsset(asset)) return
  thumbnailImages.value = {
    ...thumbnailImages.value,
    [asset.id]: await createImageThumbnail(dataUrl)
  }
}

function assetKindLabel(asset: JobAsset): string {
  if (asset.kind === "drawing-screenshot") return "ShingleScope drawing"
  return isVideoAsset(asset) ? "Jobsite video" : "Jobsite photo"
}

function assetDescription(asset: JobAsset): string {
  return descriptionDrafts.value[asset.id]?.trim() || asset.description?.trim() || "No description added yet."
}

function isVideoAsset(asset?: JobAsset | null): boolean {
  return Boolean(asset?.contentType.startsWith("video/"))
}

async function createImageThumbnail(dataUrl: string): Promise<string> {
  const image = await loadImage(dataUrl)
  const maxWidth = 360
  const scale = Math.min(1, maxWidth / image.naturalWidth)
  const canvas = document.createElement("canvas")
  canvas.width = Math.max(1, Math.round(image.naturalWidth * scale))
  canvas.height = Math.max(1, Math.round(image.naturalHeight * scale))
  canvas.getContext("2d")?.drawImage(image, 0, 0, canvas.width, canvas.height)
  return canvas.toDataURL("image/jpeg", 0.72)
}

function loadImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image()
    image.onload = () => resolve(image)
    image.onerror = reject
    image.src = dataUrl
  })
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result || ""))
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}

function handleKeydown(event: KeyboardEvent) {
  if (event.key === "Escape") closeAssetViewer()
}

onMounted(() => {
  window.addEventListener("keydown", handleKeydown)
})

onBeforeUnmount(() => {
  window.removeEventListener("keydown", handleKeydown)
})
</script>

<template>
  <main class="page customer-file-page">
    <NuxtLink class="back-link" :to="`/customers/${customerId}`">Back to Customer File</NuxtLink>

    <PageHeader
      eyebrow="Job File"
      :title="job ? jobWorkLabel(job) : 'Job'"
      :description="customerFile ? `${formatCustomerName(customerFile.customer)} - ${job?.address || customerFile.address}` : 'Job details and assets.'"
    />

    <p v-if="isLoading" class="muted">Loading job...</p>
    <p v-else-if="errorMessage" class="form-error">{{ errorMessage }}</p>

    <template v-else-if="job && customerFile">
      <section class="card customer-file-tabs-card">
        <header class="customer-section-heading">
          <div>
            <p class="eyebrow">{{ job.number || "Job" }}</p>
            <h2>{{ jobWorkLabel(job) }}</h2>
            <p class="muted">{{ job.address || "No job address saved" }}</p>
          </div>
          <span class="job-status-pill">{{ statusLabel(job.status) }}</span>
        </header>

        <dl class="job-detail-grid">
          <div>
            <dt>Job date</dt>
            <dd>{{ jobPrimaryDate(job) }}</dd>
          </div>
          <div>
            <dt>Estimator</dt>
            <dd>{{ job.estimator || "Not assigned" }}</dd>
          </div>
          <div>
            <dt>Contract</dt>
            <dd>{{ job.contractLabel || "Not generated" }}</dd>
          </div>
          <div>
            <dt>Assets</dt>
            <dd>{{ job.assets.length ? `${job.assets.length} saved` : "None yet" }}</dd>
          </div>
        </dl>

        <div class="job-action-row">
          <NuxtLink class="button" :to="`/estimates/${job.id}`">Edit estimate</NuxtLink>
          <NuxtLink class="button secondary" :to="shingleScopeRoute(job)">Open ShingleScope</NuxtLink>
        </div>
      </section>

      <section class="card customer-file-tabs-card">
        <div class="customer-asset-subtabs" role="tablist" aria-label="Job file sections">
          <button
            v-for="tab in jobFileTabs"
            :key="tab.id"
            class="customer-asset-subtab"
            :class="{ 'is-active': activeTab === tab.id }"
            type="button"
            role="tab"
            :aria-selected="activeTab === tab.id"
            @click="activeTab = tab.id"
          >
            {{ tab.label }}
          </button>
        </div>

        <section v-if="activeTab === 'drawings'" class="asset-job-list">
          <div v-if="drawingAssets.length" class="asset-thumbnail-grid">
            <article v-for="asset in drawingAssets" :key="asset.id" class="asset-card">
              <button class="asset-thumbnail-button" type="button" @click="viewAsset(asset.id)">
                <img v-if="thumbnailImages[asset.id]" :src="thumbnailImages[asset.id]" :alt="asset.label">
                <span v-else class="muted">Generating thumbnail...</span>
              </button>
              <div class="asset-card-copy">
                <div>
                  <p class="asset-kind-label">{{ assetKindLabel(asset) }}</p>
                  <h4>{{ asset.label }}</h4>
                  <p class="asset-description-copy">{{ assetDescription(asset) }}</p>
                </div>
                <label class="asset-description-field">
                  Description
                  <textarea
                    v-model="descriptionDrafts[asset.id]"
                    class="input"
                    rows="2"
                    placeholder="Add a note about this drawing."
                  />
                </label>
                <div class="asset-card-actions">
                  <button class="button secondary" type="button" @click="saveAssetDescription(asset)">
                    {{ savingDescriptionId === asset.id ? "Saving..." : "Save" }}
                  </button>
                  <button class="button danger" type="button" @click="removeAsset(asset)">Remove</button>
                </div>
              </div>
            </article>
          </div>
          <p v-else class="muted">No ShingleScope drawings are saved to this job yet.</p>
        </section>

        <section v-else-if="activeTab === 'photos'" class="asset-job-list">
          <div class="jobsite-upload-panel">
            <label class="jobsite-upload-picker">
              Add photos or videos
              <input type="file" accept="image/*,video/*" multiple @change="handleJobsiteFiles">
            </label>

            <div v-if="jobsiteUploadDrafts.length" class="jobsite-upload-draft-list">
              <article v-for="draft in jobsiteUploadDrafts" :key="draft.id" class="jobsite-upload-draft">
                <div class="jobsite-upload-preview">
                  <video
                    v-if="draft.contentType.startsWith('video/')"
                    :src="draft.dataUrl"
                    controls
                    preload="metadata"
                  />
                  <img v-else :src="draft.dataUrl" :alt="draft.fileName">
                </div>
                <div class="jobsite-upload-copy">
                  <strong>{{ draft.fileName }}</strong>
                  <label class="asset-description-field">
                    Description
                    <textarea
                      class="input"
                      rows="2"
                      placeholder="Describe the damage, job condition, or site note."
                      :value="draft.description"
                      @input="updateJobsiteDraftDescription(draft.id, $event)"
                    />
                  </label>
                  <div class="asset-card-actions">
                    <button
                      class="button secondary"
                      type="button"
                      :disabled="uploadingDraftId === draft.id"
                      @click="uploadJobsiteDraft(draft)"
                    >
                      {{ uploadingDraftId === draft.id ? "Uploading..." : "Upload" }}
                    </button>
                    <button class="button danger" type="button" @click="removeJobsiteDraft(draft.id)">Remove</button>
                  </div>
                </div>
              </article>
            </div>
          </div>

          <div v-if="jobsiteAssets.length" class="asset-thumbnail-grid">
            <article v-for="asset in jobsiteAssets" :key="asset.id" class="asset-card">
              <button class="asset-thumbnail-button" type="button" @click="viewAsset(asset.id)">
                <video
                  v-if="isVideoAsset(asset) && assetImages[asset.id]"
                  :src="assetImages[asset.id]"
                  preload="metadata"
                />
                <img v-else-if="thumbnailImages[asset.id]" :src="thumbnailImages[asset.id]" :alt="asset.label">
                <span v-else class="muted">Generating thumbnail...</span>
              </button>
              <div class="asset-card-copy">
                <div>
                  <p class="asset-kind-label">{{ assetKindLabel(asset) }}</p>
                  <h4>{{ asset.label }}</h4>
                  <p class="asset-description-copy">{{ assetDescription(asset) }}</p>
                </div>
                <label class="asset-description-field">
                  Description
                  <textarea
                    v-model="descriptionDrafts[asset.id]"
                    class="input"
                    rows="2"
                    placeholder="Add a note about this image or video."
                  />
                </label>
                <div class="asset-card-actions">
                  <button class="button secondary" type="button" @click="saveAssetDescription(asset)">
                    {{ savingDescriptionId === asset.id ? "Saving..." : "Save" }}
                  </button>
                  <button class="button danger" type="button" @click="removeAsset(asset)">Remove</button>
                </div>
              </div>
            </article>
          </div>
          <p v-else class="muted">No jobsite photos or videos uploaded for this job yet.</p>
        </section>

        <section v-else-if="activeTab === 'estimate'" class="asset-related-list">
          <NuxtLink class="asset-related-row" :to="`/estimates/${job.id}`">
            <span class="asset-related-icon" aria-hidden="true">E</span>
            <span>
              <strong>{{ jobWorkLabel(job) }}</strong>
              <small>{{ job.number || "Job" }} - {{ jobPrimaryDate(job) }}</small>
            </span>
            <span class="job-status-pill">{{ statusLabel(job.status) }}</span>
          </NuxtLink>
        </section>

        <section v-else class="asset-related-list">
          <NuxtLink class="asset-related-row" :to="`/estimates/${job.id}/contracts`">
            <span class="asset-related-icon" aria-hidden="true">C</span>
            <span>
              <strong>Composed contracts</strong>
              <small>Roofing, gutters, and siding packets · signed PDF upload</small>
            </span>
            <span class="job-status-pill">Open</span>
          </NuxtLink>
        </section>
      </section>
    </template>

    <div
      v-if="activeAssetId"
      class="asset-viewer-backdrop"
      role="presentation"
      @click="closeAssetViewer"
    >
      <section class="asset-viewer" role="dialog" aria-modal="true" aria-label="Saved job asset" @click.stop>
        <header class="asset-viewer-header">
          <div>
            <p class="eyebrow">Job Asset</p>
            <h2>{{ activeAsset?.label || "Saved asset" }}</h2>
          </div>
          <button class="asset-viewer-close" type="button" aria-label="Close asset viewer" @click="closeAssetViewer">
            x
          </button>
        </header>

        <div class="asset-viewer-body">
          <video
            v-if="activeAssetImage && activeAssetIsVideo"
            :src="activeAssetImage"
            controls
            preload="metadata"
          />
          <img v-else-if="activeAssetImage" :src="activeAssetImage" alt="Saved job asset">
          <span v-else class="muted">Loading asset...</span>
        </div>

        <footer class="asset-viewer-actions">
          <button class="button danger" type="button" @click="removeActiveAsset">Remove asset</button>
          <button class="button secondary" type="button" @click="closeAssetViewer">Close</button>
        </footer>
      </section>
    </div>
  </main>
</template>
