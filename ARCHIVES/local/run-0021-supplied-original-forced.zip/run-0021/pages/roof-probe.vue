<script setup lang="ts">
import { useRoofProbeReport } from "~/composables/useRoofProbeReport"

const config = useRuntimeConfig()
const { customers, customerFiles, loadCustomer, refreshCustomers } = useCustomers()
const { saveDrawingScreenshot } = useJobAssets()
const {
  checkStreetViewAvailability,
  clearLatestMeasurement,
  historyEntries,
  hydrateHistory,
  isCheckingStreetView,
  latestAreaShapes,
  latestIconMarkers,
  latestMeasuredLines,
  latestMeasurement,
  latestWasteFactor,
  probeAddress,
  restoreHistoryEntry,
  saveCurrentLinesToHistory,
  setWasteFactor,
  streetViewAvailability,
} = useRoofMeasurements()

const address = ref("")
const isLoading = ref(false)
const isRestoringHistory = ref(false)
const errorMessage = ref("")
const showHistory = ref(false)
const selectedAssetCustomerId = ref("")
const selectedAssetJobId = ref("")
const assetSaveStatus = ref("")
const isSavingAsset = ref(false)
const streetViewKey = computed(() =>
  typeof config.public.googleMapsApiKey === "string" ? config.public.googleMapsApiKey : ""
)
const selectedAssetCustomerFile = computed(() =>
  selectedAssetCustomerId.value ? customerFiles.value[selectedAssetCustomerId.value] ?? null : null
)
const selectedAssetCustomerJobs = computed(() => selectedAssetCustomerFile.value?.jobs ?? [])
let saveLinesTimer: ReturnType<typeof setTimeout> | undefined

const {
  report,
  ridgeVentNfaPerFt,
  wasteOptions,
} = useRoofProbeReport({
  measurement: latestMeasurement,
  measuredLines: latestMeasuredLines,
  wasteFactor: latestWasteFactor,
})

const route = useRoute()

onMounted(async () => {
  const queryAddress = typeof route.query.address === "string" ? route.query.address : ""
  const queryCustomerId = typeof route.query.customerId === "string" ? route.query.customerId : ""
  const queryJobId = typeof route.query.jobId === "string" ? route.query.jobId : ""
  clearLatestMeasurement()
  await Promise.all([
    hydrateHistory(),
    refreshCustomers().catch(() => undefined)
  ])

  if (queryAddress) {
    address.value = queryAddress
    await runProbe()
  }
  if (queryCustomerId) {
    selectedAssetJobId.value = queryJobId
    await loadAssetCustomer(queryCustomerId)
  }
})

watch(latestMeasuredLines, () => {
  if (!latestMeasurement.value) return
  if (saveLinesTimer) clearTimeout(saveLinesTimer)
  saveLinesTimer = setTimeout(() => {
    void saveCurrentLinesToHistory().catch(() => undefined)
  }, 300)
}, { deep: true })

watch(latestIconMarkers, () => {
  if (!latestMeasurement.value) return
  if (saveLinesTimer) clearTimeout(saveLinesTimer)
  saveLinesTimer = setTimeout(() => {
    void saveCurrentLinesToHistory().catch(() => undefined)
  }, 300)
}, { deep: true })

watch(latestAreaShapes, () => {
  if (!latestMeasurement.value) return
  if (saveLinesTimer) clearTimeout(saveLinesTimer)
  saveLinesTimer = setTimeout(() => {
    void saveCurrentLinesToHistory().catch(() => undefined)
  }, 300)
}, { deep: true })

watch(latestWasteFactor, (factor) => {
  if (!latestMeasurement.value) return
  setWasteFactor(factor)
})

watch(latestMeasurement, (measurement) => {
  if (!measurement) return
  void checkStreetViewAvailability(measurement).catch(() => undefined)
}, { immediate: true })

async function runProbe() {
  errorMessage.value = ""
  isLoading.value = true
  try {
    const measurement = await probeAddress({
      address: address.value,
      requiredQuality: "LOW"
    })
    address.value = measurement.address
  } catch (error) {
    errorMessage.value = error instanceof Error
      ? error.message
      : "ShingleScope scan failed"
  } finally {
    isLoading.value = false
  }
}

async function restoreFromHistory(entryId: string) {
  isRestoringHistory.value = true
  try {
    await restoreHistoryEntry(entryId)
    address.value = latestMeasurement.value?.address ?? address.value
    showHistory.value = false
  } finally {
    isRestoringHistory.value = false
  }
}

async function loadAssetCustomer(customerId: string) {
  if (selectedAssetCustomerId.value !== customerId) selectedAssetJobId.value = ""
  selectedAssetCustomerId.value = customerId
  assetSaveStatus.value = ""
  if (!customerId) return
  await loadCustomer(customerId)
}

async function saveDrawingAsset(payload: { jobId: string; label: string; imageDataUrl: string }) {
  if (!latestMeasurement.value) return
  assetSaveStatus.value = "Saving drawing..."
  isSavingAsset.value = true
  try {
    await saveDrawingScreenshot({
      jobId: payload.jobId,
      label: payload.label,
      imageDataUrl: payload.imageDataUrl,
      metadata: {
        source: "shinglescope",
        address: latestMeasurement.value.address,
        measurementId: latestMeasurement.value.id,
        capturedAt: new Date().toISOString()
      }
    })
    if (selectedAssetCustomerId.value) {
      await loadCustomer(selectedAssetCustomerId.value)
    }
    assetSaveStatus.value = "Saved to customer job."
  } catch (error) {
    assetSaveStatus.value = error instanceof Error ? error.message : "Save failed"
  } finally {
    isSavingAsset.value = false
  }
}
</script>

<template>
  <div class="page roof-probe-page">
    <RoofProbeTitleSection />

    <RoofProbePropertyAddressSection
      v-model:address="address"
      :error-message="errorMessage"
      :history-count="historyEntries.length"
      :is-loading="isLoading"
      @open-history="showHistory = true"
      @scan="runProbe"
    />

    <template v-if="latestMeasurement && report">
      <RoofMeasurementSummary
        v-model:waste-factor="latestWasteFactor"
        :measurement="latestMeasurement"
        :report="report"
        :waste-options="wasteOptions"
      />

      <RoofMeasurementWorkspaceSection
        v-model:area-shapes="latestAreaShapes"
        v-model:markers="latestIconMarkers"
        v-model:lines="latestMeasuredLines"
        :asset-customer-jobs="selectedAssetCustomerJobs"
        :asset-customers="customers"
        :asset-selected-customer-id="selectedAssetCustomerId"
        :asset-selected-job-id="selectedAssetJobId"
        :asset-save-status="assetSaveStatus"
        :is-saving-asset="isSavingAsset"
        :measurement="latestMeasurement"
        :street-view-key="streetViewKey"
        :street-view-availability="streetViewAvailability"
        :is-checking-street-view="isCheckingStreetView"
        @asset-customer-selected="loadAssetCustomer"
        @save-drawing-asset="saveDrawingAsset"
      />

      <RoofVentilationSummary
        v-if="report.ventilation"
        v-model:ridge-vent-nfa-per-ft="ridgeVentNfaPerFt"
        :summary="report.ventilation"
      />

      <RoofSegmentChartSection :rows="report.segments" />
    </template>

    <section v-else class="card">
      <h2>No measurement yet</h2>
      <p class="muted">
        Results include roof area, squares, segment pitch and orientation, plus a scaled aerial for measurements, icons, and shaded area markups.
      </p>
    </section>

    <RoofProbeHistoryDrawer
      :entries="historyEntries"
      :is-open="showHistory"
      :is-restoring="isRestoringHistory"
      @close="showHistory = false"
      @restore="restoreFromHistory"
    />
  </div>
</template>

<style scoped>
.roof-probe-page {
  gap: 1rem;
  display: grid;
}
</style>
