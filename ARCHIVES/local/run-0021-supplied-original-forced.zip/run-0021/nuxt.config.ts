export default defineNuxtConfig({
  compatibilityDate: "2026-04-30",
  devtools: { enabled: true },
  modules: ["@vueuse/nuxt"],
  ssr: false,
  css: [
    "~/assets/css/main.css",
    "~/assets/css/brand-logo.css",
    "~/assets/css/login.css",
    "~/assets/css/mobile.css",
    "~/assets/css/estimate-list.css",
    "~/assets/css/estimate-v2.css",
    "~/assets/css/estimate-help.css",
    "~/assets/css/customer-file.css",
    "~/assets/css/contract-documents.css"
  ],
  runtimeConfig: {
    databaseUrl: process.env.DATABASE_URL,
    cognitoUserPoolId: process.env.COGNITO_USER_POOL_ID,
    googleSolarApiKey: process.env.GOOGLE_SOLAR_API_KEY,
    roofProbeImageryBucket: process.env.ROOF_PROBE_IMAGERY_BUCKET,
    public: {
      appName: "ShingleFile.com",
      apiBase: process.env.NUXT_PUBLIC_API_BASE ?? "/api",
      cognitoClientId: process.env.NUXT_PUBLIC_COGNITO_CLIENT_ID,
      cognitoDomain: process.env.NUXT_PUBLIC_COGNITO_DOMAIN,
      googleMapsApiKey: process.env.NUXT_PUBLIC_GOOGLE_MAPS_API_KEY,
      awsRegion: process.env.NUXT_PUBLIC_AWS_REGION ?? "us-west-1"
    }
  },
  typescript: {
    strict: true,
    typeCheck: true
  },
  nitro: {
    compressPublicAssets: true
  },
  experimental: {
    typedPages: true
  },
  app: {
    head: {
      title: "ShingleFile.com",
      link: [
        { rel: "icon", type: "image/jpeg", href: "/shinglefile-logo.jpg" },
      ],
      meta: [
        { name: "viewport", content: "width=device-width, initial-scale=1" },
        {
          name: "description",
          content: "Roofing estimates, proposals, and job documents in one place."
        }
      ]
    }
  }
})
