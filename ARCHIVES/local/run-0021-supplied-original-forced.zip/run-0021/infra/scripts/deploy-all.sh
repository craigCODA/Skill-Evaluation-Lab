#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

"$ROOT_DIR/infra/scripts/deploy-network-data.sh"
"$ROOT_DIR/infra/scripts/migrate-aws-db.sh"
"$ROOT_DIR/infra/scripts/deploy-auth-api.sh"
"$ROOT_DIR/infra/scripts/seed-users.sh"
"$ROOT_DIR/infra/scripts/deploy-frontend.sh"
