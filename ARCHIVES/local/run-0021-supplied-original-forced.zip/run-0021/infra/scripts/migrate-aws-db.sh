#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
DATABASE_URL="$("$ROOT_DIR/infra/scripts/get-database-url.sh")"

cd "$ROOT_DIR"
DATABASE_URL="$DATABASE_URL" npm run db:migrate
