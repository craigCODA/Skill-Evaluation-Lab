#!/usr/bin/env bash
set -euo pipefail

# Seeds the initial accounts (admin + customers) into the Cognito user pool with
# permanent passwords and group membership. Idempotent: re-running updates
# passwords and group membership without failing on existing users.
#
# All emails/passwords MUST be provided via environment variables (no defaults).

REGION="${AWS_REGION:-us-west-1}"
PROJECT_NAME="${PROJECT_NAME:-shinglefile}"
ENVIRONMENT_NAME="${ENVIRONMENT_NAME:-dev}"
EXPORT_PREFIX="${PROJECT_NAME}-${ENVIRONMENT_NAME}"

: "${ADMIN_EMAIL:?Set ADMIN_EMAIL}"
: "${ADMIN_PASSWORD:?Set ADMIN_PASSWORD}"
: "${JAMES_EMAIL:?Set JAMES_EMAIL}"
: "${JAMES_PASSWORD:?Set JAMES_PASSWORD}"
: "${ROBERT_EMAIL:?Set ROBERT_EMAIL}"
: "${ROBERT_PASSWORD:?Set ROBERT_PASSWORD}"

pool_id="$(aws cloudformation list-exports \
  --region "$REGION" \
  --query "Exports[?Name=='${EXPORT_PREFIX}-CognitoUserPoolId'].Value | [0]" \
  --output text)"

if [ -z "$pool_id" ] || [ "$pool_id" = "None" ]; then
  echo "Could not find export ${EXPORT_PREFIX}-CognitoUserPoolId. Deploy the auth stack first." >&2
  exit 1
fi

seed_user() { # email password group name
  local email="$1" password="$2" group="$3" name="$4"
  echo "Seeding ${email} (${group}) ..."

  aws cognito-idp admin-create-user \
    --region "$REGION" \
    --user-pool-id "$pool_id" \
    --username "$email" \
    --user-attributes Name=email,Value="$email" Name=email_verified,Value=true Name=name,Value="$name" \
    --message-action SUPPRESS >/dev/null 2>&1 || true

  aws cognito-idp admin-set-user-password \
    --region "$REGION" \
    --user-pool-id "$pool_id" \
    --username "$email" \
    --password "$password" \
    --permanent

  aws cognito-idp admin-add-user-to-group \
    --region "$REGION" \
    --user-pool-id "$pool_id" \
    --username "$email" \
    --group-name "$group"
}

seed_user "$ADMIN_EMAIL" "$ADMIN_PASSWORD" admin "Admin"
seed_user "$JAMES_EMAIL" "$JAMES_PASSWORD" customer "James"
seed_user "$ROBERT_EMAIL" "$ROBERT_PASSWORD" customer "Robert"

echo "Seeded ${pool_id} with admin + customer accounts."
