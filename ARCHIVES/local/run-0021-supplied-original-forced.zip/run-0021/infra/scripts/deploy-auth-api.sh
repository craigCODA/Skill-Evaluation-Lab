#!/usr/bin/env bash
set -euo pipefail

REGION="${AWS_REGION:-us-west-1}"
PROJECT_NAME="${PROJECT_NAME:-shinglefile}"
ENVIRONMENT_NAME="${ENVIRONMENT_NAME:-dev}"
AUTH_STACK="${PROJECT_NAME}-auth-${ENVIRONMENT_NAME}"
API_STACK="${PROJECT_NAME}-api-${ENVIRONMENT_NAME}"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
CALLBACK_URLS="${CALLBACK_URLS:-}"
LOGOUT_URLS="${LOGOUT_URLS:-}"
GOOGLE_SOLAR_API_KEY="${GOOGLE_SOLAR_API_KEY:-}"
EXPORT_PREFIX="${PROJECT_NAME}-${ENVIRONMENT_NAME}"

cloudfront_domain="$(aws cloudformation list-exports \
  --region "$REGION" \
  --query "Exports[?Name=='${EXPORT_PREFIX}-CloudFrontDomainName'].Value | [0]" \
  --output text 2>/dev/null || true)"
if [[ -n "$cloudfront_domain" && "$cloudfront_domain" != "None" ]]; then
  CALLBACK_URLS="${CALLBACK_URLS:-https://${cloudfront_domain}/auth/callback,http://localhost:6767/auth/callback}"
  LOGOUT_URLS="${LOGOUT_URLS:-https://${cloudfront_domain}/login,http://localhost:6767/login}"
fi
CALLBACK_URLS="${CALLBACK_URLS:-http://localhost:6767/auth/callback}"
LOGOUT_URLS="${LOGOUT_URLS:-http://localhost:6767/login}"

aws cloudformation deploy \
  --region "$REGION" \
  --stack-name "$AUTH_STACK" \
  --template-file "$ROOT_DIR/infra/cloudformation/auth.yml" \
  --parameter-overrides \
    ProjectName="$PROJECT_NAME" \
    EnvironmentName="$ENVIRONMENT_NAME" \
    CallbackUrls="$CALLBACK_URLS" \
    LogoutUrls="$LOGOUT_URLS"

artifact="$("$ROOT_DIR/infra/scripts/package-api.sh")"
artifact_bucket="${artifact%%/*}"
artifact_key="${artifact#*/}"
database_url="$("$ROOT_DIR/infra/scripts/get-database-url.sh")"
api_parameter_overrides=(
  ProjectName="$PROJECT_NAME"
  EnvironmentName="$ENVIRONMENT_NAME"
  LambdaArtifactBucket="$artifact_bucket"
  LambdaArtifactKey="$artifact_key"
  DatabaseUrl="$database_url"
)
if [[ -n "$GOOGLE_SOLAR_API_KEY" ]]; then
  api_parameter_overrides+=(GoogleSolarApiKey="$GOOGLE_SOLAR_API_KEY")
fi

aws cloudformation deploy \
  --region "$REGION" \
  --stack-name "$API_STACK" \
  --template-file "$ROOT_DIR/infra/cloudformation/api.yml" \
  --capabilities CAPABILITY_IAM \
  --parameter-overrides "${api_parameter_overrides[@]}"

aws lambda update-function-code \
  --region "$REGION" \
  --function-name "${PROJECT_NAME}-${ENVIRONMENT_NAME}-api" \
  --s3-bucket "$artifact_bucket" \
  --s3-key "$artifact_key" \
  >/dev/null
aws lambda wait function-updated \
  --region "$REGION" \
  --function-name "${PROJECT_NAME}-${ENVIRONMENT_NAME}-api"

aws cloudformation describe-stacks \
  --region "$REGION" \
  --stack-name "$API_STACK" \
  --query "Stacks[0].Outputs[?OutputKey=='ApiEndpoint'].OutputValue | [0]" \
  --output text
