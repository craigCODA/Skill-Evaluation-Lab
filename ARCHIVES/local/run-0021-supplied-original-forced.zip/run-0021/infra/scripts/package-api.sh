#!/usr/bin/env bash
set -euo pipefail

REGION="${AWS_REGION:-us-west-1}"
PROJECT_NAME="${PROJECT_NAME:-shinglefile}"
ENVIRONMENT_NAME="${ENVIRONMENT_NAME:-dev}"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
EXPORT_PREFIX="${PROJECT_NAME}-${ENVIRONMENT_NAME}"
ARTIFACT_KEY="lambda/${PROJECT_NAME}-${ENVIRONMENT_NAME}-api.zip"
ARTIFACT_PATH="$ROOT_DIR/.output/${PROJECT_NAME}-${ENVIRONMENT_NAME}-api.zip"

cd "$ROOT_DIR"
NITRO_PRESET=aws-lambda npm run build >&2
rm -f "$ARTIFACT_PATH"
(cd "$ROOT_DIR/.output/server" && zip -qr "$ARTIFACT_PATH" .)

artifact_bucket="$(aws cloudformation list-exports \
  --region "$REGION" \
  --query "Exports[?Name=='${EXPORT_PREFIX}-ArtifactBucketName'].Value | [0]" \
  --output text)"

aws s3 cp "$ARTIFACT_PATH" "s3://${artifact_bucket}/${ARTIFACT_KEY}" --region "$REGION" >&2

echo "${artifact_bucket}/${ARTIFACT_KEY}"
