#!/usr/bin/env bash
set -euo pipefail

# Tears down the full CloudFormation stack set for a given project/environment.
# Deletes dependents first so cross-stack exports are never in use during a delete.
# S3 buckets are emptied first because CloudFormation cannot delete a non-empty bucket.
#
# Override target with env vars, e.g. to remove the old stacks:
#   PROJECT_NAME=roofcalc ENVIRONMENT_NAME=dev infra/scripts/teardown.sh

REGION="${AWS_REGION:-us-west-1}"
PROJECT_NAME="${PROJECT_NAME:-shinglefile}"
ENVIRONMENT_NAME="${ENVIRONMENT_NAME:-dev}"

FRONTEND_STACK="${PROJECT_NAME}-frontend-${ENVIRONMENT_NAME}"
API_STACK="${PROJECT_NAME}-api-${ENVIRONMENT_NAME}"
AUTH_STACK="${PROJECT_NAME}-auth-${ENVIRONMENT_NAME}"
DATA_STACK="${PROJECT_NAME}-data-${ENVIRONMENT_NAME}"
NETWORK_STACK="${PROJECT_NAME}-network-${ENVIRONMENT_NAME}"

stack_exists() {
  aws cloudformation describe-stacks --region "$REGION" --stack-name "$1" >/dev/null 2>&1
}

bucket_for() { # stack logical-id -> physical bucket name (empty if not found)
  aws cloudformation describe-stack-resources --region "$REGION" \
    --stack-name "$1" --logical-resource-id "$2" \
    --query "StackResources[0].PhysicalResourceId" --output text 2>/dev/null || true
}

empty_bucket() {
  local bucket="$1"
  if [ -z "$bucket" ] || [ "$bucket" = "None" ]; then
    return 0
  fi
  echo "Emptying s3://${bucket} ..."
  aws s3 rm "s3://${bucket}" --recursive --region "$REGION" >/dev/null || true
}

delete_stack() {
  local stack="$1"
  if ! stack_exists "$stack"; then
    echo "Skip ${stack} (does not exist)."
    return 0
  fi
  echo "Deleting ${stack} ..."
  aws cloudformation delete-stack --region "$REGION" --stack-name "$stack"
  aws cloudformation wait stack-delete-complete --region "$REGION" --stack-name "$stack"
  echo "Deleted ${stack}."
}

echo "Tearing down ${PROJECT_NAME}-*-${ENVIRONMENT_NAME} in ${REGION}"

if stack_exists "$FRONTEND_STACK"; then
  empty_bucket "$(bucket_for "$FRONTEND_STACK" FrontendBucket)"
fi
delete_stack "$FRONTEND_STACK"

delete_stack "$API_STACK"
delete_stack "$AUTH_STACK"
delete_stack "$DATA_STACK"

if stack_exists "$NETWORK_STACK"; then
  empty_bucket "$(bucket_for "$NETWORK_STACK" ArtifactBucket)"
fi
delete_stack "$NETWORK_STACK"

echo "Teardown complete for ${PROJECT_NAME}-*-${ENVIRONMENT_NAME}."
