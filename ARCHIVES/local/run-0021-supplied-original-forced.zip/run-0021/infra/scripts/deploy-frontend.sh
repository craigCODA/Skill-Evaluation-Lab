#!/usr/bin/env bash
set -euo pipefail

REGION="${AWS_REGION:-us-west-1}"
PROJECT_NAME="${PROJECT_NAME:-shinglefile}"
ENVIRONMENT_NAME="${ENVIRONMENT_NAME:-dev}"
FRONTEND_STACK="${PROJECT_NAME}-frontend-${ENVIRONMENT_NAME}"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
EXPORT_PREFIX="${PROJECT_NAME}-${ENVIRONMENT_NAME}"

api_endpoint="$(aws cloudformation list-exports \
  --region "$REGION" \
  --query "Exports[?Name=='${EXPORT_PREFIX}-ApiEndpoint'].Value | [0]" \
  --output text)"
api_domain="${api_endpoint#https://}"
cognito_client_id="$(aws cloudformation list-exports \
  --region "$REGION" \
  --query "Exports[?Name=='${EXPORT_PREFIX}-CognitoUserPoolClientId'].Value | [0]" \
  --output text)"
cognito_domain="$(aws cloudformation list-exports \
  --region "$REGION" \
  --query "Exports[?Name=='${EXPORT_PREFIX}-CognitoDomain'].Value | [0]" \
  --output text)"

aws cloudformation deploy \
  --region "$REGION" \
  --stack-name "$FRONTEND_STACK" \
  --template-file "$ROOT_DIR/infra/cloudformation/frontend.yml" \
  --parameter-overrides \
    ProjectName="$PROJECT_NAME" \
    EnvironmentName="$ENVIRONMENT_NAME" \
    ApiDomainName="$api_domain"

bucket="$(aws cloudformation list-exports \
  --region "$REGION" \
  --query "Exports[?Name=='${EXPORT_PREFIX}-FrontendBucketName'].Value | [0]" \
  --output text)"
distribution_id="$(aws cloudformation list-exports \
  --region "$REGION" \
  --query "Exports[?Name=='${EXPORT_PREFIX}-CloudFrontDistributionId'].Value | [0]" \
  --output text)"
domain_name="$(aws cloudformation list-exports \
  --region "$REGION" \
  --query "Exports[?Name=='${EXPORT_PREFIX}-CloudFrontDomainName'].Value | [0]" \
  --output text)"

# Register the CloudFront URL with Cognito so hosted-UI login works on the deployed site.
AUTH_STACK="${PROJECT_NAME}-auth-${ENVIRONMENT_NAME}"
aws cloudformation deploy \
  --region "$REGION" \
  --stack-name "$AUTH_STACK" \
  --template-file "$ROOT_DIR/infra/cloudformation/auth.yml" \
  --parameter-overrides \
    ProjectName="$PROJECT_NAME" \
    EnvironmentName="$ENVIRONMENT_NAME" \
    CallbackUrls="http://localhost:6767/auth/callback,https://${domain_name}/auth/callback" \
    LogoutUrls="http://localhost:6767/login,https://${domain_name}/login"

cd "$ROOT_DIR"
if [[ -f "$ROOT_DIR/.env" ]]; then
  set -a
  # shellcheck disable=SC1091
  source "$ROOT_DIR/.env"
  set +a
fi
NUXT_PUBLIC_API_BASE="/api" \
NUXT_PUBLIC_AWS_REGION="$REGION" \
NUXT_PUBLIC_COGNITO_CLIENT_ID="$cognito_client_id" \
NUXT_PUBLIC_COGNITO_DOMAIN="$cognito_domain" \
npm run generate
aws s3 sync "$ROOT_DIR/.output/public/" "s3://${bucket}/" --delete --region "$REGION"
aws cloudfront create-invalidation --distribution-id "$distribution_id" --paths "/*" >/dev/null

echo "https://${domain_name}"
