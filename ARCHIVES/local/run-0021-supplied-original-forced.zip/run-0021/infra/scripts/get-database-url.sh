#!/usr/bin/env bash
set -euo pipefail

REGION="${AWS_REGION:-us-west-1}"
PROJECT_NAME="${PROJECT_NAME:-shinglefile}"
ENVIRONMENT_NAME="${ENVIRONMENT_NAME:-dev}"
EXPORT_PREFIX="${PROJECT_NAME}-${ENVIRONMENT_NAME}"

endpoint="$(aws cloudformation list-exports \
  --region "$REGION" \
  --query "Exports[?Name=='${EXPORT_PREFIX}-DatabaseEndpoint'].Value | [0]" \
  --output text)"
port="$(aws cloudformation list-exports \
  --region "$REGION" \
  --query "Exports[?Name=='${EXPORT_PREFIX}-DatabasePort'].Value | [0]" \
  --output text)"
database_name="$(aws cloudformation list-exports \
  --region "$REGION" \
  --query "Exports[?Name=='${EXPORT_PREFIX}-DatabaseName'].Value | [0]" \
  --output text)"
secret_arn="$(aws cloudformation list-exports \
  --region "$REGION" \
  --query "Exports[?Name=='${EXPORT_PREFIX}-DatabaseSecretArn'].Value | [0]" \
  --output text)"
secret_json="$(aws secretsmanager get-secret-value \
  --region "$REGION" \
  --secret-id "$secret_arn" \
  --query SecretString \
  --output text)"

python3 - "$endpoint" "$port" "$database_name" "$secret_json" <<'PY'
import json
import sys
from urllib.parse import quote

endpoint, port, database, raw_secret = sys.argv[1:]
secret = json.loads(raw_secret)
username = quote(secret["username"])
password = quote(secret["password"])
print(f"postgres://{username}:{password}@{endpoint}:{port}/{database}?sslmode=require")
PY
