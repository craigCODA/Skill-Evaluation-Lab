#!/usr/bin/env bash
set -euo pipefail

REGION="${AWS_REGION:-us-west-1}"
PROJECT_NAME="${PROJECT_NAME:-shinglefile}"
ENVIRONMENT_NAME="${ENVIRONMENT_NAME:-dev}"
NETWORK_STACK="${PROJECT_NAME}-network-${ENVIRONMENT_NAME}"
DATA_STACK="${PROJECT_NAME}-data-${ENVIRONMENT_NAME}"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
DEVELOPER_CIDR="${DEVELOPER_CIDR:-$(curl -fsS https://checkip.amazonaws.com)/32}"

aws cloudformation deploy \
  --region "$REGION" \
  --stack-name "$NETWORK_STACK" \
  --template-file "$ROOT_DIR/infra/cloudformation/network.yml" \
  --parameter-overrides \
    ProjectName="$PROJECT_NAME" \
    EnvironmentName="$ENVIRONMENT_NAME" \
    DeveloperCidr="$DEVELOPER_CIDR"

aws cloudformation deploy \
  --region "$REGION" \
  --stack-name "$DATA_STACK" \
  --template-file "$ROOT_DIR/infra/cloudformation/data.yml" \
  --parameter-overrides \
    ProjectName="$PROJECT_NAME" \
    EnvironmentName="$ENVIRONMENT_NAME"

echo "Network and data stacks deployed in $REGION."
echo "DATABASE_URL:"
"$ROOT_DIR/infra/scripts/get-database-url.sh"
