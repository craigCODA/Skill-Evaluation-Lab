# AWS Dev Foundation

CloudFormation templates and deployment scripts for the lowest-cost dev AWS
environment. Scripts default to `us-west-1`, project `shinglefile`, env `dev`.
Override with `AWS_REGION`, `PROJECT_NAME`, and `ENVIRONMENT_NAME`.

Stacks created (in deploy order): `shinglefile-network-dev`, `shinglefile-data-dev`,
`shinglefile-auth-dev`, `shinglefile-api-dev`, `shinglefile-frontend-dev`.

## Prerequisites

- AWS CLI configured for the personal AWS account.
- Permissions for CloudFormation, EC2, RDS, Secrets Manager, Cognito, Lambda,
  API Gateway, S3, CloudFront, and IAM.

## Deploy

```bash
npm run deploy:aws:data
npm run deploy:aws:migrate
npm run deploy:aws:api
npm run seed:users
npm run deploy:aws:frontend
```

Or run the full sequence:

```bash
npm run deploy:aws
```

`deploy:aws:data` prints the generated `DATABASE_URL`. Use that value locally
if you want the Nuxt dev server to point at the AWS PostgreSQL database.

`seed:users` creates the initial admin and customer accounts in Cognito with
permanent passwords and group membership. It is idempotent and reads the pool id
from the auth stack export. Passwords are dev defaults; override with env vars
(`ADMIN_PASSWORD`, `JAMES_PASSWORD`, `ROBERT_PASSWORD`, etc.).

## Teardown

```bash
npm run teardown:aws
```

Deletes every stack for the target project/env in dependency-safe order
(`frontend`, `api`, `auth`, `data`, `network`). It empties the frontend and
artifact S3 buckets first, since CloudFormation cannot delete a non-empty
bucket. The database stack uses `DeletionPolicy: Snapshot`, so a final RDS
snapshot is created on teardown.

To remove a differently named stack set (e.g. the legacy `roofcalc` deploy):

```bash
PROJECT_NAME=roofcalc npm run teardown:aws
```

## Cost Notes

- This is a dev foundation, not a production HA setup.
- RDS is single-AZ and uses the smallest configured burstable instance class.
- No NAT Gateway is created.
- The dev database is publicly reachable only from `DEVELOPER_CIDR`, which
  defaults to your current public IP at deploy time.
