import type { Catalog } from "../pricebook/types";
import type { Extras, Money, RoofingScope } from "../types";
import type { AreaContext, JobContext } from "../options/types";
import { materialsCounts } from "../options/materials";

import { installOption } from "../options/install";
import { dripEdgeOption } from "../options/dripEdge";
import { underlaymentOption } from "../options/underlayment";
import { iceWaterOption } from "../options/iceWater";
import { ridgeOption } from "../options/ridge";
import { warrantyOption } from "../options/warranty";
import { stepFlashingOption } from "../options/stepFlashing";
import { chimneyRemovalOption } from "../options/chimneyRemoval";
import { chimneyKitOption } from "../options/chimneyKit";
import { accessoriesOption } from "../options/accessories";
import { satelliteOption } from "../options/satellite";
import { antennaOption } from "../options/antenna";
import { lightningRodsOption } from "../options/lightningRods";
import { skylightsOption } from "../options/skylights";
import { noAccessOption } from "../options/noAccess";
import { gutterRemovalOption } from "../options/gutterRemoval";
import { lowSlopeOption } from "../options/lowSlope";
import { valleyMetalOption } from "../options/valleyMetal";

export type EstimateAreaBreakdown = {
  install: ReturnType<typeof installOption.compute>;
  drip: ReturnType<typeof dripEdgeOption.compute>;
  under: ReturnType<typeof underlaymentOption.compute>;
  ice: ReturnType<typeof iceWaterOption.compute>;
  total: Money;
};

export type RoofingEstimateTotals = {
  shinglePrice: Money;
  areaCosts: EstimateAreaBreakdown[];
  totalSquares: number;
  ridge: ReturnType<typeof ridgeOption.compute>;
  warranty: ReturnType<typeof warrantyOption.compute>;
  stepFlash: ReturnType<typeof stepFlashingOption.compute>;
  chimney: ReturnType<typeof chimneyRemovalOption.compute>;
  chimneyKit: ReturnType<typeof chimneyKitOption.compute>;
  accessories: ReturnType<typeof accessoriesOption.compute>;
  satellite: ReturnType<typeof satelliteOption.compute>;
  antenna: ReturnType<typeof antennaOption.compute>;
  lightning: ReturnType<typeof lightningRodsOption.compute>;
  skylights: ReturnType<typeof skylightsOption.compute>;
  noAccess: ReturnType<typeof noAccessOption.compute>;
  gutterRemoval: ReturnType<typeof gutterRemovalOption.compute>;
  lowSlope: ReturnType<typeof lowSlopeOption.compute>;
  valleyMetal: ReturnType<typeof valleyMetalOption.compute>;
  materials: ReturnType<typeof materialsCounts>;
  grandTotal: Money;
};

export function calculateRoofingEstimate({
  roofing,
  catalog,
  permit,
  extras,
}: {
  roofing: RoofingScope;
  catalog: Catalog;
  permit: Money;
  extras: Extras;
}): RoofingEstimateTotals {
  const selectedShingle = catalog.shingles.find(
    (s) => s.id === roofing.shingle.productId,
  );
  const shinglePrice = selectedShingle?.pricePerSquare ?? 0;

  // Area phase: install produces the area's squares, which the per-area
  // add-ons (underlayment, ice & water) read from their context.
  const areaCosts: EstimateAreaBreakdown[] = roofing.areas.map((area) => {
    const install = installOption.compute({
      area,
      roofing,
      catalog,
      shinglePrice,
      squares: 0,
    });
    const ctx: AreaContext = {
      area,
      roofing,
      catalog,
      shinglePrice,
      squares: install.squares,
    };
    const drip = dripEdgeOption.compute(ctx);
    const under = underlaymentOption.compute(ctx);
    const ice = iceWaterOption.compute(ctx);
    return {
      install,
      drip,
      under,
      ice,
      total: install.total + drip.total + under.cost + ice.total,
    };
  });

  const totalSquares = areaCosts.reduce(
    (sum, area) => sum + area.install.squares,
    0,
  );

  // Job phase: options that depend on whole-job derived values
  // (totalSquares, per-area squares).
  const jobCtx: JobContext = {
    roofing,
    catalog,
    shinglePrice,
    totalSquares,
    areaResults: roofing.areas.map((area, i) => ({
      area,
      squares: areaCosts[i]?.install.squares ?? 0,
    })),
  };

  const ridge = ridgeOption.compute(jobCtx);
  const warranty = warrantyOption.compute(jobCtx);
  const stepFlash = stepFlashingOption.compute(jobCtx);
  const chimney = chimneyRemovalOption.compute(jobCtx);
  const chimneyKit = chimneyKitOption.compute(jobCtx);
  const accessories = accessoriesOption.compute(jobCtx);
  const satellite = satelliteOption.compute(jobCtx);
  const antenna = antennaOption.compute(jobCtx);
  const lightning = lightningRodsOption.compute(jobCtx);
  const skylights = skylightsOption.compute(jobCtx);
  const noAccess = noAccessOption.compute(jobCtx);
  const gutterRemoval = gutterRemovalOption.compute(jobCtx);
  const lowSlope = lowSlopeOption.compute(jobCtx);
  const valleyMetal = valleyMetalOption.compute(jobCtx);
  const materials = materialsCounts(roofing, catalog);

  // valleyMetal is intentionally excluded — it is not billed.
  const grandTotal =
    areaCosts.reduce((sum, area) => sum + area.total, 0) +
    ridge.total +
    warranty.cost +
    stepFlash.cost +
    chimney.cost +
    chimneyKit.cost +
    accessories.total +
    satellite.cost +
    antenna.cost +
    lightning.cost +
    skylights.total +
    noAccess.total +
    gutterRemoval.cost +
    lowSlope.cost +
    permit +
    extras.amount;

  return {
    shinglePrice,
    areaCosts,
    totalSquares,
    ridge,
    warranty,
    stepFlash,
    chimney,
    chimneyKit,
    accessories,
    satellite,
    antenna,
    lightning,
    skylights,
    noAccess,
    gutterRemoval,
    lowSlope,
    valleyMetal,
    materials,
    grandTotal,
  };
}
