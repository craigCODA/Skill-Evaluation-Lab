import { newId } from "./ids";
import type {
  LatLng,
  RoofBoundingBox,
  RoofImageryQuality,
  RoofMeasurement,
  RoofMeasurementComplexity,
  RoofOrientationLabel,
  RoofSegment,
} from "./types";

export const SQFT_PER_M2 = 10.76391041671;

export type GoogleSolarBuildingInsights = {
  name?: string;
  center?: GoogleLatLng;
  boundingBox?: GoogleBoundingBox;
  imageryDate?: GoogleDate;
  imageryProcessedDate?: GoogleDate;
  imageryQuality?: string;
  solarPotential?: {
    wholeRoofStats?: {
      areaMeters2?: number;
    };
    roofSegmentStats?: GoogleSolarRoofSegment[];
  };
};

type GoogleSolarRoofSegment = {
  center?: GoogleLatLng;
  boundingBox?: GoogleBoundingBox;
  pitchDegrees?: number;
  azimuthDegrees?: number;
  planeHeightAtCenterMeters?: number;
  stats?: {
    areaMeters2?: number;
  };
};

type GoogleLatLng = {
  latitude?: number;
  longitude?: number;
};

type GoogleBoundingBox = {
  sw?: GoogleLatLng;
  ne?: GoogleLatLng;
};

type GoogleDate = {
  year?: number;
  month?: number;
  day?: number;
};

export function normalizeGoogleSolarMeasurement(input: {
  address: string;
  latitude: number;
  longitude: number;
  buildingInsights: GoogleSolarBuildingInsights;
  fetchedAt?: string;
}): RoofMeasurement {
  const fetchedAt = input.fetchedAt ?? new Date().toISOString();
  const segments = normalizeSegments(input.buildingInsights);
  const totalRoofAreaM2 =
    input.buildingInsights.solarPotential?.wholeRoofStats?.areaMeters2 ??
    sumNumbers(segments.map((segment) => segment.areaM2));
  const totalRoofAreaSqft = totalRoofAreaM2
    ? m2ToSqft(totalRoofAreaM2)
    : undefined;
  const measuredSquares = totalRoofAreaSqft
    ? sqftToSquares(totalRoofAreaSqft)
    : undefined;
  const wasteFactor = estimateWasteFactor(segments.length);
  const orderSquares = measuredSquares
    ? roundTo(measuredSquares * wasteFactor, 2)
    : undefined;
  const hasPitchData = segments.some((segment) => segment.pitchDegrees !== undefined);
  const imageryQuality = normalizeImageryQuality(
    input.buildingInsights.imageryQuality,
  );

  return {
    id: newId(),
    propertyId: newId(),
    address: input.address,
    latitude: input.latitude,
    longitude: input.longitude,
    source: {
      provider: "google_solar",
      providerRequestId: input.buildingInsights.name,
      imageryDate: formatGoogleDate(input.buildingInsights.imageryDate),
      imageryProcessedDate: formatGoogleDate(
        input.buildingInsights.imageryProcessedDate,
      ),
      imageryQuality,
      fetchedAt,
      confidence: calculateOverallConfidence({
        imageryQuality,
        hasPitchData,
        segmentCount: segments.length,
      }),
      notes: ["Provider measurements are normalized for roofing review, not treated as final measurements."],
    },
    totalRoofAreaM2: totalRoofAreaM2
      ? roundTo(totalRoofAreaM2, 2)
      : undefined,
    totalRoofAreaSqft: totalRoofAreaSqft
      ? roundTo(totalRoofAreaSqft, 2)
      : undefined,
    measuredSquares: measuredSquares
      ? roundTo(measuredSquares, 2)
      : undefined,
    wasteFactor,
    orderSquares,
    segmentCount: segments.length,
    complexity: estimateComplexity(segments.length),
    segments,
    confidence: {
      overall: calculateOverallConfidence({
        imageryQuality,
        hasPitchData,
        segmentCount: segments.length,
      }),
      area: totalRoofAreaSqft ? 0.88 : 0.35,
      pitch: hasPitchData ? 0.8 : 0.4,
      linears: 0.25,
      imagery: imageryQualityConfidence(imageryQuality),
    },
    createdAt: fetchedAt,
    updatedAt: fetchedAt,
  };
}

export function m2ToSqft(areaM2: number): number {
  return areaM2 * SQFT_PER_M2;
}

export function sqftToSquares(areaSqft: number): number {
  return areaSqft / 100;
}

export function pitchDegreesToRiseOver12(degrees: number): number {
  return Math.tan((degrees * Math.PI) / 180) * 12;
}

export function pitchDegreesToLabel(degrees: number): string {
  return `${Math.round(pitchDegreesToRiseOver12(degrees))}/12`;
}

export function estimateWasteFactor(segmentCount: number): number {
  if (segmentCount <= 2) return 1.1;
  if (segmentCount <= 5) return 1.12;
  if (segmentCount <= 9) return 1.15;
  return 1.18;
}

export type RoofProbeWasteOption = {
  id: string;
  label: string;
  factor: number;
};

/** Waste multipliers for ShingleScope order-square estimates. */
export const ROOF_PROBE_WASTE_OPTIONS: RoofProbeWasteOption[] = [
  { id: "10", label: "10% — simple gable", factor: 1.1 },
  { id: "12", label: "12% — hips / moderate", factor: 1.12 },
  { id: "15", label: "15% — complex", factor: 1.15 },
  { id: "18", label: "18% — very complex", factor: 1.18 },
  { id: "20", label: "20% — extra cuts", factor: 1.2 },
];

export function wasteFactorToPercent(factor: number): number {
  return Math.round((factor - 1) * 100);
}

export function computeOrderSquares(
  measuredSquares: number | undefined,
  wasteFactor: number,
): number | undefined {
  if (measuredSquares === undefined) return undefined;
  return roundTo(measuredSquares * wasteFactor, 2);
}

export function estimateComplexity(
  segmentCount: number,
): RoofMeasurementComplexity {
  if (segmentCount === 0) return "unknown";
  if (segmentCount <= 2) return "simple";
  if (segmentCount <= 5) return "moderate";
  if (segmentCount <= 9) return "complex";
  return "very_complex";
}

function normalizeSegments(
  insights: GoogleSolarBuildingInsights,
): RoofSegment[] {
  return (insights.solarPotential?.roofSegmentStats ?? []).map(
    (segment, index) => {
      const areaM2 = segment.stats?.areaMeters2;
      const pitchDegrees = segment.pitchDegrees;
      return {
        id: newId(),
        providerSegmentId: `${insights.name ?? "google-solar"}:segment:${index + 1}`,
        areaM2,
        areaSqft: areaM2 ? roundTo(m2ToSqft(areaM2), 2) : undefined,
        pitchDegrees,
        pitchRiseOver12: pitchDegrees
          ? roundTo(pitchDegreesToRiseOver12(pitchDegrees), 2)
          : undefined,
        pitchLabel: pitchDegrees ? pitchDegreesToLabel(pitchDegrees) : undefined,
        azimuthDegrees: segment.azimuthDegrees,
        orientationLabel: orientationFromAzimuth(segment.azimuthDegrees),
        center: normalizeLatLng(segment.center),
        boundingBox: normalizeBoundingBox(segment.boundingBox),
        planeHeightAtCenterMeters: segment.planeHeightAtCenterMeters,
        confidence: pitchDegrees && areaM2 ? 0.82 : 0.55,
        source: "google_solar",
      };
    },
  );
}

function normalizeLatLng(value?: GoogleLatLng): LatLng | undefined {
  if (typeof value?.latitude !== "number" || typeof value.longitude !== "number") {
    return undefined;
  }
  return {
    latitude: value.latitude,
    longitude: value.longitude,
  };
}

function normalizeBoundingBox(
  value?: GoogleBoundingBox,
): RoofBoundingBox | undefined {
  const sw = normalizeLatLng(value?.sw);
  const ne = normalizeLatLng(value?.ne);
  if (!sw || !ne) return undefined;
  return { sw, ne };
}

function normalizeImageryQuality(value?: string): RoofImageryQuality {
  if (value === "HIGH" || value === "MEDIUM" || value === "LOW") return value;
  return "UNKNOWN";
}

function calculateOverallConfidence(input: {
  imageryQuality: RoofImageryQuality;
  hasPitchData: boolean;
  segmentCount: number;
}): number {
  let score = imageryQualityConfidence(input.imageryQuality);
  if (!input.hasPitchData) score -= 0.2;
  if (input.segmentCount === 0) score -= 0.25;
  if (input.segmentCount > 9) score -= 0.1;
  return clamp(score, 0, 1);
}

function imageryQualityConfidence(value: RoofImageryQuality): number {
  if (value === "HIGH") return 0.9;
  if (value === "MEDIUM") return 0.75;
  if (value === "LOW") return 0.55;
  return 0.5;
}

function orientationFromAzimuth(value?: number): RoofOrientationLabel {
  if (typeof value !== "number") return "UNKNOWN";
  const labels: RoofOrientationLabel[] = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  const normalized = ((value % 360) + 360) % 360;
  return labels[Math.round(normalized / 45) % 8] ?? "UNKNOWN";
}

function formatGoogleDate(value?: GoogleDate): string | undefined {
  if (!value?.year || !value.month || !value.day) return undefined;
  return [
    value.year,
    String(value.month).padStart(2, "0"),
    String(value.day).padStart(2, "0"),
  ].join("-");
}

function sumNumbers(values: Array<number | undefined>): number | undefined {
  const numbers = values.filter((value): value is number => typeof value === "number");
  if (!numbers.length) return undefined;
  return numbers.reduce((total, value) => total + value, 0);
}

function roundTo(value: number, digits: number): number {
  const multiplier = 10 ** digits;
  return Math.round(value * multiplier) / multiplier;
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}
