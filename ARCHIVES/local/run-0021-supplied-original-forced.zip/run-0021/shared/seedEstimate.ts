import type { Job, RoofArea, RoofingScope } from "./types"
import { newDraftJob } from "./job"

export function seedEstimate(): Job {
  const estimate = newDraftJob()
  const roofing = estimate.scope.roofing as RoofingScope
  const firstArea = roofing.areas[0] as RoofArea

  return {
    ...estimate,
    status: "roof-proposal",
    estimateType: "roof-proposal",
    estimator: "Sample Estimator",
    customer: {
      ...estimate.customer,
      companyName: "",
      firstName: "Sample",
      lastName: "Customer",
      address1: "123 Main St",
      city: "Des Moines",
      state: "IA",
      zip: "50309",
      phone: "555-0100"
    },
    permit: 175,
    extras: { amount: 250, description: "Starter allowance for cleanup" },
    scope: {
      roofing: {
        ...roofing,
        shingle: {
          ...roofing.shingle,
          productId: "owenscorning-duration",
          colorId: "estate-gray",
          warranty: "standard"
        },
        ridgeVentLf: 42,
        stepFlashingLf: 25,
        areas: [
          {
            ...firstArea,
            label: "House",
            location: "House",
            sizeInputMode: "dimensions",
            dimensionBasis: "surface",
            rafterFt: 42,
            eaveFt: 55,
            eaveDripStyle: "ODE Style",
            rakeDripStyle: "ODE Style",
            eaveDripLf: 55,
            rakeDripLf: 84
          }
        ]
      }
    }
  }
}
