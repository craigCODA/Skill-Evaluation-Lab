import type { RoofBoundingBox, RoofImageryGeoref } from "./types";
import { previewMetersPerPixel } from "./roofImageryGeoref";

const METERS_PER_DEGREE_LAT = 111_320;
const FEET_PER_METER = 3.28084;

export type RoofImageryCrop = {
  cx: number;
  cy: number;
  size: number;
};

/** @deprecated Prefer georef-based scale; lat/lng bounds are inaccurate for UTM rasters. */
export function boundsSpanFeet(bounds: RoofBoundingBox): {
  widthFt: number;
  heightFt: number;
} {
  const lat = (bounds.sw.latitude + bounds.ne.latitude) / 2;
  const mPerLng = METERS_PER_DEGREE_LAT * Math.cos((lat * Math.PI) / 180);
  const widthM = Math.abs(bounds.ne.longitude - bounds.sw.longitude) * mPerLng;
  const heightM = Math.abs(bounds.ne.latitude - bounds.sw.latitude) * METERS_PER_DEGREE_LAT;
  return {
    widthFt: widthM * FEET_PER_METER,
    heightFt: heightM * FEET_PER_METER,
  };
}

/** Feet across the visible (cropped) preview frame width. */
export function croppedFrameWidthFeet(
  georef: RoofImageryGeoref,
  crop: RoofImageryCrop,
): number {
  return georef.widthMeters * FEET_PER_METER * crop.size;
}

/** Feet across the visible (cropped) preview frame height. */
export function croppedFrameHeightFeet(
  georef: RoofImageryGeoref,
  crop: RoofImageryCrop,
): number {
  return georef.heightMeters * FEET_PER_METER * crop.size;
}

export function previewFeetPerPixel(georef: RoofImageryGeoref): {
  x: number;
  y: number;
} {
  const meters = previewMetersPerPixel(georef);
  return {
    x: meters.x * FEET_PER_METER,
    y: meters.y * FEET_PER_METER,
  };
}

export type FramePoint = { x: number; y: number };

/** Distance between two points in frame percent coords (0–100). */
export function frameDistanceFeet(
  start: FramePoint,
  end: FramePoint,
  frameWidthFeet: number,
  frameHeightFeet: number,
): number {
  const dx = ((end.x - start.x) / 100) * frameWidthFeet;
  const dy = ((end.y - start.y) / 100) * frameHeightFeet;
  return Math.sqrt(dx * dx + dy * dy);
}

export function frameMidpoint(start: FramePoint, end: FramePoint): FramePoint {
  return { x: (start.x + end.x) / 2, y: (start.y + end.y) / 2 };
}

/** Scale bar length as a % of the preview frame width. */
export function scaleBarWidthPercent(
  feet: number,
  frameWidthFeet: number,
): number {
  if (frameWidthFeet <= 0 || feet <= 0) return 0;
  return Math.min(100, (feet / frameWidthFeet) * 100);
}
