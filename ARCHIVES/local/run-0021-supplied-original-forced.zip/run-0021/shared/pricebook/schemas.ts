/**
 * Zod schemas for catalog JSON files.
 *
 * These schemas validate the catalog JSON files. Run validation at load time
 * so malformed data fails fast at the source instead of surfacing as
 * mysterious bugs later in pricing logic.
 */

import { z } from "zod";

export const ShingleTypeSchema = z.enum([
  "asphalt",
  "steel",
  "cedar",
  "slate",
  "davinci",
]);

export const WarrantyTierSchema = z.enum([
  "standard",
  "oc-system-advantage",
  "oc-preferred",
  "oc-platinum",
  "gaf-system-plus",
  "gaf-golden-pledge",
]);

export const ShingleColorSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  line: z.string().optional(),
});

export const ShingleProductSchema = z.object({
  id: z.string().min(1),
  type: ShingleTypeSchema,
  manufacturer: z.string().min(1),
  variety: z.string().min(1),
  pricePerSquare: z.number(),
  /** True when a real price has not been set for this variety. */
  unpriced: z.boolean().optional(),
  colors: z.array(ShingleColorSchema).default([]),
  allowedWarranties: z.array(WarrantyTierSchema).default([]),
  fastenerUpcharges: z.record(z.string(), z.number()).optional(),
});

export const WarrantyUpchargeSchema = z.object({
  tier: WarrantyTierSchema,
  displayName: z.string().min(1),
  perSquare: z.number(),
});

export const ShinglesFileSchema = z.array(ShingleProductSchema);
export const WarrantyUpchargesFileSchema = z.array(WarrantyUpchargeSchema);

export type ShingleProductData = z.infer<typeof ShingleProductSchema>;
export type WarrantyUpchargeData = z.infer<typeof WarrantyUpchargeSchema>;

// ---------------------------------------------------------------------------
// Per-area roofing rate tables (story, pitch, tearoff by layers)
// ---------------------------------------------------------------------------

/**
 * A simple (label, ratePerSqft) pair. Used for story difficulty, pitch
 * difficulty, and tearoff rate by existing-layer count. Labels match the
 * picker values ("1S", "1.5S", "Walk", "7/12", "1C", "2C+1W", ...).
 */
const RateRowSchema = z.object({
  key: z.string().min(1),
  ratePerSqft: z.number(),
});

export const StoryRateSchema = RateRowSchema;
export const PitchRateSchema = RateRowSchema;
export const TearoffRateSchema = RateRowSchema;
export const RedeckRateSchema = RateRowSchema;

export const StoryRatesFileSchema = z.array(StoryRateSchema);
export const PitchRatesFileSchema = z.array(PitchRateSchema);
export const TearoffRatesFileSchema = z.array(TearoffRateSchema);
export const RedeckRatesFileSchema = z.array(RedeckRateSchema);

export type RateRowData = z.infer<typeof RateRowSchema>;

// ---------------------------------------------------------------------------
// Drip edge styles
// ---------------------------------------------------------------------------

export const DripEdgeAppliesToSchema = z.enum(["eave", "rake", "either"]);

export const DripEdgeStyleSchema = z.object({
  key: z.string().min(1),
  pricePerFoot: z.number(),
  appliesTo: DripEdgeAppliesToSchema,
});

export const DripEdgeStylesFileSchema = z.array(DripEdgeStyleSchema);

export type DripEdgeStyleData = z.infer<typeof DripEdgeStyleSchema>;

// ---------------------------------------------------------------------------
// Underlayment options
// ---------------------------------------------------------------------------

export const FeltTypeSchema = z.enum([
  "none",
  "15-single",
  "30-single",
  "15-double",
]);

export const UnderlaymentOptionSchema = z.object({
  key: z.string().min(1),
  pricePerSquare: z.number(),
  feltType: FeltTypeSchema,
});

export const UnderlaymentsFileSchema = z.array(UnderlaymentOptionSchema);

export type UnderlaymentOptionData = z.infer<typeof UnderlaymentOptionSchema>;

// ---------------------------------------------------------------------------
// Ridge rates (per linear foot)
// ---------------------------------------------------------------------------

export const RidgeRateSchema = z.object({
  key: z.string().min(1),
  pricePerFoot: z.number(),
});

export const RidgeRatesFileSchema = z.array(RidgeRateSchema);

export type RidgeRateData = z.infer<typeof RidgeRateSchema>;

// ---------------------------------------------------------------------------
// Flashing rates (per linear foot)
// ---------------------------------------------------------------------------

export const FlashingRateSchema = z.object({
  key: z.string().min(1),
  pricePerFoot: z.number(),
});

export const FlashingRatesFileSchema = z.array(FlashingRateSchema);

export type FlashingRateData = z.infer<typeof FlashingRateSchema>;

// ---------------------------------------------------------------------------
// Chimney removal options (flat $ per chimney)
// ---------------------------------------------------------------------------

export const ChimneyRemovalOptionSchema = z.object({
  key: z.string().min(1),
  price: z.number(),
});

export const ChimneyRemovalOptionsFileSchema = z.array(
  ChimneyRemovalOptionSchema,
);

export type ChimneyRemovalOptionData = z.infer<
  typeof ChimneyRemovalOptionSchema
>;

export const ChimneyKitOptionSchema = z.object({
  key: z.string().min(1),
  price: z.number(),
});
export const ChimneyKitOptionsFileSchema = z.array(ChimneyKitOptionSchema);
export type ChimneyKitOptionData = z.infer<typeof ChimneyKitOptionSchema>;

export const AccessoryRateSchema = z.object({
  key: z.string().min(1),
  label: z.string().min(1),
  pricePerUnit: z.number(),
});
export const AccessoryRatesFileSchema = z.array(AccessoryRateSchema);
export type AccessoryRateData = z.infer<typeof AccessoryRateSchema>;

const KeyPriceSchema = z.object({
  key: z.string().min(1),
  price: z.number(),
});

export const SatelliteOptionSchema = KeyPriceSchema;
export const SatelliteOptionsFileSchema = z.array(SatelliteOptionSchema);
export type SatelliteOptionData = z.infer<typeof SatelliteOptionSchema>;

export const AntennaOptionSchema = KeyPriceSchema;
export const AntennaOptionsFileSchema = z.array(AntennaOptionSchema);
export type AntennaOptionData = z.infer<typeof AntennaOptionSchema>;

export const LightningRodOptionSchema = KeyPriceSchema;
export const LightningRodOptionsFileSchema = z.array(LightningRodOptionSchema);
export type LightningRodOptionData = z.infer<typeof LightningRodOptionSchema>;

export const SkylightOptionSchema = KeyPriceSchema;
export const SkylightOptionsFileSchema = z.array(SkylightOptionSchema);
export type SkylightOptionData = z.infer<typeof SkylightOptionSchema>;

export const LowSlopeOptionSchema = z.object({
  key: z.string().min(1),
  pricePerSquare: z.number(),
});
export const LowSlopeOptionsFileSchema = z.array(LowSlopeOptionSchema);
export type LowSlopeOptionData = z.infer<typeof LowSlopeOptionSchema>;

export const ValleyMetalRateSchema = z.object({
  key: z.string().min(1),
  pricePerFoot: z.number(),
});
export const ValleyMetalRatesFileSchema = z.array(ValleyMetalRateSchema);
export type ValleyMetalRateData = z.infer<typeof ValleyMetalRateSchema>;

export const NoAccessRateSchema = z.object({
  key: z.string().min(1),
  pricePerSquare: z.number(),
});
export const NoAccessRatesFileSchema = z.array(NoAccessRateSchema);
export type NoAccessRateData = z.infer<typeof NoAccessRateSchema>;

export const GutterRemovalRateSchema = z.object({
  key: z.string().min(1),
  pricePerFoot: z.number(),
});
export const GutterRemovalRatesFileSchema = z.array(GutterRemovalRateSchema);
export type GutterRemovalRateData = z.infer<typeof GutterRemovalRateSchema>;

// ---------------------------------------------------------------------------
// Ice & water shield (picker options + per-LF rates + overhang lookup)
// ---------------------------------------------------------------------------

export const IceWaterOptionSchema = z.object({
  key: z.string().min(1),
  coversEaves: z.boolean(),
  coversValleys: z.boolean(),
  pricePerSquare: z.number(),
});
export const IceWaterOptionsFileSchema = z.array(IceWaterOptionSchema);
export type IceWaterOptionData = z.infer<typeof IceWaterOptionSchema>;

export const IceWaterRateSchema = z.object({
  key: z.string().min(1),
  pricePerFoot: z.number(),
});
export const IceWaterRatesFileSchema = z.array(IceWaterRateSchema);
export type IceWaterRateData = z.infer<typeof IceWaterRateSchema>;

export const IceWaterOverhangSchema = z.object({
  key: z.string().min(1),
  rows: z.number(),
});
export const IceWaterOverhangsFileSchema = z.array(IceWaterOverhangSchema);
export type IceWaterOverhangData = z.infer<typeof IceWaterOverhangSchema>;

// ---------------------------------------------------------------------------
// Materials take-off rates (LF/bundle, sf/sheet, waste factor, etc.)
// ---------------------------------------------------------------------------

export const MaterialsRateSchema = z.object({
  key: z.string().min(1),
  value: z.number(),
  unit: z.string().min(1),
});
export const MaterialsRatesFileSchema = z.array(MaterialsRateSchema);
export type MaterialsRateData = z.infer<typeof MaterialsRateSchema>;
