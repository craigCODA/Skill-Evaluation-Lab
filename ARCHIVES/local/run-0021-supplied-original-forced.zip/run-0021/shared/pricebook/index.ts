/**
 * Catalog loader.
 *
 * Reads JSON files under `./data/` and validates them with the Zod schemas
 * in `./schemas`. These files provide a checked fallback shape for catalog
 * data until production pricing moves to PostgreSQL.
 */

import type { Catalog } from "./types";
import {
  ShinglesFileSchema,
  WarrantyUpchargesFileSchema,
  StoryRatesFileSchema,
  PitchRatesFileSchema,
  TearoffRatesFileSchema,
  RedeckRatesFileSchema,
  DripEdgeStylesFileSchema,
  UnderlaymentsFileSchema,
  RidgeRatesFileSchema,
  FlashingRatesFileSchema,
  ChimneyRemovalOptionsFileSchema,
  ChimneyKitOptionsFileSchema,
  AccessoryRatesFileSchema,
  SatelliteOptionsFileSchema,
  AntennaOptionsFileSchema,
  LightningRodOptionsFileSchema,
  SkylightOptionsFileSchema,
  LowSlopeOptionsFileSchema,
  ValleyMetalRatesFileSchema,
  MaterialsRatesFileSchema,
  NoAccessRatesFileSchema,
  GutterRemovalRatesFileSchema,
  IceWaterOptionsFileSchema,
  IceWaterRatesFileSchema,
  IceWaterOverhangsFileSchema,
} from "./schemas";
import belaforteShinglesJson from "./data/shingles-belaforte.json";
import certainteedShinglesJson from "./data/shingles-certainteed.json";
import gafShinglesJson from "./data/shingles-gaf.json";
import ikoShinglesJson from "./data/shingles-iko.json";
import metalRoofShinglesJson from "./data/shingles-metalroof.json";
import owensCorningShinglesJson from "./data/shingles-owenscorning.json";
import steadfastShinglesJson from "./data/shingles-steadfast.json";
import stoneCoatedMetalShinglesJson from "./data/shingles-stonecoatedmetal.json";
import tamkoShinglesJson from "./data/shingles-tamko.json";
import vermontShinglesJson from "./data/shingles-vermont.json";
import warrantyJson from "./data/warrantyUpcharges.json";
import storyRatesJson from "./data/storyRates.json";
import pitchRatesJson from "./data/pitchRates.json";
import tearoffRatesJson from "./data/tearoffRates.json";
import redeckRatesJson from "./data/redeckRates.json";
import dripEdgeJson from "./data/dripEdgeStyles.json";
import underlaymentsJson from "./data/underlayments.json";
import ridgeRatesJson from "./data/ridgeRates.json";
import flashingRatesJson from "./data/flashingRates.json";
import chimneyRemovalJson from "./data/chimneyRemovalOptions.json";
import chimneyKitJson from "./data/chimneyKitOptions.json";
import accessoryRatesJson from "./data/accessoryRates.json";
import satelliteOptionsJson from "./data/satelliteOptions.json";
import antennaOptionsJson from "./data/antennaOptions.json";
import lightningRodOptionsJson from "./data/lightningRodOptions.json";
import skylightOptionsJson from "./data/skylightOptions.json";
import lowSlopeOptionsJson from "./data/lowSlopeOptions.json";
import valleyMetalRatesJson from "./data/valleyMetalRates.json";
import materialsRatesJson from "./data/materialsRates.json";
import noAccessRatesJson from "./data/noAccessRates.json";
import gutterRemovalRatesJson from "./data/gutterRemovalRates.json";
import iceWaterOptionsJson from "./data/iceWaterOptions.json";
import iceWaterRatesJson from "./data/iceWaterRates.json";
import iceWaterOverhangsJson from "./data/iceWaterOverhangs.json";

let cached: Catalog | null = null;

export function loadCatalog(): Catalog {
  if (cached) return cached;

  const shingles = ShinglesFileSchema.parse([
    ...belaforteShinglesJson,
    ...certainteedShinglesJson,
    ...gafShinglesJson,
    ...ikoShinglesJson,
    ...metalRoofShinglesJson,
    ...owensCorningShinglesJson,
    ...steadfastShinglesJson,
    ...stoneCoatedMetalShinglesJson,
    ...tamkoShinglesJson,
    ...vermontShinglesJson,
  ]);
  const warrantyUpcharges = WarrantyUpchargesFileSchema.parse(warrantyJson);
  const storyRates = StoryRatesFileSchema.parse(storyRatesJson);
  const pitchRates = PitchRatesFileSchema.parse(pitchRatesJson);
  const tearoffRates = TearoffRatesFileSchema.parse(tearoffRatesJson);
  const redeckRates = RedeckRatesFileSchema.parse(redeckRatesJson);
  const dripEdgeStyles = DripEdgeStylesFileSchema.parse(dripEdgeJson);
  const underlayments = UnderlaymentsFileSchema.parse(underlaymentsJson);
  const ridgeRates = RidgeRatesFileSchema.parse(ridgeRatesJson);
  const flashingRates = FlashingRatesFileSchema.parse(flashingRatesJson);
  const chimneyRemovalOptions =
    ChimneyRemovalOptionsFileSchema.parse(chimneyRemovalJson);
  const chimneyKitOptions =
    ChimneyKitOptionsFileSchema.parse(chimneyKitJson);
  const accessoryRates = AccessoryRatesFileSchema.parse(accessoryRatesJson);
  const satelliteOptions =
    SatelliteOptionsFileSchema.parse(satelliteOptionsJson);
  const antennaOptions = AntennaOptionsFileSchema.parse(antennaOptionsJson);
  const lightningRodOptions = LightningRodOptionsFileSchema.parse(
    lightningRodOptionsJson,
  );
  const skylightOptions = SkylightOptionsFileSchema.parse(skylightOptionsJson);
  const lowSlopeOptions =
    LowSlopeOptionsFileSchema.parse(lowSlopeOptionsJson);
  const valleyMetalRates =
    ValleyMetalRatesFileSchema.parse(valleyMetalRatesJson);
  const materialsRates = MaterialsRatesFileSchema.parse(materialsRatesJson);
  const noAccessRates = NoAccessRatesFileSchema.parse(noAccessRatesJson);
  const gutterRemovalRates =
    GutterRemovalRatesFileSchema.parse(gutterRemovalRatesJson);
  const iceWaterOptions = IceWaterOptionsFileSchema.parse(iceWaterOptionsJson);
  const iceWaterRates = IceWaterRatesFileSchema.parse(iceWaterRatesJson);
  const iceWaterOverhangs =
    IceWaterOverhangsFileSchema.parse(iceWaterOverhangsJson);

  cached = {
    shingles,
    warrantyUpcharges,
    storyRates,
    pitchRates,
    tearoffRates,
    redeckRates,
    dripEdgeStyles,
    ridgeRates,
    flashingRates,
    chimneyRemovalOptions,
    chimneyKitOptions,
    accessoryRates,
    satelliteOptions,
    antennaOptions,
    lightningRodOptions,
    skylightOptions,
    lowSlopeOptions,
    valleyMetalRates,
    materialsRates,
    noAccessRates,
    gutterRemovalRates,
    iceWaterOptions,
    iceWaterRates,
    iceWaterOverhangs,
    underlayments,
  };
  return cached;
}

export type { Catalog } from "./types";
