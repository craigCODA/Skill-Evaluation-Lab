/**
 * Catalog types — the product data that pricing logic looks up.
 *
 * This is the editable pricing data (rates, shingles, materials, labor, etc.).
 * Eventually this data will come from JSON files or a database; right now these
 * are just the type shapes.
 */

import type { ID, Money, WarrantyTier } from "../types";

// ============================================================================
// Shingles
// ============================================================================

export type ShingleProduct = {
  id: ID;
  type: ShingleType;
  manufacturer: string;
  variety: string;
  pricePerSquare: Money;
  /** True when a real price has not been set for this variety. */
  unpriced?: boolean;
  colors: ShingleColor[];
  /** Which warranty tiers can be attached to this product. */
  allowedWarranties: WarrantyTier[];
  /** Optional per-square upcharge when hand-nailed vs gun-nailed, etc. */
  fastenerUpcharges?: Record<string, Money>;
};

export type ShingleType = "asphalt" | "steel" | "cedar" | "slate" | "davinci";

export type ShingleColor = {
  id: ID;
  name: string;
  /** Some products gate colors by manufacturer line; keep room for that. */
  line?: string;
};

// ============================================================================
// Warranty upcharges
// ============================================================================

export type WarrantyUpcharge = {
  tier: WarrantyTier;
  /** Label shown in the picker. */
  displayName: string;
  /** Added on top of base shingle price, per square. */
  perSquare: Money;
};

// ============================================================================
// Drip edge / valleys / ridge / underlayment
// ============================================================================

export type DripEdgeStyle = {
  /** Picker label, e.g. "ODE Style", "Custom Bent". */
  key: string;
  pricePerFoot: Money;
  /** Where this style can be applied. */
  appliesTo: "eave" | "rake" | "either";
};

/**
 * Per-LF rates for ridge work. Two rows:
 *   "Ridge Vent"          → $7/ft
 *   "Cut in Ridge Vent"   → $8/ft
 */
export type RidgeRate = {
  key: string;
  pricePerFoot: Money;
};

/**
 * Per-LF flashing rates. Today this is just one row:
 *   "Step Flashing"       → $3.50/ft
 * Headwall / counter / apron flashing rates can land here later.
 */
export type FlashingRate = {
  key: string;
  pricePerFoot: Money;
};

/**
 * Chimney removal options. Flat $/chimney, keyed by picker label:
 *   "No"                          → $0
 *   "Yes - 2x2 - 4' or less"      → $200
 *   "Yes - 2x3 - 4' or less"      → $300
 *   "Yes - 2x4 - 4' or less"      → $400
 */
export type ChimneyRemovalOption = {
  key: string;
  price: Money;
};

/**
 * Chimney kit picker options. Same shape as `ChimneyRemovalOption` — a flat
 * $/unit per pick.
 */
export type ChimneyKitOption = {
  key: string;
  price: Money;
};

/**
 * Accessory line items billed as `count × pricePerUnit`. Pipe boots have
 * three sizes that all share `$50` today; they're modeled as separate catalog
 * rows so per-size rates can be edited later without code changes.
 *
 * Default rates:
 *   - 12x12-vent              $45
 *   - cut-in-12x12-vent       $60
 *   - turbine-vent            $110
 *   - power-vent              $260
 *   - eyebrow                 $50
 *   - electrical-pipe-boot    $60
 *   - pipe-boot-1to3in        $50
 *   - pipe-boot-3to4in        $50
 *   - pipe-boot-3to8in        $50
 */
export type AccessoryRate = {
  key: string;
  /** Display label for the picker / breakdown row. */
  label: string;
  pricePerUnit: Money;
};

/**
 * Satellite picker options. Four options: "No" ($0), Remove & Reattach ($55),
 * Remove & Dispose ($40), Remove & Leave with homeowner ($40).
 *
 * Keys preserve their exact strings (including trailing whitespace) so old
 * saved values and imported catalog rows keep matching.
 */
export type SatelliteOption = {
  key: string;
  price: Money;
};

/**
 * Antenna picker options. Seven options (No, plus three actions × two sizes);
 * small actions $60, large actions $120.
 */
export type AntennaOption = {
  key: string;
  price: Money;
};

/**
 * Lightning-rod picker options. Three options: "No" ($0), Yes - Reattach
 * ($200), Yes - Remove ($200).
 */
export type LightningRodOption = {
  key: string;
  price: Money;
};

/**
 * Skylight options ("Small 2x4 Fixed", "Med 3x5 Fixed", "Large- Fixed",
 * "Select Skylight"). Cost is `count × price` per row.
 */
export type SkylightOption = {
  key: string;
  price: Money;
};

/**
 * Low-slope roofing options. Values are treated as `pricePerSquare` and billed
 * as `pricePerSquare × totalSquares`. The two "Dead Valley" picks carry
 * `pricePerSquare: 0` until real rates are entered. Picker keys preserve their
 * leading whitespace verbatim for saved-data compatibility.
 */
export type LowSlopeOption = {
  key: string;
  pricePerSquare: Money;
};

/**
 * Per-LF valley metal rate ($1.50/ft today). Open valleys compute
 * `openLf × pricePerFoot`; this cost is shown in the UI but **not** rolled
 * into the grand total (it only feeds materials counts).
 */
export type ValleyMetalRate = {
  key: string;
  pricePerFoot: Money;
};

/**
 * Per-square no-access surcharge by existing-layer count. When
 * `RoofArea.access === "No Access"`, the area's squares are multiplied by the
 * rate keyed on its `layers` value (1C $24/sq, 2C $34/sq, ... Slate $74/sq).
 */
export type NoAccessRate = {
  /** Catalog key matches `LayerCount` enum (1C, 2C, 3C, 1C+1W, ...). */
  key: string;
  pricePerSquare: Money;
};

/**
 * Per-LF rate for the gutter removal / work-around charge. Stored as a
 * single-row catalog so it can be edited without code changes.
 */
export type GutterRemovalRate = {
  key: string;
  pricePerFoot: Money;
};

/**
 * Ice & water shield picker options. Only `Valleys Only` and `Valleys & Eaves`
 * are billed today; all five options ship with `pricePerSquare: 0`. Edit the
 * rate when full-surface coverage should be billed.
 *
 * Coverage flags decide which per-LF rates apply to that area:
 *   coversEaves   → eave LF × overhang-rows × eave $/ft
 *   coversValleys → valley LF × valley $/ft
 *   pricePerSquare > 0 → squares × $/sq (full surface; today always 0)
 */
export type IceWaterOption = {
  key: string;
  coversEaves: boolean;
  coversValleys: boolean;
  pricePerSquare: Money;
};

/**
 * Per-LF rates used by ice & water billing. Two rows:
 *   "eave"   → $2/ft
 *   "valley" → $1.50/ft
 */
export type IceWaterRate = {
  key: string;
  pricePerFoot: Money;
};

/**
 * Overhang → rows count lookup. Picks 1 / 1.5 / 2 rows of ice & water shield
 * based on roof overhang size; rows multiply the eave-side cost.
 */
export type IceWaterOverhang = {
  /** Picker label, e.g. `"0\""`, `"24\""`, `"48\""`. */
  key: string;
  rows: number;
};

/**
 * Maps an underlayment pick to its felt-material category. Drives the
 * 15# / 30# roll counts on the materials take-off. The category is carried on
 * the catalog row so the meaning is self-evident.
 *   "none"       → no felt rolls
 *   "15-single"  → 1 × area squares of 15# felt
 *   "30-single"  → 1 × area squares of 30# felt
 *   "15-double"  → 2 × area squares of 15# felt
 */
export type FeltType = "none" | "15-single" | "30-single" | "15-double";

export type UnderlaymentOption = {
  /** Picker label, e.g. "Standard", "30# Felt over complete roof", "None". */
  key: string;
  pricePerSquare: Money;
  /** Material kind for the take-off sheet roll counts. */
  feltType: FeltType;
};

/**
 * Per-row constants used by the materials take-off function. Each row
 * is a single named scalar (LF per bundle, sf per sheet, waste factor,
 * etc.) so non-developers can tune individual values without touching
 * code. The catalog keys are stable and looked up by name in
 * `options/materials.ts`; missing keys fall back to documented
 * defaults.
 */
export type MaterialsRate = {
  key: string;
  value: number;
  /** Display unit hint shown on the Catalog page (e.g. "ft", "sq", "sf"). */
  unit: string;
};

// ============================================================================
// Per-area roofing rate tables
// ============================================================================

/**
 * A (label, rate-per-square-foot) pair used by the per-roof-area install
 * cost calculation. Three of these tables exist, each keyed by a picker label:
 *
 *   - Story rate:   "1S" | "1.5S" | "2S" | "3S"
 *   - Pitch rate:   "Walk" | "7/12" | "Flat - TPO" | "Mansard" | ...
 *   - Tearoff rate: "-" | "1C" | "2C+1W" | "Asbestos" | ...
 */
export type RateRow = {
  key: string;
  ratePerSqft: Money;
};

// ============================================================================
// The catalog itself
// ============================================================================

export type Catalog = {
  shingles: ShingleProduct[];
  warrantyUpcharges: WarrantyUpcharge[];
  storyRates: RateRow[];
  pitchRates: RateRow[];
  tearoffRates: RateRow[];
  redeckRates: RateRow[];
  dripEdgeStyles: DripEdgeStyle[];
  ridgeRates: RidgeRate[];
  flashingRates: FlashingRate[];
  chimneyRemovalOptions: ChimneyRemovalOption[];
  chimneyKitOptions: ChimneyKitOption[];
  accessoryRates: AccessoryRate[];
  satelliteOptions: SatelliteOption[];
  antennaOptions: AntennaOption[];
  lightningRodOptions: LightningRodOption[];
  skylightOptions: SkylightOption[];
  lowSlopeOptions: LowSlopeOption[];
  valleyMetalRates: ValleyMetalRate[];
  noAccessRates: NoAccessRate[];
  gutterRemovalRates: GutterRemovalRate[];
  iceWaterOptions: IceWaterOption[];
  iceWaterRates: IceWaterRate[];
  iceWaterOverhangs: IceWaterOverhang[];
  underlayments: UnderlaymentOption[];
  materialsRates: MaterialsRate[];
};
