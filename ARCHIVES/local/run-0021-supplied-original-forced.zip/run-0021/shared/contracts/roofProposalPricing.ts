import type { RoofingEstimateTotals } from "../calculator/calculateEstimate";
import type { Job, RoofingScope } from "../types";
import type { ContractLine } from "./types";
import { compactLines, line } from "./proposalCommon";

function areaLabel(roofing: RoofingScope, index: number): string {
  const custom = roofing.areas[index]?.label?.trim();
  if (custom) return custom;
  return roofing.areas.length > 1 ? `Roof area ${index + 1}` : "Roof installation";
}

export function buildRoofPricingLines(
  job: Job,
  roofing: RoofingScope,
  totals: RoofingEstimateTotals,
): ContractLine[] {
  const lines: ContractLine[] = [];

  totals.areaCosts.forEach((areaCost, index) => {
    if (areaCost.total <= 0) return;
    const install = areaCost.install;
    const detail = [
      `${install.squares.toFixed(1)} sq`,
      areaCost.drip.total > 0 ? "drip edge" : "",
      areaCost.under.cost > 0 ? "underlayment" : "",
      areaCost.ice.total > 0 ? "ice & water" : "",
    ]
      .filter(Boolean)
      .join(", ");
    lines.push({
      label: areaLabel(roofing, index),
      value: detail,
      amount: areaCost.total,
    });
  });

  const ridge = totals.ridge;
  if (ridge.total > 0) {
    const detail = [
      ridge.ridgeVentCost > 0 ? `${roofing.ridgeVentLf} LF ridge vent` : "",
      ridge.cutInRidgeVentCost > 0
        ? `${roofing.cutInRidgeVentLf} LF cut-in vent`
        : "",
    ]
      .filter(Boolean)
      .join("; ");
    lines.push({
      label: "Ridge vent",
      value: detail,
      amount: ridge.total,
    });
  }

  if (totals.warranty.cost > 0) {
    lines.push({
      label: "Warranty upcharge",
      value: totals.warranty.displayName,
      amount: totals.warranty.cost,
    });
  }

  if (totals.stepFlash.cost > 0) {
    lines.push({
      label: "Step flashing",
      value: `${roofing.stepFlashingLf} LF`,
      amount: totals.stepFlash.cost,
    });
  }

  if (totals.chimney.cost > 0) {
    lines.push({
      label: "Chimney removal",
      value: roofing.chimneyRemoval,
      amount: totals.chimney.cost,
    });
  }

  if (totals.chimneyKit.cost > 0) {
    lines.push({
      label: "Chimney kit",
      value: roofing.chimneyKit,
      amount: totals.chimneyKit.cost,
    });
  }

  for (const accessory of totals.accessories.lines) {
    if (accessory.cost <= 0) continue;
    lines.push({
      label: accessory.label,
      value: `Qty ${accessory.count}`,
      amount: accessory.cost,
    });
  }

  if (totals.satellite.cost > 0) {
    lines.push({
      label: "Satellite dish",
      value: roofing.satellite,
      amount: totals.satellite.cost,
    });
  }

  if (totals.antenna.cost > 0) {
    lines.push({
      label: "Antenna",
      value: roofing.antenna,
      amount: totals.antenna.cost,
    });
  }

  if (totals.lightning.cost > 0) {
    lines.push({
      label: "Lightning rods",
      value: roofing.lightningRods,
      amount: totals.lightning.cost,
    });
  }

  for (const skylight of totals.skylights.lines) {
    if (skylight.cost <= 0) continue;
    lines.push({
      label: "Skylight / tube",
      value: `${skylight.count} × ${skylight.option}`,
      amount: skylight.cost,
    });
  }

  if (totals.noAccess.total > 0) {
    lines.push({
      label: "No-access surcharge",
      amount: totals.noAccess.total,
    });
  }

  if (totals.gutterRemoval.cost > 0) {
    lines.push({
      label: "Gutter removal / work-around",
      value: `${roofing.gutterRemovalLf} LF`,
      amount: totals.gutterRemoval.cost,
    });
  }

  if (totals.lowSlope.cost > 0) {
    lines.push({
      label: "Low-slope roofing",
      value: roofing.lowSlope.trim(),
      amount: totals.lowSlope.cost,
    });
  }

  if (job.permit > 0) {
    lines.push({
      label: "Building permit",
      amount: job.permit,
    });
  }

  if (job.extras.amount > 0) {
    lines.push({
      label: job.extras.description?.trim() || "Additional items",
      amount: job.extras.amount,
    });
  }

  return compactLines(lines);
}
