/**
 * Layman process narrative for roofing contract specs.
 *
 * Builds complete sentences from estimate option codes so inserted values
 * read as prose (not raw picker labels pasted mid-sentence).
 */

import type { Catalog } from "../pricebook/types"
import type { RoofArea, RoofingScope } from "../types"
import type { ContractLine } from "./types"

const LAYER_PHRASES: Record<string, string> = {
  "1C": "one composition layer",
  "2C": "two composition layers",
  "3C": "three composition layers",
  "1C+1W": "one composition layer and one wood layer",
  "2C+1W": "two composition layers and one wood layer",
  "3C+1W": "three composition layers and one wood layer",
  "1W": "one wood layer",
  Asbestos: "existing asbestos roofing",
  Slate: "existing slate roofing"
}

const ICE_WATER_PHRASES: Record<string, string> = {
  "Valleys Only": "in the valleys",
  "Valleys & Eaves": "in the valleys and along the eaves",
  "Complete Surface": "over the complete roof surface",
  "Complete Surface HIGH TEMP": "over the complete roof surface with high-temperature ice and water shield"
}

const UNDERLAYMENT_PHRASES: Record<string, string> = {
  Standard: "standard felt underlayment",
  "30# Felt over complete roof": "30# felt underlayment over the complete roof",
  None: ""
}

const RIDGE_STYLE_PHRASES: Record<string, string> = {
  "new-standard": "standard ridge cap",
  "new-high-hip": "high-hip ridge cap"
}

const STARTER_PHRASES: Record<string, string> = {
  roll: "roll starter",
  preform: "preformed starter"
}

const FASTENER_PHRASES: Record<string, string> = {
  "galvanized-6": "six galvanized nails per shingle",
  "hand-nail-6": "six hand nails per shingle"
}

const MANUFACTURER_PHRASES: Record<string, string> = {
  OwensCorning: "Owens Corning",
  GAF: "GAF",
  CertainTeed: "CertainTeed",
  IKO: "IKO",
  Tamko: "Tamko",
  Belaforte: "Belaforte",
  Steadfast: "Steadfast",
  Vermont: "Vermont"
}

function tidy(value: string): string {
  return value.replace(/\s+/g, " ").trim().replace(/[.,;:\s]+$/, "")
}

/** Finish one clause as a sentence. */
function sentence(text: string): string {
  const cleaned = text.replace(/\s+/g, " ").trim()
  if (!cleaned) return ""
  const capped = cleaned.replace(/^([a-z])/, (match) => match.toUpperCase())
  return /[.!?]$/.test(capped) ? capped : `${capped}.`
}

/** Join already-written clauses into one or more finished sentences. */
function sentences(...parts: Array<string | false | null | undefined>): string {
  return parts
    .filter((part): part is string => Boolean(part && String(part).trim()))
    .map((part) => sentence(part))
    .join(" ")
}

function productPhrase(roofing: RoofingScope, catalog: Catalog): string {
  const shingle = catalog.shingles.find((item) => item.id === roofing.shingle.productId)
  if (!shingle) return "architectural asphalt shingles"
  const maker = MANUFACTURER_PHRASES[shingle.manufacturer] ?? shingle.manufacturer
  return `${maker} ${shingle.variety}`
}

function colorPhrase(roofing: RoofingScope, catalog: Catalog): string {
  const shingle = catalog.shingles.find((item) => item.id === roofing.shingle.productId)
  const color = shingle?.colors.find((item) => item.id === roofing.shingle.colorId)
  if (!color?.name) return "in a color to be selected"
  return `in ${color.name}`
}

function warrantyPhrase(roofing: RoofingScope, catalog: Catalog): string {
  const warranty = catalog.warrantyUpcharges.find(
    (item) => item.tier === roofing.shingle.warranty
  )
  const name = warranty?.displayName?.trim() || "Standard"
  if (/warranty/i.test(name)) return `the ${name}`
  if (/^standard$/i.test(name)) return "a standard manufacturer warranty"
  return `the ${name} warranty`
}

function areaLabel(area: RoofArea, index: number, total: number): string {
  const label = area.label?.trim()
  if (label) return label
  if (total <= 1) return "the house"
  return `Area ${index + 1}`
}

function layerPhrase(layers: string | undefined): string | null {
  const key = String(layers || "").trim()
  if (!key || key === "-" || key === "0") return null
  return LAYER_PHRASES[key] ?? `${key} of existing roofing`
}

function iceWaterPhrase(option: string | undefined): string | null {
  const key = String(option || "").trim()
  if (!key || key === "None" || key === "NA" || key === "Select") return null
  return ICE_WATER_PHRASES[key] ?? `per the ${key} ice and water option`
}

function underlaymentPhrase(option: string | undefined): string | null {
  const key = String(option || "").trim()
  if (!key) return null
  if (key in UNDERLAYMENT_PHRASES) {
    const mapped = UNDERLAYMENT_PHRASES[key]
    return mapped || null
  }
  if (/underlayment/i.test(key)) return key
  return `${key} underlayment`
}

function dripEdgePhrase(area: RoofArea): string | null {
  const eaveLf = Number(area.eaveDripLf) || 0
  const rakeLf = Number(area.rakeDripLf) || 0
  if (eaveLf <= 0 && rakeLf <= 0) return null
  const eaveStyle = tidy(String(area.eaveDripStyle || "drip edge"))
  const rakeStyle = tidy(String(area.rakeDripStyle || "drip edge"))
  if (eaveLf > 0 && rakeLf > 0 && eaveStyle === rakeStyle) {
    return `Install ${eaveStyle} drip edge — ${eaveLf} LF at the eaves and ${rakeLf} LF at the rakes`
  }
  const bits = [
    eaveLf > 0 ? `${eaveLf} LF of ${eaveStyle} at the eaves` : "",
    rakeLf > 0 ? `${rakeLf} LF of ${rakeStyle} at the rakes` : ""
  ].filter(Boolean)
  return `Install drip edge — ${bits.join(", and ")}`
}

function satelliteSentence(option: string): string {
  const key = tidy(option).toLowerCase()
  if (key.includes("dispose")) {
    return "Remove and dispose of the existing satellite dish"
  }
  if (key.includes("leave with homeowner")) {
    return "Remove the satellite dish and leave it with the homeowner"
  }
  if (key.includes("reattach") || key.includes("re-attach")) {
    return "Remove and reattach the satellite dish; we will align it to the best of our ability, and the homeowner remains responsible for any final signal service"
  }
  return "Include the selected satellite dish work; the homeowner remains responsible for any final signal service"
}

function antennaSentence(option: string): string {
  const key = tidy(option).toLowerCase()
  if (key.includes("leave") && key.includes("place")) {
    return `Leave the existing antenna in place (${tidy(option)})`
  }
  if (key.includes("dispose")) {
    return "Remove and dispose of the existing antenna"
  }
  if (key.includes("leave with homeowner") || key.includes("leave antenna with")) {
    return "Remove the antenna and leave it with the homeowner"
  }
  return `Handle the antenna as scoped: ${tidy(option)}`
}

function buildAreaParagraph(
  area: RoofArea,
  index: number,
  total: number
): string {
  const name = areaLabel(area, index, total)
  const clauses: string[] = []

  const layers = layerPhrase(area.layers)
  if (layers) {
    if (layers.startsWith("existing")) {
      clauses.push(`Remove ${layers} from ${name}`)
    } else {
      clauses.push(`Remove approximately ${layers} of existing roofing from ${name}`)
    }
  } else {
    clauses.push(`Prepare ${name} for recover without a full tear-off`)
  }

  if (area.redeck && area.redeck !== "No") {
    const pitch = tidy(area.redeck.replace(/^Yes\s*-\s*/i, ""))
    clauses.push(
      pitch
        ? `replace deteriorated decking as needed on ${pitch.toLowerCase()} areas`
        : "replace deteriorated decking as needed"
    )
  }

  const ice = iceWaterPhrase(area.iceWaterOption)
  if (ice) {
    clauses.push(`install ice and water shield ${ice}`)
  }

  const underlayment = underlaymentPhrase(area.underlayment)
  if (underlayment) {
    clauses.push(`install ${underlayment} over the prepared deck`)
  }

  const drip = dripEdgePhrase(area)
  // Drip edge is its own sentence — keep area paragraph for tear-off through underlayment.
  let text = sentence(clauses.join("; "))
  if (drip) {
    text = `${text} ${sentence(drip)}`
  }
  return text
}

/**
 * Verb-led process narrative for "Specifications of Work to Be Completed".
 */
export function buildRoofProcessNarrativeLines(
  roofing: RoofingScope,
  catalog: Catalog
): ContractLine[] {
  const product = productPhrase(roofing, catalog)
  const color = colorPhrase(roofing, catalog)
  const warranty = warrantyPhrase(roofing, catalog)
  const fastener =
    FASTENER_PHRASES[roofing.shingle.fastener] ?? tidy(String(roofing.shingle.fastener))
  const starter =
    STARTER_PHRASES[roofing.starterType ?? "preform"] ?? "starter"
  const ridgeStyle =
    RIDGE_STYLE_PHRASES[roofing.ridgeStyle] ?? "ridge cap"

  const paragraphs: string[] = []

  paragraphs.push(
    sentences(
      `We will recover the roof with ${product} ${color}, covered by ${warranty}`,
      `Shingles will be fastened with ${fastener}`
    )
  )

  for (const [index, area] of roofing.areas.entries()) {
    paragraphs.push(buildAreaParagraph(area, index, roofing.areas.length))
  }

  paragraphs.push(
    sentence(`Install ${starter} along the eaves and rakes as required for this roof`)
  )

  const valleyLf =
    roofing.valleys.style === "open"
      ? roofing.valleys.openLf
      : roofing.valleys.closedLf
  if (valleyLf > 0) {
    const style =
      roofing.valleys.style === "open"
        ? "open metal valleys"
        : "half-lace valleys over ice and water shield"
    paragraphs.push(sentence(`Install ${valleyLf} LF of ${style}`))
  }

  if (roofing.ridgeLf > 0) {
    paragraphs.push(sentence(`Install ${roofing.ridgeLf} LF of new ${ridgeStyle}`))
  }

  if (roofing.ridgeVentLf > 0 && roofing.cutInRidgeVentLf > 0) {
    paragraphs.push(
      sentence(
        `Install ${roofing.ridgeVentLf} LF of ridge vent and ${roofing.cutInRidgeVentLf} LF of cut-in ridge vent`
      )
    )
  } else if (roofing.ridgeVentLf > 0) {
    paragraphs.push(sentence(`Install ${roofing.ridgeVentLf} LF of ridge vent`))
  } else if (roofing.cutInRidgeVentLf > 0) {
    paragraphs.push(sentence(`Install ${roofing.cutInRidgeVentLf} LF of cut-in ridge vent`))
  }

  if (roofing.stepFlashingLf > 0) {
    paragraphs.push(
      sentence(
        `Install ${roofing.stepFlashingLf} LF of step flashing where walls meet the roof`
      )
    )
  }

  if (roofing.hipLf && roofing.hipLf > 0) {
    paragraphs.push(sentence(`Include ${roofing.hipLf} LF of hip as measured for this roof`))
  }

  if (roofing.chimneyRemoval && roofing.chimneyRemoval !== "No") {
    paragraphs.push(
      sentences(
        "Remove the chimney below the roofline as scoped",
        "The owner assumes responsibility for its non-venting status"
      )
    )
  }
  if (roofing.chimneyKit && roofing.chimneyKit !== "No Kit") {
    paragraphs.push(sentence(`Install a chimney kit (${tidy(roofing.chimneyKit)})`))
  }

  if (roofing.satellite && roofing.satellite !== "No") {
    paragraphs.push(sentence(satelliteSentence(roofing.satellite)))
  }

  if (roofing.antenna && roofing.antenna !== "No") {
    paragraphs.push(sentence(antennaSentence(roofing.antenna)))
  }

  if (roofing.lightningRods && roofing.lightningRods !== "No") {
    paragraphs.push(
      sentences(
        "Reattach lightning rods as scoped",
        "We are not responsible for system operation and recommend a licensed professional inspect the system afterward"
      )
    )
  }

  if (roofing.workAroundGutters === "Yes") {
    const lf = Number(roofing.gutterRemovalLf) || 0
    if (lf > 0) {
      paragraphs.push(
        sentences(
          `Remove and dispose of approximately ${lf} LF of existing gutters`,
          "Protect adjacent surfaces during tear-off"
        )
      )
    } else {
      paragraphs.push(
        sentences(
          "Work around existing strapped gutters during tear-off, protecting them with plywood where needed",
          "No guarantee is made to gutter performance when gutters are not being replaced"
        )
      )
    }
  }

  const lowSlope = tidy(String(roofing.lowSlope || ""))
  if (lowSlope && lowSlope !== "NA" && !/^select/i.test(lowSlope)) {
    paragraphs.push(sentence(`Complete low-slope work as scoped: ${lowSlope}`))
  }

  for (const row of roofing.skylights) {
    if (row.count <= 0) continue
    const opt = catalog.skylightOptions.find((item) => item.key === row.option)
    if (!opt || opt.key === "Select Skylight") continue
    const unit = row.count === 1 ? "unit" : "units"
    paragraphs.push(
      sentence(`Include ${row.count} ${unit} of ${tidy(opt.key)} skylight or tube work`)
    )
  }

  for (const accessory of roofing.accessories) {
    if (accessory.count <= 0) continue
    const rate = catalog.accessoryRates.find((item) => item.key === accessory.key)
    const label = tidy(rate?.label ?? accessory.key)
    const unit = accessory.count === 1 ? "unit" : "units"
    paragraphs.push(sentence(`Install ${accessory.count} ${unit} of ${label}`))
  }

  paragraphs.push(
    sentence(
      "Seal around vents, pipes, and flashings; furnish material and labor for the scope above; clean up daily; haul debris; clear roofing debris from gutters; and roll the yard with a magnetic roller"
    )
  )

  if (roofing.areas.some((area) => area.redeck && area.redeck !== "No")) {
    paragraphs.push(
      sentence(
        "Additional wood replacement found after tear-off that is not listed above is an extra charge and will be reviewed with the owner before proceeding"
      )
    )
  }

  return paragraphs.filter(Boolean).map((label) => ({ label }))
}
