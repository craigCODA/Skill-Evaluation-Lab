import { formatCustomerName } from "../customer";
import type { Catalog } from "../pricebook/types";
import type { RoofingEstimateTotals } from "../calculator/calculateEstimate";
import type { CompanyProfile, Job } from "../types";
import type { ContractParty } from "./contractParty";
import { contractParty } from "./contractParty";
import type { ContractDocument } from "./types";
import {
  commonProposalHeader,
  compactLines,
  documentHeader,
  jobAddress,
  line,
  mailingAddress,
  cityStateZip,
  proposalPaymentTerms,
  signatureSection,
} from "./proposalCommon";
import { buildRoofProposal } from "./roofProposalDocument";

type ContractContext = {
  job: Job;
  catalog: Catalog;
  roofingTotals: RoofingEstimateTotals;
  companyProfile: CompanyProfile | null;
  platformProfile?: CompanyProfile | null;
};

export function buildProposalDocuments(ctx: ContractContext): ContractDocument[] {
  const party = contractParty(
    ctx.companyProfile,
    ctx.platformProfile,
    ctx.job.customer.state,
  );
  return [
    buildRoofProposal(ctx, party),
    buildMiscProposal(ctx, 1, party),
    buildMiscProposal(ctx, 2, party),
    buildPunchlistRepair(ctx, party),
    buildTemporaryRepair(ctx, party),
    buildInvoice(ctx, party),
    buildTemporaryInvoice(ctx, party),
    buildLienWaiver(ctx, party),
    buildMaintenanceAgreement(ctx, party),
    buildRoofOrderForm(ctx, party),
  ];
}

export function buildInvoice(
  { job, roofingTotals }: ContractContext,
  party: ContractParty,
): ContractDocument {
  return {
    kind: "invoice",
    title: "Invoice",
    header: documentHeader(job, party),
    sections: [
      {
        title: "Bill To / Job Location",
        lines: [
          line("Bill To", formatCustomerName(job.customer)),
          line("Bill To Address", mailingAddress(job)),
          line("Job Location", jobAddress(job)),
          line("Salesman", job.estimator),
        ],
      },
      {
        title: "Completed Contracts",
        lines: [
          {
            label: "Roof - to be billed upon completion",
            amount: roofingTotals.grandTotal,
          },
        ],
      },
      {
        title: "Totals",
        lines: [
          { label: "Sub-Total", amount: roofingTotals.grandTotal },
          { label: "Payment Received", amount: 0 },
          { label: "Total Due", amount: roofingTotals.grandTotal },
        ],
      },
    ],
    total: roofingTotals.grandTotal,
  };
}

export function buildTemporaryInvoice(
  ctx: ContractContext,
  party: ContractParty,
): ContractDocument {
  const temporaryAmount = ctx.job.extras.amount;
  return {
    kind: "temporary-invoice",
    title: "Temporary Invoice",
    header: documentHeader(ctx.job, party),
    sections: [
      {
        title: "Temporary Repair",
        lines: [
          {
            label: ctx.job.extras.description || "Long Term Temporary Repair",
            amount: temporaryAmount,
          },
          { label: "Sub-Total", amount: temporaryAmount },
          { label: "Payment Received", amount: 0 },
          { label: "Total Due", amount: temporaryAmount },
        ],
      },
    ],
    total: temporaryAmount,
  };
}

export function buildLienWaiver(
  { job }: ContractContext,
  party: ContractParty,
): ContractDocument {
  return {
    kind: "lien-waiver",
    title: "Labor Lien Waiver",
    header: documentHeader(job, party),
    sections: [
      {
        title: "Waiver Text",
        lines: [
          { label: "FOR A VALUABLE CONSIDERATION, the undersigned hereby waives all right" },
          { label: "to claim a mechanics lien for labor, services, machinery, tools, equipment" },
          { label: "or materials furnished prior to", value: "" },
          line("To", formatCustomerName(job.customer)),
          line("Address", jobAddress(job)),
          {
            label:
              "This release is valid on the condition that the check # ____________ drawn by _____________________________ on the __________________________ bank for ____________ and dated __________________ is paid when presented.",
          },
        ],
      },
      signatureSection("Lien Waiver Signature", [
        "Authorized Signature",
        "Title",
        "Date",
      ]),
    ],
  };
}

export function buildMaintenanceAgreement(
  { job }: ContractContext,
  party: ContractParty,
): ContractDocument {
  return {
    kind: "maintenance-agreement",
    title: "Maintenance Warranty Agreement",
    header: documentHeader(job, party),
    sections: [
      {
        title: "Agreement",
        lines: [
          line("Job Number", job.number ?? ""),
          line("Owner", formatCustomerName(job.customer)),
          line("Address", jobAddress(job)),
          {
            label: "Contracts",
            value: "-     See contracts for work completed",
          },
          line("Special Conditions", job.extras.description),
          line("Job Completion Date", ""),
        ],
      },
      {
        title: "Provisions",
        lines: maintenanceProvisionLines(party),
      },
      signatureSection("Maintenance Agreement Signature", [
        "Owner Signature",
        "Date",
      ]),
    ],
  };
}

export function buildRoofOrderForm(
  { job, catalog, roofingTotals }: ContractContext,
  party: ContractParty,
): ContractDocument {
  const roofing = job.scope.roofing;
  const shingle = catalog.shingles.find(
    (item) => item.id === roofing?.shingle.productId,
  );

  return {
    kind: "roof-order-form",
    title: "Roof Order Form",
    header: documentHeader(job, party),
    sections: [
      {
        title: "Order Header",
        lines: [
          line("Job Number", job.number ?? ""),
          line("Salesman", job.estimator),
          line("Customer", formatCustomerName(job.customer)),
          line("Address", jobAddress(job)),
          line("Delivery Instructions", ""),
        ],
      },
      {
        title: "Roof Materials",
        lines: compactLines([
          line("Shingle bundles", String(Math.ceil(roofingTotals.materials.shingleSquares * 3))),
          line("Product", shingle ? `${shingle.manufacturer} - ${shingle.variety}` : ""),
          line("Cap shingle bundles", String(roofingTotals.materials.capBundles)),
          line("Starter bundles", String(roofingTotals.materials.starterBundles)),
          line("Ice & Water squares", String(roofingTotals.materials.iceWaterSquares)),
          line("15# felt rolls", String(roofingTotals.materials.felt15Rolls)),
          line("30# felt rolls", String(roofingTotals.materials.felt30Rolls)),
          line("Drip edge sticks", String(roofingTotals.materials.dripEdgeSticks)),
          line("Plywood sheets", String(roofingTotals.materials.plywoodSheets)),
        ]),
      },
    ],
  };
}

function buildMiscProposal(
  ctx: ContractContext,
  number: 1 | 2,
  party: ContractParty,
): ContractDocument {
  return placeholderProposal(
    ctx.job,
    number === 1 ? "misc-1-proposal" : "misc-2-proposal",
    `Misc ${number} Proposal`,
    party,
  );
}

function buildPunchlistRepair(
  ctx: ContractContext,
  party: ContractParty,
): ContractDocument {
  return {
    kind: "punchlist-repair",
    title: "Punchlist / Repair Ticket",
    header: commonProposalHeader(ctx.job, party),
    sections: [
      {
        title: "Repair Ticket Details",
        lines: [
          line("Original Installer", ""),
          line("Inspector", ""),
          line("Repairman", ""),
          line("Date Complete", ""),
          line("Labor Cost", ""),
          line("Material Cost", ""),
          line("Charge repairs to", ""),
        ],
      },
      {
        title: "Customer / Job Location",
        lines: [
          line("Name", formatCustomerName(ctx.job.customer)),
          line("Street", mailingAddress(ctx.job)),
          line("City & State", cityStateZip(ctx.job)),
          line("Job Street", mailingAddress(ctx.job)),
          line("Job City & State", cityStateZip(ctx.job)),
        ],
      },
      {
        title: "Repair Scope",
        lines: [
          {
            label:
              "Repair notes and completion details are entered on the punchlist / repair ticket for field use.",
          },
        ],
      },
    ],
  };
}

function buildTemporaryRepair(
  ctx: ContractContext,
  party: ContractParty,
): ContractDocument {
  const temporaryAmount = ctx.job.extras.amount;
  return {
    ...placeholderProposal(
      ctx.job,
      "temporary-repair",
      "Long Term Temporary Repair",
      party,
    ),
    sections: [
      {
        title: "Agreement",
        lines: [
          {
            label: "I / We the Owner(s) agree to pay the sum of $",
            amount: temporaryAmount,
          },
        ],
      },
      {
        title: "Temporary Repair Terms",
        lines: [
          {
            label:
              `I authorize ${party.name} to perform temporary repairs as necessary in an attempt to protect my property from further damage that would occur by not repairing the current damage sustained before permanent repairs can be made.`,
          },
          {
            label:
              `${party.name} will perform temporary repairs to the best of their ability, but will not be held responsible for further damage if it occurs, regardless of the cause.`,
          },
          line("Repair description", ctx.job.extras.description),
          { label: "Temporary repair charge", amount: temporaryAmount },
          { label: "Inspections: Minimum charge of $150 depending upon roof size, style, slope, etc." },
          { label: "Minimum Temp/Repair: Replace up to 17 shingles (1 bundle) or up to 200 Sq Ft Ice & Water Shield: $700" },
          { label: "Partial Temp: 200 - 800 Sq Ft: $1,200" },
          { label: "Large Temp: over 800 Sq Ft: $135 per 100 Sq Ft" },
          { label: "Temporary repairs will be completed with Ice and Water shield using plastic cap nails to fasten securely." },
          { label: "Payments on all minimum and partial temporaries are required upon completion. Larger temporaries require at least a 50% deposit and completion of payment within 30 days, unless pre-approved by management." },
          { label: `${party.name} is not responsible for color matching of repairs.` },
          { label: `I understand that I am, ultimately, responsible for making payment, in-full, to ${party.name}.` },
        ],
      },
      {
        title: "Payment Terms",
        lines: proposalPaymentTerms(ctx.job, party),
      },
      signatureSection("Temporary Repair Acceptance", [
        "Purchaser",
        "Purchaser Date",
        party.representative,
        "Joint Purchaser",
        "Joint Purchaser Date",
      ]),
    ],
    total: temporaryAmount,
  };
}

function placeholderProposal(
  job: Job,
  kind: ContractDocument["kind"],
  title: string,
  party: ContractParty,
): ContractDocument {
  return {
    kind,
    title,
    header: commonProposalHeader(job, party),
    sections: [
      {
        title: "Agreement",
        lines: [
          {
            label:
              "The undersigned Contractor agrees to furnish all materials and labor necessary for the work specified below.",
          },
          {
            label:
              "I / We the Owner(s) agree to pay the sum shown on this proposal, subject to the completed scope and supplements.",
          },
        ],
      },
      {
        title: "SPECIFICATIONS OF WORK TO BE COMPLETED",
        lines: [
          {
            label:
              "This estimate type is represented in the contract layer. Its trade-specific pricing and scope fields will be filled when that calculator workflow is added.",
          },
        ],
      },
      {
        title: "Payment Terms",
        lines: proposalPaymentTerms(job, party),
      },
      signatureSection("Proposal Acceptance", [
        "Owner",
        "Owner Date",
        "Co-Owner",
        "Co-Owner Date",
        party.representative,
      ]),
    ],
  };
}

function maintenanceProvisionLines(party: ContractParty) {
  return [
    {
      label:
        "For a period of five (5) years, we agree to repair at our own expense any problems associated with the work described in the contract agreement.",
    },
    {
      label:
        "This Labor Warranty Agreement does not cover damage caused by lightning, high winds, hurricane, tornado, hailstorm, impact, foreign objects, or other violent external causes.",
    },
    {
      label:
        `The owner or agent must notify ${party.name} by registered mail within five days from discovery of any problem and within the terms of this agreement.`,
    },
    {
      label:
        "This warranty covers problems associated with the work completed on the contract agreement and does not include alterations, changes, additions, or repairs made by others.",
    },
    {
      label:
        "No liability is assumed for damage to person, building, interior decoration, insulation, decking, fixtures, or contents of any structure because of problems.",
    },
    {
      label:
        "The foregoing is in lieu of all other warranties, expressed or implied, and is not transferable without written consent.",
    },
  ];
}
