import {
  APP_NAME,
  APP_REPRESENTATIVE,
  APP_REP_SHORT,
  APP_SUPPORT_EMAIL,
} from "../branding";
import {
  formatLicensesForState,
  formatLocationAddress,
  locationPhone,
  resolveCompanyLocation,
} from "../companyLocation";
import type { CompanyProfile } from "../types";

/**
 * The contractor identity printed on proposals/contracts. Derived from the
 * estimate owner's company profile, falling back to the ShingleFile platform
 * branding when a field hasn't been filled in yet.
 */
export type ContractParty = {
  name: string;
  representative: string;
  repShort: string;
  supportEmail: string;
  address: string;
  phone: string;
  license: string;
};

export function contractParty(
  profile: CompanyProfile | null | undefined,
  platform: CompanyProfile | null | undefined = null,
  jobState?: string,
): ContractParty {
  const customerName = profile?.companyName?.trim() || profile?.legalName?.trim() || ""
  const platformName = platform?.companyName?.trim()
    || platform?.legalName?.trim()
    || APP_NAME
  const name = customerName || platformName
  const usingCustomerName = Boolean(customerName)
  const location = resolveCompanyLocation(profile, jobState)
  const platformLocation = resolveCompanyLocation(platform, jobState)

  return {
    name,
    representative: usingCustomerName
      ? `${name} Representative`
      : platformName !== APP_NAME
        ? `${platformName} Representative`
        : APP_REPRESENTATIVE,
    repShort: usingCustomerName
      ? `${name} Rep.`
      : platformName !== APP_NAME
        ? `${platformName} Rep.`
        : APP_REP_SHORT,
    supportEmail: profile?.email?.trim()
      || platform?.email?.trim()
      || APP_SUPPORT_EMAIL,
    address: (location ? formatLocationAddress(location) : "")
      || formatOfficeAddress(profile)
      || (platformLocation ? formatLocationAddress(platformLocation) : "")
      || formatOfficeAddress(platform),
    phone: locationPhone(location)
      || profile?.phone?.trim()
      || profile?.officePhone?.trim()
      || locationPhone(platformLocation)
      || platform?.phone?.trim()
      || platform?.officePhone?.trim()
      || "",
    license: formatLicensesForState(profile, jobState)
      || formatLicensesForState(platform, jobState)
      || formatLicenses(profile)
      || formatLicenses(platform),
  };
}

function formatOfficeAddress(profile: CompanyProfile | null | undefined): string {
  if (!profile) return "";
  const stateZip = [profile.state, profile.zip].filter(Boolean).join(" ");
  const cityLine = [profile.city, stateZip].filter(Boolean).join(", ");
  return [profile.address1, profile.address2, cityLine]
    .map((part) => part?.trim())
    .filter(Boolean)
    .join(", ");
}

function formatLicenses(profile: CompanyProfile | null | undefined): string {
  if (!profile?.licenses?.length) return "";
  return profile.licenses
    .filter((license) => license.licenseId?.trim())
    .map((license) => license.state
      ? `${license.state} #${license.licenseId}`
      : `#${license.licenseId}`)
    .join(", ");
}
