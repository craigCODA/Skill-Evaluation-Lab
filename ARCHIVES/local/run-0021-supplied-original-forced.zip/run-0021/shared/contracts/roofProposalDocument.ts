import { formatCustomerName } from "../customer";
import { resolveLogoUrl } from "../branding";
import type { CompanyProfile, Job } from "../types";
import type { Catalog } from "../pricebook/types";
import type { RoofingEstimateTotals } from "../calculator/calculateEstimate";
import type { ContractParty } from "./contractParty";
import type { ContractDocument } from "./types";
import {
  commonProposalHeader,
  compactLines,
  line,
  proposalPaymentTerms,
  signatureSection,
} from "./proposalCommon";
import { buildRoofPricingLines } from "./roofProposalPricing";
import {
  buildConditionalAddendumLines,
  buildPreparationLines,
  buildRoofSpecificationLines,
  buildWorkmanshipLines,
} from "./roofProposalScope";

type RoofProposalContext = {
  job: Job;
  catalog: Catalog;
  roofingTotals: RoofingEstimateTotals;
  companyProfile: CompanyProfile | null;
  platformProfile?: CompanyProfile | null;
};

export function buildRoofProposal(
  ctx: RoofProposalContext,
  party: ContractParty,
): ContractDocument {
  const { job, catalog, roofingTotals, companyProfile, platformProfile } = ctx;
  const roofing = job.scope.roofing!;
  const hasSkylights = roofing.skylights.some(
    (row) => row.count > 0 && row.option !== "Select Skylight",
  );
  const logoUrl = resolveLogoUrl(
    companyProfile?.logoUrl || platformProfile?.logoUrl,
  );

  return {
    kind: "roof-proposal",
    title: "Roofing Proposal & Agreement",
    meta: {
      companyName: party.name,
      logoUrl: logoUrl || undefined,
      license: party.license || undefined,
      supportEmail: party.supportEmail,
      representative: party.representative,
      documentDate: new Date().toLocaleDateString(),
    },
    header: commonProposalHeader(job, party),
    sections: [
      {
        title: "Agreement",
        lines: [
          {
            label: `${party.name} (“Contractor”) agrees to furnish all materials and labor necessary to complete the roofing work described in this proposal for the property listed below.`,
          },
          {
            label:
              "I / We the Owner(s) agree to pay the Contract Price shown in the Scope Summary for the work specified herein, subject to approved supplements and change orders.",
            amount: roofingTotals.grandTotal,
          },
        ],
      },
      {
        title: "Contract Price / Scope Summary",
        kind: "pricing",
        lines: buildRoofPricingLines(job, roofing, roofingTotals),
      },
      {
        title: "Specifications of Work to Be Completed",
        lines: buildRoofSpecificationLines(roofing, catalog),
      },
      {
        title: "Included Workmanship",
        kind: "bullets",
        lines: buildWorkmanshipLines(party.name, job.permit),
      },
      {
        title: "Payment Terms",
        lines: proposalPaymentTerms(job, party),
      },
      signatureSection("Proposal Acceptance", [
        "Owner / Purchaser",
        "Date",
        "Co-Owner / Joint Purchaser",
        "Date",
        party.representative,
        "Date",
      ]),
      {
        title: "Insurance Approval Clause",
        lines: compactLines([
          {
            label: `I, ${formatCustomerName(job.customer)}, Owner(s), acknowledge and approve ${party.name} to proceed with the contracted work. I understand that during the course of work additional damage and costs may be incurred.`,
          },
          line("Insurance company", job.customer.insurance?.company),
          line("Claim number", job.customer.insurance?.claimNumber),
          line(
            "Insurance contact",
            job.customer.insurance?.contact,
          ),
        ]),
      },
      signatureSection("Insurance Approval Signatures", [
        "Owner / Purchaser",
        "Date",
        "Co-Owner / Joint Purchaser",
        "Date",
      ]),
      {
        title: "How to Prepare for Your Roofing Job",
        lines: buildPreparationLines(party.name, hasSkylights),
      },
      {
        title: "Additional Roofing Provisions",
        lines: buildConditionalAddendumLines(roofing),
      },
      signatureSection("Addendum Signatures", [
        "Owner / Purchaser",
        "Date",
        party.representative,
        "Date",
        "Co-Owner / Joint Purchaser",
        "Date",
      ]),
      {
        title: "After the Work Is Completed",
        lines: [
          {
            label: `After the work is completed, ${party.name} urges you to have a licensed plumber or qualified HVAC service technician inspect the complete furnace pipe assembly.`,
          },
          {
            label: `${party.name} will inspect the furnace pipe assembly from the exterior of your home and correct any damage, crimping, or visible obstruction observed from the exterior.`,
          },
        ],
      },
      {
        title: "Consumer's Right to Cancel",
        lines: [
          {
            label:
              "If your insurer denies all or any part of your claim to pay for goods and services in connection with the repair or replacement of a roof system, you may cancel this transaction without penalty or obligation within three business days.",
          },
          {
            label:
              "If you cancel, any payments made by you under the contract will be returned within ten business days following receipt by the seller of your cancellation notice.",
          },
          {
            label: `To cancel this transaction, mail or deliver a signed and dated copy of this notice, or any other written notice, to ${party.name} at the address or email below.`,
          },
          line("Cancellation contact", party.supportEmail),
          { label: "I HEREBY CANCEL THIS TRANSACTION." },
          {
            label: `Roof contract amount: ${formatContractAmount(roofingTotals.grandTotal)}`,
          },
          { label: "Other (specify): ____________________________________________" },
        ],
      },
      signatureSection("Cancellation Notice Signatures", [
        "Owner / Purchaser",
        "Date",
        "Co-Owner / Joint Purchaser",
        "Date",
        party.repShort,
        "Date",
      ]),
    ],
    total: roofingTotals.grandTotal,
  };
}

function formatContractAmount(amount: number): string {
  return amount.toLocaleString(undefined, {
    style: "currency",
    currency: "USD",
  });
}
