import { formatCustomerName } from "../customer";
import type { Job } from "../types";
import type { ContractParty } from "./contractParty";
import type { ContractLine } from "./types";

export function line(label: string, value?: string): ContractLine {
  return { label, value: value ?? "" };
}

export function compactLines(lines: ContractLine[]): ContractLine[] {
  return lines.filter(
    (item) => item.value !== "" || item.amount !== undefined || !item.value,
  );
}

export function signatureSection(
  title: string,
  labels: string[],
): { title: string; kind: "signatures"; lines: ContractLine[] } {
  return {
    title,
    kind: "signatures",
    lines: labels.map((label) => ({ label })),
  };
}

export function mailingAddress(job: Job): string {
  return job.customer.address1 ?? job.customer.street ?? "";
}

export function jobAddress(job: Job): string {
  return [mailingAddress(job), cityStateZip(job)].filter(Boolean).join(", ");
}

export function cityStateZip(job: Job): string {
  const stateZip = [job.customer.state, job.customer.zip]
    .filter(Boolean)
    .join(" ");
  return [job.customer.city, stateZip].filter(Boolean).join(", ");
}

export function commonProposalHeader(
  job: Job,
  party: ContractParty,
): ContractLine[] {
  return [
    line("Office", party.address),
    line("Phone", party.phone),
    line("Name", formatCustomerName(job.customer)),
    line("Street", mailingAddress(job)),
    line("City & State", cityStateZip(job)),
    line("Customer Phone", job.customer.phone),
    line("Office Phone", job.customer.officePhone ?? ""),
    line("Date", new Date().toLocaleDateString()),
    line("Job Street", job.customer.address1 ?? job.customer.street ?? ""),
    line("Job City & State", cityStateZip(job)),
    line("Estimator", job.estimator),
  ];
}

export function documentHeader(job: Job, party: ContractParty): ContractLine[] {
  return [
    line("Company", [party.name, party.address].filter(Boolean).join(", ")),
    line("Phone", party.phone),
    line("Job Number", job.number ?? ""),
    line("Claim #", job.customer.insurance?.claimNumber ?? ""),
  ];
}

export function proposalPaymentTerms(
  _job: Job,
  party: ContractParty,
): ContractLine[] {
  return [
    {
      label:
        "Payable upon completion per trade and upon receipt of insurance proceeds. Deductible is due immediately. Additional provisions for this contract are listed with this proposal.",
    },
    {
      label:
        "You may cancel this contract in connection with the repair or replacement of a roof system within seventy-two hours after you have been notified that your insurer has denied all or any part of your claim.",
    },
    line("Company", [party.name, party.license].filter(Boolean).join(" ")),
  ];
}
