import type { Catalog } from "../pricebook/types";
import type { RoofingScope } from "../types";
import type { ContractLine } from "./types";
import { compactLines, line } from "./proposalCommon";

const RIDGE_STYLE_LABELS: Record<string, string> = {
  "new-standard": "Standard ridge",
  "new-high-hip": "High hip ridge",
};

const STARTER_LABELS: Record<string, string> = {
  roll: "Roll starter",
  preform: "Preform starter",
};

const FASTENER_LABELS: Record<string, string> = {
  "galvanized-6": "6 galvanized nails",
  "hand-nail-6": "6 hand nails",
};

function areaPrefix(roofing: RoofingScope, index: number): string {
  if (roofing.areas.length <= 1) return "";
  const label = roofing.areas[index]?.label?.trim();
  return label ? `${label}: ` : `Area ${index + 1}: `;
}

function selectedColorLabel(
  roofing: RoofingScope,
  shingle: Catalog["shingles"][number] | undefined,
): string {
  const color = shingle?.colors.find(
    (item) => item.id === roofing.shingle.colorId,
  );
  return color?.name ?? "To be selected";
}

export function buildRoofSpecificationLines(
  roofing: RoofingScope,
  catalog: Catalog,
): ContractLine[] {
  const shingle = catalog.shingles.find(
    (item) => item.id === roofing.shingle.productId,
  );
  const warranty = catalog.warrantyUpcharges.find(
    (item) => item.tier === roofing.shingle.warranty,
  );

  const jobLines: ContractLine[] = compactLines([
    line("Recover roof with", shingle?.manufacturer),
    line("Shingle style", shingle?.variety),
    line("Color", selectedColorLabel(roofing, shingle)),
    line("Manufacturer warranty", warranty?.displayName),
    line(
      "Ridge cap",
      `${roofing.ridgeLf} LF — ${RIDGE_STYLE_LABELS[roofing.ridgeStyle] ?? roofing.ridgeStyle}`,
    ),
    line(
      "Starter",
      STARTER_LABELS[roofing.starterType ?? "roll"] ?? roofing.starterType,
    ),
    line(
      "Fasteners",
      FASTENER_LABELS[roofing.shingle.fastener] ?? roofing.shingle.fastener,
    ),
  ]);

  const areaLines: ContractLine[] = [];
  roofing.areas.forEach((area, index) => {
    const prefix = areaPrefix(roofing, index);
    const squares = area.inputSquares
      ? `${area.inputSquares} squares (report)`
      : undefined;
    areaLines.push(
      ...compactLines([
        line(
          `${prefix}Roof plane`,
          [area.location, area.story, area.pitch, squares]
            .filter(Boolean)
            .join(" · "),
        ),
        line(`${prefix}Remove existing roofing`, area.layers),
        ...(area.redeck !== "No"
          ? [line(`${prefix}Redeck / plywood`, area.redeck)]
          : []),
        ...(area.access === "No Access"
          ? [line(`${prefix}Access`, "No access surcharge applies")]
          : []),
        line(`${prefix}Ice & water shield`, area.iceWaterOption),
        line(`${prefix}Underlayment`, area.underlayment),
        line(
          `${prefix}Drip edge — eaves`,
          `${area.eaveDripLf} LF ${area.eaveDripStyle}`,
        ),
        line(
          `${prefix}Drip edge — rakes`,
          `${area.rakeDripLf} LF ${area.rakeDripStyle}`,
        ),
      ]),
    );
  });

  const valleyLf =
    roofing.valleys.style === "open"
      ? roofing.valleys.openLf
      : roofing.valleys.closedLf;
  const valleyLine =
    valleyLf > 0
      ? line(
          "Valleys",
          `${valleyLf} LF — ${roofing.valleys.style === "open" ? "Open valley" : "Half lace valley"}`,
        )
      : line("Valleys", "None on this roof");

  const ridgeVentLf = roofing.ridgeVentLf + roofing.cutInRidgeVentLf;
  const ridgeLines = compactLines([
    ...(ridgeVentLf > 0
      ? [
          line(
            "Ridge vent",
            [
              roofing.ridgeVentLf > 0
                ? `${roofing.ridgeVentLf} LF ridge vent`
                : "",
              roofing.cutInRidgeVentLf > 0
                ? `${roofing.cutInRidgeVentLf} LF cut-in ridge vent`
                : "",
            ]
              .filter(Boolean)
              .join("; "),
          ),
        ]
      : []),
    ...(roofing.stepFlashingLf > 0
      ? [line("Step flashing", `${roofing.stepFlashingLf} LF`)]
      : []),
    ...(roofing.hipLf && roofing.hipLf > 0
      ? [line("Hip length (measurement)", `${roofing.hipLf} LF`)]
      : []),
  ]);

  const addonLines = buildSelectedAddonLines(roofing, catalog);

  return compactLines([
    ...jobLines,
    ...areaLines,
    valleyLine,
    ...ridgeLines,
    ...addonLines,
    { label: "Seal around all vents, pipes, and flashings" },
  ]);
}

function buildSelectedAddonLines(
  roofing: RoofingScope,
  catalog: Catalog,
): ContractLine[] {
  const lines: ContractLine[] = [];

  if (roofing.chimneyRemoval && roofing.chimneyRemoval !== "No") {
    lines.push(line("Chimney removal", roofing.chimneyRemoval));
  }
  if (roofing.chimneyKit && roofing.chimneyKit !== "No Kit") {
    lines.push(line("Chimney kit", roofing.chimneyKit));
  }
  if (roofing.satellite && roofing.satellite !== "No") {
    lines.push(line("Satellite dish", roofing.satellite));
  }
  if (roofing.antenna && roofing.antenna !== "No") {
    lines.push(line("Antenna", roofing.antenna));
  }
  if (roofing.lightningRods && roofing.lightningRods !== "No") {
    lines.push(line("Lightning rods", roofing.lightningRods));
  }

  for (const row of roofing.skylights) {
    if (row.count <= 0) continue;
    const opt = catalog.skylightOptions.find((item) => item.key === row.option);
    if (!opt || opt.key === "Select Skylight") continue;
    lines.push(
      line("Skylight / tube", `${row.count} × ${opt.key}`),
    );
  }

  if (roofing.workAroundGutters === "Yes" && roofing.gutterRemovalLf > 0) {
    lines.push(
      line(
        "Gutter removal / work-around",
        `${roofing.gutterRemovalLf} LF`,
      ),
    );
  }

  const lowSlope = roofing.lowSlope?.trim();
  if (lowSlope && lowSlope !== " NA" && lowSlope !== "NA") {
    lines.push(line("Low-slope roofing", lowSlope));
  }

  for (const accessory of roofing.accessories) {
    if (accessory.count <= 0) continue;
    const rate = catalog.accessoryRates.find((item) => item.key === accessory.key);
    const label = rate?.label ?? accessory.key;
    lines.push(line(label, String(accessory.count)));
  }

  return lines;
}

export function buildWorkmanshipLines(
  partyName: string,
  permit: number,
): ContractLine[] {
  const lines: ContractLine[] = [
    { label: "Furnish all material and labor for the scope described above" },
    { label: "Five (5) year workmanship warranty on installation labor" },
    { label: "Clean up and haul all trash from the roof daily" },
    { label: "Remove roofing debris from gutters" },
    { label: "Roll yard with magnetic roller" },
  ];
  if (permit > 0) {
    lines.push({ label: `Building permit furnished by ${partyName}` });
  }
  return lines;
}

export function buildConditionalAddendumLines(
  roofing: RoofingScope,
): ContractLine[] {
  const lines: ContractLine[] = [];

  if (roofing.satellite && roofing.satellite !== "No") {
    lines.push({
      label:
        "Remove and replace satellite dish: we will align to the best of our ability. Homeowner is responsible for any necessary service alignment.",
    });
  }
  if (roofing.chimneyRemoval && roofing.chimneyRemoval !== "No") {
    lines.push({
      label:
        "Remove chimney below roofline at owner's request. Owner assumes responsibility for its non-venting status.",
    });
  }
  if (roofing.workAroundGutters === "Yes") {
    lines.push({
      label:
        "Work around strap gutters to the best of our ability, protecting with plywood during tear-off. No guarantee to working ability when gutters are not being replaced.",
    });
  }
  if (roofing.lightningRods && roofing.lightningRods !== "No") {
    lines.push({
      label:
        "Reattach lightning rods: not responsible for system operation. We recommend a licensed professional inspect the system.",
    });
  }

  const hasSkylights = roofing.skylights.some(
    (row) => row.count > 0 && row.option !== "Select Skylight",
  );
  if (hasSkylights) {
    lines.push({
      label:
        "Existing skylights/tubes will be sealed to the best of our ability. Replacement is recommended; reused units carry no leak warranty.",
    });
  }

  lines.push({
    label:
      "Projects including three or more trades may be subject to additional overhead and profit submitted to the insurance company and added to the final project total.",
  });

  return lines;
}

export function buildPreparationLines(partyName: string, hasSkylights: boolean): ContractLine[] {
  const lines: ContractLine[] = [
    {
      label: `When materials are delivered, check the color immediately. Notify ${partyName} right away if the color is not what you specified.`
    },
    {
      label:
        "Be prepared for noise and vibration. There will be constant hammering for two or more days, depending on the size of your project."
    },
    {
      label:
        "Keep children and pets away from the work area. Remove pets from outdoor areas for the duration of the project."
    },
    {
      label:
        "Remove loose items from walls and shelves. Hammering can shake pictures, collectibles, and dishes free."
    },
    {
      label: `${partyName} is not responsible for pre-existing structural problems. Irregularities in the deck or framing may show through new shingles.`
    },
    {
      label:
        "Clear the driveway before work begins so trucks and crews can access the job."
    },
    {
      label:
        "Move patio furniture, grills, potted plants, and yard equipment away from the house and work zone."
    },
    {
      label:
        "Provide outside electrical power for the crew. If exterior outlets are unavailable, run an extension cord through a window or door."
    },
    {
      label:
        "Rain may delay work. Crews will not tear off more roofing than they can replace or dry-in the same day."
    },
    {
      label:
        "Nails will be picked up with a magnetic roller to the best of our ability; some hidden nails may remain in landscaping."
    },
    {
      label:
        "We will protect landscaping and shrubbery to the best of our ability. Fragile plantings should be moved by the owner when possible."
    },
    {
      label:
        "Dust and small debris may drop through sheathing gaps into the attic. Cover stored attic items with plastic before work starts."
    },
    {
      label:
        "Park vehicles away from the house. Falling debris and tear-off material can damage nearby cars."
    },
    {
      label:
        "Plan for limited outdoor use of the property while crews are on site. Porches and walkways near the roof may be blocked."
    },
    {
      label:
        "Exact color match to existing materials, weathered samples, or printed swatches cannot be guaranteed."
    },
    {
      label:
        "During tear-off and steep work, minor scuffing of siding or gutters can occur and is not always avoidable."
    },
    {
      label: `Please make all payments to ${partyName}. Do not make checks payable to individual crew members or any other party.`
    },
    {
      label:
        "Returned checks are subject to a returned-check fee in addition to any bank charges."
    },
    {
      label:
        "Someone should be reachable by phone during the project in case questions about scope or extras arise."
    },
    {
      label:
        "If you have solar, antennas, or specialty roof equipment not listed in this contract, tell the office before tear-off begins."
    }
  ]

  if (hasSkylights) {
    lines.push({
      label: `${partyName} recommends replacing skylights/tubes when the roof is replaced. If existing units are reused, we will seal them to the best of our ability, but reused units carry no leak warranty.`
    })
  }

  lines.push({
    label:
      "Items not replaced by the contractor as part of this contract are not covered by the workmanship warranty."
  })

  return lines
}
