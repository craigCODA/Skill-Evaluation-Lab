import type { Money } from "../types";

export type ContractDocumentKind =
  | "roof-proposal"
  | "misc-1-proposal"
  | "misc-2-proposal"
  | "punchlist-repair"
  | "temporary-repair"
  | "invoice"
  | "temporary-invoice"
  | "lien-waiver"
  | "maintenance-agreement"
  | "roof-order-form";

export type ContractLine = {
  label: string;
  value?: string;
  amount?: Money;
};

export type ContractSection = {
  title: string;
  kind?: "content" | "signatures" | "pricing" | "bullets";
  lines: ContractLine[];
};

/** Contractor branding printed on contract-style documents. */
export type ContractDocumentMeta = {
  companyName: string;
  logoUrl?: string;
  license?: string;
  supportEmail?: string;
  representative?: string;
  documentDate?: string;
};

export type ContractDocument = {
  kind: ContractDocumentKind;
  title: string;
  header: ContractLine[];
  sections: ContractSection[];
  total?: Money;
  meta?: ContractDocumentMeta;
};
