import { newId } from "../../ids"
import {
  CONTRACT_MODULE_CATALOG,
  defaultEnabledRecipes,
  defaultModuleContents,
  defaultRecipeSlots,
  defaultRecipes,
  DEFAULT_MODULE_BODIES,
  isContractRecipeKind
} from "./catalog"
import type {
  CompanyContractConfig,
  ContractModuleContent,
  ContractModuleKind,
  ContractRecipeKind,
  ContractRecipeSlot
} from "./types"
import { CONTRACT_RECIPE_KINDS } from "./types"

const KIND_SET = new Set(CONTRACT_MODULE_CATALOG.map((entry) => entry.kind))

function isModuleKind(value: unknown): value is ContractModuleKind {
  return typeof value === "string" && KIND_SET.has(value as ContractModuleKind)
}

export function resolveModuleBody(
  content: ContractModuleContent | undefined,
  state?: string
): string {
  if (!content) return ""
  const normalized = state?.trim().toUpperCase() || ""
  if (normalized && content.bodyByState[normalized]?.trim()) {
    return content.bodyByState[normalized]
  }
  if (content.bodyByState.DEFAULT?.trim()) return content.bodyByState.DEFAULT
  return DEFAULT_MODULE_BODIES[content.key] ?? ""
}

export function normalizeRecipeSlots(
  kind: ContractRecipeKind,
  input: unknown
): ContractRecipeSlot[] {
  const defaults = defaultRecipeSlots(kind)
  const byKey = new Map(defaults.map((slot) => [slot.key, { ...slot }]))

  if (Array.isArray(input)) {
    for (const raw of input) {
      if (!raw || typeof raw !== "object") continue
      const row = raw as Record<string, unknown>
      const key = typeof row.key === "string" ? row.key : ""
      const existing = byKey.get(key)
      if (!existing) continue
      if (typeof row.enabled === "boolean" && !existing.required) {
        existing.enabled = row.enabled
      }
    }
  }

  return defaults.map((slot) => byKey.get(slot.key) ?? slot)
}

export function normalizeModuleContents(input: unknown): ContractModuleContent[] {
  const defaults = defaultModuleContents()
  const byKey = new Map(defaults.map((module) => [module.key, { ...module, bodyByState: { ...module.bodyByState } }]))

  if (Array.isArray(input)) {
    for (const raw of input) {
      if (!raw || typeof raw !== "object") continue
      const row = raw as Record<string, unknown>
      const key = typeof row.key === "string" ? row.key : ""
      const existing = byKey.get(key)
      if (!existing) continue
      if (typeof row.label === "string" && row.label.trim()) {
        existing.label = row.label.trim()
      }
      if (row.bodyByState && typeof row.bodyByState === "object") {
        const next: Record<string, string> = { ...existing.bodyByState }
        for (const [state, body] of Object.entries(row.bodyByState as Record<string, unknown>)) {
          if (typeof body !== "string") continue
          const stateKey = state.trim().toUpperCase() || "DEFAULT"
          next[stateKey === "DEFAULT" ? "DEFAULT" : stateKey] = body
        }
        existing.bodyByState = next
      }
    }
  }

  return defaults.map((module) => byKey.get(module.key) ?? module)
}

export function normalizeEnabledRecipes(input: unknown): Record<ContractRecipeKind, boolean> {
  const defaults = defaultEnabledRecipes()
  if (!input || typeof input !== "object") return defaults
  const source = input as Record<string, unknown>
  return {
    roofing: true,
    gutters: typeof source.gutters === "boolean" ? source.gutters : defaults.gutters,
    siding: typeof source.siding === "boolean" ? source.siding : defaults.siding
  }
}

export function normalizeRecipes(input: unknown, legacyRecipe?: unknown): Record<ContractRecipeKind, ContractRecipeSlot[]> {
  const source = input && typeof input === "object" ? input as Record<string, unknown> : {}
  const recipes = defaultRecipes()
  for (const kind of CONTRACT_RECIPE_KINDS) {
    const fromRecipes = source[kind]
    const legacy = kind === "roofing" ? legacyRecipe : undefined
    recipes[kind] = normalizeRecipeSlots(kind, fromRecipes ?? legacy)
  }
  return recipes
}

export function normalizeCompanyContractConfig(
  customerAccountId: string,
  input?: Partial<CompanyContractConfig> | null
): CompanyContractConfig {
  return {
    customerAccountId,
    recipes: normalizeRecipes(input?.recipes, input?.recipe),
    enabledRecipes: normalizeEnabledRecipes(input?.enabledRecipes),
    modules: normalizeModuleContents(input?.modules),
    updatedAt: input?.updatedAt || new Date().toISOString()
  }
}

export function newCompanyContractConfig(customerAccountId: string): CompanyContractConfig {
  return normalizeCompanyContractConfig(customerAccountId, {
    customerAccountId,
    recipes: defaultRecipes(),
    enabledRecipes: defaultEnabledRecipes(),
    modules: defaultModuleContents(),
    updatedAt: new Date().toISOString()
  })
}

export function enabledRecipeSlots(
  config: CompanyContractConfig,
  kind: ContractRecipeKind
): ContractRecipeSlot[] {
  return (config.recipes[kind] ?? defaultRecipeSlots(kind))
    .filter((slot) => slot.required || slot.enabled)
}

export function activeRecipeKinds(config: CompanyContractConfig): ContractRecipeKind[] {
  return CONTRACT_RECIPE_KINDS.filter((kind) =>
    kind === "roofing" || config.enabledRecipes[kind]
  )
}

export function moduleContentByKey(
  config: CompanyContractConfig,
  key: string
): ContractModuleContent | undefined {
  return config.modules.find((module) => module.key === key)
}

export function newJobContractSnapshotId(): string {
  return `job-contract:${newId()}`
}

export function parseContractRecipeKind(value: unknown): ContractRecipeKind {
  if (isContractRecipeKind(value)) return value
  return "roofing"
}
