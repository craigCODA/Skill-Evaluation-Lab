/**
 * Modular contract system — types.
 *
 * Modules are reusable sections. Company recipes (roofing / gutters / siding)
 * order them into one composed contract per trade. Job snapshots freeze results.
 */

import type { Money } from "../../types"
import type { ContractDocumentMeta, ContractLine, ContractSection } from "../types"

export type ContractRecipeKind = "roofing" | "gutters" | "siding"

export const CONTRACT_RECIPE_KINDS = [
  "roofing",
  "gutters",
  "siding"
] as const satisfies readonly ContractRecipeKind[]

export const CONTRACT_RECIPE_LABELS: Record<ContractRecipeKind, string> = {
  roofing: "Roofing",
  gutters: "Gutters",
  siding: "Siding"
}

/** Built-in module kinds the composer knows how to render. */
export type ContractModuleKind =
  | "letterhead"
  | "customer-header"
  | "measurement-grid"
  | "agreement-amount"
  | "roof-specifications"
  | "gutter-specifications"
  | "siding-specifications"
  | "workmanship"
  | "payment-terms"
  | "insurance-clause"
  | "job-prep"
  | "after-work"
  | "right-to-cancel"
  | "owner-signature"
  | "terms-conditions"
  | "locations"

/** How the print shell treats the module for initials / signature / page breaks. */
export type ContractModulePageRole =
  | "content"
  | "page1-end"
  | "page2"
  | "prep-page"
  | "notice-page"
  | "signature"
  | "appendix"

export type ContractModuleKey = string

export type ContractRecipeSlot = {
  key: ContractModuleKey
  kind: ContractModuleKind
  /** Always included; hidden from optional toggles in admin recipe editor. */
  required: boolean
  /** When not required, whether the recipe includes it. */
  enabled: boolean
}

/**
 * Company-editable module copy. State keys are uppercase (IA, LA).
 * `DEFAULT` is the fallback when the job state has no override.
 */
export type ContractModuleContent = {
  key: ContractModuleKey
  kind: ContractModuleKind
  label: string
  /** Free-text body for editable kinds; ignored for data-driven kinds. */
  bodyByState: Record<string, string>
}

export type CompanyContractConfig = {
  customerAccountId: string
  /** @deprecated Prefer `recipes.roofing` — kept for older saved configs. */
  recipe?: ContractRecipeSlot[]
  recipes: Record<ContractRecipeKind, ContractRecipeSlot[]>
  /** Roofing is always on; gutters/siding can be toggled per company. */
  enabledRecipes: Record<ContractRecipeKind, boolean>
  modules: ContractModuleContent[]
  updatedAt: string
}

export type ComposedContractModule = {
  key: ContractModuleKey
  kind: ContractModuleKind
  title: string
  pageRole: ContractModulePageRole
  section: ContractSection
}

export type ComposedContract = {
  title: string
  recipeKind: ContractRecipeKind
  meta: ContractDocumentMeta
  modules: ComposedContractModule[]
  total?: Money
  generatedAt: string
  /** Convenience flat header lines for letterhead rendering. */
  letterhead: ContractLine[]
}

export type JobContractStatus = "unsigned" | "signed"

export type JobContractSignedPdf = {
  key: string
  fileName: string
  contentType: string
  size: number
  uploadedAt: string
}

export type JobContractSnapshot = {
  id: string
  jobId: string
  customerAccountId: string
  recipeKind: ContractRecipeKind
  status: JobContractStatus
  composed: ComposedContract
  generatedAt: string
  signedAt?: string
  signedPdf?: JobContractSignedPdf
}

export type JobContractPair = {
  unsigned: JobContractSnapshot | null
  signed: JobContractSnapshot | null
}

export type JobContractBundle = Record<ContractRecipeKind, JobContractPair>
