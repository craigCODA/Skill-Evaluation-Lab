/**
 * Default recipes + module catalog for company contract setup.
 */

import type {
  ContractModuleContent,
  ContractModuleKind,
  ContractModulePageRole,
  ContractRecipeKind,
  ContractRecipeSlot
} from "./types"
import { CONTRACT_RECIPE_KINDS } from "./types"

export type ContractModuleCatalogEntry = {
  kind: ContractModuleKind
  key: string
  label: string
  description: string
  /** Admin can edit bodyByState for these. */
  editable: boolean
  pageRole: ContractModulePageRole
  /** Which trade recipes include this module by default. */
  recipes: readonly ContractRecipeKind[]
  requiredInDefaultRecipe: boolean
  enabledInDefaultRecipe: boolean
}

export const CONTRACT_MODULE_CATALOG: readonly ContractModuleCatalogEntry[] = [
  {
    kind: "letterhead",
    key: "letterhead",
    label: "Letterhead",
    description: "Company name, logo, address, phone, and license.",
    editable: false,
    pageRole: "content",
    recipes: CONTRACT_RECIPE_KINDS,
    requiredInDefaultRecipe: true,
    enabledInDefaultRecipe: true
  },
  {
    kind: "customer-header",
    key: "customer-header",
    label: "Customer & job header",
    description: "Customer name, addresses, phone, date, and estimator.",
    editable: false,
    pageRole: "content",
    recipes: CONTRACT_RECIPE_KINDS,
    requiredInDefaultRecipe: true,
    enabledInDefaultRecipe: true
  },
  {
    kind: "measurement-grid",
    key: "measurement-grid",
    label: "Measurement grid",
    description: "Stories, pitch, layers, and square footage from the estimate.",
    editable: false,
    pageRole: "content",
    recipes: ["roofing"],
    requiredInDefaultRecipe: false,
    enabledInDefaultRecipe: true
  },
  {
    kind: "agreement-amount",
    key: "agreement-amount",
    label: "Agreement amount",
    description: "Owner agrees to pay the contract total.",
    editable: false,
    pageRole: "content",
    recipes: CONTRACT_RECIPE_KINDS,
    requiredInDefaultRecipe: true,
    enabledInDefaultRecipe: true
  },
  {
    kind: "roof-specifications",
    key: "roof-specifications",
    label: "Roof specifications",
    description: "Materials, planes, and scope lines from the estimate.",
    editable: false,
    pageRole: "content",
    recipes: ["roofing"],
    requiredInDefaultRecipe: true,
    enabledInDefaultRecipe: true
  },
  {
    kind: "gutter-specifications",
    key: "gutter-specifications",
    label: "Gutter specifications",
    description: "Gutter/downspout scope. Uses estimate extras plus editable copy.",
    editable: true,
    pageRole: "content",
    recipes: ["gutters"],
    requiredInDefaultRecipe: true,
    enabledInDefaultRecipe: true
  },
  {
    kind: "siding-specifications",
    key: "siding-specifications",
    label: "Siding specifications",
    description: "Siding scope. Uses estimate extras plus editable copy.",
    editable: true,
    pageRole: "content",
    recipes: ["siding"],
    requiredInDefaultRecipe: true,
    enabledInDefaultRecipe: true
  },
  {
    kind: "workmanship",
    key: "workmanship",
    label: "Included workmanship",
    description: "Standard workmanship bullets.",
    editable: false,
    pageRole: "content",
    recipes: CONTRACT_RECIPE_KINDS,
    requiredInDefaultRecipe: false,
    enabledInDefaultRecipe: true
  },
  {
    kind: "payment-terms",
    key: "payment-terms",
    label: "Payment terms",
    description: "Company/state payment fine print. Ends print page 1.",
    editable: true,
    pageRole: "page1-end",
    recipes: CONTRACT_RECIPE_KINDS,
    requiredInDefaultRecipe: true,
    enabledInDefaultRecipe: true
  },
  {
    kind: "insurance-clause",
    key: "insurance-clause",
    label: "Insurance approval",
    description: "Insurance approval clause, claim fields, and job-specific notes (print page 2).",
    editable: true,
    pageRole: "page2",
    recipes: CONTRACT_RECIPE_KINDS,
    requiredInDefaultRecipe: false,
    enabledInDefaultRecipe: true
  },
  {
    kind: "job-prep",
    key: "job-prep",
    label: "How to prepare for the job",
    description: "Full prep checklist built from standard job-prep rules. Starts print page 3 with After the work.",
    editable: false,
    pageRole: "prep-page",
    recipes: CONTRACT_RECIPE_KINDS,
    requiredInDefaultRecipe: true,
    enabledInDefaultRecipe: true
  },
  {
    kind: "after-work",
    key: "after-work",
    label: "After the work is completed",
    description: "Post-completion instructions (same print page as job prep).",
    editable: true,
    pageRole: "content",
    recipes: CONTRACT_RECIPE_KINDS,
    requiredInDefaultRecipe: true,
    enabledInDefaultRecipe: true
  },
  {
    kind: "right-to-cancel",
    key: "right-to-cancel",
    label: "Consumer's right to cancel",
    description: "Large cancel notice with insurance contingency (its own print page).",
    editable: true,
    pageRole: "notice-page",
    recipes: CONTRACT_RECIPE_KINDS,
    requiredInDefaultRecipe: true,
    enabledInDefaultRecipe: true
  },
  {
    kind: "terms-conditions",
    key: "terms-conditions",
    label: "Terms & conditions",
    description: "Numbered legal terms (company/state text).",
    editable: true,
    pageRole: "appendix",
    recipes: CONTRACT_RECIPE_KINDS,
    requiredInDefaultRecipe: true,
    enabledInDefaultRecipe: true
  },
  {
    kind: "locations",
    key: "locations",
    label: "Service locations",
    description: "Company license and office locations list (near the end).",
    editable: false,
    pageRole: "appendix",
    recipes: CONTRACT_RECIPE_KINDS,
    requiredInDefaultRecipe: true,
    enabledInDefaultRecipe: true
  },
  {
    kind: "owner-signature",
    key: "owner-signature",
    label: "Owner signature",
    description: "Single owner signature block at the bottom (no initials on this page).",
    editable: false,
    pageRole: "signature",
    recipes: CONTRACT_RECIPE_KINDS,
    requiredInDefaultRecipe: true,
    enabledInDefaultRecipe: true
  }
]

export const DEFAULT_MODULE_BODIES: Record<string, string> = {
  "payment-terms":
    "Payable upon completion of each trade and upon receipt of insurance proceeds. The homeowner deductible is due immediately. Additional provisions for this contract appear with this proposal.",
  "insurance-clause":
    "INSURANCE APPROVAL: I, the Owner(s), acknowledge and approve the contractor to proceed with the contracted work. I understand that during the course of work additional damage and costs may be discovered, and that those items may be billed to my insurance company. I am responsible for my deductible and for any upgrades or work not covered by insurance.",
  "after-work":
    "After the work is completed, have a licensed plumber or qualified HVAC technician inspect the complete furnace pipe assembly. Roofing work can disturb pipe sections that pass through the attic and roof deck. The contractor will inspect the assembly from the exterior and correct any damage or obstruction observed from outside the home. Interior inspection, carbon monoxide testing, and any electrical work for power vents remain the homeowner's responsibility through a licensed professional.",
  "right-to-cancel":
    "INSURANCE CONTINGENCY: You may cancel this contract in connection with the repair or replacement of a roof system or related property damage within seventy-two (72) hours after you have been notified that your insurer has denied all or any part of your claim for goods and services to repair or replace the damaged property. To cancel under this contingency, deliver written notice to the company within that 72-hour period.\n\nCONSUMER'S RIGHT TO CANCEL: You may cancel this transaction, without any penalty or obligation, within three (3) business days from the date above.\n\nIf you cancel, any property traded in, any payments made by you under the contract or sale, and any negotiable instrument executed by you will be returned within ten (10) business days following receipt by the seller of your cancellation notice, and any security interest arising out of the transaction will be cancelled.\n\nIf you cancel, you must make available to the seller at your residence, in substantially as good condition as when received, any goods delivered to you under this contract or sale; or you may, if you wish, comply with the instructions of the seller regarding the return shipment of the goods at the seller's expense and risk.\n\nIf you do make the goods available to the seller and the seller does not pick them up within twenty (20) days of the date of your notice of cancellation, you may retain or dispose of the goods without any further obligation. If you fail to make the goods available to the seller, or if you agree to return the goods to the seller and fail to do so, then you remain liable for performance of all obligations under the contract.\n\nTo cancel this transaction, mail or deliver a signed and dated copy of this cancellation notice, or any other written notice, to the company address or email listed on this contract.",
  "terms-conditions":
    "1. All proposals are subject to management approval. The company reserves the right to cancel this proposal at any time.\n2. The equity in the property described is security for this contract. This contract becomes binding upon written acceptance or commencement of work.\n3. The contractor is an independent contractor and not an agent or subcontractor of any other corporation.\n4. This written contract constitutes the entire understanding between the parties. Changes must be in writing and signed.\n5. Replacement of deteriorating decking, extra layers, fascia, vents, and flashings are not included unless stated and will be charged as extras.\n6. Proposals expire twenty (20) days from the proposal date.\n7. A restocking fee of 15% or actual costs incurred applies if materials are ordered and the customer cancels.\n8. Only written terms in this contract are binding.\n9. The company is not responsible for pre-existing structural conditions, appearance due to underlying irregularities, or movement from weight-load changes.\n10. The company is not responsible for problems caused by improper ventilation.\n11. The company is not responsible for minor siding or gutter scuffing during tear-off.\n12. Leftover materials remain the property of the contractor.\n13. Labor warranty excludes damage from extreme weather (including winds over 50 mph), lightning, hail, or settlement/distortion of the building.\n14. Unpaid balances over 30 days accrue interest at 1.5% per month.\n15. The owner agrees to pay reasonable attorney fees and costs if legal action is required to enforce this contract.\n16. The company is not responsible for inspections of areas not visible during the normal trade process. The homeowner is responsible for third-party inspections.",
  "gutter-specifications":
    "Install seamless gutters and downspouts as specified.\nFurnish all material and labor.\nClean up and haul away all debris.\nPermit furnished by contractor if needed.",
  "siding-specifications":
    "Furnish and install siding materials as specified.\nTear off existing siding as noted.\nFurnish all material and labor.\n5 Year workmanship warranty.\nClean up and haul all trash daily.\nRoll yard with magnetic roller."
}

export function defaultRecipeSlots(kind: ContractRecipeKind = "roofing"): ContractRecipeSlot[] {
  return CONTRACT_MODULE_CATALOG
    .filter((entry) => entry.recipes.includes(kind))
    .map((entry) => ({
      key: entry.key,
      kind: entry.kind,
      required: entry.requiredInDefaultRecipe,
      enabled: entry.enabledInDefaultRecipe
    }))
}

export function defaultEnabledRecipes(): Record<ContractRecipeKind, boolean> {
  return {
    roofing: true,
    gutters: true,
    siding: true
  }
}

export function defaultRecipes(): Record<ContractRecipeKind, ContractRecipeSlot[]> {
  return {
    roofing: defaultRecipeSlots("roofing"),
    gutters: defaultRecipeSlots("gutters"),
    siding: defaultRecipeSlots("siding")
  }
}

export function defaultModuleContents(): ContractModuleContent[] {
  return CONTRACT_MODULE_CATALOG.map((entry) => {
    const bodyByState: Record<string, string> = {}
    if (entry.editable) {
      bodyByState.DEFAULT = DEFAULT_MODULE_BODIES[entry.key] ?? ""
    }
    return {
      key: entry.key,
      kind: entry.kind,
      label: entry.label,
      bodyByState
    }
  })
}

export function catalogEntryForKind(kind: ContractModuleKind) {
  return CONTRACT_MODULE_CATALOG.find((entry) => entry.kind === kind)
}

export function isContractRecipeKind(value: unknown): value is ContractRecipeKind {
  return CONTRACT_RECIPE_KINDS.includes(value as ContractRecipeKind)
}
