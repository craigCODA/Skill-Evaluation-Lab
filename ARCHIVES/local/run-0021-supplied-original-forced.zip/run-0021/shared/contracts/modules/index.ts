export type {
  CompanyContractConfig,
  ComposedContract,
  ComposedContractModule,
  ContractModuleContent,
  ContractModuleKey,
  ContractModuleKind,
  ContractModulePageRole,
  ContractRecipeKind,
  ContractRecipeSlot,
  JobContractBundle,
  JobContractPair,
  JobContractSignedPdf,
  JobContractSnapshot,
  JobContractStatus
} from "./types"

export {
  CONTRACT_RECIPE_KINDS,
  CONTRACT_RECIPE_LABELS
} from "./types"

export {
  CONTRACT_MODULE_CATALOG,
  DEFAULT_MODULE_BODIES,
  catalogEntryForKind,
  defaultEnabledRecipes,
  defaultModuleContents,
  defaultRecipeSlots,
  defaultRecipes,
  isContractRecipeKind
} from "./catalog"
export type { ContractModuleCatalogEntry } from "./catalog"

export {
  activeRecipeKinds,
  enabledRecipeSlots,
  moduleContentByKey,
  newCompanyContractConfig,
  newJobContractSnapshotId,
  normalizeCompanyContractConfig,
  normalizeModuleContents,
  normalizeRecipeSlots,
  parseContractRecipeKind,
  resolveModuleBody
} from "./normalize"

export { composeRoofingContract, composeTradeContract } from "./compose"
export type { ComposeContractContext } from "./compose"
