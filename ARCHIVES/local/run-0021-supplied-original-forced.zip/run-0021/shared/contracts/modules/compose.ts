/**
 * Compose one trade contract from company config + estimate context.
 */

import { formatCustomerName } from "../../customer"
import { resolveLogoUrl } from "../../branding"
import type { Catalog } from "../../pricebook/types"
import type { RoofingEstimateTotals } from "../../calculator/calculateEstimate"
import type { CompanyProfile, Job } from "../../types"
import type { ContractParty } from "../contractParty"
import { contractParty } from "../contractParty"
import type { ContractLine } from "../types"
import { compactLines, line } from "../proposalCommon"
import {
  buildConditionalAddendumLines,
  buildWorkmanshipLines,
  buildPreparationLines
} from "../roofProposalScope"
import { buildRoofProcessNarrativeLines } from "../roofProposalNarrative"
import { catalogEntryForKind } from "./catalog"
import {
  enabledRecipeSlots,
  moduleContentByKey,
  resolveModuleBody
} from "./normalize"
import type {
  CompanyContractConfig,
  ComposedContract,
  ComposedContractModule,
  ContractModuleKind,
  ContractRecipeKind
} from "./types"
import { CONTRACT_RECIPE_LABELS } from "./types"

export type ComposeContractContext = {
  job: Job
  catalog: Catalog
  roofingTotals?: RoofingEstimateTotals | null
  companyProfile: CompanyProfile | null
  platformProfile?: CompanyProfile | null
  config: CompanyContractConfig
  recipeKind: ContractRecipeKind
}

function paragraphsToLines(body: string): ContractLine[] {
  return body
    .split(/\n+/)
    .map((part) => part.trim())
    .filter(Boolean)
    .map((label) => ({ label }))
}

function buildMeasurementLines(job: Job): ContractLine[] {
  const roofing = job.scope.roofing
  if (!roofing) return []
  return roofing.areas.map((area, index) => {
    const label = area.label?.trim() || `Area ${index + 1}`
    const parts = [
      area.story ? `Stories: ${area.story}` : "",
      area.pitch ? `Pitch: ${area.pitch}` : "",
      area.inputSquares ? `Squares: ${area.inputSquares}` : "",
      area.location ? `Location: ${area.location}` : ""
    ].filter(Boolean)
    return { label, value: parts.join(" · ") || "—" }
  })
}

function buildLocationLines(profile: CompanyProfile | null, license?: string): ContractLine[] {
  const lines: ContractLine[] = []
  if (license?.trim()) {
    lines.push({ label: "License", value: license.trim() })
  }
  const locations = profile?.locations ?? []
  if (!locations.length) {
    lines.push({
      label: "No office locations configured. Add them under Company Information."
    })
    return lines
  }
  lines.push(
    ...locations.map((location) => ({
      label: location.label || location.city || "Office",
      value: [
        [location.address1, location.city, location.state, location.zip].filter(Boolean).join(", "),
        location.phone || location.officePhone
      ]
        .filter(Boolean)
        .join(" · ")
    }))
  )
  return lines
}

function tradeAmount(ctx: ComposeContractContext): number {
  if (ctx.recipeKind === "roofing") return ctx.roofingTotals?.grandTotal ?? 0
  return ctx.job.extras?.amount || 0
}

function tradeTitle(kind: ContractRecipeKind): string {
  if (kind === "gutters") return "Gutter Proposal & Agreement"
  if (kind === "siding") return "Siding Proposal & Agreement"
  return "Roofing Proposal & Agreement"
}

function buildModule(
  kind: ContractModuleKind,
  key: string,
  title: string,
  sectionKind: ComposedContractModule["section"]["kind"],
  lines: ContractLine[]
): ComposedContractModule {
  const catalog = catalogEntryForKind(kind)
  return {
    key,
    kind,
    title,
    pageRole: catalog?.pageRole ?? "content",
    section: {
      title,
      kind: sectionKind,
      lines
    }
  }
}

function composeModule(
  kind: ContractModuleKind,
  key: string,
  ctx: ComposeContractContext,
  party: ContractParty
): ComposedContractModule | null {
  const { job, catalog, companyProfile, config, recipeKind } = ctx
  const content = moduleContentByKey(config, key)
  const label = content?.label || catalogEntryForKind(kind)?.label || key
  const state = job.customer.state
  const body = resolveModuleBody(content, state)
  const amount = tradeAmount(ctx)

  switch (kind) {
    case "letterhead":
      return buildModule(kind, key, label, "content", compactLines([
        line("Company", party.name),
        line("Office", party.address),
        line("Phone", party.phone),
        line("License", party.license),
        line("Email", party.supportEmail)
      ]))
    case "customer-header":
      return buildModule(kind, key, label, "content", compactLines([
        line("Name", formatCustomerName(job.customer)),
        line("Street", job.customer.address1 ?? job.customer.street ?? ""),
        line("City & State", [job.customer.city, job.customer.state, job.customer.zip].filter(Boolean).join(", ")),
        line("Phone", job.customer.phone),
        line("Date", new Date().toLocaleDateString()),
        line("Job Street", job.customer.address1 ?? job.customer.street ?? ""),
        line("Job City & State", [job.customer.city, job.customer.state, job.customer.zip].filter(Boolean).join(", ")),
        line("Estimator", job.estimator)
      ]))
    case "measurement-grid":
      if (recipeKind !== "roofing" || !job.scope.roofing) return null
      return buildModule(kind, key, label, "content", buildMeasurementLines(job))
    case "agreement-amount":
      return buildModule(kind, key, label, "pricing", [
        {
          label: `${party.name} (“Contractor”) agrees to furnish all materials and labor necessary to complete the ${CONTRACT_RECIPE_LABELS[recipeKind].toLowerCase()} work described in this proposal.`,
        },
        {
          label: "I / We the Owner(s) agree to pay the sum of",
          amount
        }
      ])
    case "roof-specifications": {
      if (!job.scope.roofing) return null
      return buildModule(
        kind,
        key,
        "Specifications of Work to Be Completed",
        "content",
        buildRoofProcessNarrativeLines(job.scope.roofing, catalog)
      )
    }
    case "gutter-specifications":
      return buildModule(kind, key, "Specifications of Work to Be Completed", "content", [
        ...paragraphsToLines(body),
        ...compactLines([
          line("Extras / notes", job.extras?.description),
          job.extras?.amount
            ? { label: "Extras amount", amount: job.extras.amount }
            : { label: "" }
        ].filter((item) => item.label))
      ])
    case "siding-specifications":
      return buildModule(kind, key, "Specifications of Work to Be Completed", "content", [
        ...paragraphsToLines(body),
        ...compactLines([
          line("Extras / notes", job.extras?.description),
          job.extras?.amount
            ? { label: "Extras amount", amount: job.extras.amount }
            : { label: "" }
        ].filter((item) => item.label))
      ])
    case "workmanship":
      return buildModule(
        kind,
        key,
        label,
        "bullets",
        buildWorkmanshipLines(party.name, job.permit)
      )
    case "payment-terms":
      return buildModule(kind, key, label, "content", paragraphsToLines(body))
    case "insurance-clause":
      return buildModule(kind, key, label, "content", [
        ...paragraphsToLines(body),
        ...compactLines([
          line("Insurance company", job.customer.insurance?.company),
          line("Claim number", job.customer.insurance?.claimNumber),
          line("Insurance contact", job.customer.insurance?.contact)
        ]),
        ...(job.scope.roofing ? buildConditionalAddendumLines(job.scope.roofing) : [])
      ])
    case "job-prep": {
      const hasSkylights = Boolean(
        job.scope.roofing?.skylights.some(
          (row) => row.count > 0 && row.option !== "Select Skylight"
        )
      )
      return buildModule(
        kind,
        key,
        "How to Prepare for the Job",
        "bullets",
        buildPreparationLines(party.name, hasSkylights)
      )
    }
    case "after-work":
      return buildModule(kind, key, "After the Work Is Completed", "content", paragraphsToLines(body))
    case "right-to-cancel":
      return buildModule(kind, key, "Consumer's Right to Cancel", "content", [
        ...paragraphsToLines(body),
        {
          label: `${CONTRACT_RECIPE_LABELS[recipeKind]} contract amount: ${amount.toLocaleString(undefined, { style: "currency", currency: "USD" })}`
        },
        line("Cancellation contact", party.supportEmail || party.address)
      ])
    case "owner-signature":
      return buildModule(kind, key, "Owner Signature", "signatures", [
        { label: "Owner / Purchaser" },
        { label: "Date" }
      ])
    case "terms-conditions":
      return buildModule(kind, key, label, "content", paragraphsToLines(body))
    case "locations":
      return buildModule(
        kind,
        key,
        label,
        "content",
        buildLocationLines(companyProfile, party.license)
      )
    default:
      return null
  }
}

export function composeTradeContract(ctx: ComposeContractContext): ComposedContract {
  const party = contractParty(
    ctx.companyProfile,
    ctx.platformProfile,
    ctx.job.customer.state
  )
  const logoUrl = resolveLogoUrl(
    ctx.companyProfile?.logoUrl || ctx.platformProfile?.logoUrl
  )
  const modules: ComposedContractModule[] = []

  for (const slot of enabledRecipeSlots(ctx.config, ctx.recipeKind)) {
    const composed = composeModule(slot.kind, slot.key, ctx, party)
    if (composed) modules.push(composed)
  }

  const letterhead = modules.find((module) => module.kind === "letterhead")?.section.lines ?? []

  return {
    title: tradeTitle(ctx.recipeKind),
    recipeKind: ctx.recipeKind,
    meta: {
      companyName: party.name,
      logoUrl: logoUrl || undefined,
      license: party.license || undefined,
      supportEmail: party.supportEmail,
      representative: party.representative,
      documentDate: new Date().toLocaleDateString()
    },
    modules,
    total: tradeAmount(ctx),
    generatedAt: new Date().toISOString(),
    letterhead
  }
}

/** @deprecated Use composeTradeContract */
export function composeRoofingContract(ctx: Omit<ComposeContractContext, "recipeKind">): ComposedContract {
  return composeTradeContract({ ...ctx, recipeKind: "roofing" })
}
