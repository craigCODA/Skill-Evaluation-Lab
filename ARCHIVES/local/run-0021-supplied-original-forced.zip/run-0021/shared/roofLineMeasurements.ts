import type { FramePoint } from "./roofImageryScale";

export type RoofLineMeasurementType =
  | "measurement"
  | "ridge"
  | "hip"
  | "valley"
  | "eave"
  | "rake"
  | "caution-tape";

export type RoofLineMeasurement = {
  id: string;
  type: RoofLineMeasurementType;
  start: FramePoint;
  end: FramePoint;
  pitchRiseOver12?: number;
  feet: number;
};

export type RoofIconMarkerType =
  | "downspout"
  | "roof-vent"
  | "ladder"
  | "number-1"
  | "number-2"
  | "number-3"
  | "number-4"
  | "number-5"
  | "number-6"
  | "number-7"
  | "number-8";

export type RoofIconMarker = {
  id: string;
  type: RoofIconMarkerType;
  point: FramePoint;
};

export const roofIconMarkerTypes: Array<{
  type: RoofIconMarkerType;
  label: string;
  iconPath?: string;
  markerText?: string;
}> = [
  {
    type: "downspout",
    label: "Downspout",
    iconPath: "/roof-icons/downspout.svg",
  },
  {
    type: "roof-vent",
    label: "Roof vent",
    iconPath: "/roof-icons/roof-vent.svg",
  },
  {
    type: "ladder",
    label: "Ladder",
    iconPath: "/roof-icons/ladder.svg",
  },
  ...([1, 2, 3, 4, 5, 6, 7, 8] as const).map((number) => ({
    type: `number-${number}` as RoofIconMarkerType,
    label: `${number}`,
    markerText: `${number}`,
  })),
];

export function roofIconMarkerMeta(type: RoofIconMarkerType) {
  const fallback = roofIconMarkerTypes[0];
  if (!fallback) {
    throw new Error("Roof icon marker types are not configured");
  }
  return roofIconMarkerTypes.find((item) => item.type === type) ?? fallback;
}

export type RoofAreaShapeColor = "pink" | "blue" | "green" | "yellow" | "orange";

export type RoofAreaShape = {
  id: string;
  color: RoofAreaShapeColor;
  points: FramePoint[];
};

export const roofAreaShapeColors: Array<{
  color: RoofAreaShapeColor;
  label: string;
  value: string;
}> = [
  { color: "pink", label: "Pink", value: "#ec4899" },
  { color: "blue", label: "Blue", value: "#2563eb" },
  { color: "green", label: "Green", value: "#22c55e" },
  { color: "yellow", label: "Yellow", value: "#eab308" },
  { color: "orange", label: "Orange", value: "#f97316" },
];

export function roofAreaShapeColorMeta(color: RoofAreaShapeColor) {
  const fallback = roofAreaShapeColors[0];
  if (!fallback) {
    throw new Error("Roof area shape colors are not configured");
  }
  return roofAreaShapeColors.find((item) => item.color === color) ?? fallback;
}

export const roofLineMeasurementTypes: Array<{
  type: RoofLineMeasurementType;
  label: string;
  color: string;
  countsTowardRoofTotal: boolean;
  pitchAdjustment: "none" | "optional" | "required";
}> = [
  {
    type: "measurement",
    label: "Measure",
    color: "#ffffff",
    countsTowardRoofTotal: false,
    pitchAdjustment: "none",
  },
  {
    type: "ridge",
    label: "Ridge",
    color: "#ef4444",
    countsTowardRoofTotal: true,
    pitchAdjustment: "none",
  },
  {
    type: "hip",
    label: "Hip",
    color: "#f97316",
    countsTowardRoofTotal: true,
    pitchAdjustment: "optional",
  },
  {
    type: "valley",
    label: "Valley",
    color: "#a855f7",
    countsTowardRoofTotal: true,
    pitchAdjustment: "optional",
  },
  {
    type: "eave",
    label: "Eave",
    color: "#2563eb",
    countsTowardRoofTotal: true,
    pitchAdjustment: "none",
  },
  {
    type: "rake",
    label: "Rake",
    color: "#22c55e",
    countsTowardRoofTotal: true,
    pitchAdjustment: "required",
  },
  {
    type: "caution-tape",
    label: "Caution tape",
    color: "#facc15",
    countsTowardRoofTotal: false,
    pitchAdjustment: "none",
  },
];

export const roofPitchRiseOptions = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12] as const;

export function roofLineTypeMeta(type: RoofLineMeasurementType) {
  const fallback = roofLineMeasurementTypes[0];
  if (!fallback) {
    throw new Error("Roof line measurement types are not configured");
  }
  return roofLineMeasurementTypes.find((item) => item.type === type) ?? fallback;
}

export function roofLineMeasurementTotals(lines: RoofLineMeasurement[]) {
  return roofLineMeasurementTypes.reduce(
    (totals, item) => {
      totals[item.type] = lines
        .filter((line) => line.type === item.type)
        .reduce((sum, line) => sum + roofLineAdjustedFeet(line), 0);
      return totals;
    },
    {} as Record<RoofLineMeasurementType, number>,
  );
}

export function roofLinePitchFactor(pitchRiseOver12: number): number {
  return Math.sqrt(pitchRiseOver12 ** 2 + 12 ** 2) / 12;
}

export function roofLineAdjustedFeet(line: RoofLineMeasurement): number {
  const meta = roofLineTypeMeta(line.type);
  if (meta.pitchAdjustment === "none" || line.pitchRiseOver12 === undefined) {
    return line.feet;
  }
  return line.feet * roofLinePitchFactor(line.pitchRiseOver12);
}

export function roofLineUsesPitch(type: RoofLineMeasurementType): boolean {
  return roofLineTypeMeta(type).pitchAdjustment !== "none";
}
