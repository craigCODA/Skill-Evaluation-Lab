/**
 * Step flashing (job level).
 *
 *   cost = stepFlashingLf × lookup("Step Flashing").pricePerFoot
 */

import type { Money } from "../types";
import type { Catalog, FlashingRate } from "../pricebook/types";
import type { JobContext, JobOption } from "./types";

const STEP_FLASHING_KEY = "Step Flashing";

export type StepFlashingInputs = {
  stepFlashingLf: number;
};

export type StepFlashingBreakdown = {
  pricePerFoot: Money;
  cost: Money;
};

function findRate(rates: FlashingRate[], key: string): FlashingRate | null {
  return rates.find((r) => r.key === key) ?? null;
}

function stepFlashingCost(
  inputs: StepFlashingInputs,
  cat: Catalog,
): StepFlashingBreakdown {
  const row = findRate(cat.flashingRates, STEP_FLASHING_KEY);
  const pricePerFoot = row?.pricePerFoot ?? 0;
  return {
    pricePerFoot,
    cost: inputs.stepFlashingLf * pricePerFoot,
  };
}

export const stepFlashingOption: JobOption<StepFlashingBreakdown> = {
  id: "stepFlash",
  title: "Step Flashing",
  summary: "Step flashing billed per linear foot at its catalog rate.",
  phase: "job",
  billed: true,
  pricingPlain:
    "Charged by the foot: the step-flashing length times its per-foot rate.",
  example: "25 ft of step flashing at $3/ft = $75.",
  fieldLabels: ["Step flashing LF"],
  catalogTables: ["flashingRates"],
  inputs: [
    { name: "Step flashing LF", description: "Linear feet of step flashing." },
  ],
  formula: `cost = stepFlashingLf x lookup("Step Flashing").pricePerFoot`,
  contractEffect: "Adds the step flashing cost to the roofing proposal grand total.",
  compute: (ctx: JobContext) =>
    stepFlashingCost(
      { stepFlashingLf: ctx.roofing.stepFlashingLf },
      ctx.catalog,
    ),
};
