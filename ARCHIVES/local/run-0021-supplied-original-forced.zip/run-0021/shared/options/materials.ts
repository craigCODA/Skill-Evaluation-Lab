/**
 * Materials take-off — pure function.
 *
 * Every count is derived from the existing `Job` state plus a small set of
 * named scalars in `cat.materialsRates` (LF per bundle, sf per sheet, waste
 * factor, etc.) that non-developers can tune.
 *
 * Notes:
 *   - Starter strip + drip edge sticks divide by `eaveLf` directly,
 *     not `eaveLf × $/ft`.
 *   - Ridge LF is an explicit input (`RoofingScope.ridgeLf`).
 *   - Per-area felt counts iterate over `RoofArea.underlayment.feltType`
 *     (carried on the catalog row).
 */

import type { Catalog, MaterialsRate, UnderlaymentOption } from "../pricebook/types";
import type { RoofArea, RoofingScope } from "../types";
import { roofAreaSurfaceSqft } from "../roofArea";
import { perAreaInstallCost } from "./install";

export type MaterialsCounts = {
  shingleSquares: number;
  capBundles: number;
  starterBundles: number;
  iceWaterSquares: number;
  felt15Rolls: number;
  felt30Rolls: number;
  dripEdgeSticks: number;
  capNailsLbs: number;
  coilNailsLbs: number;
  plywoodSheets: number;
  /** Raw intermediates exposed for UI tooltips and debugging. */
  intermediates: {
    /** Sum of per-area squares with waste. */
    totalSquaresWithWaste: number;
    /** Sum of per-area raw sqft. */
    totalAreaSqft: number;
    /** Sum of per-area `eaveDripLf`. */
    totalEaveLf: number;
    /** Sum of per-area 15# felt squares. */
    felt15Squares: number;
    /** Sum of per-area 30# felt squares. */
    felt30Squares: number;
    /** Sum of per-area redeck sf. */
    redeckSqft: number;
    /** Sum of per-area I&W coverage in sf-equivalent. */
    iceWaterSqft: number;
  };
};

function rate(cat: Catalog, key: string, fallback: number): number {
  const row = (cat.materialsRates as MaterialsRate[]).find((r) => r.key === key);
  return row?.value ?? fallback;
}

function feltType(
  cat: Catalog,
  key: string,
): UnderlaymentOption["feltType"] {
  const row = cat.underlayments.find((u) => u.key === key);
  return row?.feltType ?? "none";
}

function iceWaterCovers(cat: Catalog, key: string): {
  eaves: boolean;
  valleys: boolean;
} {
  const opt = cat.iceWaterOptions.find((o) => o.key === key);
  return { eaves: opt?.coversEaves ?? false, valleys: opt?.coversValleys ?? false };
}

function overhangRows(cat: Catalog, key: string): number {
  return cat.iceWaterOverhangs.find((o) => o.key === key)?.rows ?? 0;
}

/**
 * Aggregate per-area squares-with-waste + raw sqft. Reuses
 * `perAreaInstallCost` so the math stays identical to what the install
 * cost slice produces.
 */
function aggregateGeometry(
  area: RoofArea,
  shinglePricePerSquare: number,
  cat: Catalog,
): { areaSqft: number; squares: number } {
  const bd = perAreaInstallCost(
    {
      story: area.story,
      pitch: area.pitch,
      tearoff: area.layers,
      redeck: area.redeck,
      areaSqft: roofAreaSurfaceSqft(area),
      wasteMultiplier: 1 + area.wastePercent / 100,
    },
    shinglePricePerSquare,
    cat,
  );
  return { areaSqft: bd.areaSqft, squares: bd.squares };
}

export function materialsCounts(
  scope: RoofingScope,
  cat: Catalog,
): MaterialsCounts {
  const wasteFactor = rate(cat, "shingle-waste-factor", 0.967);
  const lfPerCapBundle = rate(cat, "cap-shingle-lf-per-bundle", 32);
  const lfPerStarterBundle = rate(cat, "starter-strip-lf-per-bundle", 100);
  const sfPerIceWaterSquare = rate(cat, "ice-water-sf-per-square", 33);
  const sqPerFelt15Roll = rate(cat, "felt-15-squares-per-roll", 4);
  const sqPerFelt30Roll = rate(cat, "felt-30-squares-per-roll", 2);
  const lfPerDripStick = rate(cat, "drip-edge-lf-per-stick", 10);
  const dripSpareSticks = rate(cat, "drip-edge-spare-sticks", 2);
  const sqPerCapNailLb = rate(cat, "cap-nails-squares-per-lb", 25);
  const sqPerCoilNailLb = rate(cat, "coil-nails-squares-per-lb", 18);
  const sfPerPlywoodSheet = rate(cat, "plywood-sf-per-sheet", 32);
  const plywoodSpareSheets = rate(cat, "plywood-spare-sheets", 2);

  const shinglePricePerSquare = 0;

  let totalSquares = 0;
  let totalAreaSqft = 0;
  let totalEaveLf = 0;
  let felt15Squares = 0;
  let felt30Squares = 0;
  let redeckSqft = 0;
  let iceWaterSqft = 0;

  for (const area of scope.areas) {
    const { areaSqft, squares } = aggregateGeometry(
      area,
      shinglePricePerSquare,
      cat,
    );
    totalSquares += squares;
    totalAreaSqft += areaSqft;
    totalEaveLf += area.eaveDripLf;

    const ft = feltType(cat, area.underlayment);
    if (ft === "15-single") felt15Squares += squares;
    else if (ft === "15-double") felt15Squares += 2 * squares;
    else if (ft === "30-single") felt30Squares += squares;

    if (area.redeck !== "No") redeckSqft += areaSqft;

    const cover = iceWaterCovers(cat, area.iceWaterOption);
    const rows = overhangRows(cat, area.iceWaterOverhang);
    if (cover.eaves) iceWaterSqft += area.eaveDripLf * rows;
    if (cover.valleys) iceWaterSqft += area.iceWaterValleyLf;
  }

  const shingleSquares = roundUp(totalSquares * wasteFactor, 1);
  const capBundles = roundUpInt(scope.ridgeLf / lfPerCapBundle);
  const starterBundles = roundUpInt(totalEaveLf / lfPerStarterBundle);
  const iceWaterSquares = roundUpInt(iceWaterSqft / sfPerIceWaterSquare);
  const felt15Rolls = roundUpInt(felt15Squares / sqPerFelt15Roll);
  const felt30Rolls = roundUpInt(felt30Squares / sqPerFelt30Roll);
  const dripEdgeSticks =
    totalEaveLf > 0
      ? roundUpInt(totalEaveLf / lfPerDripStick) + dripSpareSticks
      : 0;
  const capNailsLbs = roundUpInt(totalSquares / sqPerCapNailLb);
  const coilNailsLbs = roundUpInt(totalSquares / sqPerCoilNailLb);
  const plywoodSheets =
    redeckSqft > 0
      ? roundUpInt(redeckSqft / sfPerPlywoodSheet) + plywoodSpareSheets
      : 0;

  return {
    shingleSquares,
    capBundles,
    starterBundles,
    iceWaterSquares,
    felt15Rolls,
    felt30Rolls,
    dripEdgeSticks,
    capNailsLbs,
    coilNailsLbs,
    plywoodSheets,
    intermediates: {
      totalSquaresWithWaste: totalSquares,
      totalAreaSqft,
      totalEaveLf,
      felt15Squares,
      felt30Squares,
      redeckSqft,
      iceWaterSqft,
    },
  };
}

function roundUpInt(n: number): number {
  return Math.ceil(n - 1e-9);
}

function roundUp(n: number, decimals: number): number {
  const m = Math.pow(10, decimals);
  return Math.ceil(n * m - 1e-9) / m;
}
