/**
 * Chimney removal (job level).
 *
 *   cost = lookup(option).price
 *
 * Catalog options:
 *   "No"                          → $0
 *   "Yes - 2x2 - 4' or less"      → $200
 *   "Yes - 2x3 - 4' or less"      → $300
 *   "Yes - 2x4 - 4' or less"      → $400
 *
 * Unknown / empty keys resolve to $0 so missing data on legacy jobs is safe.
 */

import type { Money } from "../types";
import type { Catalog, ChimneyRemovalOption } from "../pricebook/types";
import type { JobContext, JobOption } from "./types";

export type ChimneyRemovalInputs = {
  /** Catalog key (`ChimneyRemovalOption.key`). Empty / unknown → $0. */
  option: string;
};

export type ChimneyRemovalBreakdown = {
  price: Money;
  cost: Money;
};

function findOption(
  options: ChimneyRemovalOption[],
  key: string,
): ChimneyRemovalOption | null {
  return options.find((o) => o.key === key) ?? null;
}

function chimneyRemovalCost(
  inputs: ChimneyRemovalInputs,
  cat: Catalog,
): ChimneyRemovalBreakdown {
  const row = findOption(cat.chimneyRemovalOptions, inputs.option);
  const price = row?.price ?? 0;
  return { price, cost: price };
}

export const chimneyRemovalOption: JobOption<ChimneyRemovalBreakdown> = {
  id: "chimney",
  title: "Chimney Removal",
  summary:
    "A flat job-level charge based on the selected chimney removal option. No measurements involved — the option itself carries the price.",
  phase: "job",
  billed: true,
  pricingPlain:
    "A flat price based on the option you pick — no measuring. Bigger chimneys cost more; 'No' is free.",
  example: "Picking 'Yes - 2x3 - 4' or less' adds a flat $300.",
  fieldLabels: ["Chimney removal"],
  catalogTables: ["chimneyRemovalOptions"],
  inputs: [
    { name: "Chimney removal option", description: "Picker key (keys chimneyRemovalOptions); 'No' means no removal." },
  ],
  formula: `cost = lookup(option).price

No   -> $0
Yes - 2x2 - 4' or less -> $200
Yes - 2x3 - 4' or less -> $300
Yes - 2x4 - 4' or less -> $400`,
  contractEffect:
    "Adds a flat chimney-removal charge to the roofing proposal grand total. Not printed as its own specification line today.",
  notes:
    "Unknown or empty keys resolve to $0 so legacy jobs with missing data stay safe.",
  compute: (ctx: JobContext) =>
    chimneyRemovalCost({ option: ctx.roofing.chimneyRemoval }, ctx.catalog),
};
