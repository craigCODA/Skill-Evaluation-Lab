/**
 * Gutter removal / work-around (job level).
 *
 *   cost = workAroundGutters === "Yes" ? lf × pricePerFoot : 0
 */

import type { Money } from "../types";
import type { Catalog, GutterRemovalRate } from "../pricebook/types";
import type { JobContext, JobOption } from "./types";

export type GutterRemovalInputs = {
  workAroundGutters: "No" | "Yes";
  lf: number;
};

export type GutterRemovalBreakdown = {
  pricePerFoot: Money;
  cost: Money;
};

function gutterRemovalCost(
  inputs: GutterRemovalInputs,
  cat: Catalog,
): GutterRemovalBreakdown {
  const rates = cat.gutterRemovalRates as GutterRemovalRate[];
  const row = rates.find((r) => r.key === "default");
  const pricePerFoot = row?.pricePerFoot ?? 0;
  const cost =
    inputs.workAroundGutters === "Yes" ? inputs.lf * pricePerFoot : 0;
  return { pricePerFoot, cost };
}

export const gutterRemovalOption: JobOption<GutterRemovalBreakdown> = {
  id: "gutterRemoval",
  title: "Gutter Removal / Work-around",
  summary:
    "When working around gutters, billed per linear foot at the gutter removal rate; otherwise $0.",
  phase: "job",
  billed: true,
  pricingPlain:
    "Only charged when 'work around gutters' is set to Yes: the gutter length times the per-foot rate. Otherwise it's $0.",
  example: "60 ft at $1.50/ft = $90 (or $0 when set to No).",
  fieldLabels: ["Gutter workaround", "Gutter removal LF"],
  catalogTables: ["gutterRemovalRates"],
  inputs: [
    { name: "Gutter workaround", description: "'Yes' enables the gutter removal charge." },
    { name: "Gutter removal LF", description: "Linear feet of gutter to remove / work around." },
  ],
  formula: `cost = workAroundGutters = "Yes" ? lf x pricePerFoot : 0`,
  contractEffect: "Adds the gutter removal cost to the roofing proposal grand total.",
  compute: (ctx: JobContext) =>
    gutterRemovalCost(
      {
        workAroundGutters: ctx.roofing.workAroundGutters,
        lf: ctx.roofing.gutterRemovalLf,
      },
      ctx.catalog,
    ),
};
