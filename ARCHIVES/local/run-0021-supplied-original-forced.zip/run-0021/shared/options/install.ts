/**
 * Install (story / pitch / layers / redeck geometry + labor & material).
 *
 * Per-area install math:
 *
 *   areaSqft             = length * width
 *   squares              = (areaSqft * wasteMultiplier) / 100
 *   laborRate            = storyRate + pitchRate                       // per sqft
 *   tearoffAndRedeckRate = tearoffRate + redeckRate                    // per sqft
 *   tearoffAndRedeckCost = tearoffAndRedeckRate * areaSqft
 *   laborAndMaterialCost = (laborRate * 100 + shinglePricePerSquare) * squares
 *   installCost          = tearoffAndRedeckCost + laborAndMaterialCost
 *
 * Labels for story / pitch / tearoff / redeck are the exact picker strings
 * (e.g. "1S", "7/12", "1C", "Yes - Walk"). Unknown labels resolve to a 0 rate.
 */

import type { Money } from "../types";
import type { Catalog, RateRow } from "../pricebook/types";
import { roofAreaSurfaceSqft } from "../roofArea";
import type { AreaContext, AreaOption } from "./types";

export type PerAreaInputs = {
  story: string;
  pitch: string;
  tearoff: string;
  redeck: string;
  /** Sloped roof surface sq ft (before waste). */
  areaSqft: number;
  wasteMultiplier: number;
};

export type PerAreaBreakdown = {
  areaSqft: number;
  squares: number;
  storyRate: Money;
  pitchRate: Money;
  tearoffRate: Money;
  redeckRate: Money;
  tearoffAndRedeckCost: Money;
  laborAndMaterialCost: Money;
  total: Money;
};

function lookupRate(rows: RateRow[], key: string): Money {
  const row = rows.find((r) => r.key === key);
  return row?.ratePerSqft ?? 0;
}

export function perAreaInstallCost(
  inputs: PerAreaInputs,
  shinglePricePerSquare: Money,
  cat: Catalog,
): PerAreaBreakdown {
  const areaSqft = inputs.areaSqft;
  const squares = (areaSqft * inputs.wasteMultiplier) / 100;

  const storyRate = lookupRate(cat.storyRates, inputs.story);
  const pitchRate = lookupRate(cat.pitchRates, inputs.pitch);
  const tearoffRate = lookupRate(cat.tearoffRates, inputs.tearoff);
  const redeckRate = lookupRate(cat.redeckRates, inputs.redeck);

  const m = storyRate + pitchRate;
  const n = tearoffRate + redeckRate;

  const tearoffAndRedeckCost = n * areaSqft;
  const laborAndMaterialCost = (m * 100 + shinglePricePerSquare) * squares;

  return {
    areaSqft,
    squares,
    storyRate,
    pitchRate,
    tearoffRate,
    redeckRate,
    tearoffAndRedeckCost,
    laborAndMaterialCost,
    total: tearoffAndRedeckCost + laborAndMaterialCost,
  };
}

export const installOption: AreaOption<PerAreaBreakdown> = {
  id: "install",
  title: "Install (story, pitch, layers, redeck)",
  summary:
    "The per-area core: story and pitch set the labor rate, layers and redeck set the tearoff/redeck rate, and the plane size (squares, sq ft, or L×W) sets the squares. Combined with the shingle price, this produces the area's labor + material cost.",
  phase: "area",
  billed: true,
  pricingPlain:
    "Enter the plane size from your measurement report (squares or sq ft) or measure length × width on site. Story and pitch set the labor rate; layers and redeck set tearoff/redeck. Waste is added on top to get ordering squares.",
  example:
    "A 12-square plane with 10% waste = 13.2 ordering squares. At ~$250/square labor+material ≈ $3,300; tearoff at $0.50/sq ft on 1,200 sq ft adds $600.",
  fieldLabels: [
    "Story",
    "Pitch",
    "Layers",
    "Redeck",
    "Plane size",
    "Waste percent",
  ],
  catalogTables: ["storyRates", "pitchRates", "tearoffRates", "redeckRates"],
  inputs: [
    { name: "Story", description: "Height picker (1S, 1.5S, 2S, 3S). Keys storyRates." },
    { name: "Pitch", description: "Slope picker (Walk, 7/12, Flat - TPO, ...). Keys pitchRates." },
    { name: "Layers", description: "Tearoff picker (1C, 2C+1W, Asbestos, ...). Keys tearoffRates; also keys no-access $/sq and felt material parity." },
    { name: "Redeck", description: "Redeck picker (No, Yes - Walk, Yes - Steep). Keys redeckRates; if not 'No', drives plywood sheet counts." },
    { name: "Plane size", description: "Squares, surface sq ft, or L×W (surface or horizontal footprint with pitch factor)." },
    { name: "Waste percent", description: "Waste allowance; wasteMultiplier = 1 + wastePercent / 100." },
    { name: "Shingle price", description: "Selected product $/square; shared by every area." },
  ],
  formula: `areaSqft  = squares x 100 | surface sq ft | L x W (x pitch factor if footprint)
squares   = areaSqft x wasteMultiplier / 100
laborRate = storyRate + pitchRate                       (per sqft)
tearoffAndRedeck = (tearoffRate + redeckRate) x areaSqft
laborAndMaterial = (laborRate x 100 + shinglePrice) x squares
total = tearoffAndRedeck + laborAndMaterial`,
  contractEffect:
    "Drives the per-area squares and the labor + material line that rolls into the roofing proposal grand total. The area's squares also feed the materials take-off.",
  notes:
    "Unknown story/pitch/layers/redeck labels resolve to a 0 rate. Layers also keys the no-access surcharge and felt material parity; redeck (when not 'No') drives plywood sheet counts.",
  compute: (ctx: AreaContext) =>
    perAreaInstallCost(
      {
        story: ctx.area.story,
        pitch: ctx.area.pitch,
        tearoff: ctx.area.layers,
        redeck: ctx.area.redeck,
        areaSqft: roofAreaSurfaceSqft(ctx.area),
        wasteMultiplier: 1 + ctx.area.wastePercent / 100,
      },
      ctx.shinglePrice,
      ctx.catalog,
    ),
};
