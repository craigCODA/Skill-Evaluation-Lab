/**
 * Valley metal (job level).
 *
 *   cost = style === "open" ? openLf × pricePerFoot : 0
 *
 * This is computed and surfaced in the UI for visibility, but it is NOT rolled
 * into the grand total (it only informs materials counts).
 */

import type { Money, ValleySelection } from "../types";
import type { Catalog, ValleyMetalRate } from "../pricebook/types";
import type { JobContext, JobOption } from "./types";

export type ValleyMetalBreakdown = {
  pricePerFoot: Money;
  /**
   * Linear feet that would be billed at `pricePerFoot`. Equals `valleys.openLf`
   * when style is "open", else 0.
   */
  billableLf: number;
  cost: Money;
};

function valleyMetalCost(
  valleys: ValleySelection,
  cat: Catalog,
): ValleyMetalBreakdown {
  const row = (cat.valleyMetalRates as ValleyMetalRate[]).find(
    (r) => r.key === "open-valley",
  );
  const pricePerFoot = row?.pricePerFoot ?? 0;
  const billableLf = valleys.style === "open" ? valleys.openLf : 0;
  return { pricePerFoot, billableLf, cost: billableLf * pricePerFoot };
}

export const valleyMetalOption: JobOption<ValleyMetalBreakdown> = {
  id: "valleyMetal",
  title: "Valley Metal",
  summary:
    "Open-valley metal computed for visibility. NOT billed to the customer; it only informs materials counts.",
  phase: "job",
  billed: false,
  pricingPlain:
    "Only open valleys are figured: open-valley feet times the per-foot rate. This is shown for reference and is NOT added to the customer total.",
  example: "30 ft of open valley at $3/ft = $90 (reference only — not billed).",
  fieldLabels: ["Valley style", "Open valley LF", "Closed valley LF"],
  catalogTables: ["valleyMetalRates"],
  inputs: [
    { name: "Valley style", description: "'open' or 'closed'. Only 'open' is computed for billing visibility." },
    { name: "Open valley LF", description: "Linear feet of open valley." },
    { name: "Closed valley LF", description: "Linear feet of closed valley (tracked, not billed)." },
  ],
  formula: `billableLf = style = "open" ? openLf : 0
cost = billableLf x lookup("open-valley").pricePerFoot`,
  contractEffect:
    "Shown for visibility only; NOT added to the grand total. Informs valley metal material counts.",
  notes: "Closed-valley LF is tracked only so the value is not lost when switching valley styles.",
  compute: (ctx: JobContext) => valleyMetalCost(ctx.roofing.valleys, ctx.catalog),
};
