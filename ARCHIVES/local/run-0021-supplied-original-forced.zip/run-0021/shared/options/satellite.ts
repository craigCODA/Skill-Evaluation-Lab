/**
 * Satellite removal (job level).
 *
 *   cost = lookup(option).price   (flat $, $0 for unknown / empty keys)
 */

import type { Money } from "../types";
import type { Catalog, SatelliteOption } from "../pricebook/types";
import type { JobContext, JobOption } from "./types";

export type SatelliteInputs = {
  /** Catalog key (`SatelliteOption.key`). Empty / unknown → $0. */
  option: string;
};

export type SatelliteBreakdown = {
  price: Money;
  cost: Money;
};

function satelliteCost(
  inputs: SatelliteInputs,
  cat: Catalog,
): SatelliteBreakdown {
  const row =
    (cat.satelliteOptions as SatelliteOption[]).find(
      (o) => o.key === inputs.option,
    ) ?? null;
  const price = row?.price ?? 0;
  return { price, cost: price };
}

export const satelliteOption: JobOption<SatelliteBreakdown> = {
  id: "satellite",
  title: "Satellite",
  summary: "A flat job-level charge for the selected satellite option.",
  phase: "job",
  billed: true,
  pricingPlain:
    "A flat price for the satellite option you pick — no measuring.",
  example: "Selecting a satellite removal priced at $50 adds a flat $50.",
  fieldLabels: ["Satellite"],
  catalogTables: ["satelliteOptions"],
  inputs: [
    { name: "Satellite", description: "Picker key (keys satelliteOptions); carries a flat price." },
  ],
  formula: `cost = lookup(option).price`,
  contractEffect: "Adds a flat satellite charge to the roofing proposal grand total.",
  notes: "Unknown or empty keys resolve to $0.",
  compute: (ctx: JobContext) =>
    satelliteCost({ option: ctx.roofing.satellite }, ctx.catalog),
};
