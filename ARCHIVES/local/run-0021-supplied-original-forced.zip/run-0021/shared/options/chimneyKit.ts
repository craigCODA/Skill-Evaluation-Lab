/**
 * Chimney kit (job level).
 *
 *   cost = catalog.chimneyKitOptions[key].price   (or $0 for unknown keys)
 *
 * Same shape as chimney removal: a flat $ lookup keyed by the picked option.
 */

import type { Money } from "../types";
import type { Catalog, ChimneyKitOption } from "../pricebook/types";
import type { JobContext, JobOption } from "./types";

export type ChimneyKitInputs = {
  /** Catalog key (`ChimneyKitOption.key`). Empty / unknown → $0. */
  option: string;
};

export type ChimneyKitBreakdown = {
  price: Money;
  cost: Money;
};

function findOption(
  options: ChimneyKitOption[],
  key: string,
): ChimneyKitOption | null {
  return options.find((o) => o.key === key) ?? null;
}

function chimneyKitCost(
  inputs: ChimneyKitInputs,
  cat: Catalog,
): ChimneyKitBreakdown {
  const row = findOption(cat.chimneyKitOptions, inputs.option);
  const price = row?.price ?? 0;
  return { price, cost: price };
}

export const chimneyKitOption: JobOption<ChimneyKitBreakdown> = {
  id: "chimneyKit",
  title: "Chimney Kit",
  summary: "A flat job-level charge for the selected chimney kit.",
  phase: "job",
  billed: true,
  pricingPlain:
    "A flat price for the chimney kit you pick — no measuring.",
  example: "Selecting a chimney kit priced at $150 adds a flat $150.",
  fieldLabels: ["Chimney kit"],
  catalogTables: ["chimneyKitOptions"],
  inputs: [
    { name: "Chimney kit", description: "Picker key (keys chimneyKitOptions); carries a flat price." },
  ],
  formula: `cost = lookup(option).price`,
  contractEffect: "Adds a flat chimney-kit charge to the roofing proposal grand total.",
  notes: "Unknown or empty keys resolve to $0.",
  compute: (ctx: JobContext) =>
    chimneyKitCost({ option: ctx.roofing.chimneyKit }, ctx.catalog),
};
