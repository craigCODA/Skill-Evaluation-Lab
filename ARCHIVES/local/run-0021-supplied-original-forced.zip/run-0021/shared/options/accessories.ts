/**
 * Accessories (job level).
 *
 * For each `(catalogKey → count)` pair, computes
 * `lineCost = count × catalog.accessoryRates[key].pricePerUnit`. Returns one
 * breakdown row per accessory plus the rolled-up total.
 *
 * See `AccessorySelection` and `AccessoryRate` for the list of accessory line
 * items.
 */

import type { ID, Money } from "../types";
import type { AccessorySelection } from "../types";
import type { Catalog, AccessoryRate } from "../pricebook/types";
import type { JobContext, JobOption } from "./types";

const LEGACY_ACCESSORY_RATE_KEYS = {
  vents12x12: "12x12-vent",
  cutIn12x12Vents: "cut-in-12x12-vent",
  turbineVents: "turbine-vent",
  powerVents: "power-vent",
  eyebrows: "eyebrow",
  electricalPipeBoots: "electrical-pipe-boot",
  pipeBoots1To3In: "pipe-boot-1to3in",
  pipeBoots3To4In: "pipe-boot-3to4in",
  pipeBoots3To8In: "pipe-boot-3to8in",
} as const;

export type AccessoryLine = {
  id: ID;
  key: string;
  label: string;
  count: number;
  pricePerUnit: Money;
  cost: Money;
};

export type AccessoriesBreakdown = {
  lines: AccessoryLine[];
  total: Money;
};

function findRate(rates: AccessoryRate[], key: string): AccessoryRate | null {
  return rates.find((r) => r.key === key) ?? null;
}

function normalizeAccessorySelection(
  inputs: AccessorySelection | Record<string, number>,
): AccessorySelection {
  if (Array.isArray(inputs)) return inputs;
  return Object.entries(LEGACY_ACCESSORY_RATE_KEYS)
    .map(([field, key]) => ({
      id: key,
      key,
      count: Number(inputs[field] ?? 0),
    }))
    .filter((line) => line.count > 0);
}

function accessoriesCost(
  inputs: AccessorySelection | Record<string, number>,
  cat: Catalog,
): AccessoriesBreakdown {
  const lines: AccessoryLine[] = [];
  let total = 0;
  for (const input of normalizeAccessorySelection(inputs)) {
    const key = input.key;
    const rate = findRate(cat.accessoryRates, key);
    const count = input.count;
    const pricePerUnit = rate?.pricePerUnit ?? 0;
    const cost = count * pricePerUnit;
    total += cost;
    lines.push({
      id: input.id,
      key,
      label: rate?.label ?? key,
      count,
      pricePerUnit,
      cost,
    });
  }
  return { lines, total };
}

export const accessoriesOption: JobOption<AccessoriesBreakdown> = {
  id: "accessories",
  title: "Accessories",
  summary:
    "Vents, pipe boots, eyebrows, and similar line items, each billed as count x unit price; rolled up to a single accessories total.",
  phase: "job",
  billed: true,
  pricingPlain:
    "Each accessory line (vents, pipe boots, eyebrows, etc.) is count × its unit price. All the lines are added up into one accessories total.",
  example:
    "3 pipe boots at $50 each = $150, plus 1 power vent at $120 → $270 total.",
  fieldLabels: ["Accessory"],
  catalogTables: ["accessoryRates"],
  inputs: [
    { name: "Accessory", description: "Accessory line item (keys accessoryRates)." },
    { name: "Count", description: "Quantity for the accessory line." },
  ],
  formula: `lineCost = count x lookup(key).pricePerUnit
total = SUM(lineCost)`,
  contractEffect: "Adds the accessories total to the roofing proposal grand total.",
  compute: (ctx: JobContext) =>
    accessoriesCost(ctx.roofing.accessories, ctx.catalog),
};
