/**
 * Lightning rod handling (job level).
 *
 *   cost = lookup(option).price   (flat $, $0 for unknown / empty keys)
 */

import type { Money } from "../types";
import type { Catalog, LightningRodOption } from "../pricebook/types";
import type { JobContext, JobOption } from "./types";

export type LightningRodInputs = {
  /** Catalog key (`LightningRodOption.key`). Empty / unknown → $0. */
  option: string;
};

export type LightningRodBreakdown = {
  price: Money;
  cost: Money;
};

function lightningRodCost(
  inputs: LightningRodInputs,
  cat: Catalog,
): LightningRodBreakdown {
  const row =
    (cat.lightningRodOptions as LightningRodOption[]).find(
      (o) => o.key === inputs.option,
    ) ?? null;
  const price = row?.price ?? 0;
  return { price, cost: price };
}

export const lightningRodsOption: JobOption<LightningRodBreakdown> = {
  id: "lightning",
  title: "Lightning Rods",
  summary: "A flat job-level charge for the selected lightning rod option.",
  phase: "job",
  billed: true,
  pricingPlain:
    "A flat price for the lightning-rod option you pick — no measuring.",
  example: "Selecting a lightning-rod option priced at $75 adds a flat $75.",
  fieldLabels: ["Lightning rods"],
  catalogTables: ["lightningRodOptions"],
  inputs: [
    { name: "Lightning rods", description: "Picker key (keys lightningRodOptions); carries a flat price." },
  ],
  formula: `cost = lookup(option).price`,
  contractEffect: "Adds a flat lightning-rod charge to the roofing proposal grand total.",
  notes: "Unknown or empty keys resolve to $0.",
  compute: (ctx: JobContext) =>
    lightningRodCost({ option: ctx.roofing.lightningRods }, ctx.catalog),
};
