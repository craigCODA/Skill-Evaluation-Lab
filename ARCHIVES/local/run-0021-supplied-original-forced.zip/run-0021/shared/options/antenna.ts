/**
 * Antenna removal (job level).
 *
 *   cost = lookup(option).price   (flat $, $0 for unknown / empty keys)
 */

import type { Money } from "../types";
import type { Catalog, AntennaOption } from "../pricebook/types";
import type { JobContext, JobOption } from "./types";

export type AntennaInputs = {
  /** Catalog key (`AntennaOption.key`). Empty / unknown → $0. */
  option: string;
};

export type AntennaBreakdown = {
  price: Money;
  cost: Money;
};

function antennaCost(
  inputs: AntennaInputs,
  cat: Catalog,
): AntennaBreakdown {
  const row =
    (cat.antennaOptions as AntennaOption[]).find(
      (o) => o.key === inputs.option,
    ) ?? null;
  const price = row?.price ?? 0;
  return { price, cost: price };
}

export const antennaOption: JobOption<AntennaBreakdown> = {
  id: "antenna",
  title: "Antenna",
  summary: "A flat job-level charge for the selected antenna option.",
  phase: "job",
  billed: true,
  pricingPlain:
    "A flat price for the antenna option you pick — no measuring.",
  example: "Selecting an antenna removal priced at $50 adds a flat $50.",
  fieldLabels: ["Antenna"],
  catalogTables: ["antennaOptions"],
  inputs: [
    { name: "Antenna", description: "Picker key (keys antennaOptions); carries a flat price." },
  ],
  formula: `cost = lookup(option).price`,
  contractEffect: "Adds a flat antenna charge to the roofing proposal grand total.",
  notes: "Unknown or empty keys resolve to $0.",
  compute: (ctx: JobContext) =>
    antennaCost({ option: ctx.roofing.antenna }, ctx.catalog),
};
