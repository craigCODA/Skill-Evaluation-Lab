/**
 * Underlayment (per roof area).
 *
 * Each area picks its own underlayment from `Catalog.underlayments` and pays
 * `pricePerSquare * area.squares`.
 *
 * Picker keys match the labels exactly: "Standard",
 * "30# Felt over complete roof", "None". An unknown / empty key resolves to
 * a 0 rate.
 */

import type { Money } from "../types";
import type { Catalog, UnderlaymentOption } from "../pricebook/types";
import type { AreaContext, AreaOption } from "./types";

export type UnderlaymentInputs = {
  /** Picker key matching `UnderlaymentOption.key`. */
  underlayment: string;
  /** Roofing squares for this area (sqft × waste-multiplier ÷ 100). */
  squares: number;
};

export type UnderlaymentBreakdown = {
  pricePerSquare: Money;
  cost: Money;
};

function findOption(
  options: UnderlaymentOption[],
  key: string,
): UnderlaymentOption | null {
  if (!key) return null;
  return options.find((o) => o.key === key) ?? null;
}

function underlaymentCost(
  inputs: UnderlaymentInputs,
  cat: Catalog,
): UnderlaymentBreakdown {
  const opt = findOption(cat.underlayments, inputs.underlayment);
  const pricePerSquare = opt?.pricePerSquare ?? 0;
  return {
    pricePerSquare,
    cost: inputs.squares * pricePerSquare,
  };
}

export const underlaymentOption: AreaOption<UnderlaymentBreakdown> = {
  id: "underlayment",
  title: "Underlayment",
  summary:
    "Per-area underlayment billed per square at the selected option's rate.",
  phase: "area",
  billed: true,
  pricingPlain:
    "Charged per square (100 sq ft). The underlayment you pick has a per-square rate, multiplied by the area's squares.",
  example:
    "An area of 13 squares with underlayment at $5/square = $65.",
  fieldLabels: ["Underlayment"],
  catalogTables: ["underlayments"],
  inputs: [
    { name: "Underlayment", description: "Underlayment pick (keys underlayments); carries the $/square rate and felt type." },
    { name: "Squares", description: "This area's squares (sqft x waste ÷ 100)." },
  ],
  formula: `cost = squares x lookup(underlayment).pricePerSquare`,
  contractEffect:
    "Contributes to the area total in the grand total. The underlayment's felt type also drives 15# / 30# felt roll counts on the materials take-off.",
  notes: "An unknown / empty key resolves to a 0 rate.",
  compute: (ctx: AreaContext) =>
    underlaymentCost(
      { underlayment: ctx.area.underlayment, squares: ctx.squares },
      ctx.catalog,
    ),
};
