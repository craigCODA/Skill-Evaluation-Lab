/**
 * Option modules — one self-describing module per estimator question.
 *
 * Each module lives in its own file under `shared/options/` and bundles
 * everything that question needs in one place:
 *   - the math (`compute`) plus the pure pricing helper it wraps,
 *   - the inputs it reads and the catalog tables it depends on,
 *   - whether it is billed, what it does to the contract, and its help text.
 *
 * `compute` receives a context (per-area or per-job) so a module reads exactly
 * the answers it needs without the orchestrator wiring inputs by hand. The
 * `OptionModule` type is the built-in checklist: TypeScript forces every module
 * to declare all of its properties.
 */

import type { Catalog } from "../pricebook/types";
import type { Money, RoofArea, RoofingScope } from "../types";

export type OptionInput = {
  /** Human label for the input, e.g. "Eave LF". */
  name: string;
  /** What the input means and where it comes from. */
  description: string;
};

/** Per-area answers + derived values handed to an area-phase module. */
export type AreaContext = {
  area: RoofArea;
  roofing: RoofingScope;
  catalog: Catalog;
  /** Selected product $/square, shared by every area. */
  shinglePrice: Money;
  /** This area's squares (sqft x waste ÷ 100); produced by the install module. */
  squares: number;
};

/** Whole-job answers + derived values handed to a job-phase module. */
export type JobContext = {
  roofing: RoofingScope;
  catalog: Catalog;
  shinglePrice: Money;
  /** Sum of squares across every area. */
  totalSquares: number;
  /** Per-area area + squares, for options that bill per area (e.g. no access). */
  areaResults: ReadonlyArray<{ area: RoofArea; squares: number }>;
};

/** The shared, self-describing metadata every option declares. */
export type OptionMeta = {
  /** Stable id, e.g. "iceWater". */
  id: string;
  /** Display title, e.g. "Ice & Water Shield". */
  title: string;
  /** One-line plain-English summary (what this option is). */
  summary: string;
  /** Plain-English, no-jargon explanation of how the price is figured. */
  pricingPlain: string;
  /** A short worked example with real numbers. */
  example: string;
  /** True when the option's cost is added to the customer grand total. */
  billed: boolean;
  /**
   * Estimator field labels this module backs. Matches the `label` passed to
   * `<EstimateHelp>` so the popover can resolve the module.
   */
  fieldLabels: string[];
  /** Catalog table names this option reads (keys of `Catalog`). */
  catalogTables: string[];
  /** Inputs that feed the math. */
  inputs: OptionInput[];
  /** Plain-English / pseudo-math formula. Multiline allowed. */
  formula: string;
  /** What this option produces in the contract / contract documents. */
  contractEffect: string;
  /** Optional notes: edge cases, divergences, TODOs. */
  notes?: string;
};

export type AreaOption<B extends object = object> = OptionMeta & {
  phase: "area";
  compute: (ctx: AreaContext) => B;
};

export type JobOption<B extends object = object> = OptionMeta & {
  phase: "job";
  compute: (ctx: JobContext) => B;
};

export type OptionModule = AreaOption | JobOption;
