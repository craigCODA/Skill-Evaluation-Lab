/**
 * Option module registry.
 *
 * Register every option module here. The estimate calculator imports each
 * module directly for precise types, while documentation consumers (the `?`
 * help popovers in `EstimateHelp.vue` and the `/calculator` docs page) read
 * from these registries — so adding a module file and registering it
 * documents a new option everywhere.
 */

import type { AreaOption, JobOption, OptionMeta, OptionModule } from "./types";

import { installOption } from "./install";
import { dripEdgeOption } from "./dripEdge";
import { underlaymentOption } from "./underlayment";
import { iceWaterOption } from "./iceWater";

import { ridgeOption } from "./ridge";
import { warrantyOption } from "./warranty";
import { stepFlashingOption } from "./stepFlashing";
import { chimneyRemovalOption } from "./chimneyRemoval";
import { chimneyKitOption } from "./chimneyKit";
import { accessoriesOption } from "./accessories";
import { satelliteOption } from "./satellite";
import { antennaOption } from "./antenna";
import { lightningRodsOption } from "./lightningRods";
import { skylightsOption } from "./skylights";
import { noAccessOption } from "./noAccess";
import { gutterRemovalOption } from "./gutterRemoval";
import { lowSlopeOption } from "./lowSlope";
import { valleyMetalOption } from "./valleyMetal";

/** Area-phase modules, in display order. Computed once per roof area. */
export const areaOptions: AreaOption[] = [
  installOption,
  dripEdgeOption,
  underlaymentOption,
  iceWaterOption,
];

/** Job-phase modules, in display order. Computed once for the whole job. */
export const jobOptions: JobOption[] = [
  ridgeOption,
  warrantyOption,
  stepFlashingOption,
  chimneyRemovalOption,
  chimneyKitOption,
  accessoriesOption,
  satelliteOption,
  antennaOption,
  lightningRodsOption,
  skylightsOption,
  noAccessOption,
  gutterRemovalOption,
  lowSlopeOption,
  valleyMetalOption,
];

/** Every option module, area phase first then job phase. */
export const calcOptions: OptionModule[] = [...areaOptions, ...jobOptions];

/** Index from estimator field label → module, built once from `calcOptions`. */
const optionByFieldLabel: Map<string, OptionModule> = new Map();
for (const option of calcOptions) {
  for (const label of option.fieldLabels) {
    optionByFieldLabel.set(label, option);
  }
}

export function getOptionByFieldLabel(label: string): OptionModule | undefined {
  return optionByFieldLabel.get(label);
}

/**
 * Renders a module into the plain-text help string shown in the `?` popover.
 * Customer-facing and jargon-free: what it is, how it's priced, a worked
 * example, and who pays. The technical formula lives on the /calculator page.
 */
export function optionHelpText(option: OptionMeta): string {
  const billing = option.billed
    ? "Billed to the customer (part of the grand total)."
    : "Reference only — not added to the customer total.";
  return `${option.summary}\n\nHow it's priced: ${option.pricingPlain}\n\nExample: ${option.example}\n\n${billing}`;
}
