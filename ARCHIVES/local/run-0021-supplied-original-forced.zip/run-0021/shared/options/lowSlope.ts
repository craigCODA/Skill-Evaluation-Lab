/**
 * Low-slope roofing (job level).
 *
 *   cost = lookup(option).pricePerSquare × totalSquares
 *
 * The rate is treated as a price per square and billed against the total
 * squares across all roof areas.
 */

import type { Money } from "../types";
import type { Catalog, LowSlopeOption } from "../pricebook/types";
import type { JobContext, JobOption } from "./types";

export type LowSlopeInputs = {
  /** Catalog key (must match the option list exactly, including leading whitespace). */
  option: string;
  /** Sum of squares across all roof areas. */
  totalSquares: number;
};

export type LowSlopeBreakdown = {
  pricePerSquare: Money;
  cost: Money;
};

function lowSlopeCost(
  inputs: LowSlopeInputs,
  cat: Catalog,
): LowSlopeBreakdown {
  const opt = (cat.lowSlopeOptions as LowSlopeOption[]).find(
    (o) => o.key === inputs.option,
  );
  const pricePerSquare = opt?.pricePerSquare ?? 0;
  return { pricePerSquare, cost: pricePerSquare * inputs.totalSquares };
}

export const lowSlopeOption: JobOption<LowSlopeBreakdown> = {
  id: "lowSlope",
  title: "Low Slope",
  summary:
    "Low-slope roofing billed per square against the whole job's total squares.",
  phase: "job",
  billed: true,
  pricingPlain:
    "Charged per square against the whole job's total squares, using the rate of the low-slope option you pick.",
  example: "A 25-square job with a low-slope rate of $40/square = $1,000.",
  fieldLabels: ["Low slope"],
  catalogTables: ["lowSlopeOptions"],
  inputs: [
    { name: "Low slope", description: "Low-slope option (keys lowSlopeOptions); carries the $/square rate." },
    { name: "Total squares", description: "Sum of squares across all roof areas." },
  ],
  formula: `cost = lookup(option).pricePerSquare x totalSquares`,
  contractEffect: "Adds the low-slope cost to the roofing proposal grand total.",
  compute: (ctx: JobContext) =>
    lowSlopeCost(
      { option: ctx.roofing.lowSlope, totalSquares: ctx.totalSquares },
      ctx.catalog,
    ),
};
