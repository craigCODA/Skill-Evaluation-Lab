/**
 * Drip edge (per roof area).
 *
 *   eaveDripCost = eaveDripLf * lookup(eaveStyle).pricePerFoot
 *   rakeDripCost = rakeDripLf * lookup(rakeStyle).pricePerFoot
 *   total        = eaveDripCost + rakeDripCost
 *
 * Style keys match the picker labels exactly ("ODE Style", "Custom Bent",
 * "Use Existing", ...). An unknown / empty key resolves to a 0 rate.
 */

import type { Money } from "../types";
import type { Catalog, DripEdgeStyle } from "../pricebook/types";
import type { AreaContext, AreaOption } from "./types";

export type DripEdgeInputs = {
  eaveStyle: string;
  rakeStyle: string;
  eaveLf: number;
  rakeLf: number;
};

export type DripEdgeBreakdown = {
  eavePricePerFoot: Money;
  rakePricePerFoot: Money;
  eaveCost: Money;
  rakeCost: Money;
  total: Money;
};

function findStyle(styles: DripEdgeStyle[], key: string): DripEdgeStyle | null {
  if (!key) return null;
  return styles.find((s) => s.key === key) ?? null;
}

function dripEdgeCost(
  inputs: DripEdgeInputs,
  cat: Catalog,
): DripEdgeBreakdown {
  const eaveStyle = findStyle(cat.dripEdgeStyles, inputs.eaveStyle);
  const rakeStyle = findStyle(cat.dripEdgeStyles, inputs.rakeStyle);
  const eavePricePerFoot = eaveStyle?.pricePerFoot ?? 0;
  const rakePricePerFoot = rakeStyle?.pricePerFoot ?? 0;
  const eaveCost = inputs.eaveLf * eavePricePerFoot;
  const rakeCost = inputs.rakeLf * rakePricePerFoot;
  return {
    eavePricePerFoot,
    rakePricePerFoot,
    eaveCost,
    rakeCost,
    total: eaveCost + rakeCost,
  };
}

export const dripEdgeOption: AreaOption<DripEdgeBreakdown> = {
  id: "dripEdge",
  title: "Drip Edge",
  summary:
    "Per-area eave and rake drip edge, each billed by linear feet at the rate of its selected style.",
  phase: "area",
  billed: true,
  pricingPlain:
    "Charged by the foot. The eave and the rake each have their own length and use the per-foot rate of the style you pick. They're figured separately, then added together.",
  example:
    "55 ft of eave at $2.00/ft = $110, plus 84 ft of rake at $2.00/ft = $168 → $278 for this area.",
  fieldLabels: ["Eave drip style", "Eave drip LF", "Rake drip style", "Rake drip LF"],
  catalogTables: ["dripEdgeStyles"],
  inputs: [
    { name: "Eave drip style", description: "Eave drip edge style (keys dripEdgeStyles)." },
    { name: "Eave drip LF", description: "Eave linear feet of drip edge." },
    { name: "Rake drip style", description: "Rake drip edge style (keys dripEdgeStyles)." },
    { name: "Rake drip LF", description: "Rake linear feet of drip edge." },
  ],
  formula: `eaveDripCost = eaveDripLf x lookup(eaveStyle).pricePerFoot
rakeDripCost = rakeDripLf x lookup(rakeStyle).pricePerFoot
total = eaveDripCost + rakeDripCost`,
  contractEffect:
    "Contributes to the area total in the roofing proposal grand total. Eave LF also feeds ice & water eave coverage and drip-edge stick material counts.",
  notes: "An unknown / empty style key resolves to a 0 rate.",
  compute: (ctx: AreaContext) =>
    dripEdgeCost(
      {
        eaveStyle: ctx.area.eaveDripStyle,
        rakeStyle: ctx.area.rakeDripStyle,
        eaveLf: ctx.area.eaveDripLf,
        rakeLf: ctx.area.rakeDripLf,
      },
      ctx.catalog,
    ),
};
