/**
 * Ice & water shield (per roof area).
 *
 *   eaveCost   = coversEaves   ? eaveLf × overhangRows × eave $/ft   : 0
 *   valleyCost = coversValleys ? valleyLf × valley $/ft              : 0
 *   surfaceCost = squares × pricePerSquare                            (always 0
 *                                                                      today)
 *   total       = eaveCost + valleyCost + surfaceCost
 *
 * Only `Valleys Only` and `Valleys & Eaves` are billed today; every option
 * carries `pricePerSquare: 0`, so full-surface coverage is unbilled until a
 * rate (and the picker's coverage flag) is set.
 */

import type { Money } from "../types";
import type {
  Catalog,
  IceWaterOption,
  IceWaterOverhang,
  IceWaterRate,
} from "../pricebook/types";
import type { AreaContext, AreaOption } from "./types";

export type IceWaterInputs = {
  /** Catalog key (`IceWaterOption.key`). Empty / unknown → $0. */
  option: string;
  /** Catalog key (`IceWaterOverhang.key`). Unknown → 0 rows. */
  overhang: string;
  /** Eave LF receiving I&W (today: per-area `eaveDripLf`). */
  eaveLf: number;
  /** Closed-valley LF receiving I&W. */
  valleyLf: number;
  /** Roof squares for this area; only matters when `pricePerSquare > 0`. */
  squares: number;
};

export type IceWaterBreakdown = {
  rows: number;
  eavePricePerFoot: Money;
  valleyPricePerFoot: Money;
  pricePerSquare: Money;
  eaveCost: Money;
  valleyCost: Money;
  surfaceCost: Money;
  total: Money;
};

const EAVE_RATE_KEY = "eave";
const VALLEY_RATE_KEY = "valley";

function findOption(
  options: IceWaterOption[],
  key: string,
): IceWaterOption | null {
  return options.find((o) => o.key === key) ?? null;
}

function findOverhang(
  overhangs: IceWaterOverhang[],
  key: string,
): IceWaterOverhang | null {
  return overhangs.find((o) => o.key === key) ?? null;
}

function findRate(rates: IceWaterRate[], key: string): IceWaterRate | null {
  return rates.find((r) => r.key === key) ?? null;
}

function iceWaterCost(
  inputs: IceWaterInputs,
  cat: Catalog,
): IceWaterBreakdown {
  const opt = findOption(cat.iceWaterOptions, inputs.option);
  const overhang = findOverhang(cat.iceWaterOverhangs, inputs.overhang);
  const eaveRate = findRate(cat.iceWaterRates, EAVE_RATE_KEY);
  const valleyRate = findRate(cat.iceWaterRates, VALLEY_RATE_KEY);

  const rows = overhang?.rows ?? 0;
  const eavePricePerFoot = eaveRate?.pricePerFoot ?? 0;
  const valleyPricePerFoot = valleyRate?.pricePerFoot ?? 0;
  const pricePerSquare = opt?.pricePerSquare ?? 0;

  const eaveCost = opt?.coversEaves
    ? inputs.eaveLf * rows * eavePricePerFoot
    : 0;
  const valleyCost = opt?.coversValleys
    ? inputs.valleyLf * valleyPricePerFoot
    : 0;
  const surfaceCost = pricePerSquare > 0 ? inputs.squares * pricePerSquare : 0;

  return {
    rows,
    eavePricePerFoot,
    valleyPricePerFoot,
    pricePerSquare,
    eaveCost,
    valleyCost,
    surfaceCost,
    total: eaveCost + valleyCost + surfaceCost,
  };
}

export const iceWaterOption: AreaOption<IceWaterBreakdown> = {
  id: "iceWater",
  title: "Ice & Water Shield",
  summary:
    "Adds ice & water shield cost for a roof area based on the coverage option, the eave length (multiplied by an overhang row count), and the valley length.",
  phase: "area",
  billed: true,
  pricingPlain:
    "Charged along the eaves and valleys that your coverage choice includes. Eaves: eave feet × the overhang row count × the eave per-foot rate. Valleys: valley feet × the valley per-foot rate. Full-surface coverage isn't charged today.",
  example:
    "With eave coverage: 55 eave ft × 2 rows × $1.50/ft = $165, plus 20 valley ft × $2.00/ft = $40 → $205.",
  fieldLabels: ["Ice & water", "Overhang", "Ice & water valley LF"],
  catalogTables: ["iceWaterOptions", "iceWaterOverhangs", "iceWaterRates"],
  inputs: [
    { name: "Ice & water option", description: "Coverage pick (keys iceWaterOptions); sets coversEaves / coversValleys / $ per square." },
    { name: "Overhang", description: "Overhang size pick (keys iceWaterOverhangs); resolves to 1, 1.5, or 2 rows." },
    { name: "Eave LF", description: "Eave linear feet receiving I&W (today the area's eaveDripLf)." },
    { name: "Valley LF", description: "Closed-valley linear feet receiving I&W (iceWaterValleyLf)." },
    { name: "Squares", description: "Area squares; only used when an option carries a $/square surface rate." },
  ],
  formula: `rows = lookup(overhang).rows                       (1 / 1.5 / 2)
eaveCost   = coversEaves   ? eaveLf x rows x eaveRatePerFt : 0
valleyCost = coversValleys ? valleyLf x valleyRatePerFt    : 0
surfaceCost = pricePerSquare > 0 ? squares x pricePerSquare : 0
total = eaveCost + valleyCost + surfaceCost`,
  contractEffect:
    'Appears on the roofing proposal as the "Install ice & water shield" specification line and contributes to the area total in the grand total.',
  notes:
    "Only 'Valleys Only' and 'Valleys & Eaves' are billed today; both 'Complete Surface' rows carry pricePerSquare: 0 until full-surface coverage is billed. Unknown option/overhang keys resolve to $0 / 0 rows.",
  compute: (ctx: AreaContext) =>
    iceWaterCost(
      {
        option: ctx.area.iceWaterOption,
        overhang: ctx.area.iceWaterOverhang,
        eaveLf: ctx.area.eaveDripLf,
        valleyLf: ctx.area.iceWaterValleyLf,
        squares: ctx.squares,
      },
      ctx.catalog,
    ),
};
