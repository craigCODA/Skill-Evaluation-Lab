/**
 * No-access surcharge (job level, summed per area).
 *
 * Per area: `if (access === "No Access") squares × rate(layers); else 0`,
 * summed across all areas. The per-layer rate comes from `noAccessRates`.
 *
 * `squares` is passed in (rather than recomputed here) so this stays a pure
 * dollar function — the install module already produces squares per area.
 */

import type { Money, RoofArea } from "../types";
import type { Catalog, NoAccessRate } from "../pricebook/types";
import type { JobContext, JobOption } from "./types";

export type NoAccessLineBreakdown = {
  areaId: string;
  squares: number;
  layerKey: string;
  pricePerSquare: Money;
  cost: Money;
};

export type NoAccessBreakdown = {
  lines: NoAccessLineBreakdown[];
  total: Money;
};

function noAccessCost(
  areas: ReadonlyArray<{ area: RoofArea; squares: number }>,
  cat: Catalog,
): NoAccessBreakdown {
  const rates = cat.noAccessRates as NoAccessRate[];
  const lines: NoAccessLineBreakdown[] = areas.map(({ area, squares }) => {
    const billed = area.access === "No Access";
    const row = rates.find((r) => r.key === area.layers);
    const pricePerSquare = row?.pricePerSquare ?? 0;
    const cost = billed ? squares * pricePerSquare : 0;
    return {
      areaId: area.id,
      squares,
      layerKey: area.layers,
      pricePerSquare,
      cost,
    };
  });
  const total = lines.reduce((sum, l) => sum + l.cost, 0);
  return { lines, total };
}

export const noAccessOption: JobOption<NoAccessBreakdown> = {
  id: "noAccess",
  title: "No Access Surcharge",
  summary:
    "For each area marked 'No Access', a per-square surcharge keyed by the area's layer count, summed across all areas.",
  phase: "job",
  billed: true,
  pricingPlain:
    "Only applies to areas marked 'No Access'. For each such area, its squares are charged at a per-square rate set by that area's layer count, then all qualifying areas are added up.",
  example: "A 'No Access' area of 12 squares at a $20/square rate = $240.",
  fieldLabels: ["Access"],
  catalogTables: ["noAccessRates"],
  inputs: [
    { name: "Access", description: "Per-area access picker; 'No Access' triggers the surcharge." },
    { name: "Layers", description: "Per-area layer count; keys the per-square no-access rate." },
    { name: "Squares", description: "Per-area squares (from the install module)." },
  ],
  formula: `per area: if access = "No Access": squares x rate(layers); else 0
total = SUM(per area)`,
  contractEffect: "Adds the no-access surcharge total to the roofing proposal grand total.",
  compute: (ctx: JobContext) => noAccessCost(ctx.areaResults, ctx.catalog),
};
