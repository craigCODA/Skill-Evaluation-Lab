/**
 * Warranty upcharge (job level).
 *
 *   cost = lookup(tier).perSquare × totalSquares
 *
 * `totalSquares` is the sum of squares across every roof area (each area
 * already factors in its waste-multiplier).
 */

import type { Money, WarrantyTier } from "../types";
import type { Catalog } from "../pricebook/types";
import type { JobContext, JobOption } from "./types";

export type WarrantyInputs = {
  tier: WarrantyTier;
  totalSquares: number;
};

export type WarrantyBreakdown = {
  tier: WarrantyTier;
  displayName: string;
  perSquare: Money;
  cost: Money;
};

function warrantyCost(
  inputs: WarrantyInputs,
  cat: Catalog,
): WarrantyBreakdown {
  const row = cat.warrantyUpcharges.find((w) => w.tier === inputs.tier);
  const perSquare = row?.perSquare ?? 0;
  return {
    tier: inputs.tier,
    displayName: row?.displayName ?? inputs.tier,
    perSquare,
    cost: perSquare * inputs.totalSquares,
  };
}

export const warrantyOption: JobOption<WarrantyBreakdown> = {
  id: "warranty",
  title: "Warranty Upcharge",
  summary:
    "Optional warranty tier billed per square across the whole job's total squares.",
  phase: "job",
  billed: true,
  pricingPlain:
    "An upgrade charged per square across the whole job. The tier's per-square rate is multiplied by the job's total squares. The standard tier adds nothing.",
  example:
    "A 25-square job with a warranty tier at $8/square = $200.",
  fieldLabels: ["Warranty"],
  catalogTables: ["warrantyUpcharges"],
  inputs: [
    { name: "Warranty", description: "Warranty tier (keys warrantyUpcharges by tier)." },
    { name: "Total squares", description: "Sum of squares across all roof areas." },
  ],
  formula: `cost = lookup(tier).perSquare x totalSquares
totalSquares = SUM(areaSquares)`,
  contractEffect: "Adds the warranty upcharge to the roofing proposal grand total.",
  compute: (ctx: JobContext) =>
    warrantyCost(
      { tier: ctx.roofing.shingle.warranty, totalSquares: ctx.totalSquares },
      ctx.catalog,
    ),
};
