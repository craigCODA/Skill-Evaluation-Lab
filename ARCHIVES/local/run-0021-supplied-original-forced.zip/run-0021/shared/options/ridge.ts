/**
 * Ridge vent (job level).
 *
 * Two billable line items, both per linear foot:
 *
 *   ridgeVentCost      = ridgeVentLf      * lookup("Ridge Vent").pricePerFoot
 *   cutInRidgeVentCost = cutInRidgeVentLf * lookup("Cut in Ridge Vent").pricePerFoot
 *
 * Lookups by exact key match against `Catalog.ridgeRates`. A missing key
 * resolves to a 0 rate.
 *
 * Note: this does NOT cover plain ridge LF, which drives cap-shingle material
 * counts and the high-hip upgrade (those live with their own concerns).
 */

import type { Money } from "../types";
import type { Catalog, RidgeRate } from "../pricebook/types";
import type { JobContext, JobOption } from "./types";

const RIDGE_VENT_KEY = "Ridge Vent";
const CUT_IN_RIDGE_VENT_KEY = "Cut in Ridge Vent";

export type RidgeInputs = {
  ridgeVentLf: number;
  cutInRidgeVentLf: number;
};

export type RidgeBreakdown = {
  ridgeVentPricePerFoot: Money;
  cutInRidgeVentPricePerFoot: Money;
  ridgeVentCost: Money;
  cutInRidgeVentCost: Money;
  total: Money;
};

function findRate(rates: RidgeRate[], key: string): RidgeRate | null {
  return rates.find((r) => r.key === key) ?? null;
}

function ridgeCost(inputs: RidgeInputs, cat: Catalog): RidgeBreakdown {
  const vent = findRate(cat.ridgeRates, RIDGE_VENT_KEY);
  const cutIn = findRate(cat.ridgeRates, CUT_IN_RIDGE_VENT_KEY);
  const ridgeVentPricePerFoot = vent?.pricePerFoot ?? 0;
  const cutInRidgeVentPricePerFoot = cutIn?.pricePerFoot ?? 0;
  const ridgeVentCost = inputs.ridgeVentLf * ridgeVentPricePerFoot;
  const cutInRidgeVentCost =
    inputs.cutInRidgeVentLf * cutInRidgeVentPricePerFoot;
  return {
    ridgeVentPricePerFoot,
    cutInRidgeVentPricePerFoot,
    ridgeVentCost,
    cutInRidgeVentCost,
    total: ridgeVentCost + cutInRidgeVentCost,
  };
}

export const ridgeOption: JobOption<RidgeBreakdown> = {
  id: "ridge",
  title: "Ridge Vent",
  summary:
    "Ridge vent and cut-in ridge vent, each billed per linear foot at its catalog rate.",
  phase: "job",
  billed: true,
  pricingPlain:
    "Two separate per-foot charges — ridge vent and cut-in ridge vent. Each is its length times its own per-foot rate, then added together.",
  example:
    "40 ft of ridge vent at $4/ft = $160, plus 10 ft of cut-in ridge vent at $6/ft = $60 → $220.",
  fieldLabels: ["Ridge vent LF", "Cut-in ridge vent LF"],
  catalogTables: ["ridgeRates"],
  inputs: [
    { name: "Ridge vent LF", description: "Linear feet of ridge vent." },
    { name: "Cut-in ridge vent LF", description: "Linear feet of cut-in ridge vent." },
  ],
  formula: `ridgeVentCost      = ridgeVentLf x lookup("Ridge Vent").pricePerFoot
cutInRidgeVentCost = cutInRidgeVentLf x lookup("Cut in Ridge Vent").pricePerFoot
total = ridgeVentCost + cutInRidgeVentCost`,
  contractEffect: "Adds the ridge vent total to the roofing proposal grand total.",
  notes:
    "Does not cover plain ridge LF, which is material take-off only (cap-shingle bundles). Missing keys resolve to a 0 rate.",
  compute: (ctx: JobContext) =>
    ridgeCost(
      {
        ridgeVentLf: ctx.roofing.ridgeVentLf,
        cutInRidgeVentLf: ctx.roofing.cutInRidgeVentLf,
      },
      ctx.catalog,
    ),
};
