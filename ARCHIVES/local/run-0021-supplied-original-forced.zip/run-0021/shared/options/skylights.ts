/**
 * Skylights (job level).
 *
 * Each row contributes `count × price` for the picked option. Unknown option
 * keys (or the placeholder `"Select Skylight"` row at $0) cost nothing.
 */

import type { Money, SkylightLine } from "../types";
import type { Catalog, SkylightOption } from "../pricebook/types";
import type { JobContext, JobOption } from "./types";

export type SkylightLineBreakdown = {
  id: string;
  option: string;
  count: number;
  pricePerUnit: Money;
  cost: Money;
};

export type SkylightsBreakdown = {
  lines: SkylightLineBreakdown[];
  total: Money;
};

function skylightsCost(
  rows: SkylightLine[],
  cat: Catalog,
): SkylightsBreakdown {
  const options = cat.skylightOptions as SkylightOption[];
  const lines: SkylightLineBreakdown[] = rows.map((r) => {
    const opt = options.find((o) => o.key === r.option);
    const pricePerUnit = opt?.price ?? 0;
    return {
      id: r.id,
      option: r.option,
      count: r.count,
      pricePerUnit,
      cost: pricePerUnit * r.count,
    };
  });
  const total = lines.reduce((sum, l) => sum + l.cost, 0);
  return { lines, total };
}

export const skylightsOption: JobOption<SkylightsBreakdown> = {
  id: "skylights",
  title: "Skylights",
  summary:
    "One or more skylight rows, each billed as count x unit price; rolled up to a single skylights total.",
  phase: "job",
  billed: true,
  pricingPlain:
    "Each skylight row is count × the unit price of the type you pick. All rows are added into one skylights total.",
  example: "2 skylights at $400 each = $800.",
  fieldLabels: [],
  catalogTables: ["skylightOptions"],
  inputs: [
    { name: "Skylight option", description: "Skylight type per row (keys skylightOptions)." },
    { name: "Count", description: "Quantity for the skylight row." },
  ],
  formula: `lineCost = count x lookup(option).price
total = SUM(lineCost)`,
  contractEffect: "Adds the skylights total to the roofing proposal grand total.",
  notes: "The placeholder 'Select Skylight' row and unknown keys cost $0.",
  compute: (ctx: JobContext) => skylightsCost(ctx.roofing.skylights, ctx.catalog),
};
