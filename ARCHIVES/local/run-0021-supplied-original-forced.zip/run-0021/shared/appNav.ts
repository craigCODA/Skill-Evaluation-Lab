/**
 * Primary sidebar navigation.
 *
 * Work = daily destinations. Company = setup. Account = personal / platform.
 * Visibility is evaluated with `isAppNavItemVisible` using capabilities + admin.
 */

import type { AccountCapability } from "./accountPermissions"

export type AppNavSectionId = "work" | "company" | "account"

export type AppNavItem = {
  id: string
  label: string
  to: string
  section: AppNavSectionId
  /** Visible if the user has any of these capabilities. Omit for always-visible. */
  anyCapabilities?: readonly AccountCapability[]
  requiresPlatformAdmin?: boolean
  /** Hide for platform admins (company-account destinations only). */
  excludePlatformAdmin?: boolean
  /** Only highlight when the path matches exactly (hub routes under a prefix). */
  exact?: boolean
}

export type AppNavSection = {
  id: AppNavSectionId
  /** Null = no section label (primary work links). */
  label: string | null
  items: AppNavItem[]
}

export const APP_NAV_SECTION_ORDER: readonly AppNavSectionId[] = [
  "work",
  "company",
  "account"
]

export const APP_NAV_SECTION_LABELS: Record<AppNavSectionId, string | null> = {
  work: null,
  company: "Company",
  account: "Account"
}

export const APP_NAV_ITEMS: readonly AppNavItem[] = [
  { id: "dashboard", label: "Dashboard", to: "/", section: "work", exact: true },
  {
    id: "customers",
    label: "Customers",
    to: "/customers",
    section: "work",
    anyCapabilities: ["editCustomers", "manageJobAssets"]
  },
  {
    id: "estimates",
    label: "Estimates",
    to: "/estimates",
    section: "work",
    anyCapabilities: ["viewEstimates", "editEstimates"]
  },
  {
    id: "shingle-scope",
    label: "ShingleScope",
    to: "/roof-probe",
    section: "work",
    anyCapabilities: ["useRoofProbe"]
  },
  {
    id: "company",
    label: "Company",
    to: "/account/company",
    section: "company",
    anyCapabilities: ["editCompanyProfile"],
    excludePlatformAdmin: true
  },
  {
    id: "team",
    label: "Team",
    to: "/account/team",
    section: "company",
    anyCapabilities: ["manageSubAccounts"]
  },
  {
    id: "roles",
    label: "Role permissions",
    to: "/account/roles",
    section: "company",
    anyCapabilities: ["manageSubAccounts"]
  },
  {
    id: "contract-setup",
    label: "Contract setup",
    to: "/account/contracts",
    section: "company",
    anyCapabilities: ["editContractSetup"]
  },
  {
    id: "catalog",
    label: "Catalog",
    to: "/catalog",
    section: "company",
    anyCapabilities: ["editCatalog"]
  },
  {
    id: "statistics",
    label: "Statistics",
    to: "/account/statistics",
    section: "company",
    anyCapabilities: ["viewAccountStatistics"]
  },
  { id: "account", label: "Account", to: "/account", section: "account", exact: true },
  { id: "settings", label: "Settings", to: "/account/user", section: "account" },
  {
    id: "admin",
    label: "Admin",
    to: "/admin",
    section: "account",
    requiresPlatformAdmin: true
  }
]

export function isAppNavItemVisible(
  item: AppNavItem,
  options: {
    isAdmin: boolean
    can: (capability: AccountCapability) => boolean
  }
): boolean {
  if (item.requiresPlatformAdmin && !options.isAdmin) return false
  if (item.excludePlatformAdmin && options.isAdmin) return false
  if (item.anyCapabilities?.length) {
    return item.anyCapabilities.some((capability) => options.can(capability))
  }
  return true
}

export function buildAppNavSections(options: {
  isAdmin: boolean
  can: (capability: AccountCapability) => boolean
}): AppNavSection[] {
  return APP_NAV_SECTION_ORDER.map((id) => ({
    id,
    label: APP_NAV_SECTION_LABELS[id],
    items: APP_NAV_ITEMS.filter(
      (item) => item.section === id && isAppNavItemVisible(item, options)
    )
  })).filter((section) => section.items.length > 0)
}
