import type { RoofLineMeasurement } from "./roofLineMeasurements";
import { roofLineMeasurementTotals } from "./roofLineMeasurements";
import type { RoofMeasurement, RoofSegment } from "./types";
import {
  computeOrderSquares,
  estimateWasteFactor,
  wasteFactorToPercent,
} from "./roofMeasurement";

export type RoofProbeStat = {
  id: string;
  label: string;
  value: string;
  note?: string;
};

export type RoofProbeMetaItem = {
  id: string;
  label: string;
  value: string;
  tone?: "default" | "warning";
  badge?: string;
  tooltip?: string;
};

export type RoofProbeVentilationSummary = {
  atticSqft: number;
  footprintSqft?: number;
  surfaceSqft: number;
  nfvaOneToThreeHundred: number;
  nfvaOneToOneFifty: number;
  recommendedExhaust: number;
  recommendedIntake: number;
  ridgeVentNeededFt: number;
  availableRidgeFt: number;
  ridgeCapacitySufficient: boolean;
  boxVentsNeeded: number;
  boxVentCapacitySqIn: number;
  ventedDripEdgeFt: number;
  soffitVentFt: number;
  birdBlocksEach: number;
};

export type RoofProbeSegmentRow = {
  id: string;
  label: string;
  area: string;
  pitch: string;
  orientation: string;
  confidence: string;
};

export type RoofProbeReport = {
  orderSquares?: number;
  wastePercent: number;
  suggestedWasteFactor: number;
  isSuggestedWasteFactor: boolean;
  stats: RoofProbeStat[];
  metaItems: RoofProbeMetaItem[];
  ventilation: RoofProbeVentilationSummary | null;
  segments: RoofProbeSegmentRow[];
};

const STALE_IMAGERY_WARNING = "This image is more than 5 years old. The house may have changed; check with the owner for additions, remodels, or other roof changes.";

export function buildRoofProbeReport(input: {
  measurement: RoofMeasurement;
  measuredLines: RoofLineMeasurement[];
  wasteFactor: number;
  ridgeVentNfaPerFt: number;
  now?: Date;
}): RoofProbeReport {
  const { measurement, measuredLines, wasteFactor, ridgeVentNfaPerFt } = input;
  const orderSquares = computeOrderSquares(measurement.measuredSquares, wasteFactor);
  const suggestedWasteFactor = estimateWasteFactor(measurement.segmentCount);
  const wastePercent = wasteFactorToPercent(wasteFactor);

  return {
    orderSquares,
    wastePercent,
    suggestedWasteFactor,
    isSuggestedWasteFactor: wasteFactor === suggestedWasteFactor,
    stats: [
      {
        id: "roof-sq-ft",
        label: "Roof sq ft",
        value: formatNumber(measurement.totalRoofAreaSqft, 0),
      },
      {
        id: "measured-squares",
        label: "Measured squares",
        value: formatNumber(measurement.measuredSquares, 2),
      },
      {
        id: "order-squares",
        label: "Order squares",
        value: formatNumber(orderSquares, 2),
        note: `${wastePercent}% waste included`,
      },
      {
        id: "segments",
        label: "Segments",
        value: String(measurement.segmentCount),
      },
    ],
    metaItems: buildMetaItems(measurement, input.now ?? new Date()),
    ventilation: buildVentilationSummary({
      measurement,
      measuredLines,
      ridgeVentNfaPerFt,
    }),
    segments: buildSegmentRows(measurement.segments),
  };
}

export function buildVentilationSummary(input: {
  measurement: RoofMeasurement;
  measuredLines: RoofLineMeasurement[];
  ridgeVentNfaPerFt: number;
}): RoofProbeVentilationSummary | null {
  const surfaceSqft = input.measurement.totalRoofAreaSqft;
  if (!surfaceSqft) return null;

  const footprintSqft = estimateRoofFootprintSqft(input.measurement);
  const atticSqft = footprintSqft ?? surfaceSqft;
  const nfvaOneToThreeHundred = Math.ceil((atticSqft * 144) / 300);
  const nfvaOneToOneFifty = Math.ceil((atticSqft * 144) / 150);
  const recommendedExhaust = Math.ceil(nfvaOneToThreeHundred / 2);
  const recommendedIntake = Math.ceil(nfvaOneToThreeHundred / 2);
  const availableRidgeFt = Math.round(roofLineMeasurementTotals(input.measuredLines).ridge);
  const ridgeVentNeededFt = Math.ceil(recommendedExhaust / input.ridgeVentNfaPerFt);
  const boxVentsNeeded = Math.ceil(recommendedExhaust / 50);

  return {
    atticSqft: Math.round(atticSqft),
    footprintSqft: footprintSqft ? Math.round(footprintSqft) : undefined,
    surfaceSqft: Math.round(surfaceSqft),
    nfvaOneToThreeHundred,
    nfvaOneToOneFifty,
    recommendedExhaust,
    recommendedIntake,
    ridgeVentNeededFt,
    availableRidgeFt,
    ridgeCapacitySufficient: availableRidgeFt >= ridgeVentNeededFt,
    boxVentsNeeded,
    boxVentCapacitySqIn: boxVentsNeeded * 50,
    ventedDripEdgeFt: Math.ceil(recommendedIntake / 9),
    soffitVentFt: Math.ceil(recommendedIntake / 9),
    birdBlocksEach: Math.ceil(recommendedIntake / 3.5),
  };
}

function buildMetaItems(measurement: RoofMeasurement, now: Date): RoofProbeMetaItem[] {
  return [
    {
      id: "imagery-quality",
      label: "Imagery quality",
      value: measurement.source.imageryQuality,
    },
    {
      id: "imagery-date",
      label: "Imagery date",
      value: measurement.source.imageryDate || "Unknown",
      ...(isImageryOlderThanYears(measurement.source.imageryDate, 10, now)
        ? {
            tone: "warning" as const,
            badge: "Review age",
            tooltip: STALE_IMAGERY_WARNING,
          }
        : {}),
    },
    {
      id: "primary-pitch",
      label: "Primary pitch",
      value: primaryPitchLabel(measurement.segments),
    },
    {
      id: "complexity",
      label: "Complexity",
      value: formatComplexity(measurement.complexity),
    },
  ];
}

function buildSegmentRows(segments: RoofSegment[]): RoofProbeSegmentRow[] {
  return segments.map((segment, index) => ({
    id: segment.id,
    label: `Segment ${index + 1}`,
    area: `${formatNumber(segment.areaSqft, 0)} sq ft`,
    pitch: segment.pitchLabel || "Unknown",
    orientation: segment.orientationLabel,
    confidence: formatPercent(segment.confidence),
  }));
}

function estimateRoofFootprintSqft(value: RoofMeasurement): number | undefined {
  const segmentFootprint = value.segments
    .filter((segment) => segment.areaSqft && segment.pitchRiseOver12 !== undefined)
    .reduce((sum, segment) => (
      sum + (segment.areaSqft ?? 0) / pitchSurfaceMultiplier(segment.pitchRiseOver12 ?? 0)
    ), 0);

  if (segmentFootprint > 0) return segmentFootprint;

  const pitch = value.segments.find((segment) => segment.pitchRiseOver12 !== undefined)?.pitchRiseOver12;
  if (value.totalRoofAreaSqft && pitch !== undefined) {
    return value.totalRoofAreaSqft / pitchSurfaceMultiplier(pitch);
  }
  return undefined;
}

function pitchSurfaceMultiplier(pitchRiseOver12: number): number {
  return Math.sqrt(pitchRiseOver12 ** 2 + 12 ** 2) / 12;
}

function isImageryOlderThanYears(dateValue: string | undefined, years: number, now: Date): boolean {
  if (!dateValue) return false;
  const parsed = new Date(`${dateValue}T00:00:00Z`);
  if (Number.isNaN(parsed.getTime())) return false;
  const threshold = new Date(now);
  threshold.setFullYear(threshold.getFullYear() - years);
  return parsed < threshold;
}

function primaryPitchLabel(segments: RoofSegment[]): string {
  return segments.find((segment) => segment.pitchLabel)?.pitchLabel ?? "Unknown";
}

function formatComplexity(value: string): string {
  return value.replace("_", " ");
}

function formatPercent(value?: number): string {
  if (value === undefined) return "Not available";
  return `${Math.round(value * 100)}%`;
}

function formatNumber(value?: number, digits = 1): string {
  if (value === undefined) return "Not available";
  return value.toLocaleString(undefined, {
    maximumFractionDigits: digits,
    minimumFractionDigits: digits,
  });
}
