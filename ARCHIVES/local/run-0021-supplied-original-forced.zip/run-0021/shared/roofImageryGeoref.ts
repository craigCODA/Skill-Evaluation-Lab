import type { RoofImageryGeoref } from "./types";

/** Build client-facing georef metadata from a downloaded Solar API GeoTIFF. */
export function buildImageryGeoref(input: {
  bbox: number[];
  epsg?: number;
  sourceWidthPx: number;
  sourceHeightPx: number;
  previewWidthPx: number;
  previewHeightPx: number;
  pixelSizeMeters: number;
  extentMeters?: { widthMeters: number; heightMeters: number };
}): RoofImageryGeoref {
  const widthMeters =
    input.extentMeters?.widthMeters ??
    input.sourceWidthPx * input.pixelSizeMeters;
  const heightMeters =
    input.extentMeters?.heightMeters ??
    input.sourceHeightPx * input.pixelSizeMeters;

  return {
    sourceWidthPx: input.sourceWidthPx,
    sourceHeightPx: input.sourceHeightPx,
    previewWidthPx: input.previewWidthPx,
    previewHeightPx: input.previewHeightPx,
    widthMeters,
    heightMeters,
    pixelSizeMeters: input.pixelSizeMeters,
  };
}

/** Preview resolution in ground metres per pixel (uses UTM extent when available). */
export function previewMetersPerPixel(georef: RoofImageryGeoref): {
  x: number;
  y: number;
} {
  return {
    x: georef.widthMeters / Math.max(georef.previewWidthPx, 1),
    y: georef.heightMeters / Math.max(georef.previewHeightPx, 1),
  };
}
