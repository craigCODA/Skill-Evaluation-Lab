/**
 * Pure validation rules for estimates.
 *
 * Used by the estimate page to decide whether a draft is complete enough to
 * save. No behavior beyond reporting which required fields are still missing.
 */

import type { Job } from "./types";

export type RequiredEstimateField =
  | "Estimate type"
  | "First name"
  | "Last name"
  | "Phone";

export type EstimateValidationField =
  | RequiredEstimateField
  | "Email"
  | "ZIP";

export type EstimateValidationIssue = {
  field: EstimateValidationField;
  message: string;
};

/** Fields that must be filled before an estimate can be saved. */
export function missingRequiredEstimateFields(job: Job): RequiredEstimateField[] {
  const missing: RequiredEstimateField[] = [];
  if (!job.estimateType) missing.push("Estimate type");
  if (!job.customer.firstName?.trim()) missing.push("First name");
  if (!job.customer.lastName?.trim()) missing.push("Last name");
  if (!job.customer.phone?.trim()) missing.push("Phone");
  return missing;
}

export function estimateValidationIssues(job: Job): EstimateValidationIssue[] {
  const issues: EstimateValidationIssue[] = missingRequiredEstimateFields(job).map((field) => ({
    field,
    message: `${field} is required`,
  }));

  if (job.customer.phone?.trim() && !normalizeUsPhoneNumber(job.customer.phone)) {
    issues.push({
      field: "Phone",
      message: "Phone must be +1-xxx-xxx-xxxx",
    });
  }

  if (job.customer.email?.trim() && !isValidEmail(job.customer.email)) {
    issues.push({
      field: "Email",
      message: "Email must look like name@example.com",
    });
  }

  if (job.customer.zip?.trim() && !isValidFiveDigitZip(job.customer.zip)) {
    issues.push({
      field: "ZIP",
      message: "ZIP must be 5 digits",
    });
  }

  return issues;
}

export function normalizeUsPhoneNumber(value: string): string {
  const digits = value.replace(/\D/g, "");
  const tenDigits = digits.length === 11 && digits.startsWith("1")
    ? digits.slice(1)
    : digits;

  if (tenDigits.length !== 10) return "";
  return `+1-${tenDigits.slice(0, 3)}-${tenDigits.slice(3, 6)}-${tenDigits.slice(6)}`;
}

export function formatUsPhoneInput(value: string): string {
  const digits = value.replace(/\D/g, "");
  const tenDigits = digits.startsWith("1") ? digits.slice(1, 11) : digits.slice(0, 10);

  if (tenDigits.length === 0) return "";
  if (tenDigits.length <= 3) return `+1-${tenDigits}`;
  if (tenDigits.length <= 6) return `+1-${tenDigits.slice(0, 3)}-${tenDigits.slice(3)}`;
  return `+1-${tenDigits.slice(0, 3)}-${tenDigits.slice(3, 6)}-${tenDigits.slice(6)}`;
}

export function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

export function isValidFiveDigitZip(value: string): boolean {
  return /^\d{5}$/.test(value.trim());
}
