/**
 * Pure constructors and normalizers for the company profile.
 *
 * Immutable like the other shared modules: build new records, don't mutate.
 */

import type { CompanyContact, CompanyLicense, CompanyLocation, CompanyProfile } from "./types";
import { newId } from "./ids";
import {
  APP_LOGO_PATH,
  APP_NAME,
  APP_SUPPORT_EMAIL,
} from "./branding";

/** Fixed key for the single-tenant company record. */
export const COMPANY_PROFILE_ID = "default";

/** Platform-wide ShingleFile branding stored separately from customer profiles. */
export const PLATFORM_PROFILE_ID = "platform";

export function newCompanyContact(): CompanyContact {
  return { id: newId(), name: "", role: "", email: "", phone: "" };
}

export function newCompanyLicense(state = ""): CompanyLicense {
  return { id: newId(), state, licenseId: "" };
}

export function newCompanyLocation(state = ""): CompanyLocation {
  return {
    id: newId(),
    label: state ? `${state} office` : "",
    state,
    address1: "",
    address2: "",
    city: "",
    zip: "",
    phone: "",
    officePhone: "",
  };
}

export function newCompanyProfile(): CompanyProfile {
  return {
    id: COMPANY_PROFILE_ID,
    companyName: "",
    legalName: "",
    website: "",
    email: "",
    phone: "",
    officePhone: "",
    address1: "",
    address2: "",
    city: "",
    state: "",
    zip: "",
    logoUrl: "",
    licenses: [],
    contacts: [],
    locations: [],
    updatedAt: new Date().toISOString(),
  };
}

/** Default ShingleFile platform identity — editable by admins, used as contract fallback. */
export function newPlatformProfile(): CompanyProfile {
  return {
    ...newCompanyProfile(),
    id: PLATFORM_PROFILE_ID,
    companyName: APP_NAME,
    legalName: APP_NAME,
    website: "https://shinglefile.com",
    email: APP_SUPPORT_EMAIL,
    logoUrl: APP_LOGO_PATH,
  };
}

/**
 * Coerce an arbitrary (possibly partial or older) record into a complete,
 * well-shaped profile. Keeps the stored shape stable as fields are added.
 */
export function normalizeCompanyProfile(
  input: Partial<CompanyProfile> | null | undefined,
): CompanyProfile {
  const base = newCompanyProfile();
  if (!input) return base;

  return {
    ...base,
    ...input,
    id: COMPANY_PROFILE_ID,
    licenses: (input.licenses ?? []).map((license) => ({
      ...newCompanyLicense(),
      ...license,
    })),
    contacts: (input.contacts ?? []).map((contact) => ({
      ...newCompanyContact(),
      ...contact,
    })),
    locations: (input.locations ?? []).map((location) => ({
      ...newCompanyLocation(),
      ...location,
    })),
  };
}
