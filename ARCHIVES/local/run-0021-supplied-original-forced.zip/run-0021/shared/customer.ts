/**
 * Pure functions for working with Customer records.
 *
 * All functions are immutable: they take a Customer and return a new one.
 */

import type { Customer, Insurance } from "./types";
import { newId } from "./ids";

export function newInsurance(): Insurance {
  return {
    company: "",
    claimNumber: "",
    contact: "",
  };
}

export function ensureCustomerInsurance(customer: Customer): Insurance {
  if (!customer.insurance) {
    customer.insurance = newInsurance();
  }
  return customer.insurance;
}

export function newCustomer(name: string): Customer {
  return {
    id: newId(),
    name,
    companyName: "",
    firstName: "",
    lastName: "",
    address1: "",
    address2: "",
    city: "",
    state: "",
    zip: "",
    phone: "",
  };
}

export function formatCustomerName(customer: Customer): string {
  const contactName = [customer.firstName, customer.lastName]
    .map((part) => part?.trim())
    .filter(Boolean)
    .join(" ");

  return (
    customer.companyName?.trim() ||
    contactName ||
    customer.name?.trim() ||
    "Unnamed customer"
  );
}
