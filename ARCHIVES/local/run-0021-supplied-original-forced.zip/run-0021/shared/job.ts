/**
 * Pure functions for building and updating a Job.
 *
 * All functions are immutable. None of these compute prices — see
 * `shared/options/*` for that.
 */

import type {
  Customer,
  Job,
  JobScope,
  RoofArea,
  RoofingScope,
} from "./types";
import { normalizeRoofArea } from "./roofArea";
import { newId } from "./ids";
import { newCustomer } from "./customer";

function nowIso(): string {
  return new Date().toISOString();
}

function newJob(customer: Customer): Job {
  const now = nowIso();
  return {
    id: newId(),
    status: "draft",
    customer,
    state: "IA",
    estimator: "",
    commissionRate: 0.1,
    scope: {},
    permit: 0,
    extras: { amount: 0, description: "" },
    createdAt: now,
    updatedAt: now,
  };
}

/**
 * Build an empty RoofArea with sensible defaults (1S / Walk / 1C, no redeck,
 * 10% waste).
 */
export function newRoofArea(): RoofArea {
  return normalizeRoofArea({
    label: "",
    sizeInputMode: "squares",
    inputSquares: 0,
    inputSurfaceSqft: 0,
    dimensionBasis: "surface",
    wastePercent: 10,
  });
}

/**
 * Build an empty RoofingScope with one roof area and defaulted picker values.
 * Pricing lookups that require a real id (shingle product, drip edge styles,
 * etc.) start empty — the UI will guide the user into filling them.
 */
export function newRoofingScope(): RoofingScope {
  return {
    areas: [newRoofArea()],
    shingle: {
      productId: "owenscorning-duration",
      colorId: "",
      fastener: "galvanized-6",
      warranty: "standard",
    },
    ridgeStyle: "new-standard",
    starterType: "preform",
    ridgeLf: 0,
    hipLf: 0,
    ridgeVentLf: 0,
    cutInRidgeVentLf: 0,
    stepFlashingLf: 0,
    chimneyRemoval: "No",
    chimneyKit: "No Kit",
    satellite: "No",
    antenna: "No",
    lightningRods: "No",
    skylights: [],
    workAroundGutters: "No",
    gutterRemovalLf: 0,
    lowSlope: " NA",
    valleys: { style: "closed", openLf: 0, closedLf: 0 },
    accessories: [],
  };
}

/**
 * Create a fresh draft Job: empty customer, roofing scope with one area,
 * no siding or gutter scopes yet. This is what `jobs.createDraft` returns
 * on the server — the UI can immediately navigate to it and start editing.
 */
export function newDraftJob(): Job {
  const job = newJob(newCustomer(""));
  return updateScope(job, { roofing: newRoofingScope() });
}

function touch(job: Job): Job {
  return { ...job, updatedAt: nowIso() };
}

function updateScope(job: Job, patch: Partial<JobScope>): Job {
  return touch({ ...job, scope: { ...job.scope, ...patch } });
}
