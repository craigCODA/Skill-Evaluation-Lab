export const APP_NAME = "ShingleFile.com"

/** Hosted in `public/` — used for app chrome and platform contract fallback. */
export const APP_LOGO_PATH = "/shinglefile-logo.jpg"

export function resolveLogoUrl(
  customUrl?: string | null,
  usePlatformFallback = true,
): string {
  const trimmed = customUrl?.trim()
  if (trimmed) return trimmed
  return usePlatformFallback ? APP_LOGO_PATH : ""
}

export const APP_REPRESENTATIVE = "ShingleFile.com Representative"

export const APP_REP_SHORT = "ShingleFile.com Rep."

export const APP_SUPPORT_EMAIL = "support@shinglefile.com"
