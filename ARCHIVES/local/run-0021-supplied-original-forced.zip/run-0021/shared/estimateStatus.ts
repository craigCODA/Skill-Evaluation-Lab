import type { JobStatus } from "./types"

export type EstimateStatusKey = JobStatus

export type EstimateStatusStyle = {
  label: string
  rowClass: string
  badgeClass: string
  swatch: string
}

/** Display order for the status legend. */
export const ESTIMATE_STATUS_ORDER: EstimateStatusKey[] = [
  "draft",
  "roof-proposal",
  "temporary-repair",
  "proposed",
  "signed",
  "in-progress",
  "complete",
  "cancelled"
]

export const ESTIMATE_STATUS_STYLES: Record<EstimateStatusKey, EstimateStatusStyle> = {
  draft: {
    label: "Draft",
    rowClass: "estimate-status-draft",
    badgeClass: "estimate-status-badge-draft",
    swatch: "var(--sf-status-draft-accent)"
  },
  "roof-proposal": {
    label: "Roof Proposal",
    rowClass: "estimate-status-roof-proposal",
    badgeClass: "estimate-status-badge-roof-proposal",
    swatch: "var(--sf-status-roof-accent)"
  },
  "temporary-repair": {
    label: "Temporary Repair",
    rowClass: "estimate-status-temporary-repair",
    badgeClass: "estimate-status-badge-temporary-repair",
    swatch: "var(--sf-status-repair-accent)"
  },
  proposed: {
    label: "Proposed",
    rowClass: "estimate-status-proposed",
    badgeClass: "estimate-status-badge-proposed",
    swatch: "var(--sf-status-proposed-accent)"
  },
  signed: {
    label: "Signed",
    rowClass: "estimate-status-signed",
    badgeClass: "estimate-status-badge-signed",
    swatch: "var(--sf-status-signed-accent)"
  },
  "in-progress": {
    label: "In Progress",
    rowClass: "estimate-status-in-progress",
    badgeClass: "estimate-status-badge-in-progress",
    swatch: "var(--sf-status-progress-accent)"
  },
  complete: {
    label: "Complete",
    rowClass: "estimate-status-complete",
    badgeClass: "estimate-status-badge-complete",
    swatch: "var(--sf-status-complete-accent)"
  },
  cancelled: {
    label: "Cancelled",
    rowClass: "estimate-status-cancelled",
    badgeClass: "estimate-status-badge-cancelled",
    swatch: "var(--sf-status-cancelled-accent)"
  }
}

export function estimateStatusStyle(status: string): EstimateStatusStyle {
  return ESTIMATE_STATUS_STYLES[status as EstimateStatusKey] ?? {
    label: status.replace(/-/g, " "),
    rowClass: "estimate-status-draft",
    badgeClass: "estimate-status-badge-draft",
    swatch: "var(--sf-status-draft-accent)"
  }
}

export function sortEstimatesByRecent<
  T extends { updatedAt: string }
>(items: T[]): T[] {
  return [...items].sort(
    (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  )
}
