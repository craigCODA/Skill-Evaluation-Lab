/**
 * Login password rules for Cognito-backed accounts.
 * Keep in sync with `infra/cloudformation/auth.yml` PasswordPolicy.
 */
export const PASSWORD_POLICY_DESCRIPTION =
  "Password must be at least 8 characters and include an uppercase letter"

export function passwordPolicyError(password: string): string | null {
  if (password.length < 8) {
    return "Password must be at least 8 characters"
  }
  if (!/[A-Z]/.test(password)) {
    return "Password must include an uppercase letter"
  }
  return null
}
