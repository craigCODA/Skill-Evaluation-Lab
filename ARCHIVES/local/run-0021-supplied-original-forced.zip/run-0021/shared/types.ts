/**
 * Domain types for the roofing calculator / job & invoice system.
 *
 * This file describes *shape only* — what a roofing Job and its inputs look
 * like. No behavior. Every other module in `shared/**` operates on these
 * types with pure functions.
 *
 * Keep this file as the single source of truth for the shared vocabulary.
 * If a concept needs a type, put it here.
 */

// ============================================================================
// Primitives
// ============================================================================

/** USD, stored as whole dollars for now. Revisit if we need cents precision. */
export type Money = number;

export type ID = string;

/** ISO 8601 date-time (YYYY-MM-DDTHH:mm:ssZ). */
export type ISODateTime = string;

// ============================================================================
// Customer
// ============================================================================

export type Customer = {
  id: ID;
  /** Legacy/display name kept so older saved jobs still load cleanly. */
  name: string;
  companyName: string;
  firstName: string;
  lastName: string;
  address1: string;
  address2?: string;
  city: string;
  state: string;
  zip: string;
  street?: string;
  stateZip?: string;
  phone: string;
  officePhone?: string;
  email?: string;
  insurance?: Insurance;
  notes?: string;
};

/**
 * Role inside a roofing company account (not Cognito).
 * Platform admin/customer is `AccountRole`. Capability defaults and
 * per-company overrides live in `shared/accountPermissions.ts`.
 */
export type CustomerAccountRole =
  | "customer-account-admin"
  | "estimator"
  | "installer"
  | "sub-account";

/**
 * Optional per-company overrides of default role capabilities.
 * Keys are assignable roles; values are capability id lists.
 * See `shared/accountPermissions.ts`.
 */
export type CompanyRoleCapabilities = Partial<
  Record<"customer-account-admin" | "estimator" | "installer", string[]>
>;

export type CustomerAccount = {
  id: ID;
  name: string;
  adminUserId: ID;
  /** When set, replaces default capabilities for that role on this company. */
  roleCapabilities?: CompanyRoleCapabilities;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
};

export type SubAccount = {
  id: ID;
  customerAccountId: ID;
  userId: ID;
  email: string;
  name: string;
  title?: string;
  role: CustomerAccountRole;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
};

export type AccountDashboard = {
  customerAccountId: ID;
  customerAccountName: string;
  subAccountId: ID;
  canSeeAllCustomerAccountWork: boolean;
  totalSubAccounts: number;
  totalCustomers: number;
  totalEstimates: number;
  totalContracts: number;
  draftEstimates: number;
  signedEstimates: number;
  completeEstimates: number;
};

export type CustomerRecord = {
  id: ID;
  customerAccountId: ID;
  createdBySubAccountId: ID;
  customer: Customer;
  displayName: string;
  address: string;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
};

export type CustomerJobSummary = {
  id: ID;
  customerId: ID;
  customerAccountId: ID;
  createdBySubAccountId: ID;
  number?: string;
  estimateType?: EstimateType;
  estimator: string;
  displayName: string;
  address: string;
  status: string;
  contractKind?: EstimateType;
  contractLabel?: string;
  assets: JobAsset[];
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
  proposedAt?: ISODateTime;
  signedAt?: ISODateTime;
};

export type CustomerFile = CustomerRecord & {
  jobs: CustomerJobSummary[];
};

export type JobAssetKind = "drawing-screenshot" | "image";

export type DrawingScreenshotAssetMetadata = {
  source: "shinglescope";
  address?: string;
  measurementId?: ID;
  capturedAt: ISODateTime;
};

export type JobAsset = {
  id: ID;
  customerAccountId: ID;
  createdBySubAccountId: ID;
  customerId: ID;
  jobId: ID;
  kind: JobAssetKind;
  label: string;
  description?: string;
  contentType: string;
  imageKey: string;
  metadata?: DrawingScreenshotAssetMetadata;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
};

export type Insurance = {
  company: string;
  claimNumber: string;
  contact?: string;
};

// ============================================================================
// Job
// ============================================================================

export type EstimateType =
  | "roof-proposal"
  | "temporary-repair";

export type JobStatus =
  | "draft"
  | EstimateType
  | "proposed"
  | "signed"
  | "in-progress"
  | "complete"
  | "cancelled";

export type LicenseState = "IA" | "LA";

export type Job = {
  id: ID;
  customerAccountId?: ID;
  createdBySubAccountId?: ID;
  customerId?: ID;
  /** Human-friendly number, e.g. "J-2026-0042". Optional until assigned. */
  number?: string;
  /** Selected contract/workflow type for this estimate. */
  estimateType?: EstimateType;
  status: JobStatus;
  customer: Customer;
  /** Which state's license / rules apply. */
  state: LicenseState;
  estimator: string;
  /** Sales commission as a fraction (0.10 = 10%). */
  commissionRate: number;
  scope: JobScope;
  permit: Money;
  extras: Extras;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
  proposedAt?: ISODateTime;
  signedAt?: ISODateTime;
};

export type Extras = {
  amount: Money;
  description: string;
};

/** A job can include a roofing scope. More trades can be added when needed. */
export type JobScope = {
  roofing?: RoofingScope;
};

// ============================================================================
// Roofing scope
// ============================================================================

export type RoofingScope = {
  areas: RoofArea[];
  shingle: ShingleSelection;
  ridgeStyle: RidgeStyle;
  starterType?: StarterType;
  /**
   * Total linear feet of ridge for the whole job (the geometric ridge
   * length, independent of how much carries vent). Drives the cap-shingle
   * bundle count on the materials take-off; not used in pricing today.
   */
  ridgeLf: number;
  /** Temporary persisted roof measurement; not priced yet. */
  hipLf?: number;
  /** Linear feet of ridge vent across the whole job. */
  ridgeVentLf: number;
  /** Linear feet of cut-in ridge vent across the whole job. */
  cutInRidgeVentLf: number;
  /** Linear feet of step flashing for the whole job. */
  stepFlashingLf: number;
  /**
   * Chimney removal pick (catalog key in `chimneyRemovalOptions`).
   * "No" means no removal.
   */
  chimneyRemoval: string;
  /**
   * Chimney kit pick (catalog key in `chimneyKitOptions`).
   * "No Kit" means no kit installed.
   */
  chimneyKit: string;
  /**
   * Satellite-dish pick (catalog key in `satelliteOptions`).
   * "No" means no satellite work.
   */
  satellite: string;
  /**
   * Antenna pick (catalog key in `antennaOptions`).
   * "No" means no antenna work.
   */
  antenna: string;
  /**
   * Lightning-rod pick (catalog key in `lightningRodOptions`).
   * "No" means no lightning-rod work.
   */
  lightningRods: string;
  /**
   * Skylights billed as `count × price` per row. Multiple rows allowed
   * so different sizes can each carry their own count.
   */
  skylights: SkylightLine[];
  /**
   * Gutter removal / work-around toggle. `"No"` skips billing, `"Yes"` charges
   * `gutterRemovalLf × $/ft`.
   */
  workAroundGutters: "No" | "Yes";
  /** Linear feet of gutter to remove or work around. */
  gutterRemovalLf: number;
  /**
   * Low-slope roofing pick (catalog key in `lowSlopeOptions`). Default `" NA"`
   * (leading space). Cost is `pricePerSquare × totalSquares`.
   */
  lowSlope: string;
  valleys: ValleySelection;
  accessories: AccessorySelection;
};

/** One row of the skylight list. `option` matches `SkylightOption.key`. */
export type SkylightLine = {
  id: ID;
  option: string;
  count: number;
};

export type RoofArea = {
  id: ID;
  label: string;
  description?: string;
  location: RoofLocation;
  /** Primary size entry mode (defaults to dimensions for legacy jobs). */
  sizeInputMode?: RoofSizeInputMode;
  /** Squares from a measurement report (1 square = 100 sq ft, before waste). */
  inputSquares?: number;
  /** Surface sq ft from a measurement report (before waste). */
  inputSurfaceSqft?: number;
  /**
   * L×W mode only: measure on the roof surface, or horizontal footprint
   * (footprint uses pitch multiplier for sloped area).
   */
  dimensionBasis?: RoofDimensionBasis;
  story: Story;
  pitch: Pitch;
  layers: LayerCount;
  redeck: RedeckChoice;
  access: AccessChoice;
  /** L×W mode: length along slope (ridge to eave). */
  rafterFt: number;
  /** L×W mode: width along the eave. */
  eaveFt: number;
  wastePercent: number;
  /** Drip edge inputs for this area. Match catalog `DripEdgeStyle.key`. */
  eaveDripStyle: string;
  rakeDripStyle: string;
  eaveDripLf: number;
  rakeDripLf: number;
  /** Underlayment picker for this area. Matches catalog `UnderlaymentOption.key`. */
  underlayment: string;
  /**
   * Ice & water shield picker for this area. Matches catalog
   * `IceWaterOption.key` (e.g. `"None"`, `"Valleys & Eaves"`). Tracked
   * per-area so each area can choose its own coverage.
   */
  iceWaterOption: string;
  /**
   * Overhang picker for this area; resolves to a row count
   * (`IceWaterOverhang.rows`, 1 / 1.5 / 2) that multiplies the eave-side
   * I&W cost.
   */
  iceWaterOverhang: string;
  /**
   * Closed-valley LF receiving ice & water shield on this area. Tracked
   * per-area so different areas can carry different valley footage.
   */
  iceWaterValleyLf: number;
};

export type RoofLocation =
  | "House" | "Entry" | "Front Porch" | "Back Porch" | "Breezeway"
  | "Att. Garage" | "Unatt. Garage" | "Carport" | "Shed 1" | "Shed 2"
  | "Lean to" | "Barn 1" | "Barn 2" | "Shop" | "North Slope" | "South Slope"
  | "East Slope" | "West Slope" | "Dead Valley" | "Dormer" | "Church";

export type Story = "1S" | "1.5S" | "2S" | "3S";

export type Pitch =
  | "Flat - SBS" | "Flat - TPO" | "Low Slope IW 3/12-2X felt"
  | "Walk" | "7/12" | "8/12" | "9/12" | "10/12" | "11/12" | "12/12"
  | "13/12" | "14/12" | "Mansard" | "Mansard Tar";

export type LayerCount =
  | "1C" | "2C" | "3C" | "1C+1W" | "2C+1W" | "3C+1W"
  | "1W" | "Asbestos" | "Slate";

export type RedeckChoice = "No" | "Yes - Walk" | "Yes - Steep" | "Yes - Mansard";

export type AccessChoice = "Access" | "No Access";

/** How the roofer enters this plane's surface area. */
export type RoofSizeInputMode = "squares" | "sqft" | "dimensions";

/**
 * When measuring L×W: dimensions on the roof surface, or horizontal footprint
 * (pitch multiplier applied to convert to sloped surface area).
 */
export type RoofDimensionBasis = "surface" | "footprint";

// --- Roof plane (facet) -------------------------------------------------------

export type ShingleSelection = {
  productId: ID;
  colorId: ID;
  fastener: FastenerChoice;
  warranty: WarrantyTier;
};

export type FastenerChoice = "galvanized-6" | "hand-nail-6";

export type WarrantyTier =
  | "standard"
  | "oc-system-advantage"
  | "oc-preferred"
  | "oc-platinum"
  | "gaf-system-plus"
  | "gaf-golden-pledge";

// --- Ridge / valleys --------------------------------------------------------

export type RidgeStyle = "new-standard" | "new-high-hip";
export type StarterType = "roll" | "preform";

export type ValleySelection = {
  style: "open" | "closed";
  /**
   * Linear feet of valley. Two slots are kept so the unused side can carry
   * historical data when the picker flips between styles.
   */
  openLf: number;
  closedLf: number;
};

/**
 * Job-level count-based accessory line items. Each field maps to one
 * `accessoryRates` catalog row; the cost is `count × pricePerUnit`. The
 * three pipe-boot sizes share `$50` today but get separate catalog rows so
 * per-size rates can be edited later. This is intentionally dynamic: adding a
 * new catalog row in `accessoryRates` makes it selectable on the Job page
 * without adding a new TypeScript field.
 */
export type AccessorySelection = AccessoryLineSelection[];

export type AccessoryLineSelection = {
  id: ID;
  /** Catalog key from `AccessoryRate.key`. */
  key: string;
  count: number;
};

// ============================================================================
// Roof measurements
// ============================================================================

export type RoofMeasurementProvider =
  | "google_solar"
  | "nearmap"
  | "vexcel"
  | "eagleview_import"
  | "roofr_import"
  | "hover_import"
  | "drone_upload"
  | "manual"
  | "shinglefile_ai";

export type RoofImageryQuality = "HIGH" | "MEDIUM" | "LOW" | "UNKNOWN";

export type RoofMeasurementComplexity =
  | "simple"
  | "moderate"
  | "complex"
  | "very_complex"
  | "unknown";

export type RoofOrientationLabel =
  | "N"
  | "NE"
  | "E"
  | "SE"
  | "S"
  | "SW"
  | "W"
  | "NW"
  | "UNKNOWN";

export type LatLng = {
  latitude: number;
  longitude: number;
};

export type RoofBoundingBox = {
  sw: LatLng;
  ne: LatLng;
};

export type RoofMeasurementSource = {
  provider: RoofMeasurementProvider;
  providerRequestId?: string;
  rawResponseStorageKey?: string;
  imageryDate?: string;
  imageryProcessedDate?: string;
  imageryQuality: RoofImageryQuality;
  fetchedAt: ISODateTime;
  confidence: number;
  notes?: string[];
};

export type RoofSegment = {
  id: ID;
  providerSegmentId?: string;
  areaM2?: number;
  areaSqft?: number;
  pitchDegrees?: number;
  pitchRiseOver12?: number;
  pitchLabel?: string;
  azimuthDegrees?: number;
  orientationLabel: RoofOrientationLabel;
  center?: LatLng;
  boundingBox?: RoofBoundingBox;
  planeHeightAtCenterMeters?: number;
  confidence: number;
  source: RoofMeasurementProvider;
};

export type RoofMeasurementOverrides = {
  totalRoofAreaSqft?: number;
  measuredSquares?: number;
  wasteFactor?: number;
  orderSquares?: number;
  primaryPitchLabel?: string;
  complexity?: RoofMeasurementComplexity;
  eavesFt?: number;
  rakesFt?: number;
  ridgesFt?: number;
  hipsFt?: number;
  valleysFt?: number;
  dripEdgeFt?: number;
  starterFt?: number;
  ridgeCapFt?: number;
  notes?: string;
  adjustedByUserId?: string;
  adjustedAt?: ISODateTime;
};

export type RoofMeasurement = {
  id: ID;
  propertyId: ID;
  address: string;
  latitude: number;
  longitude: number;
  source: RoofMeasurementSource;
  totalRoofAreaM2?: number;
  totalRoofAreaSqft?: number;
  measuredSquares?: number;
  wasteFactor: number;
  orderSquares?: number;
  segmentCount: number;
  complexity: RoofMeasurementComplexity;
  segments: RoofSegment[];
  assumedLinearMeasurements?: {
    eavesFt?: number;
    rakesFt?: number;
    ridgesFt?: number;
    hipsFt?: number;
    valleysFt?: number;
    dripEdgeFt?: number;
    starterFt?: number;
    ridgeCapFt?: number;
  };
  imagery?: RoofMeasurementImagery;
  manualOverrides?: RoofMeasurementOverrides;
  confidence: {
    overall: number;
    area: number;
    pitch: number;
    linears: number;
    imagery: number;
  };
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
};

export type RoofMeasurementImagery = {
  previewDataUrl?: string;
  maskDataUrl?: string;
  imageryDate?: string;
  imageryProcessedDate?: string;
  imageryQuality: RoofImageryQuality;
  bounds?: RoofBoundingBox;
  /** Ground extent of the preview image from GeoTIFF georeferencing. */
  georef?: RoofImageryGeoref;
  maskGeometry?: RoofMaskGeometry;
  elevation?: RoofMeasurementElevationAnalysis;
  availableLayers: RoofMeasurementLayerType[];
};

/** Geographic extent and resolution of the aerial preview raster. */
export type RoofImageryGeoref = {
  sourceWidthPx: number;
  sourceHeightPx: number;
  previewWidthPx: number;
  previewHeightPx: number;
  widthMeters: number;
  heightMeters: number;
  pixelSizeMeters: number;
};

export type RoofMaskGeometry = {
  outlines: RoofMaskOutline[];
  segmentValidations: RoofSegmentMaskValidation[];
  maskCoveragePercent: number;
  notes: string[];
};

export type RoofMaskOutline = {
  id: string;
  path: string;
  areaPixels: number;
  areaPercent: number;
  centroid: RoofMaskPoint;
  boundingBox: {
    left: number;
    top: number;
    width: number;
    height: number;
  };
};

export type RoofMaskPoint = {
  x: number;
  y: number;
};

export type RoofSegmentMaskValidation = {
  segmentId: ID;
  centerInsideMask: boolean;
  marker: RoofMaskPoint;
  box?: {
    left: number;
    top: number;
    width: number;
    height: number;
  };
  boundingBoxOverlapRatio?: number;
  notes: string[];
};

export type RoofMeasurementElevationAnalysis = {
  sampleCount: number;
  minHeightMeters: number;
  maxHeightMeters: number;
  meanHeightMeters: number;
  heightRangeMeters: number;
  typicalHeightRangeMeters: number;
  highOutlierMeters: number;
  lowOutlierMeters: number;
  possibleObstruction: boolean;
  notes: string[];
};

export type RoofMeasurementLayerType =
  | "rgb"
  | "dsm"
  | "mask"
  | "annual_flux"
  | "monthly_flux"
  | "hourly_shade";

// ============================================================================
// Company profile (the roofer's own account / business identity)
// ============================================================================

/** A named contact or owner for the company. */
export type CompanyContact = {
  id: ID;
  name: string;
  /** e.g. "Owner", "Estimator", "Office". */
  role: string;
  email: string;
  phone: string;
};

/** A state contractor license the company holds. */
export type CompanyLicense = {
  id: ID;
  /** State the license is issued in (e.g. "IA", "LA"). */
  state: string;
  licenseId: string;
};

/** A contractor office tied to a state — printed on contracts for jobs in that state. */
export type CompanyLocation = {
  id: ID;
  /** Short label for the UI, e.g. "Iowa office". */
  label: string;
  /** State code matched to the estimate job state (e.g. "IA", "LA"). */
  state: string;
  address1: string;
  address2: string;
  city: string;
  zip: string;
  phone: string;
  officePhone: string;
};

/**
 * The account holder's business identity. Single record for now (one company
 * per install); becomes per-user when accounts are multi-tenant.
 */
export type CompanyProfile = {
  id: ID;
  companyName: string;
  legalName: string;
  website: string;
  email: string;
  phone: string;
  officePhone: string;
  address1: string;
  address2: string;
  city: string;
  state: string;
  zip: string;
  /** Logo image URL. Direct file upload (S3) comes later. */
  logoUrl: string;
  licenses: CompanyLicense[];
  contacts: CompanyContact[];
  /** Per-state offices used on contracts when the job state matches. */
  locations: CompanyLocation[];
  updatedAt: ISODateTime;
};

// ============================================================================
// Accounts (users managed by an admin)
// ============================================================================

export type AccountRole = "admin" | "customer";

/** An account as shown to an admin, with a summary of its company profile. */
export type AccountSummary = {
  /** Cognito user id (sub). */
  userId: ID;
  email: string;
  name: string;
  role: AccountRole;
  createdAt: ISODateTime;
  companyName: string;
};
