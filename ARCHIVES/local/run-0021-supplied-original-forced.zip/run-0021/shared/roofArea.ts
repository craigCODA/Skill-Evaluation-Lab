/**
 * Roof plane (facet) geometry and normalization.
 *
 * Roofers enter size as squares (EagleView), sq ft, or L×W. All pricing paths
 * resolve to a single surface sq ft before waste is applied.
 */

import type {
  Pitch,
  RoofArea,
  RoofDimensionBasis,
  RoofingScope,
  RoofLocation,
  RoofSizeInputMode,
} from "./types";
import { newId } from "./ids";

export const ROOF_LOCATIONS: RoofLocation[] = [
  "House", "Entry", "Front Porch", "Back Porch", "Breezeway",
  "Att. Garage", "Unatt. Garage", "Carport", "Shed 1", "Shed 2",
  "Lean to", "Barn 1", "Barn 2", "Shop", "North Slope", "South Slope",
  "East Slope", "West Slope", "Dead Valley", "Dormer", "Church",
];

export const WASTE_PRESETS = [
  { id: "simple", label: "Simple gable (10%)", percent: 10 },
  { id: "hip", label: "Hips / moderate (12%)", percent: 12 },
  { id: "complex", label: "Complex / cut-up (15%)", percent: 15 },
] as const;

export type RoofAreaSquares = {
  surfaceSqft: number;
  squaresBeforeWaste: number;
  squaresWithWaste: number;
};

/** Approximate pitch factor: horizontal footprint → sloped surface area. */
export function pitchSurfaceMultiplier(pitch: Pitch): number {
  const slash = pitch.match(/(\d+)\/12/)
  if (slash?.[1]) {
    const rise = Number(slash[1])
    return Math.sqrt(1 + Math.pow(rise / 12, 2))
  }

  const flat: Partial<Record<Pitch, number>> = {
    "Walk": 1.03,
    "Flat - SBS": 1,
    "Flat - TPO": 1,
    "Low Slope IW 3/12-2X felt": 1.031,
    "Mansard": 1.25,
    "Mansard Tar": 1.25,
  }
  return flat[pitch] ?? 1.1
}

/** Sloped roof surface sq ft for one plane (before waste). */
export function roofAreaSurfaceSqft(area: RoofArea): number {
  const mode: RoofSizeInputMode = area.sizeInputMode ?? inferSizeInputMode(area)

  if (mode === "squares") {
    return (area.inputSquares ?? 0) * 100
  }
  if (mode === "sqft") {
    return area.inputSurfaceSqft ?? 0
  }

  const footprint = (area.rafterFt ?? 0) * (area.eaveFt ?? 0)
  const basis: RoofDimensionBasis = area.dimensionBasis ?? "surface"
  if (basis === "footprint") {
    return footprint * pitchSurfaceMultiplier(area.pitch)
  }
  return footprint
}

export function roofAreaSquares(area: RoofArea): RoofAreaSquares {
  const surfaceSqft = roofAreaSurfaceSqft(area)
  const wasteMultiplier = 1 + (area.wastePercent ?? 0) / 100
  return {
    surfaceSqft,
    squaresBeforeWaste: surfaceSqft / 100,
    squaresWithWaste: (surfaceSqft * wasteMultiplier) / 100,
  }
}

export function normalizeRoofArea(input: Partial<RoofArea> | null | undefined): RoofArea {
  const mode = input?.sizeInputMode ?? inferSizeInputMode(input ?? {})
  return {
    id: input?.id ?? newId(),
    label: input?.label ?? "",
    description: input?.description ?? "",
    location: input?.location ?? "House",
    sizeInputMode: mode,
    inputSquares: input?.inputSquares ?? 0,
    inputSurfaceSqft: input?.inputSurfaceSqft ?? 0,
    dimensionBasis: input?.dimensionBasis ?? "surface",
    story: input?.story ?? "1S",
    pitch: input?.pitch ?? "Walk",
    layers: input?.layers ?? "1C",
    redeck: input?.redeck ?? "No",
    access: input?.access ?? "Access",
    rafterFt: input?.rafterFt ?? 0,
    eaveFt: input?.eaveFt ?? 0,
    wastePercent: input?.wastePercent ?? 10,
    eaveDripStyle: input?.eaveDripStyle ?? "",
    rakeDripStyle: input?.rakeDripStyle ?? "",
    eaveDripLf: input?.eaveDripLf ?? 0,
    rakeDripLf: input?.rakeDripLf ?? 0,
    underlayment: input?.underlayment ?? "",
    iceWaterOption: input?.iceWaterOption ?? "None",
    iceWaterOverhang: input?.iceWaterOverhang ?? "0\"",
    iceWaterValleyLf: input?.iceWaterValleyLf ?? 0,
  }
}

export function normalizeRoofingScope(scope: RoofingScope): RoofingScope {
  return {
    ...scope,
    areas: scope.areas.map((area) => normalizeRoofArea(area)),
  }
}

function inferSizeInputMode(area: Partial<RoofArea>): RoofSizeInputMode {
  if (area.sizeInputMode) return area.sizeInputMode
  if ((area.inputSquares ?? 0) > 0) return "squares"
  if ((area.inputSurfaceSqft ?? 0) > 0) return "sqft"
  if ((area.rafterFt ?? 0) > 0 || (area.eaveFt ?? 0) > 0) return "dimensions"
  return "squares"
}
