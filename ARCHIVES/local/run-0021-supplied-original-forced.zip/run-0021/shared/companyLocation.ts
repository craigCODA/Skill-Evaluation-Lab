import type { CompanyLocation, CompanyProfile } from "./types";
import { newId } from "./ids";

/** States available on estimates today — locations use the same codes. */
export const SUPPORTED_STATE_OPTIONS = [
  { code: "IA", name: "Iowa" },
  { code: "LA", name: "Louisiana" },
] as const;

export function formatLocationAddress(location: CompanyLocation): string {
  const stateZip = [location.state, location.zip].filter(Boolean).join(" ");
  const cityLine = [location.city, stateZip].filter(Boolean).join(", ");
  return [location.address1, location.address2, cityLine]
    .map((part) => part?.trim())
    .filter(Boolean)
    .join(", ");
}

function normalizeStateCode(state?: string): string {
  return state?.trim().toUpperCase() ?? "";
}

/** Pick the office that matches the job's state, with sensible fallbacks. */
export function resolveCompanyLocation(
  profile: CompanyProfile | null | undefined,
  jobState?: string,
): CompanyLocation | null {
  if (!profile) return null;

  const state = normalizeStateCode(jobState);
  const locations = profile.locations ?? [];

  if (state && locations.length) {
    const match = locations.find(
      (location) => normalizeStateCode(location.state) === state,
    );
    if (match) return match;
  }

  if (locations.length === 1) return locations[0] ?? null;

  if (profile.state?.trim() || profile.address1?.trim()) {
    return {
      id: "legacy-primary",
      label: profile.state ? `${profile.state} office` : "Primary office",
      state: profile.state,
      address1: profile.address1,
      address2: profile.address2,
      city: profile.city,
      zip: profile.zip,
      phone: profile.phone,
      officePhone: profile.officePhone,
    };
  }

  return locations[0] ?? null;
}

export function locationPhone(location: CompanyLocation | null | undefined): string {
  return location?.phone?.trim() || location?.officePhone?.trim() || "";
}

export function formatLicensesForState(
  profile: CompanyProfile | null | undefined,
  jobState?: string,
): string {
  if (!profile?.licenses?.length) return "";

  const state = normalizeStateCode(jobState);
  const licenses = state
    ? profile.licenses.filter(
        (license) => normalizeStateCode(license.state) === state,
      )
    : profile.licenses;

  return licenses
    .filter((license) => license.licenseId?.trim())
    .map((license) => license.state
      ? `${license.state} #${license.licenseId}`
      : `#${license.licenseId}`)
    .join(", ");
}

/** Seed one location row from legacy profile-level address fields. */
export function seedLocationsFromLegacyProfile(
  profile: CompanyProfile,
): CompanyProfile {
  const locations = profile.locations ?? [];
  if (locations.length > 0) return { ...profile, locations };
  if (!profile.state?.trim() && !profile.address1?.trim()) {
    return { ...profile, locations };
  }

  const state = profile.state.trim();
  return {
    ...profile,
    locations: [
      {
        id: newId(),
        label: state ? `${state} office` : "Primary office",
        state,
        address1: profile.address1,
        address2: profile.address2,
        city: profile.city,
        zip: profile.zip,
        phone: profile.phone,
        officePhone: profile.officePhone,
      },
    ],
  };
}
