export type ParsedRoofProbeAddress = {
  address: string;
  forceRefresh: boolean;
};

export function parseRoofProbeAddressInput(address: string): ParsedRoofProbeAddress {
  return {
    address: address.replace(/!/g, " ").replace(/\s+/g, " ").trim(),
    forceRefresh: address.includes("!"),
  };
}

export function normalizeRoofProbeAddress(address: string): string {
  return address
    .toLowerCase()
    .replace(/[^\d a-z]/g, " ")
    .replace(/\b(street|str)\b/g, "st")
    .replace(/\b(avenue)\b/g, "ave")
    .replace(/\b(road)\b/g, "rd")
    .replace(/\b(drive)\b/g, "dr")
    .replace(/\b(lane)\b/g, "ln")
    .replace(/\b(highway)\b/g, "hwy")
    .replace(/\s+/g, " ")
    .trim();
}
