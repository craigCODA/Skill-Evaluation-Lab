/**
 * Company-account capability map.
 *
 * Cognito/platform admin is separate (`AccountRole` / `isAdmin`).
 * These roles live on `sub_accounts.role` and answer “what can this person
 * do inside their roofing company?”
 *
 * Defaults live in `ROLE_CAPABILITIES`. A company may override assignable roles
 * via `CustomerAccount.roleCapabilities` (edited by account admins).
 *
 * To extend:
 * 1. Add a capability string to `AccountCapability`
 * 2. Grant it on the roles that should have it by default in `ROLE_CAPABILITIES`
 * 3. Call `hasCapability` / `assertAccountCapability` at the enforcement point
 * 4. Add a label in `ACCOUNT_CAPABILITY_LABELS`
 */

import type { CustomerAccountRole } from "./types"

export type AccountCapability =
  | "manageSubAccounts"
  | "editCompanyProfile"
  | "editCatalog"
  | "editContractSetup"
  | "editCustomers"
  | "editEstimates"
  | "viewEstimates"
  | "viewContracts"
  | "manageJobAssets"
  | "useRoofProbe"
  | "viewAccountStatistics"

/** Roles an account admin may assign in the UI (excludes legacy `sub-account`). */
export const ASSIGNABLE_CUSTOMER_ACCOUNT_ROLES = [
  "customer-account-admin",
  "estimator",
  "installer"
] as const satisfies readonly CustomerAccountRole[]

export type AssignableCustomerAccountRole =
  (typeof ASSIGNABLE_CUSTOMER_ACCOUNT_ROLES)[number]

/** Per-company overrides keyed by assignable role. */
export type CompanyRoleCapabilityOverrides = Partial<
  Record<AssignableCustomerAccountRole, AccountCapability[]>
>

export function isAssignableCustomerAccountRole(
  value: unknown
): value is AssignableCustomerAccountRole {
  return ASSIGNABLE_CUSTOMER_ACCOUNT_ROLES.includes(value as AssignableCustomerAccountRole)
}

export const CUSTOMER_ACCOUNT_ROLE_LABELS: Record<CustomerAccountRole, string> = {
  "customer-account-admin": "Account admin",
  estimator: "Estimator",
  installer: "Installer",
  "sub-account": "Team member (legacy)"
}

export const ACCOUNT_CAPABILITIES: readonly AccountCapability[] = [
  "manageSubAccounts",
  "editCompanyProfile",
  "editCatalog",
  "editContractSetup",
  "editCustomers",
  "editEstimates",
  "viewEstimates",
  "viewContracts",
  "manageJobAssets",
  "useRoofProbe",
  "viewAccountStatistics"
]

export const ACCOUNT_CAPABILITY_LABELS: Record<AccountCapability, string> = {
  manageSubAccounts: "Manage team members and roles",
  editCompanyProfile: "Edit company information",
  editCatalog: "Edit catalog and pricing",
  editContractSetup: "Edit contract modules and recipe",
  editCustomers: "Create and edit customers",
  editEstimates: "Create and edit estimates",
  viewEstimates: "View estimates",
  viewContracts: "View contracts",
  manageJobAssets: "Manage job photos and drawings",
  useRoofProbe: "Use ShingleScope",
  viewAccountStatistics: "View account statistics"
}

/** Cannot be removed from account admin (prevents lockout). */
export const LOCKED_ACCOUNT_ADMIN_CAPABILITIES: readonly AccountCapability[] = [
  "manageSubAccounts",
  "editContractSetup"
]

const ESTIMATOR_CAPABILITIES: readonly AccountCapability[] = [
  "editCustomers",
  "editEstimates",
  "viewEstimates",
  "viewContracts",
  "manageJobAssets",
  "useRoofProbe",
  "viewAccountStatistics"
]

const INSTALLER_CAPABILITIES: readonly AccountCapability[] = [
  "manageJobAssets",
  "useRoofProbe"
]

/** Default capability sets when a company has no override. */
export const ROLE_CAPABILITIES: Record<
  CustomerAccountRole,
  ReadonlySet<AccountCapability>
> = {
  "customer-account-admin": new Set(ACCOUNT_CAPABILITIES),
  estimator: new Set(ESTIMATOR_CAPABILITIES),
  installer: new Set(INSTALLER_CAPABILITIES),
  // Legacy: same as estimator until rows are backfilled
  "sub-account": new Set(ESTIMATOR_CAPABILITIES)
}

export function normalizeCustomerAccountRole(
  value: unknown
): CustomerAccountRole {
  if (
    value === "customer-account-admin"
    || value === "estimator"
    || value === "installer"
    || value === "sub-account"
  ) {
    return value
  }
  return "sub-account"
}

export function seesAllAccountWork(role: CustomerAccountRole): boolean {
  return role === "customer-account-admin"
}

export function isAccountCapability(value: unknown): value is AccountCapability {
  return ACCOUNT_CAPABILITIES.includes(value as AccountCapability)
}

export function defaultCapabilitiesForRole(role: CustomerAccountRole): AccountCapability[] {
  return [...ROLE_CAPABILITIES[normalizeCustomerAccountRole(role)]]
}

/** Maps legacy `sub-account` to estimator overrides. */
export function capabilityOverrideRole(
  role: CustomerAccountRole
): AssignableCustomerAccountRole {
  const normalized = normalizeCustomerAccountRole(role)
  if (normalized === "sub-account") return "estimator"
  if (isAssignableCustomerAccountRole(normalized)) return normalized
  return "estimator"
}

export function sanitizeCapabilityList(values: unknown): AccountCapability[] {
  if (!Array.isArray(values)) return []
  const seen = new Set<AccountCapability>()
  for (const value of values) {
    if (isAccountCapability(value)) seen.add(value)
  }
  return ACCOUNT_CAPABILITIES.filter((capability) => seen.has(capability))
}

function withLockedAccountAdminCapabilities(
  role: AssignableCustomerAccountRole,
  capabilities: AccountCapability[]
): AccountCapability[] {
  if (role !== "customer-account-admin") return capabilities
  const seen = new Set(capabilities)
  for (const capability of LOCKED_ACCOUNT_ADMIN_CAPABILITIES) {
    seen.add(capability)
  }
  return ACCOUNT_CAPABILITIES.filter((capability) => seen.has(capability))
}

export function resolveCapabilitiesForRole(
  role: CustomerAccountRole,
  overrides?: CompanyRoleCapabilityOverrides | null
): AccountCapability[] {
  const overrideRole = capabilityOverrideRole(role)
  const override = overrides?.[overrideRole]
  const capabilities = override
    ? sanitizeCapabilityList(override)
    : defaultCapabilitiesForRole(role)
  return withLockedAccountAdminCapabilities(overrideRole, capabilities)
}

export function hasCapability(
  role: CustomerAccountRole,
  capability: AccountCapability,
  overrides?: CompanyRoleCapabilityOverrides | null
): boolean {
  return resolveCapabilitiesForRole(role, overrides).includes(capability)
}

export function listCapabilities(
  role: CustomerAccountRole,
  overrides?: CompanyRoleCapabilityOverrides | null
): AccountCapability[] {
  return resolveCapabilitiesForRole(role, overrides)
}

/** Platform admins get every company capability while acting in the app. */
export function capabilitiesForAccountUser(input: {
  isPlatformAdmin: boolean
  role: CustomerAccountRole
  roleCapabilities?: CompanyRoleCapabilityOverrides | null
}): AccountCapability[] {
  if (input.isPlatformAdmin) return [...ACCOUNT_CAPABILITIES]
  return resolveCapabilitiesForRole(input.role, input.roleCapabilities)
}

export function accountUserHasCapability(input: {
  isPlatformAdmin: boolean
  role: CustomerAccountRole
  capability: AccountCapability
  roleCapabilities?: CompanyRoleCapabilityOverrides | null
}): boolean {
  return capabilitiesForAccountUser(input).includes(input.capability)
}

export function defaultCompanyRoleCapabilities(): Record<
  AssignableCustomerAccountRole,
  AccountCapability[]
> {
  return {
    "customer-account-admin": defaultCapabilitiesForRole("customer-account-admin"),
    estimator: defaultCapabilitiesForRole("estimator"),
    installer: defaultCapabilitiesForRole("installer")
  }
}

/**
 * Normalize a company override payload. Always returns all assignable roles so
 * saves replace the full matrix (missing roles fall back to defaults).
 */
export function normalizeCompanyRoleCapabilities(
  input: unknown
): Record<AssignableCustomerAccountRole, AccountCapability[]> {
  const source =
    input && typeof input === "object"
      ? (input as Record<string, unknown>)
      : {}

  const next = {} as Record<AssignableCustomerAccountRole, AccountCapability[]>
  for (const role of ASSIGNABLE_CUSTOMER_ACCOUNT_ROLES) {
    const capabilities = source[role] === undefined
      ? defaultCapabilitiesForRole(role)
      : sanitizeCapabilityList(source[role])
    next[role] = withLockedAccountAdminCapabilities(role, capabilities)
  }
  return next
}

export function readCompanyRoleCapabilities(
  value: unknown
): CompanyRoleCapabilityOverrides | undefined {
  if (!value || typeof value !== "object") return undefined
  const source = value as Record<string, unknown>
  const next: CompanyRoleCapabilityOverrides = {}
  let hasAny = false
  for (const role of ASSIGNABLE_CUSTOMER_ACCOUNT_ROLES) {
    if (source[role] === undefined) continue
    next[role] = withLockedAccountAdminCapabilities(
      role,
      sanitizeCapabilityList(source[role])
    )
    hasAny = true
  }
  return hasAny ? next : undefined
}

export type RoleCapabilityMatrixRow = {
  role: AssignableCustomerAccountRole
  label: string
  capabilities: AccountCapability[]
  defaults: AccountCapability[]
  locked: AccountCapability[]
}

export function buildRoleCapabilityMatrix(
  overrides?: CompanyRoleCapabilityOverrides | null
): RoleCapabilityMatrixRow[] {
  return ASSIGNABLE_CUSTOMER_ACCOUNT_ROLES.map((role) => ({
    role,
    label: CUSTOMER_ACCOUNT_ROLE_LABELS[role],
    capabilities: resolveCapabilitiesForRole(role, overrides),
    defaults: defaultCapabilitiesForRole(role),
    locked: role === "customer-account-admin"
      ? [...LOCKED_ACCOUNT_ADMIN_CAPABILITIES]
      : []
  }))
}
