<script setup lang="ts">
import type { AssignableCustomerAccountRole } from "~~/shared/accountPermissions"
import { PASSWORD_POLICY_DESCRIPTION } from "~~/shared/passwordPolicy"

const form = defineModel<{
  email: string
  name: string
  password: string
  title: string
  role: AssignableCustomerAccountRole
}>("form", { required: true })

defineProps<{
  roleOptions: { value: AssignableCustomerAccountRole, label: string, hint: string }[]
  isBusy: boolean
  status: string
}>()

const emit = defineEmits<{
  submit: []
}>()
</script>

<template>
  <section class="card team-invite">
    <div class="card-header">
      <div>
        <p class="eyebrow">Invite</p>
        <h2>Add team member</h2>
        <p class="muted team-invite-copy">
          Creates a login on your company account. Share the temporary password securely.
        </p>
      </div>
    </div>

    <form class="team-invite-form" @submit.prevent="emit('submit')">
      <label>
        <span>Email</span>
        <input v-model="form.email" class="input" type="email" autocomplete="off" required>
      </label>
      <label>
        <span>Full name</span>
        <input v-model="form.name" class="input" type="text" autocomplete="name">
      </label>
      <label>
        <span>Job title</span>
        <input v-model="form.title" class="input" type="text" placeholder="Optional">
      </label>
      <label>
        <span>Temporary password</span>
        <input
          v-model="form.password"
          class="input"
          type="password"
          autocomplete="new-password"
          required
          minlength="8"
        >
        <small class="muted">{{ PASSWORD_POLICY_DESCRIPTION }}</small>
      </label>

      <fieldset class="team-role-picker">
        <legend>Role</legend>
        <label
          v-for="option in roleOptions"
          :key="option.value"
          class="team-role-option"
          :class="{ 'is-selected': form.role === option.value }"
        >
          <input v-model="form.role" type="radio" :value="option.value">
          <span>
            <strong>{{ option.label }}</strong>
            <small class="muted">{{ option.hint }}</small>
          </span>
        </label>
      </fieldset>

      <div class="team-invite-actions">
        <button class="button" type="submit" :disabled="isBusy">
          {{ isBusy ? "Working..." : "Add to team" }}
        </button>
        <p v-if="status" class="muted team-status">{{ status }}</p>
      </div>
    </form>
  </section>
</template>

<style scoped>
.team-invite-copy {
  margin: 0.35rem 0 0;
  max-width: 36rem;
}

.team-invite-form {
  display: grid;
  gap: 0.9rem;
}

.team-invite-form label {
  display: grid;
  gap: 0.35rem;
}

.team-role-picker {
  border: 1px solid var(--sf-border);
  border-radius: 14px;
  display: grid;
  gap: 0.55rem;
  margin: 0;
  padding: 0.85rem;
}

.team-role-picker legend {
  font-size: 0.85rem;
  font-weight: 700;
  padding: 0 0.25rem;
}

.team-role-option {
  align-items: flex-start;
  background: var(--sf-surface-subtle);
  border: 1px solid transparent;
  border-radius: 12px;
  cursor: pointer;
  display: grid;
  gap: 0.65rem;
  grid-template-columns: auto 1fr;
  padding: 0.7rem 0.8rem;
}

.team-role-option.is-selected {
  background: var(--sf-section-blue);
  border-color: var(--sf-section-blue-border);
}

.team-role-option input {
  margin-top: 0.2rem;
}

.team-role-option span {
  display: grid;
  gap: 0.15rem;
}

.team-role-option small {
  line-height: 1.35;
}

.team-invite-actions {
  align-items: center;
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
}

.team-status {
  margin: 0;
}
</style>
