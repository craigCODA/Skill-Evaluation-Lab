<script setup lang="ts">
import type { RoofProbeWasteOption } from "~~/shared/roofMeasurement";
import type { RoofProbeReport } from "~~/shared/roofProbeReport";
import type { RoofMeasurement } from "~~/shared/types";

const { measurement, report } = defineProps<{
  measurement: RoofMeasurement;
  report: RoofProbeReport;
  wasteOptions: RoofProbeWasteOption[];
}>();

const wasteFactor = defineModel<number>("wasteFactor", { required: true });

const mapsUrl = computed(() => {
  const center = `${measurement.latitude},${measurement.longitude}`;
  const query = encodeURIComponent(measurement.address);
  return `https://www.google.com/maps/@?api=1&map_action=map&center=${center}&zoom=20&basemap=satellite&query=${query}`;
});

function formatPercent(value?: number): string {
  if (value === undefined) return "Not available";
  return `${Math.round(value * 100)}%`;
}
</script>

<template>
  <section class="roof-report-section roof-results-section">
    <div class="section-header">
      <div>
        <p class="section-eyebrow">ShingleScope results</p>
        <h2>Roof measurement summary</h2>
        <p>
          Review area, order squares, imagery source data, and measurement confidence.
        </p>
      </div>
      <div class="roof-header-actions">
        <a
          class="button secondary"
          :href="mapsUrl"
          target="_blank"
          rel="noopener noreferrer"
        >
          Open in Google Maps
        </a>
        <div class="roof-confidence">
          {{ formatPercent(measurement.confidence.overall) }}
          <span>confidence</span>
        </div>
      </div>
    </div>

    <RoofProbeStatsGrid :stats="report.stats" />

    <RoofWasteFactorControl
      v-model:waste-factor="wasteFactor"
      :is-suggested="report.isSuggestedWasteFactor"
      :suggested-waste-factor="report.suggestedWasteFactor"
      :waste-options="wasteOptions"
      :waste-percent="report.wastePercent"
    />

    <RoofProbeMetaGrid :items="report.metaItems" />
  </section>
</template>

<style scoped>
.roof-report-section {
  border: 1px solid;
  border-radius: 1.1rem;
  box-shadow: 0 10px 30px rgb(23 33 58 / 6%);
  display: grid;
  gap: 1rem;
  padding: 1rem;
}

.roof-results-section {
  background: var(--sf-section-blue);
  border-color: var(--sf-section-blue-border);
}

.section-header {
  align-items: center;
  display: grid;
  gap: 1rem;
  grid-template-columns: minmax(0, 1fr) auto;
}

.section-eyebrow {
  color: var(--sf-action);
  font-size: 0.72rem;
  font-weight: 900;
  letter-spacing: 0.08em;
  margin: 0 0 0.25rem;
  text-transform: uppercase;
}

.section-header h2 {
  margin: 0 0 0.3rem;
}

.section-header p {
  color: var(--sf-text-muted);
  margin: 0;
}

.roof-header-actions {
  align-items: center;
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  justify-content: flex-end;
}

.roof-confidence {
  background: var(--sf-action);
  border-radius: 999px;
  color: white;
  font-size: 1.4rem;
  font-weight: 900;
  padding: 0.75rem 1rem;
  text-align: center;
}

.roof-confidence span {
  display: block;
  font-size: 0.75rem;
  font-weight: 700;
  opacity: 0.9;
}

@media (max-width: 860px) {
  .section-header {
    grid-template-columns: 1fr;
  }

  .roof-header-actions {
    justify-content: flex-start;
  }
}
</style>
