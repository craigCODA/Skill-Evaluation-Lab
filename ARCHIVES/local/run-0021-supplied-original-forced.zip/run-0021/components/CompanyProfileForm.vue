<script setup lang="ts">
import type { CompanyProfile } from "~~/shared/types"
import { newCompanyContact, newCompanyLicense } from "~~/shared/company"

const draft = defineModel<CompanyProfile>({ required: true })

const { manageLocations = false } = defineProps<{
  manageLocations?: boolean
}>()

function addLicense() {
  draft.value.licenses.push(newCompanyLicense())
}

function removeLicense(id: string) {
  draft.value.licenses = draft.value.licenses.filter((license) => license.id !== id)
}

function addContact() {
  draft.value.contacts.push(newCompanyContact())
}

function removeContact(id: string) {
  draft.value.contacts = draft.value.contacts.filter((contact) => contact.id !== id)
}
</script>

<template>
  <section class="card">
    <h2>Company Details</h2>
    <div class="form-grid">
      <label class="field">
        <span>Company name</span>
        <input v-model="draft.companyName" class="input" type="text">
      </label>
      <label class="field">
        <span>Legal name</span>
        <input v-model="draft.legalName" class="input" type="text">
      </label>
      <label class="field">
        <span>Website</span>
        <input v-model="draft.website" class="input" type="text" placeholder="https://">
      </label>
      <label class="field">
        <span>Email</span>
        <input v-model="draft.email" class="input" type="email">
      </label>
      <label class="field">
        <span>Phone</span>
        <input v-model="draft.phone" class="input" type="tel">
      </label>
      <label class="field">
        <span>Office phone</span>
        <input v-model="draft.officePhone" class="input" type="tel">
      </label>
    </div>
  </section>

  <section class="card">
    <h2>Logo</h2>
    <div class="company-profile-logo-row">
      <BrandLogo
        :src="draft.logoUrl"
        alt="Company logo preview"
        size="md"
        fallback="none"
      />
      <label class="field company-profile-logo-field">
        <span>Logo image URL</span>
        <input v-model="draft.logoUrl" class="input" type="text" placeholder="/shinglefile-logo.jpg or https://...">
        <small class="muted">Paste a hosted image URL, or use the default path above. Shown in a circle on contracts and your dashboard.</small>
      </label>
    </div>
  </section>

  <CompanyLocationsSection
    v-if="manageLocations"
    v-model="draft.locations"
  />

  <section v-else class="card">
    <h2>Address</h2>
    <div class="form-grid">
      <label class="field">
        <span>Address line 1</span>
        <input v-model="draft.address1" class="input" type="text">
      </label>
      <label class="field">
        <span>Address line 2</span>
        <input v-model="draft.address2" class="input" type="text">
      </label>
      <label class="field">
        <span>City</span>
        <input v-model="draft.city" class="input" type="text">
      </label>
      <label class="field">
        <span>State</span>
        <input v-model="draft.state" class="input" type="text">
      </label>
      <label class="field">
        <span>ZIP</span>
        <input v-model="draft.zip" class="input" type="text">
      </label>
    </div>
  </section>

  <section class="card">
    <div class="section-head">
      <h2>State Licenses</h2>
      <button class="button secondary" type="button" @click="addLicense">+ Add license</button>
    </div>
    <p v-if="draft.licenses.length === 0" class="muted">No licenses added yet.</p>
    <div v-for="license in draft.licenses" :key="license.id" class="repeat-row">
      <label class="field">
        <span>State</span>
        <input v-model="license.state" class="input" type="text" placeholder="IA">
      </label>
      <label class="field grow">
        <span>License ID</span>
        <input v-model="license.licenseId" class="input" type="text">
      </label>
      <button class="button secondary" type="button" @click="removeLicense(license.id)">Remove</button>
    </div>
  </section>

  <section class="card">
    <div class="section-head">
      <h2>Contacts &amp; Owners</h2>
      <button class="button secondary" type="button" @click="addContact">+ Add contact</button>
    </div>
    <p v-if="draft.contacts.length === 0" class="muted">No contacts added yet.</p>
    <div v-for="contact in draft.contacts" :key="contact.id" class="repeat-row">
      <label class="field grow">
        <span>Name</span>
        <input v-model="contact.name" class="input" type="text">
      </label>
      <label class="field">
        <span>Role</span>
        <input v-model="contact.role" class="input" type="text" placeholder="Owner">
      </label>
      <label class="field grow">
        <span>Email</span>
        <input v-model="contact.email" class="input" type="email">
      </label>
      <label class="field">
        <span>Phone</span>
        <input v-model="contact.phone" class="input" type="tel">
      </label>
      <button class="button secondary" type="button" @click="removeContact(contact.id)">Remove</button>
    </div>
  </section>
</template>

<style scoped>
.form-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 1rem;
}

.section-head {
  align-items: center;
  display: flex;
  gap: 1rem;
  justify-content: space-between;
}

.repeat-row {
  align-items: flex-end;
  border-top: 1px solid var(--sf-border);
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  padding: 0.75rem 0;
}

.repeat-row .field {
  flex: 1 1 140px;
}

.repeat-row .field.grow {
  flex: 2 1 220px;
}

@media (max-width: 860px) {
  .repeat-row {
    align-items: stretch;
    flex-direction: column;
  }

  .repeat-row .button {
    width: 100%;
  }
}
</style>
