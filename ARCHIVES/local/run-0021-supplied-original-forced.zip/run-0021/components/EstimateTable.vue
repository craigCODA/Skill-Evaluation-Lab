<script setup lang="ts">
import type { EstimateListItem } from "~/composables/useEstimates"
import { estimateStatusStyle, sortEstimatesByRecent } from "~~/shared/estimateStatus"

const props = defineProps<{
  estimates: EstimateListItem[]
  embedded?: boolean
}>()

const emit = defineEmits<{
  removeDraft: [estimateId: string]
}>()

const { formatDate } = useFormatters()

const sortedEstimates = computed(() => sortEstimatesByRecent(props.estimates))

const presentStatuses = computed(() =>
  Array.from(new Set(sortedEstimates.value.map((estimate) => estimate.status)))
)

function statusClass(status: string) {
  return estimateStatusStyle(status).rowClass
}

function shingleScopeHref(estimate: EstimateListItem) {
  return estimate.address
    ? `/roof-probe?address=${encodeURIComponent(estimate.address)}`
    : "/roof-probe"
}
</script>

<template>
  <component :is="embedded ? 'div' : 'section'" :class="embedded ? 'estimate-table-embedded' : 'card'">
    <div v-if="sortedEstimates.length === 0" class="muted">No estimates saved yet.</div>
    <template v-else>
      <EstimateStatusLegend :present-statuses="presentStatuses" />

      <div class="estimate-card-grid">
        <article
          v-for="estimate in sortedEstimates"
          :key="estimate.id"
          class="estimate-list-card"
          :class="statusClass(estimate.status)"
        >
          <header class="estimate-list-card-head">
            <div>
              <NuxtLink class="estimate-list-card-title" :to="`/estimates/${estimate.id}`">
                {{ estimate.displayName }}
              </NuxtLink>
              <p class="estimate-list-card-id">{{ estimate.id.slice(0, 8) }}</p>
            </div>
            <StatusBadge :status="estimate.status" />
          </header>

          <dl class="estimate-card-details">
            <div>
              <dt>Address</dt>
              <dd>{{ estimate.address || "No address yet" }}</dd>
            </div>
            <div>
              <dt>Updated</dt>
              <dd>{{ formatDate(estimate.updatedAt) }}</dd>
            </div>
          </dl>

          <footer class="estimate-list-card-actions">
            <NuxtLink class="button" :to="`/estimates/${estimate.id}`">
              Open Estimate
            </NuxtLink>
            <NuxtLink class="button secondary" :to="shingleScopeHref(estimate)">
              ShingleScope
            </NuxtLink>
            <NuxtLink
              v-if="estimate.contractKind"
              class="button secondary"
              :to="`/estimates/${estimate.id}/contracts`"
            >
              {{ estimate.contractLabel }}
            </NuxtLink>
            <button
              v-if="estimate.status === 'draft'"
              class="button danger"
              type="button"
              @click="emit('removeDraft', estimate.id)"
            >
              Remove
            </button>
          </footer>
        </article>
      </div>
    </template>
  </component>
</template>
