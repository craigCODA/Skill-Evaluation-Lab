<script setup lang="ts">
import type { EstimateListItem } from "~/composables/useEstimates";

defineProps<{
  estimates: EstimateListItem[];
}>();

const emit = defineEmits<{
  create: [];
  removeDraft: [estimateId: string];
}>();
</script>

<template>
  <section class="estimate-list-section">
    <div class="estimate-list-header">
      <div>
        <p class="section-eyebrow">Estimate library</p>
        <h2>Customer jobs</h2>
        <p>
          Open active work, review generated contracts, or remove local drafts before they become saved jobs.
        </p>
      </div>
      <button class="button secondary" type="button" @click="emit('create')">
        New Estimate
      </button>
    </div>

    <div class="estimate-list-panel">
      <EstimateTable
        embedded
        :estimates="estimates"
        @remove-draft="emit('removeDraft', $event)"
      />
    </div>
  </section>
</template>

<style scoped>
.estimate-list-section {
  background: var(--sf-section-sand);
  border: 1px solid var(--sf-border-strong);
  border-radius: 1.1rem;
  box-shadow: 0 10px 30px rgb(23 33 58 / 6%);
  display: grid;
  gap: 1rem;
  padding: 1.25rem;
}

.estimate-list-header {
  align-items: center;
  display: grid;
  gap: 1rem;
  grid-template-columns: minmax(0, 1fr) auto;
}

.section-eyebrow {
  color: var(--sf-action);
  font-size: 0.72rem;
  font-weight: 900;
  letter-spacing: 0.08em;
  margin: 0 0 0.25rem;
  text-transform: uppercase;
}

.estimate-list-header h2 {
  margin: 0 0 0.3rem;
}

.estimate-list-header p {
  color: var(--sf-text-muted);
  margin: 0;
}

.estimate-list-panel {
  background: var(--sf-surface);
  border: 1px solid var(--sf-border);
  border-radius: 0.95rem;
  overflow: hidden;
  padding: 1rem;
}

@media (max-width: 860px) {
  .estimate-list-header {
    align-items: stretch;
    grid-template-columns: 1fr;
  }

  .estimate-list-header .button {
    justify-content: center;
  }
}

@media (max-width: 560px) {
  .estimate-list-section,
  .estimate-list-panel {
    padding: 0.85rem;
  }
}
</style>
