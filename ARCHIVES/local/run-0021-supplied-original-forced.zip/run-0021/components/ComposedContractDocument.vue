<script setup lang="ts">
import type { ComposedContract, ComposedContractModule } from "~~/shared/contracts/modules"
import type { ContractLine } from "~~/shared/contracts/types"

defineProps<{
  contract: ComposedContract
  variant: "unsigned" | "signed"
}>()

const { formatMoney } = useFormatters()

function headerValue(lines: ContractLine[], label: string) {
  return lines.find((line) => line.label === label)?.value?.trim() || ""
}

function hasStructuredValue(line: ContractLine) {
  return line.amount !== undefined || Boolean(line.value?.trim())
}

function isParagraphLine(line: ContractLine) {
  return !hasStructuredValue(line) && line.label.trim() !== ""
}

function moduleClass(module: ComposedContractModule) {
  return [
    "composed-module",
    `composed-module--${module.kind}`,
    module.pageRole === "page1-end" ? "is-page1-end" : "",
    module.pageRole === "page2" ? "is-page2" : "",
    module.pageRole === "prep-page" ? "is-prep-page" : "",
    module.pageRole === "notice-page" ? "is-notice-page" : "",
    module.pageRole === "signature" ? "is-signature" : "",
    module.pageRole === "appendix" ? "is-appendix" : "",
    module.section.kind === "pricing" ? "is-pricing" : ""
  ].filter(Boolean)
}

function visibleModules(modules: ComposedContractModule[]) {
  return modules.filter((module) => module.kind !== "letterhead" && module.kind !== "customer-header")
}

function showInitials(module: ComposedContractModule) {
  return module.pageRole !== "signature"
}
</script>

<template>
  <article class="composed-contract baker-sheet" :data-variant="variant">
    <header class="baker-letterhead">
      <div class="baker-brand">
        <img
          v-if="contract.meta.logoUrl"
          class="baker-logo"
          :src="contract.meta.logoUrl"
          alt=""
        >
        <div>
          <p class="baker-company">{{ contract.meta.companyName }}</p>
          <p class="baker-meta">{{ headerValue(contract.letterhead, "Office") }}</p>
          <p class="baker-meta">
            {{ headerValue(contract.letterhead, "Phone") }}
            <span v-if="contract.meta.license"> · {{ contract.meta.license }}</span>
          </p>
        </div>
      </div>
      <div class="baker-doc-title">
        <p class="baker-title">{{ contract.title.replace(" & Agreement", "") }}</p>
        <p class="baker-date">{{ contract.meta.documentDate }}</p>
        <p class="composed-badge no-print">{{ variant === "signed" ? "Signed copy" : "Unsigned draft" }}</p>
      </div>
    </header>

    <section
      v-if="contract.modules.some((module) => module.kind === 'customer-header')"
      class="baker-customer-grid"
    >
      <div
        v-for="line in (contract.modules.find((module) => module.kind === 'customer-header')?.section.lines ?? [])"
        :key="line.label"
        class="baker-field"
      >
        <span class="baker-field-label">{{ line.label }}</span>
        <span class="baker-field-value">{{ line.value || "—" }}</span>
      </div>
    </section>

    <section
      v-for="module in visibleModules(contract.modules)"
      :key="module.key"
      :class="moduleClass(module)"
    >
      <div class="composed-module-head">
        <h2>{{ module.title }}</h2>
        <p v-if="showInitials(module)" class="initials-box">
          Initials ________
        </p>
      </div>

      <div v-if="module.section.kind === 'signatures'" class="signature-block">
        <div
          v-for="(line, index) in module.section.lines"
          :key="`${module.key}-${index}`"
          class="signature-line"
        >
          <span class="signature-pad" />
          <span>{{ line.label }}</span>
        </div>
      </div>

      <ul v-else-if="module.section.kind === 'bullets'" class="composed-bullets">
        <li
          v-for="(line, index) in module.section.lines"
          :key="`${module.key}-${index}`"
        >
          {{ line.label }}
          <span v-if="line.value"> — {{ line.value }}</span>
        </li>
      </ul>

      <div v-else-if="module.kind === 'measurement-grid'" class="baker-measure-table">
        <div
          v-for="(line, index) in module.section.lines"
          :key="`${module.key}-${index}`"
          class="baker-measure-row"
        >
          <strong>{{ line.label }}</strong>
          <span>{{ line.value || "—" }}</span>
        </div>
      </div>

      <div v-else class="composed-lines" :class="{
        'baker-fineprint': module.kind === 'payment-terms' || module.kind === 'terms-conditions',
        'baker-notice': module.kind === 'right-to-cancel' || module.kind === 'insurance-clause',
        'baker-narrative': module.kind === 'roof-specifications'
      }">
        <p
          v-for="(line, index) in module.section.lines"
          :key="`${module.key}-${index}`"
          :class="{ 'is-paragraph': isParagraphLine(line), 'is-row': hasStructuredValue(line) }"
        >
          <template v-if="hasStructuredValue(line)">
            <strong>{{ line.label }}</strong>
            <span v-if="line.value">{{ line.value }}</span>
            <span v-if="line.amount !== undefined" class="baker-amount">{{ formatMoney(line.amount) }}</span>
          </template>
          <template v-else>
            {{ line.label }}
          </template>
        </p>
      </div>
    </section>

    <footer class="composed-footer muted">
      Generated {{ new Date(contract.generatedAt).toLocaleString() }}
      <span v-if="contract.total !== undefined">
        · Total {{ formatMoney(contract.total) }}
      </span>
    </footer>
  </article>
</template>
