<script setup lang="ts">
import type { RoofingEstimateTotals } from "~~/shared/calculator/calculateEstimate"

defineProps<{
  totals: RoofingEstimateTotals | null
}>()

const { formatMoney } = useFormatters()
</script>

<template>
  <section class="card">
    <div v-if="totals" class="summary-list">
      <div class="summary-row">
        <span>Total squares</span>
        <strong>{{ totals.totalSquares.toFixed(2) }}</strong>
      </div>
      <div class="summary-row">
        <span>Roof areas</span>
        <strong>{{ formatMoney(totals.areaCosts.reduce((sum, area) => sum + area.total, 0)) }}</strong>
      </div>
      <div class="summary-row">
        <span>Ridge</span>
        <strong>{{ formatMoney(totals.ridge.total) }}</strong>
      </div>
      <div class="summary-row">
        <span>Warranty</span>
        <strong>{{ formatMoney(totals.warranty.cost) }}</strong>
      </div>
      <div class="summary-row">
        <span>Step flashing</span>
        <strong>{{ formatMoney(totals.stepFlash.cost) }}</strong>
      </div>
      <div class="summary-row">
        <span>Accessories</span>
        <strong>{{ formatMoney(totals.accessories.total) }}</strong>
      </div>
      <div class="summary-row total">
        <span>Total</span>
        <strong>{{ formatMoney(totals.grandTotal) }}</strong>
      </div>
    </div>
    <p v-else class="muted">Add a roofing scope to calculate this estimate.</p>
  </section>
</template>
