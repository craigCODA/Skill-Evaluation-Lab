<script setup lang="ts">
import type { Catalog } from "~~/shared/pricebook/types"
import type { RoofingEstimateTotals } from "~~/shared/calculator/calculateEstimate"
import type { RoofingScope } from "~~/shared/types"
import { newRoofArea } from "~~/shared/job"
import { newId } from "~~/shared/ids"

const roofing = defineModel<RoofingScope>({ required: true })

const { catalog, totals } = defineProps<{
  catalog: Catalog
  totals: RoofingEstimateTotals | null
}>()

const activeAreaIndex = ref(0)
const activeArea = computed(() => roofing.value.areas[activeAreaIndex.value])
const activeAreaCost = computed(() => totals?.areaCosts[activeAreaIndex.value] ?? null)
const selectedShingle = computed(() =>
  catalog.shingles.find((shingle) => shingle.id === roofing.value.shingle.productId)
)

function addArea() {
  roofing.value.areas.push({
    ...newRoofArea(),
    label: `Plane ${roofing.value.areas.length + 1}`
  })
  activeAreaIndex.value = roofing.value.areas.length - 1
}

function removeActiveArea() {
  if (roofing.value.areas.length <= 1) return
  roofing.value.areas.splice(activeAreaIndex.value, 1)
  activeAreaIndex.value = Math.max(0, activeAreaIndex.value - 1)
}

function addAccessory() {
  const key = catalog.accessoryRates[0]?.key
  if (!key) return
  roofing.value.accessories.push({ id: newId(), key, count: 1 })
}

function removeAccessory(index: number) {
  roofing.value.accessories.splice(index, 1)
}

function addSkylight() {
  const option = catalog.skylightOptions[0]?.key
  if (!option) return
  roofing.value.skylights.push({ id: newId(), option, count: 1 })
}

function removeSkylight(index: number) {
  roofing.value.skylights.splice(index, 1)
}

function formatMoney(value: number) {
  return value.toLocaleString(undefined, { style: "currency", currency: "USD" })
}
</script>

<template>
  <RoofProductSection v-model="roofing" :catalog="catalog" />

  <section class="card v2-card v2-section-planes">
    <div class="v2-area-intro">
      <h2>
        Roof planes
        <EstimateHelp
          label="Roof planes"
          text="Each tab is one facet of the roof. Enter size from your measurement report (squares) or measure on site. Eave, rake, and valley edges are linear feet along those edges — not plane width."
        />
      </h2>
      <p class="v2-note">
        Match your EagleView or field sketch: one plane per tab. Size drives squares; edges drive drip edge and ice &amp; water.
      </p>
    </div>
    <div class="tab-list">
      <button
        v-for="(area, index) in roofing.areas"
        :key="area.id"
        class="tab-button"
        :class="{ active: index === activeAreaIndex }"
        type="button"
        @click="activeAreaIndex = index"
      >
        {{ area.label || `Plane ${index + 1}` }}
      </button>
      <button class="tab-button v2-area-tab-add" type="button" @click="addArea">+ Add plane</button>
    </div>

    <template v-if="activeArea">
      <div class="v2-plane-panel">
        <div class="card-header v2-area-card-header">
        <div class="v2-area-heading">
          <h2>{{ activeArea.label || `Plane ${activeAreaIndex + 1}` }}</h2>
          <p>{{ activeArea.description || activeArea.location }}</p>
        </div>
        <button
          class="button danger"
          type="button"
          :disabled="roofing.areas.length <= 1"
          @click="removeActiveArea"
        >
          Remove plane
        </button>
      </div>

      <div class="v2-area-sections">
        <RoofPlaneIdentifySection v-model="activeArea" />
        <RoofPlaneSizeSection v-model="activeArea" />
        <RoofPlaneConditionsSection v-model="activeArea" :catalog="catalog" />
        <RoofPlaneEdgesSection v-model="activeArea" />

        <div class="v2-area-section">
          <h3 class="v2-subhead">Underlayment</h3>
          <div class="form-grid">
            <label class="field">
              <span>Underlayment <EstimateHelp label="Underlayment" /></span>
              <select v-model="activeArea.underlayment" class="input">
                <option value="">None</option>
                <option v-for="option in catalog.underlayments" :key="option.key" :value="option.key">
                  {{ option.key }}
                </option>
              </select>
            </label>
          </div>
          <h4 class="v2-field-group-title">Ice &amp; water shield</h4>
          <div class="form-grid">
            <label class="field">
              <span>Coverage <EstimateHelp label="Ice & water" /></span>
              <select v-model="activeArea.iceWaterOption" class="input">
                <option v-for="option in catalog.iceWaterOptions" :key="option.key" :value="option.key">
                  {{ option.key }}
                </option>
              </select>
            </label>
            <label class="field">
              <span>Overhang <EstimateHelp label="Overhang" /></span>
              <select v-model="activeArea.iceWaterOverhang" class="input">
                <option v-for="option in catalog.iceWaterOverhangs" :key="option.key" :value="option.key">
                  {{ option.key }}
                </option>
              </select>
            </label>
          </div>
        </div>

        <div class="v2-area-section v2-section-pricing">
          <h3 class="v2-subhead">Plane pricing</h3>
          <dl class="v2-breakdown">
            <div class="v2-breakdown-row"><dt>Surface sq ft</dt><dd>{{ activeAreaCost?.install.areaSqft.toFixed(0) ?? "0" }}</dd></div>
            <div class="v2-breakdown-row"><dt>Squares with waste</dt><dd>{{ activeAreaCost?.install.squares.toFixed(2) ?? "0.00" }} sq</dd></div>
            <div class="v2-breakdown-row"><dt>Tearoff + redeck</dt><dd>{{ formatMoney(activeAreaCost?.install.tearoffAndRedeckCost ?? 0) }}</dd></div>
            <div class="v2-breakdown-row"><dt>Labor + material</dt><dd>{{ formatMoney(activeAreaCost?.install.laborAndMaterialCost ?? 0) }}</dd></div>
            <div class="v2-breakdown-row"><dt>Plane subtotal</dt><dd>{{ formatMoney(activeAreaCost?.total ?? 0) }}</dd></div>
            <div class="v2-breakdown-row"><dt>Product</dt><dd>{{ selectedShingle?.variety ?? "—" }}</dd></div>
          </dl>
        </div>
      </div>
      </div>
    </template>
  </section>

  <RoofJobTotalsSection v-model="roofing" />

  <section class="card v2-card v2-section-addon">
    <h2>Drip edge</h2>
    <p class="v2-note">Style per plane; linear feet are on each plane's Edges section.</p>
    <div v-if="activeArea" class="form-grid">
      <label class="field">
        <span>Eave style <EstimateHelp label="Eave drip style" /></span>
        <select v-model="activeArea.eaveDripStyle" class="input">
          <option value="">None</option>
          <option v-for="style in catalog.dripEdgeStyles" :key="style.key" :value="style.key">
            {{ style.key }}
          </option>
        </select>
      </label>
      <label class="field">
        <span>Rake style <EstimateHelp label="Rake drip style" /></span>
        <select v-model="activeArea.rakeDripStyle" class="input">
          <option value="">None</option>
          <option v-for="style in catalog.dripEdgeStyles" :key="style.key" :value="style.key">
            {{ style.key }}
          </option>
        </select>
      </label>
    </div>
    <dl v-if="activeAreaCost" class="v2-breakdown">
      <div class="v2-breakdown-row"><dt>Eave drip</dt><dd>{{ formatMoney(activeAreaCost.drip.eaveCost) }}</dd></div>
      <div class="v2-breakdown-row"><dt>Rake drip</dt><dd>{{ formatMoney(activeAreaCost.drip.rakeCost) }}</dd></div>
      <div class="v2-breakdown-row"><dt>Drip edge total</dt><dd>{{ formatMoney(activeAreaCost.drip.total) }}</dd></div>
    </dl>
  </section>

  <div id="roofing-addons" class="v2-anchor" />

  <section class="card v2-card v2-section-addon">
    <h2>Ridge vent</h2>
    <div class="form-grid">
      <label class="field">
        <span>Ridge vent (linear ft) <EstimateHelp label="Ridge vent LF" /></span>
        <input v-model.number="roofing.ridgeVentLf" class="input" type="number" min="0">
      </label>
      <label class="field">
        <span>Cut-in ridge vent (linear ft) <EstimateHelp label="Cut-in ridge vent LF" /></span>
        <input v-model.number="roofing.cutInRidgeVentLf" class="input" type="number" min="0">
      </label>
    </div>
    <dl v-if="totals" class="v2-breakdown">
      <div class="v2-breakdown-row"><dt>Ridge vent @ {{ formatMoney(totals.ridge.ridgeVentPricePerFoot) }}/ft</dt><dd>{{ formatMoney(totals.ridge.ridgeVentCost) }}</dd></div>
      <div class="v2-breakdown-row"><dt>Cut-in @ {{ formatMoney(totals.ridge.cutInRidgeVentPricePerFoot) }}/ft</dt><dd>{{ formatMoney(totals.ridge.cutInRidgeVentCost) }}</dd></div>
      <div class="v2-breakdown-row"><dt>Ridge vent total</dt><dd>{{ formatMoney(totals.ridge.total) }}</dd></div>
    </dl>
  </section>

  <section class="card v2-card v2-section-addon">
    <h2>Step flashing</h2>
    <label class="field">
      <span>Step flashing (linear ft) <EstimateHelp label="Step flashing LF" /></span>
      <input v-model.number="roofing.stepFlashingLf" class="input" type="number" min="0">
    </label>
    <dl v-if="totals" class="v2-breakdown">
      <div class="v2-breakdown-row"><dt>Step flashing</dt><dd>{{ formatMoney(totals.stepFlash.cost) }}</dd></div>
    </dl>
  </section>

  <section class="card v2-card v2-section-addon">
    <h2>Tear-down chimney</h2>
    <label class="field">
      <span>Removal <EstimateHelp label="Chimney removal" /></span>
      <select v-model="roofing.chimneyRemoval" class="input">
        <option v-for="option in catalog.chimneyRemovalOptions" :key="option.key" :value="option.key">
          {{ option.key }} @ {{ formatMoney(option.price) }}
        </option>
      </select>
    </label>
    <dl v-if="totals" class="v2-breakdown">
      <div class="v2-breakdown-row"><dt>{{ roofing.chimneyRemoval }}</dt><dd>{{ formatMoney(totals.chimney.cost) }}</dd></div>
    </dl>
  </section>

  <section class="card v2-card v2-section-addon">
    <h2>Chimney kit</h2>
    <label class="field">
      <span>Kit <EstimateHelp label="Chimney kit" /></span>
      <select v-model="roofing.chimneyKit" class="input">
        <option v-for="option in catalog.chimneyKitOptions" :key="option.key" :value="option.key">
          {{ option.key }} @ {{ formatMoney(option.price) }}
        </option>
      </select>
    </label>
    <dl v-if="totals" class="v2-breakdown">
      <div class="v2-breakdown-row"><dt>{{ roofing.chimneyKit }}</dt><dd>{{ formatMoney(totals.chimneyKit.cost) }}</dd></div>
    </dl>
  </section>

  <section class="card v2-card v2-section-addon">
    <h2>Satellite dish</h2>
    <label class="field">
      <span>Satellite <EstimateHelp label="Satellite" /></span>
      <select v-model="roofing.satellite" class="input">
        <option v-for="option in catalog.satelliteOptions" :key="option.key" :value="option.key">
          {{ option.key.trim() || option.key }} @ {{ formatMoney(option.price) }}
        </option>
      </select>
    </label>
    <dl v-if="totals" class="v2-breakdown">
      <div class="v2-breakdown-row"><dt>{{ roofing.satellite }}</dt><dd>{{ formatMoney(totals.satellite.cost) }}</dd></div>
    </dl>
  </section>

  <section class="card v2-card v2-section-addon">
    <h2>Antenna</h2>
    <label class="field">
      <span>Antenna <EstimateHelp label="Antenna" /></span>
      <select v-model="roofing.antenna" class="input">
        <option v-for="option in catalog.antennaOptions" :key="option.key" :value="option.key">
          {{ option.key.trim() || option.key }} @ {{ formatMoney(option.price) }}
        </option>
      </select>
    </label>
    <dl v-if="totals" class="v2-breakdown">
      <div class="v2-breakdown-row"><dt>{{ roofing.antenna }}</dt><dd>{{ formatMoney(totals.antenna.cost) }}</dd></div>
    </dl>
  </section>

  <section class="card v2-card v2-section-addon">
    <h2>Lightning rods</h2>
    <label class="field">
      <span>Lightning rods <EstimateHelp label="Lightning rods" /></span>
      <select v-model="roofing.lightningRods" class="input">
        <option v-for="option in catalog.lightningRodOptions" :key="option.key" :value="option.key">
          {{ option.key }} @ {{ formatMoney(option.price) }}
        </option>
      </select>
    </label>
    <dl v-if="totals" class="v2-breakdown">
      <div class="v2-breakdown-row"><dt>{{ roofing.lightningRods }}</dt><dd>{{ formatMoney(totals.lightning.cost) }}</dd></div>
    </dl>
  </section>

  <section class="card v2-card v2-section-addon">
    <div class="card-header">
      <h2>Skylights</h2>
      <button class="button secondary" type="button" @click="addSkylight">+ Add skylight</button>
    </div>
    <p v-if="roofing.skylights.length === 0" class="v2-muted">No skylights on this job.</p>
    <div v-for="(skylight, index) in roofing.skylights" :key="skylight.id" class="form-grid line-item">
      <label class="field">
        <span>Type <EstimateHelp label="Type" /></span>
        <select v-model="skylight.option" class="input">
          <option v-for="option in catalog.skylightOptions" :key="option.key" :value="option.key">
            {{ option.key }} @ {{ formatMoney(option.price) }} ea
          </option>
        </select>
      </label>
      <label class="field">
        <span>Count <EstimateHelp label="Count" /></span>
        <input v-model.number="skylight.count" class="input" type="number" min="0">
      </label>
      <div class="field line-item-actions">
        <span>&nbsp;</span>
        <button class="button danger" type="button" @click="removeSkylight(index)">Remove</button>
      </div>
    </div>
    <dl v-if="totals && roofing.skylights.length > 0" class="v2-breakdown">
      <div v-for="line in totals.skylights.lines" :key="line.id" class="v2-breakdown-row">
        <dt>{{ line.option }} x {{ line.count }}</dt>
        <dd>{{ formatMoney(line.cost) }}</dd>
      </div>
      <div class="v2-breakdown-row"><dt>Skylights total</dt><dd>{{ formatMoney(totals.skylights.total) }}</dd></div>
    </dl>
  </section>

  <section class="card v2-card v2-section-addon">
    <div class="card-header">
      <h2>Accessories</h2>
      <button class="button secondary" type="button" @click="addAccessory">+ Add accessory</button>
    </div>
    <p v-if="roofing.accessories.length === 0" class="v2-muted">No accessories on this job.</p>
    <div v-for="(accessory, index) in roofing.accessories" :key="accessory.id" class="form-grid line-item">
      <label class="field">
        <span>Accessory <EstimateHelp label="Accessory" /></span>
        <select v-model="accessory.key" class="input">
          <option v-for="rate in catalog.accessoryRates" :key="rate.key" :value="rate.key">
            {{ rate.label }} ({{ formatMoney(rate.pricePerUnit) }} ea)
          </option>
        </select>
      </label>
      <label class="field">
        <span>Count <EstimateHelp label="Count" /></span>
        <input v-model.number="accessory.count" class="input" type="number" min="0">
      </label>
      <div class="field line-item-actions">
        <span>&nbsp;</span>
        <button class="button danger" type="button" @click="removeAccessory(index)">Remove</button>
      </div>
    </div>
    <dl v-if="totals" class="v2-breakdown">
      <div v-for="line in totals.accessories.lines" :key="line.id" class="v2-breakdown-row">
        <dt>{{ line.label }} x {{ line.count }}</dt>
        <dd>{{ formatMoney(line.cost) }}</dd>
      </div>
      <div class="v2-breakdown-row"><dt>Accessories total</dt><dd>{{ formatMoney(totals.accessories.total) }}</dd></div>
    </dl>
  </section>

  <section class="card v2-card v2-section-addon">
    <h2>Gutter removal / work-around</h2>
    <div class="form-grid">
      <label class="field">
        <span>Work around gutters <EstimateHelp label="Gutter workaround" /></span>
        <select v-model="roofing.workAroundGutters" class="input">
          <option value="No">No</option>
          <option value="Yes">Yes</option>
        </select>
      </label>
      <label class="field">
        <span>Linear ft <EstimateHelp label="Gutter removal LF" /></span>
        <input v-model.number="roofing.gutterRemovalLf" class="input" type="number" min="0">
      </label>
    </div>
    <dl v-if="totals" class="v2-breakdown">
      <div class="v2-breakdown-row"><dt>{{ roofing.gutterRemovalLf }} ft @ {{ formatMoney(totals.gutterRemoval.pricePerFoot) }}/ft</dt><dd>{{ formatMoney(totals.gutterRemoval.cost) }}</dd></div>
    </dl>
  </section>

  <section class="card v2-card v2-section-addon">
    <h2>Low-slope roofing</h2>
    <label class="field">
      <span>Style <EstimateHelp label="Low slope" /></span>
      <select v-model="roofing.lowSlope" class="input">
        <option v-for="option in catalog.lowSlopeOptions" :key="option.key" :value="option.key">
          {{ option.key.trim() || option.key }} @ {{ formatMoney(option.pricePerSquare) }}/sq
        </option>
      </select>
    </label>
    <dl v-if="totals" class="v2-breakdown">
      <div class="v2-breakdown-row"><dt>{{ totals.totalSquares.toFixed(2) }} sq @ {{ formatMoney(totals.lowSlope.pricePerSquare) }}/sq</dt><dd>{{ formatMoney(totals.lowSlope.cost) }}</dd></div>
    </dl>
  </section>

  <section class="card v2-card v2-section-addon">
    <h2>Valley metal</h2>
    <p class="v2-note">Computed for visibility only; not added to the customer total.</p>
    <div class="form-grid">
      <label class="field">
        <span>Valley style <EstimateHelp label="Valley style" /></span>
        <select v-model="roofing.valleys.style" class="input">
          <option value="closed">Closed valley</option>
          <option value="open">Open valley</option>
        </select>
      </label>
      <label class="field">
        <span>Open valley (linear ft) <EstimateHelp label="Open valley LF" /></span>
        <input v-model.number="roofing.valleys.openLf" class="input" type="number" min="0">
      </label>
      <label class="field">
        <span>Closed valley (linear ft) <EstimateHelp label="Closed valley LF" /></span>
        <input v-model.number="roofing.valleys.closedLf" class="input" type="number" min="0">
      </label>
    </div>
    <dl v-if="totals" class="v2-breakdown">
      <div class="v2-breakdown-row">
        <dt>{{ totals.valleyMetal.billableLf }} ft @ {{ formatMoney(totals.valleyMetal.pricePerFoot) }}/ft (not billed)</dt>
        <dd>{{ formatMoney(totals.valleyMetal.cost) }}</dd>
      </div>
    </dl>
  </section>
</template>
