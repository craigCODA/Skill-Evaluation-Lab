<script setup lang="ts">
import { getOptionByFieldLabel, optionHelpText } from "~~/shared/options"

const { label, text } = defineProps<{
  label: string
  text?: string
}>()

const modalOpen = ref(false)
const isNarrow = useMediaQuery("(max-width: 860px)")
const isCoarsePointer = useMediaQuery("(pointer: coarse)")
const useModal = computed(() => isNarrow.value || isCoarsePointer.value)

const fieldHelp: Record<string, string> = {
  "Estimate type":
    "Choose Roof Proposal or Temporary Repair. This controls which questions and contract document appear for this estimate.",
  "Company Contact": "Salesman or Estimator Name.",
  "Company name": "Customer company name, if applicable.",
  "First name": "First name of the customer.",
  "Last name": "Last name of the customer.",
  Phone: "Customer phone number.",
  Email: "Customer email address.",
  Address: "Street address for the job site.",
  "Address 2": "Apartment, suite, or second address line (optional).",
  City: "City for the job site.",
  State:
    "State for the job site. Also controls which contractor license appears on generated documents.",
  Zip: "ZIP code for the job site.",
  "Insurance company":
    "Homeowner's insurance carrier. Printed on the Insurance Approval section of the roof proposal.",
  "Claim number":
    "Insurance claim number for this job. Printed on the roof proposal contract.",
  "Insurance contact":
    "Adjuster or insurance representative name and phone. Printed on the roof proposal contract.",
  "Product Type":
    "Asphalt Shingle shows asphalt products; Metal shows steel roof products.",
  Manufacturer: "Filters the product list to the selected manufacturer.",
  "Product Style":
    "The shingle or metal product used for pricing. Labor and material cost is based on this price per square.",
  Color: "Shingle or metal color shown on the proposal.",
  Fastener: "Optional fastener type saved with the roof scope.",
  "Ridge LF":
    "Total ridge length for the whole job, in linear feet. Used for material take-off.",
  "Ridge Type": "Ridge cap style for asphalt roofs (standard or high hip).",
  "Starter Type": "Starter strip type for asphalt roofs.",
  "Hip LF": "Total hip length for the whole job, in linear feet.",
  Count: "How many of this item are on the job.",
  Permit: "Permit fee added to the customer grand total.",
  Extras: "Extra charge added to the customer grand total.",
  "Extras description": "Description shown on the proposal for the extra charge."
}

const helpText = computed(() => {
  if (text) return text
  const option = getOptionByFieldLabel(label)
  if (option) return optionHelpText(option)
  return fieldHelp[label]
})

function closeModal() {
  modalOpen.value = false
}

function openModal() {
  modalOpen.value = true
}

function onTriggerClick(event: MouseEvent) {
  if (!useModal.value) return
  event.preventDefault()
  event.stopPropagation()
  modalOpen.value = !modalOpen.value
}

function onOutsideClick(event: MouseEvent) {
  const target = event.target
  if (target instanceof Element && target.closest(".estimate-help")) return
  closeModal()
}

function onKeydown(event: KeyboardEvent) {
  if (event.key === "Escape") closeModal()
}

watch(modalOpen, (open) => {
  if (!import.meta.client) return
  document.body.style.overflow = open ? "hidden" : ""
  if (open) {
    window.addEventListener("keydown", onKeydown)
    requestAnimationFrame(() => {
      document.addEventListener("click", onOutsideClick)
    })
  } else {
    window.removeEventListener("keydown", onKeydown)
    document.removeEventListener("click", onOutsideClick)
  }
})

watch(useModal, (modal) => {
  if (!modal) closeModal()
})

onBeforeUnmount(() => {
  if (!import.meta.client) return
  document.body.style.overflow = ""
  window.removeEventListener("keydown", onKeydown)
  document.removeEventListener("click", onOutsideClick)
})
</script>

<template>
  <span
    v-if="helpText"
    class="estimate-help"
    :aria-label="`${label}: ${helpText}`"
    :tabindex="useModal ? 0 : -1"
    role="button"
    @click="onTriggerClick"
    @keydown.enter.prevent="useModal && (modalOpen ? closeModal() : openModal())"
    @keydown.space.prevent="useModal && (modalOpen ? closeModal() : openModal())"
  >
    ?
    <span v-if="!useModal" class="estimate-help__popover" role="tooltip">
      <span class="estimate-help-content__title">{{ label }}</span>
      <span class="estimate-help-content__text">{{ helpText }}</span>
    </span>
    <Teleport v-if="useModal && modalOpen" to="body">
      <div class="estimate-help-layer" role="dialog" :aria-label="label">
        <button
          type="button"
          class="estimate-help-layer__backdrop"
          aria-label="Close help"
          @click="closeModal"
        />
        <div class="estimate-help-layer__panel">
          <span class="estimate-help-content__title">{{ label }}</span>
          <span class="estimate-help-content__text">{{ helpText }}</span>
          <button type="button" class="estimate-help-layer__close" @click="closeModal">
            Close
          </button>
        </div>
      </div>
    </Teleport>
  </span>
</template>
