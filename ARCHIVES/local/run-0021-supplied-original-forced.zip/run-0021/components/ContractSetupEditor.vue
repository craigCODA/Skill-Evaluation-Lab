<script setup lang="ts">
import type {
  ContractModuleContent,
  ContractRecipeKind,
  ContractRecipeSlot
} from "~~/shared/contracts/modules"

const recipes = defineModel<Record<ContractRecipeKind, ContractRecipeSlot[]>>("recipes", {
  required: true
})
const enabledRecipes = defineModel<Record<ContractRecipeKind, boolean>>("enabledRecipes", {
  required: true
})
const modules = defineModel<ContractModuleContent[]>("modules", { required: true })
const activeRecipe = defineModel<ContractRecipeKind>("activeRecipe", { required: true })

defineProps<{
  catalog: {
    key: string
    kind: string
    label: string
    description: string
    editable: boolean
    recipes: ContractRecipeKind[]
  }[]
  recipeOptions: { kind: ContractRecipeKind, label: string }[]
  stateOptions: { code: string, name: string }[]
  selectedState: string
  isBusy: boolean
  status: string
}>()

const emit = defineEmits<{
  "update:selectedState": [value: string]
  save: []
  reset: []
}>()

function slotFor(key: string) {
  return recipes.value[activeRecipe.value]?.find((slot) => slot.key === key)
}

function moduleFor(key: string) {
  return modules.value.find((module) => module.key === key)
}

function toggleEnabled(key: string) {
  const slot = slotFor(key)
  if (!slot || slot.required) return
  recipes.value = {
    ...recipes.value,
    [activeRecipe.value]: (recipes.value[activeRecipe.value] ?? []).map((item) =>
      item.key === key ? { ...item, enabled: !item.enabled } : item
    )
  }
}

function toggleRecipe(kind: ContractRecipeKind) {
  if (kind === "roofing") return
  enabledRecipes.value = {
    ...enabledRecipes.value,
    [kind]: !enabledRecipes.value[kind]
  }
}

function bodyFor(key: string, state: string) {
  const module = moduleFor(key)
  if (!module) return ""
  return module.bodyByState[state] ?? module.bodyByState.DEFAULT ?? ""
}

function updateBody(key: string, state: string, value: string) {
  modules.value = modules.value.map((module) => {
    if (module.key !== key) return module
    return {
      ...module,
      bodyByState: {
        ...module.bodyByState,
        [state]: value
      }
    }
  })
}
</script>

<template>
  <div class="contract-setup-editor">
    <section class="card">
      <div class="card-header">
        <div>
          <p class="eyebrow">Trades</p>
          <h2>Active contract recipes</h2>
          <p class="muted">Roofing is always available. Enable gutters and siding when your company sells those contracts.</p>
        </div>
      </div>
      <div class="recipe-kind-toggles">
        <label
          v-for="option in recipeOptions"
          :key="option.kind"
          class="recipe-kind-toggle"
        >
          <input
            type="checkbox"
            :checked="option.kind === 'roofing' || enabledRecipes[option.kind]"
            :disabled="isBusy || option.kind === 'roofing'"
            @change="toggleRecipe(option.kind)"
          >
          <span>{{ option.label }}</span>
        </label>
      </div>
    </section>

    <section class="card">
      <div class="card-header contract-copy-header">
        <div>
          <p class="eyebrow">Recipe</p>
          <h2>{{ recipeOptions.find((item) => item.kind === activeRecipe)?.label }} modules</h2>
          <p class="muted">Required modules always print. Optional modules can be turned off for this recipe.</p>
        </div>
        <div class="recipe-tabs">
          <button
            v-for="option in recipeOptions"
            :key="option.kind"
            class="button"
            type="button"
            :class="{ secondary: activeRecipe !== option.kind }"
            :disabled="option.kind !== 'roofing' && !enabledRecipes[option.kind]"
            @click="activeRecipe = option.kind"
          >
            {{ option.label }}
          </button>
        </div>
      </div>

      <ul class="recipe-list">
        <li
          v-for="entry in catalog.filter((item) => item.recipes.includes(activeRecipe))"
          :key="entry.key"
          class="recipe-row"
        >
          <label class="recipe-toggle">
            <input
              type="checkbox"
              :checked="slotFor(entry.key)?.required || slotFor(entry.key)?.enabled"
              :disabled="isBusy || slotFor(entry.key)?.required"
              @change="toggleEnabled(entry.key)"
            >
            <span>
              <strong>{{ entry.label }}</strong>
              <small class="muted">{{ entry.description }}</small>
              <small v-if="slotFor(entry.key)?.required" class="recipe-required">Required</small>
            </span>
          </label>
        </li>
      </ul>
    </section>

    <section class="card">
      <div class="card-header contract-copy-header">
        <div>
          <p class="eyebrow">Copy</p>
          <h2>Editable module text</h2>
          <p class="muted">Shared wording is reused across recipes. DEFAULT is used when a state has no override.</p>
        </div>
        <label class="state-picker">
          <span>Editing state</span>
          <select
            class="input"
            :value="selectedState"
            @change="emit('update:selectedState', ($event.target as HTMLSelectElement).value)"
          >
            <option value="DEFAULT">DEFAULT (fallback)</option>
            <option
              v-for="state in stateOptions"
              :key="state.code"
              :value="state.code"
            >
              {{ state.name }} ({{ state.code }})
            </option>
          </select>
        </label>
      </div>

      <div
        v-for="entry in catalog.filter((item) => item.editable)"
        :key="entry.key"
        class="copy-block"
      >
        <h3>{{ entry.label }}</h3>
        <p class="muted">{{ entry.description }}</p>
        <textarea
          class="input copy-textarea"
          rows="8"
          :disabled="isBusy"
          :value="bodyFor(entry.key, selectedState)"
          @input="updateBody(entry.key, selectedState, ($event.target as HTMLTextAreaElement).value)"
        />
      </div>
    </section>

    <div class="contract-setup-actions">
      <button class="button" type="button" :disabled="isBusy" @click="emit('save')">
        {{ isBusy ? "Saving..." : "Save contract setup" }}
      </button>
      <button class="button secondary" type="button" :disabled="isBusy" @click="emit('reset')">
        Reset to defaults
      </button>
      <p v-if="status" class="muted">{{ status }}</p>
    </div>
  </div>
</template>

<style scoped>
.contract-setup-editor {
  display: grid;
  gap: 1.25rem;
}

.recipe-kind-toggles,
.recipe-tabs {
  display: flex;
  flex-wrap: wrap;
  gap: 0.65rem;
}

.recipe-kind-toggle {
  align-items: center;
  border: 1px solid var(--sf-border);
  border-radius: 999px;
  display: inline-flex;
  gap: 0.45rem;
  padding: 0.45rem 0.8rem;
}

.recipe-list {
  display: grid;
  gap: 0.65rem;
  list-style: none;
  margin: 0;
  padding: 0;
}

.recipe-row {
  border: 1px solid var(--sf-border);
  border-radius: 12px;
  padding: 0.75rem 0.9rem;
}

.recipe-toggle {
  align-items: flex-start;
  cursor: pointer;
  display: grid;
  gap: 0.75rem;
  grid-template-columns: auto 1fr;
}

.recipe-toggle span {
  display: grid;
  gap: 0.2rem;
}

.recipe-required {
  font-weight: 700;
}

.contract-copy-header {
  align-items: end;
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  justify-content: space-between;
}

.state-picker {
  display: grid;
  gap: 0.35rem;
  min-width: 12rem;
}

.copy-block {
  display: grid;
  gap: 0.45rem;
  margin-top: 1.1rem;
}

.copy-block h3 {
  margin: 0;
}

.copy-textarea {
  font-family: inherit;
  line-height: 1.45;
  resize: vertical;
}

.contract-setup-actions {
  align-items: center;
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
}

.contract-setup-actions .muted {
  margin: 0;
}
</style>
