<script setup lang="ts">
import { resolveLogoUrl } from "~~/shared/branding"

const props = withDefaults(defineProps<{
  src?: string
  alt?: string
  size?: "sm" | "md" | "lg"
  /** When src is empty, show the ShingleFile logo instead of a blank circle. */
  fallback?: "platform" | "none"
}>(), {
  alt: "Logo",
  size: "md",
  fallback: "platform",
})

const imageSrc = computed(() =>
  resolveLogoUrl(props.src, props.fallback === "platform"),
)
</script>

<template>
  <div class="brand-logo" :class="`brand-logo--${size}`">
    <img
      v-if="imageSrc"
      :src="imageSrc"
      :alt="alt"
      class="brand-logo__image"
    >
  </div>
</template>
