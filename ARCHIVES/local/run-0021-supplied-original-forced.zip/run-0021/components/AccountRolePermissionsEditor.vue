<script setup lang="ts">
import type {
  AccountCapability,
  AssignableCustomerAccountRole
} from "~~/shared/accountPermissions"

const draft = defineModel<Record<AssignableCustomerAccountRole, AccountCapability[]>>("draft", {
  required: true
})

const props = defineProps<{
  capabilityOptions: { id: AccountCapability, label: string }[]
  roles: {
    role: AssignableCustomerAccountRole
    label: string
    locked: AccountCapability[]
  }[]
  isBusy: boolean
  status: string
}>()

const emit = defineEmits<{
  save: []
  reset: []
}>()

function isChecked(role: AssignableCustomerAccountRole, capability: AccountCapability): boolean {
  return draft.value[role]?.includes(capability) ?? false
}

function isLocked(role: AssignableCustomerAccountRole, capability: AccountCapability): boolean {
  return props.roles.find((item) => item.role === role)?.locked.includes(capability) ?? false
}

function toggle(role: AssignableCustomerAccountRole, capability: AccountCapability) {
  if (isLocked(role, capability)) return
  const current = new Set(draft.value[role] ?? [])
  if (current.has(capability)) current.delete(capability)
  else current.add(capability)
  draft.value = {
    ...draft.value,
    [role]: props.capabilityOptions
      .map((option) => option.id)
      .filter((id) => current.has(id))
  }
}
</script>

<template>
  <section class="card role-permissions-editor">
    <div class="card-header">
      <div>
        <p class="eyebrow">Permissions</p>
        <h2>Role permissions</h2>
        <p class="muted role-permissions-copy">
          Choose what each company role can do. Changes apply to everyone with that role.
        </p>
      </div>
    </div>

    <div class="role-permissions-table-wrap">
      <table class="role-permissions-table">
        <thead>
          <tr>
            <th scope="col">Permission</th>
            <th
              v-for="role in roles"
              :key="role.role"
              scope="col"
            >
              {{ role.label }}
            </th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="capability in capabilityOptions"
            :key="capability.id"
          >
            <th scope="row">{{ capability.label }}</th>
            <td
              v-for="role in roles"
              :key="`${role.role}-${capability.id}`"
            >
              <label class="role-permissions-check">
                <input
                  type="checkbox"
                  :checked="isChecked(role.role, capability.id)"
                  :disabled="isBusy || isLocked(role.role, capability.id)"
                  :aria-label="`${capability.label} for ${role.label}`"
                  @change="toggle(role.role, capability.id)"
                >
              </label>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <p class="muted role-permissions-note">
      Account admin must keep “Manage team members and roles” and “Edit contract modules and recipe” so you cannot lock yourself out of setup.
    </p>

    <div class="role-permissions-actions">
      <button class="button" type="button" :disabled="isBusy" @click="emit('save')">
        {{ isBusy ? "Saving..." : "Save permissions" }}
      </button>
      <button class="button secondary" type="button" :disabled="isBusy" @click="emit('reset')">
        Reset to defaults
      </button>
      <p v-if="status" class="muted">{{ status }}</p>
    </div>
  </section>
</template>

<style scoped>
.role-permissions-copy {
  margin: 0.35rem 0 0;
  max-width: 40rem;
}

.role-permissions-table-wrap {
  overflow-x: auto;
}

.role-permissions-table {
  border-collapse: collapse;
  min-width: 36rem;
  width: 100%;
}

.role-permissions-table th,
.role-permissions-table td {
  border-bottom: 1px solid var(--sf-border);
  padding: 0.7rem 0.75rem;
  text-align: left;
  vertical-align: middle;
}

.role-permissions-table thead th {
  font-size: 0.85rem;
  font-weight: 700;
}

.role-permissions-table tbody th {
  font-weight: 600;
  max-width: 16rem;
}

.role-permissions-table td {
  text-align: center;
  width: 8rem;
}

.role-permissions-check {
  display: inline-flex;
  justify-content: center;
}

.role-permissions-note {
  margin: 0.85rem 0 0;
}

.role-permissions-actions {
  align-items: center;
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  margin-top: 1rem;
}

.role-permissions-actions .muted {
  margin: 0;
}
</style>
