<script setup lang="ts">
defineProps<{
  label: string
  value: number | string
}>()
</script>

<template>
  <section class="card">
    <div class="stat-value">{{ value }}</div>
    <div class="muted">{{ label }}</div>
  </section>
</template>
