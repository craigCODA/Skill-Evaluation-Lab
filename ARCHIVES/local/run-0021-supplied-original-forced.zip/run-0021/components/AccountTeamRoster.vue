<script setup lang="ts">
import type { AssignableCustomerAccountRole } from "~~/shared/accountPermissions"

export type AccountTeamMemberView = {
  id: string
  name: string
  email: string
  title: string
  roleLabel: string
  roleTone: "admin" | "estimator" | "installer" | "legacy"
  initials: string
  isCurrentUser: boolean
  roleDraft: AssignableCustomerAccountRole
  canEditRole: boolean
  roleDirty: boolean
}

export type AccountTeamGroupView = {
  key: string
  title: string
  description: string
  tone: "admin" | "estimator" | "installer" | "legacy"
  members: AccountTeamMemberView[]
}

defineProps<{
  groups: AccountTeamGroupView[]
  roleOptions: { value: AssignableCustomerAccountRole, label: string }[]
  isBusy: boolean
}>()

const emit = defineEmits<{
  "update-role-draft": [subAccountId: string, role: AssignableCustomerAccountRole]
  "save-role": [subAccountId: string]
}>()
</script>

<template>
  <div class="team-roster">
    <section
      v-for="group in groups"
      :key="group.key"
      class="card team-group"
      :class="`tone-${group.tone}`"
    >
      <div class="card-header team-group-header">
        <div>
          <p class="eyebrow">{{ group.title }}</p>
          <h2>{{ group.members.length }} {{ group.members.length === 1 ? "person" : "people" }}</h2>
          <p class="muted">{{ group.description }}</p>
        </div>
      </div>

      <div v-if="group.members.length" class="team-member-list">
        <article
          v-for="member in group.members"
          :key="member.id"
          class="team-member-card"
          :class="{ 'is-you': member.isCurrentUser }"
        >
          <div class="team-member-identity">
            <span class="team-avatar" aria-hidden="true">{{ member.initials }}</span>
            <div class="team-member-copy">
              <div class="team-member-name-row">
                <strong>{{ member.name }}</strong>
                <span v-if="member.isCurrentUser" class="team-you-pill">You</span>
                <span class="team-role-badge" :class="`tone-${member.roleTone}`">
                  {{ member.roleLabel }}
                </span>
              </div>
              <p v-if="member.title" class="muted">{{ member.title }}</p>
              <p class="team-member-email">{{ member.email }}</p>
            </div>
          </div>

          <div v-if="member.canEditRole" class="team-member-controls">
            <label class="team-role-select">
              <span class="sr-only">Role for {{ member.name }}</span>
              <select
                class="input"
                :value="member.roleDraft"
                :disabled="isBusy"
                @change="emit(
                  'update-role-draft',
                  member.id,
                  ($event.target as HTMLSelectElement).value as AssignableCustomerAccountRole
                )"
              >
                <option
                  v-for="option in roleOptions"
                  :key="option.value"
                  :value="option.value"
                >
                  {{ option.label }}
                </option>
              </select>
            </label>
            <button
              class="button secondary"
              type="button"
              :disabled="isBusy || !member.roleDirty"
              @click="emit('save-role', member.id)"
            >
              Save role
            </button>
          </div>
          <p v-else-if="member.isCurrentUser" class="muted team-self-note">
            Your role can’t be changed here.
          </p>
        </article>
      </div>

      <p v-else class="muted team-empty">No one in this group yet.</p>
    </section>
  </div>
</template>

<style scoped>
.team-roster {
  display: grid;
  gap: 1.25rem;
}

.team-group.tone-admin {
  border-color: color-mix(in oklab, var(--sf-section-blue-border) 70%, var(--sf-border));
}

.team-group.tone-estimator {
  border-color: color-mix(in oklab, var(--sf-section-green-border) 70%, var(--sf-border));
}

.team-group.tone-installer {
  border-color: color-mix(in oklab, var(--sf-section-sand-border) 80%, var(--sf-border));
}

.team-group-header h2 {
  margin: 0.15rem 0;
}

.team-member-list {
  display: grid;
  gap: 0.75rem;
}

.team-member-card {
  align-items: center;
  background: var(--sf-surface-subtle);
  border: 1px solid var(--sf-border);
  border-radius: 16px;
  display: flex;
  gap: 1rem;
  justify-content: space-between;
  padding: 0.95rem 1rem;
}

.team-member-card.is-you {
  background: var(--sf-section-cream);
  border-color: var(--sf-section-cream-border);
}

.team-member-identity {
  align-items: center;
  display: flex;
  gap: 0.85rem;
  min-width: 0;
}

.team-avatar {
  align-items: center;
  background: var(--sf-ink);
  border-radius: 999px;
  color: var(--sf-page);
  display: inline-flex;
  flex: 0 0 auto;
  font-size: 0.85rem;
  font-weight: 700;
  height: 2.5rem;
  justify-content: center;
  letter-spacing: 0.02em;
  width: 2.5rem;
}

.team-member-copy {
  display: grid;
  gap: 0.15rem;
  min-width: 0;
}

.team-member-name-row {
  align-items: center;
  display: flex;
  flex-wrap: wrap;
  gap: 0.4rem;
}

.team-member-email {
  color: var(--sf-text-soft);
  font-size: 0.92rem;
  margin: 0;
  overflow-wrap: anywhere;
}

.team-you-pill,
.team-role-badge {
  border-radius: 999px;
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.02em;
  padding: 0.18rem 0.55rem;
  text-transform: uppercase;
}

.team-you-pill {
  background: var(--sf-ink);
  color: var(--sf-page);
}

.team-role-badge.tone-admin {
  background: var(--sf-section-blue);
  color: var(--sf-ink);
}

.team-role-badge.tone-estimator {
  background: var(--sf-section-green);
  color: var(--sf-success-text);
}

.team-role-badge.tone-installer {
  background: var(--sf-section-sand);
  color: var(--sf-ink);
}

.team-role-badge.tone-legacy {
  background: var(--sf-section-neutral);
  color: var(--sf-text-soft);
}

.team-member-controls {
  align-items: center;
  display: flex;
  flex: 0 0 auto;
  gap: 0.5rem;
}

.team-role-select {
  min-width: 10rem;
}

.team-self-note,
.team-empty {
  margin: 0;
}

@media (max-width: 820px) {
  .team-member-card,
  .team-member-controls {
    align-items: stretch;
    display: grid;
  }
}
</style>
