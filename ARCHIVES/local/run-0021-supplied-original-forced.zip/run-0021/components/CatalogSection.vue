<script setup lang="ts">
defineProps<{
  section: string
  title: string
  rows: Record<string, unknown>[]
}>()

const emit = defineEmits<{
  update: [section: string, itemKey: string, patch: Record<string, unknown>]
}>()

function displayValue(value: unknown): string {
  if (Array.isArray(value)) return String(value.length)
  if (typeof value === "boolean") return value ? "Yes" : "No"
  if (value === null || value === undefined || value === "") return "-"
  if (typeof value === "object") return JSON.stringify(value)
  return String(value)
}

function itemKey(row: Record<string, unknown>) {
  return String(row.id ?? row.tier ?? row.key ?? "")
}

function isEditableKey(key: string, value: unknown) {
  return !["id", "key", "tier", "colors", "allowedWarranties", "fastenerUpcharges"].includes(key)
    && ["string", "number", "boolean"].includes(typeof value)
}

function coerceValue(original: unknown, value: string | boolean) {
  if (typeof original === "number") return Number(value)
  if (typeof original === "boolean") return Boolean(value)
  return String(value)
}

function updateValue(section: string, row: Record<string, unknown>, key: string, value: string | boolean) {
  const id = itemKey(row)
  if (!id) return
  emit("update", section, id, { [key]: coerceValue(row[key], value) })
}
</script>

<template>
  <section class="card card-table-section">
    <div class="card-header">
      <h2>{{ title }}</h2>
      <span class="muted">{{ rows.length }} rows</span>
    </div>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th v-for="key in Object.keys(rows[0] ?? {})" :key="key">{{ key }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(row, index) in rows" :key="index">
            <td v-for="key in Object.keys(row)" :key="key">
              <input
                v-if="isEditableKey(key, row[key]) && typeof row[key] === 'number'"
                class="input table-input"
                type="number"
                min="0"
                :value="row[key]"
                @change="updateValue(section, row, key, ($event.target as HTMLInputElement).value)"
              >
              <select
                v-else-if="isEditableKey(key, row[key]) && typeof row[key] === 'boolean'"
                class="input table-input"
                :value="String(row[key])"
                @change="updateValue(section, row, key, ($event.target as HTMLSelectElement).value === 'true')"
              >
                <option value="true">Yes</option>
                <option value="false">No</option>
              </select>
              <input
                v-else-if="isEditableKey(key, row[key])"
                class="input table-input"
                :value="displayValue(row[key])"
                @change="updateValue(section, row, key, ($event.target as HTMLInputElement).value)"
              >
              <span v-else>{{ displayValue(row[key]) }}</span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</template>
