<script setup lang="ts">
import type { RoofProbeVentilationSummary } from "~~/shared/roofProbeReport";

defineProps<{
  summary: RoofProbeVentilationSummary;
}>();

const ridgeVentNfaPerFt = defineModel<number>("ridgeVentNfaPerFt", { required: true });

const ridgeVentNfaOptions = [10, 12, 18] as const;

function formatNumber(value?: number, digits = 1): string {
  if (value === undefined) return "Not available";
  return value.toLocaleString(undefined, {
    maximumFractionDigits: digits,
    minimumFractionDigits: digits,
  });
}
</script>

<template>
  <section class="roof-page-section airflow-panel">
    <div class="airflow-heading">
      <div>
        <p class="section-eyebrow">Attic airflow estimate</p>
        <h2>Balance ridge exhaust with low intake</h2>
        <p>
          Uses estimated attic footprint and a balanced 50/50 split for exhaust and intake.
        </p>
      </div>
      <div class="attic-area-card">
        <span>Estimated attic</span>
        <strong>{{ formatNumber(summary.atticSqft, 0) }}</strong>
        <small>sq ft</small>
      </div>
    </div>

    <div class="airflow-metrics">
      <div class="metric-card metric-card-exhaust">
        <span>Exhaust target</span>
        <strong>{{ formatNumber(summary.recommendedExhaust, 0) }} sq in</strong>
      </div>
      <div class="metric-card metric-card-intake">
        <span>Intake target</span>
        <strong>{{ formatNumber(summary.recommendedIntake, 0) }} sq in</strong>
      </div>
      <div class="metric-card metric-card-surface">
        <span>Roof surface</span>
        <strong>{{ formatNumber(summary.surfaceSqft, 0) }} sq ft</strong>
      </div>
      <div class="metric-card metric-card-footprint">
        <span>Footprint basis</span>
        <strong>{{ formatNumber(summary.footprintSqft, 0) }} sq ft</strong>
      </div>
    </div>

    <div class="airflow-grid">
      <section class="airflow-card airflow-card-basis">
        <div class="section-title">
          <span>Ventilation basis</span>
          <strong>NFVA check</strong>
        </div>
        <div class="ratio-grid">
          <div class="ratio-card is-selected">
            <span>Planning target</span>
            <strong>1:300</strong>
            <p>{{ formatNumber(summary.nfvaOneToThreeHundred, 0) }} sq in total NFVA</p>
            <small>Split into {{ formatNumber(summary.recommendedExhaust, 0) }} exhaust / {{ formatNumber(summary.recommendedIntake, 0) }} intake</small>
          </div>
          <div class="ratio-card">
            <span>Higher airflow check</span>
            <strong>1:150</strong>
            <p>{{ formatNumber(summary.nfvaOneToOneFifty, 0) }} sq in total NFVA</p>
            <small>{{ formatNumber(Math.ceil(summary.nfvaOneToOneFifty / 2), 0) }} sq in per side</small>
          </div>
        </div>
      </section>

      <section class="airflow-card airflow-card-ridge">
        <div class="section-title">
          <span>Ridge exhaust</span>
          <strong>Vent length estimate</strong>
        </div>
        <div class="ridge-layout">
          <label class="ridge-nfa-field">
            <span>Ridge vent rating</span>
            <select v-model.number="ridgeVentNfaPerFt">
              <option
                v-for="rating in ridgeVentNfaOptions"
                :key="rating"
                :value="rating"
              >
                {{ rating }} sq in/lf
              </option>
            </select>
          </label>
          <div class="ridge-needed">
            <span>Estimated ridge vent</span>
            <strong>{{ formatNumber(summary.ridgeVentNeededFt, 0) }} ft</strong>
          </div>
          <p class="ridge-note">
            {{ summary.availableRidgeFt
              ? `${formatNumber(summary.availableRidgeFt, 0)} ft of ridge drawn. ${summary.ridgeCapacitySufficient ? "Ridge length looks sufficient." : "Confirm more ridge can be vented."}`
              : "Draw ridge lines to compare available ridge length against the estimate." }}
          </p>
        </div>
      </section>
    </div>

    <section class="intake-guide airflow-card-intake">
      <div class="section-title">
        <span>Intake takeoff guide</span>
        <strong>Ways to meet {{ formatNumber(summary.recommendedIntake, 0) }} sq in</strong>
      </div>
      <div class="intake-cards">
        <div>
          <span>Vented drip edge</span>
          <strong>{{ summary.ventedDripEdgeFt }} ft</strong>
          <small>9 sq in/ft</small>
        </div>
        <div>
          <span>Soffit vent</span>
          <strong>{{ summary.soffitVentFt }} ft</strong>
          <small>9 sq in/ft</small>
        </div>
        <div>
          <span>Bird blocks</span>
          <strong>{{ summary.birdBlocksEach }} ea</strong>
          <small>~3.5 sq in each</small>
        </div>
      </div>
    </section>
  </section>
</template>

<style scoped>
.roof-page-section {
  border: 1px solid;
  border-radius: 1.1rem;
  box-shadow: 0 10px 30px rgb(23 33 58 / 6%);
  display: grid;
  gap: 1rem;
  padding: 1rem;
}

.airflow-panel {
  background: var(--sf-page);
  border-color: var(--sf-border);
}

.airflow-heading {
  align-items: center;
  background: var(--sf-surface);
  border: 1px solid var(--sf-border);
  border-radius: 1rem;
  display: grid;
  gap: 1rem;
  grid-template-columns: minmax(0, 1fr) auto;
  padding: 1rem;
}

.section-eyebrow {
  color: var(--sf-action);
  font-size: 0.72rem;
  font-weight: 900;
  letter-spacing: 0.08em;
  margin: 0 0 0.25rem;
  text-transform: uppercase;
}

.airflow-heading h2 {
  margin: 0 0 0.3rem;
}

.airflow-heading p {
  color: var(--sf-text-muted);
  margin: 0;
}

.attic-area-card {
  background: var(--sf-action);
  border-radius: 1rem;
  color: white;
  min-width: 9rem;
  padding: 0.85rem 1rem;
  text-align: center;
}

.attic-area-card span,
.attic-area-card small {
  display: block;
  font-size: 0.74rem;
  font-weight: 800;
  opacity: 0.88;
}

.attic-area-card strong {
  display: block;
  font-size: 1.7rem;
  line-height: 1;
  margin: 0.2rem 0;
}

.airflow-metrics,
.airflow-grid {
  display: grid;
  gap: 0.85rem;
}

.airflow-metrics {
  grid-template-columns: repeat(4, minmax(0, 1fr));
}

.airflow-grid {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.metric-card,
.airflow-card,
.intake-guide {
  border: 1px solid;
  border-radius: 0.9rem;
}

.metric-card,
.airflow-card,
.intake-guide {
  padding: 0.85rem;
}

.metric-card-exhaust,
.airflow-card-basis {
  background: var(--sf-section-blue);
  border-color: var(--sf-section-blue-border);
}

.metric-card-intake,
.airflow-card-ridge {
  background: var(--sf-section-green);
  border-color: var(--sf-section-green-border);
}

.metric-card-surface {
  background: var(--sf-section-sand);
  border-color: var(--sf-border-strong);
}

.metric-card-footprint,
.airflow-card-intake {
  background: var(--sf-section-cream);
  border-color: var(--sf-section-cream-border);
}

.airflow-card,
.intake-guide {
  display: grid;
  gap: 0.85rem;
}

.airflow-metrics span,
.section-title span,
.ratio-card span,
.ridge-nfa-field span,
.ridge-needed span,
.intake-cards span {
  color: var(--sf-text-muted);
  display: block;
  font-size: 0.74rem;
  font-weight: 900;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.airflow-metrics strong,
.section-title strong {
  color: var(--sf-text);
  display: block;
  font-size: 1.05rem;
  margin-top: 0.25rem;
}

.ratio-grid,
.intake-cards {
  display: grid;
  gap: 0.75rem;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.ratio-card,
.intake-cards div {
  background: color-mix(in oklab, var(--sf-surface) 82%, transparent);
  border: 1px solid rgb(23 33 58 / 10%);
  border-radius: 0.8rem;
  padding: 0.85rem;
}

.ratio-card.is-selected {
  background: var(--sf-surface);
  border-color: color-mix(in oklab, var(--sf-action) 32%, transparent);
}

.ratio-card strong,
.intake-cards strong,
.ridge-needed strong {
  color: var(--sf-action);
  display: block;
  font-size: 1.35rem;
  line-height: 1.1;
  margin: 0.25rem 0;
}

.ratio-card p,
.ridge-note {
  color: var(--sf-text);
  font-weight: 800;
  margin: 0.2rem 0;
}

.ratio-card small,
.intake-cards small {
  color: var(--sf-text-muted);
  display: block;
  font-size: 0.78rem;
  line-height: 1.3;
}

.ridge-layout,
.ridge-nfa-field {
  display: grid;
  gap: 0.35rem;
}

.ridge-layout {
  gap: 0.75rem;
}

.ridge-nfa-field select {
  background: white;
  border: 1px solid var(--sf-border);
  border-radius: 999px;
  color: var(--sf-text);
  font: inherit;
  font-size: 0.85rem;
  font-weight: 800;
  padding: 0.5rem 0.7rem;
}

@media (max-width: 860px) {
  .airflow-heading,
  .airflow-grid,
  .airflow-metrics {
    grid-template-columns: 1fr;
  }

  .attic-area-card {
    text-align: left;
  }
}

@media (max-width: 600px) {
  .ratio-grid,
  .intake-cards {
    grid-template-columns: 1fr;
  }
}
</style>
