<script setup lang="ts">
import type { RoofArea } from "~~/shared/types"
import { ROOF_LOCATIONS } from "~~/shared/roofArea"

const area = defineModel<RoofArea>({ required: true })
</script>

<template>
  <div class="v2-area-section">
    <h3 class="v2-subhead">Name this plane</h3>
    <p class="v2-note">
      One tab = one roof plane (facet). Match your measurement report or sketch — e.g. "Main roof", "Garage", "North dormer".
    </p>
    <div class="form-grid">
      <label class="field">
        <span>Plane name <EstimateHelp label="Plane name" text="Shown on the estimate and in tabs. No pricing math." /></span>
        <input v-model="area.label" class="input" placeholder="Main roof">
      </label>
      <label class="field">
        <span>Location <EstimateHelp label="Location" text="Which part of the property this plane belongs to." /></span>
        <select v-model="area.location" class="input">
          <option v-for="loc in ROOF_LOCATIONS" :key="loc" :value="loc">{{ loc }}</option>
        </select>
      </label>
      <label class="field field-span-all">
        <span>Notes</span>
        <input v-model="area.description" class="input" placeholder="Optional — e.g. north-facing slope above garage">
      </label>
    </div>
  </div>
</template>

<style scoped>
.field-span-all {
  grid-column: 1 / -1;
}
</style>
