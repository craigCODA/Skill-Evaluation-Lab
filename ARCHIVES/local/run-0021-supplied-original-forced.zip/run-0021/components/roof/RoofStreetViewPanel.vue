<script setup lang="ts">
import type { StreetViewAvailability } from "~/composables/useRoofMeasurements";

const {
  address,
  apiKey,
  availability,
  isChecking,
  latitude,
  longitude,
} = defineProps<{
  address: string;
  apiKey?: string;
  availability?: StreetViewAvailability | null;
  isChecking?: boolean;
  latitude: number;
  longitude: number;
}>();

const streetViewUrl = computed(() => {
  if (!apiKey || !availability?.available) return "";
  const params = new URLSearchParams({
    key: apiKey,
    location: `${latitude},${longitude}`,
    fov: "80",
    heading: "0",
    pitch: "0",
  });

  return `https://www.google.com/maps/embed/v1/streetview?${params}`;
});

const googleMapsStreetViewUrl = computed(() => {
  const params = new URLSearchParams({
    api: "1",
    map_action: "pano",
    viewmode: "streetview",
    viewpoint: `${latitude},${longitude}`,
    query: address,
  });

  return `https://www.google.com/maps/@?${params}`;
});
</script>

<template>
  <section class="street-view-panel">
    <div class="street-view-copy">
      <div>
        <p class="section-eyebrow">Street View</p>
        <h3>Check the home from the road</h3>
      </div>
      <p>
        Use this view to spot access issues, steep driveways, trees, dormers, roof-to-wall areas,
        and other details that may not be obvious from the aerial image.
      </p>
      <a
        class="button secondary street-view-link"
        :href="googleMapsStreetViewUrl"
        target="_blank"
        rel="noopener noreferrer"
      >
        Open in Google Maps
      </a>
    </div>

    <div v-if="isChecking" class="street-view-missing">
      <h3>Checking Street View coverage</h3>
      <p>We are checking whether Google has road-level imagery for this property.</p>
    </div>

    <iframe
      v-else-if="streetViewUrl"
      class="street-view-frame"
      :src="streetViewUrl"
      :title="`Street view for ${address}`"
      allowfullscreen
      loading="lazy"
      referrerpolicy="no-referrer-when-downgrade"
    />

    <div v-else-if="!apiKey" class="street-view-missing">
      <h3>Street View is not configured</h3>
      <p>Add a domain-restricted browser map key to enable this tab.</p>
    </div>

    <div v-else class="street-view-missing">
      <h3>Street View is not available here</h3>
      <p>
        Google did not return road-level imagery for this property. You can still open Google Maps
        to inspect nearby coverage manually.
      </p>
    </div>
  </section>
</template>

<style scoped>
.street-view-panel {
  display: grid;
  gap: 1rem;
}

.street-view-copy {
  align-items: start;
  display: grid;
  gap: 1rem;
  grid-template-columns: minmax(12rem, 1fr) minmax(18rem, 2fr) auto;
}

.street-view-copy h3 {
  margin: 0;
}

.street-view-copy p {
  color: var(--sf-text-muted);
  line-height: 1.5;
  margin: 0;
  max-width: 46rem;
}

.street-view-link {
  align-self: start;
  white-space: nowrap;
}

.section-eyebrow {
  color: var(--sf-action);
  font-size: 0.72rem;
  font-weight: 900;
  letter-spacing: 0.08em;
  margin: 0 0 0.25rem;
  text-transform: uppercase;
}

.street-view-frame,
.street-view-missing {
  background: var(--sf-section-neutral);
  border: 1px solid color-mix(in oklab, var(--sf-border) 75%, white);
  border-radius: 1rem;
  min-height: 34rem;
  width: 100%;
}

.street-view-frame {
  display: block;
}

.street-view-missing {
  align-content: center;
  display: grid;
  justify-items: center;
  padding: 2rem;
  text-align: center;
}

.street-view-missing h3 {
  margin: 0 0 0.35rem;
}

.street-view-missing p {
  color: var(--sf-text-muted);
  margin: 0;
}

@media (max-width: 860px) {
  .street-view-copy {
    grid-template-columns: 1fr;
  }

  .street-view-link {
    justify-self: start;
  }

  .street-view-frame,
  .street-view-missing {
    min-height: 27rem;
  }
}
</style>
