<script setup lang="ts">
import type { RoofProbeHistoryEntry } from "~/composables/useRoofMeasurements";

const { entries, isOpen, isRestoring } = defineProps<{
  entries: RoofProbeHistoryEntry[];
  isOpen: boolean;
  isRestoring: boolean;
}>();

const emit = defineEmits<{
  close: [];
  restore: [entryId: string];
}>();

function formatDate(value: string): string {
  return new Date(value).toLocaleString(undefined, {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

function requestClose() {
  if (isRestoring) return;
  emit("close");
}
</script>

<template>
  <div
    v-if="isOpen"
    class="roof-history-panel"
    :class="{ 'is-restoring': isRestoring }"
  >
    <div class="roof-history-backdrop" @click="requestClose" />
    <aside class="roof-history-drawer" aria-label="Recent roof scans" :aria-busy="isRestoring">
      <div v-if="isRestoring" class="roof-history-loading" role="status" aria-live="polite">
        Loading historical address...
      </div>
      <div class="roof-history-header">
        <div>
          <p class="page-eyebrow">Recent searches</p>
          <h2>Roof scan history</h2>
        </div>
        <button
          type="button"
          class="button secondary roof-history-close"
          :disabled="isRestoring"
          @click="requestClose"
        >
          Close
        </button>
      </div>

      <p class="roof-history-note">
        Restoring a scan uses the saved result and drawn lines without running a new lookup.
      </p>

      <ol v-if="entries.length" class="roof-history-list">
        <li v-for="entry in entries" :key="entry.id">
          <button type="button" :disabled="isRestoring" @click="emit('restore', entry.id)">
            <strong>{{ entry.address }}</strong>
            <span>{{ formatDate(entry.searchedAt) }}</span>
            <em>
              {{ entry.lines.length }} drawn line{{ entry.lines.length === 1 ? "" : "s" }}
            </em>
          </button>
        </li>
      </ol>

      <div v-else class="roof-history-empty">
        <h3>No saved scans yet</h3>
        <p class="muted">Run a ShingleScope scan and it will appear here for this login.</p>
      </div>
    </aside>
  </div>
</template>

<style scoped>
.roof-history-panel {
  inset: 0;
  position: fixed;
  z-index: 80;
}

.roof-history-backdrop {
  background: var(--sf-overlay);
  inset: 0;
  position: absolute;
}

.roof-history-drawer {
  background: var(--sf-surface);
  border-left: 1px solid var(--sf-border);
  box-shadow: -20px 0 48px rgb(15 31 23 / 24%);
  align-content: start;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  height: 100%;
  margin-left: auto;
  max-width: min(32rem, 92vw);
  overflow: auto;
  padding: 1.25rem;
  position: relative;
  width: 100%;
}

.roof-history-panel.is-restoring .roof-history-drawer > :not(.roof-history-loading) {
  opacity: 0.38;
}

.roof-history-loading {
  background: rgb(23 33 58 / 86%);
  border: 1px solid rgb(255 255 255 / 18%);
  border-radius: 999px;
  box-shadow: 0 14px 36px rgb(15 31 23 / 22%);
  color: white;
  font-weight: 900;
  left: 50%;
  padding: 0.8rem 1.05rem;
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  z-index: 3;
}

.roof-history-header {
  align-items: center;
  background: color-mix(in oklab, var(--sf-section-neutral) 38%, white);
  border: 1px solid color-mix(in oklab, var(--sf-border) 70%, white);
  border-radius: 1rem;
  display: flex;
  gap: 1rem;
  justify-content: space-between;
  padding: 1rem;
}

.roof-history-close {
  flex: 0 0 auto;
}

.roof-history-header h2 {
  margin: 0;
}

.roof-history-note {
  background: var(--sf-section-cream);
  border: 1px solid var(--sf-section-cream-border);
  border-radius: 0.95rem;
  color: var(--sf-text-muted);
  line-height: 1.45;
  margin: 0;
  padding: 0.85rem 1rem;
}

.roof-history-list {
  display: grid;
  gap: 0.75rem;
  list-style: none;
  margin: 0;
  padding: 0;
}

.roof-history-list button {
  background: white;
  border: 1px solid var(--sf-border);
  border-radius: 0.95rem;
  color: var(--sf-text);
  cursor: pointer;
  display: grid;
  gap: 0.3rem;
  padding: 0.9rem 1rem;
  text-align: left;
  transition:
    border-color 0.15s ease,
    box-shadow 0.15s ease,
    transform 0.15s ease;
  width: 100%;
}

.roof-history-list button:hover,
.roof-history-list button:focus-visible {
  border-color: var(--sf-action);
  box-shadow: 0 10px 24px rgb(23 33 58 / 7%);
  outline: none;
  transform: translateY(-1px);
}

.roof-history-list button:disabled,
.roof-history-close:disabled {
  cursor: wait;
}

.roof-history-list strong,
.roof-history-list span,
.roof-history-list em {
  display: block;
}

.roof-history-list span,
.roof-history-list em {
  color: var(--sf-text-muted);
  font-size: 0.84rem;
}

.roof-history-list em {
  font-style: normal;
  font-weight: 700;
}

.roof-history-empty {
  background: white;
  border: 1px dashed var(--sf-border);
  border-radius: 0.85rem;
  padding: 1rem;
}

@media (max-width: 640px) {
  .roof-history-panel {
    align-items: end;
    display: grid;
  }

  .roof-history-drawer {
    border-left: 0;
    border-radius: 1.25rem 1.25rem 0 0;
    box-shadow: 0 -18px 42px rgb(15 31 23 / 24%);
    height: auto;
    max-height: 86dvh;
    max-width: none;
    padding: 1rem;
  }

  .roof-history-header {
    align-items: center;
    background: var(--sf-surface);
    border: 0;
    border-bottom: 1px solid color-mix(in oklab, var(--sf-border) 70%, transparent);
    border-radius: 0;
    margin: -1rem -1rem 0;
    padding: 1rem;
    position: sticky;
    top: -1rem;
    z-index: 1;
  }

  .roof-history-header h2 {
    font-size: 1.2rem;
  }

  .roof-history-close {
    min-height: 2.2rem;
    padding: 0.45rem 0.75rem;
  }

  .roof-history-list {
    gap: 0.75rem;
  }

  .roof-history-list button {
    border-radius: 0.95rem;
    gap: 0.35rem;
    padding: 0.9rem;
  }

  .roof-history-list strong {
    line-height: 1.25;
  }
}
</style>
