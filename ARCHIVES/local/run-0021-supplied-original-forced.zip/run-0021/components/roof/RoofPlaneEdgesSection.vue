<script setup lang="ts">
import type { RoofArea } from "~~/shared/types"

const area = defineModel<RoofArea>({ required: true })
</script>

<template>
  <div class="v2-area-section">
    <h3 class="v2-subhead">
      Edges on this plane
      <EstimateHelp
        label="Plane edges"
        text="Linear feet along each edge of this plane — from your report or field measure. Ridge and hip for the whole job are entered once under Whole roof totals."
      />
    </h3>
    <div class="form-grid form-grid-three">
      <label class="field">
        <span>Eave edge (linear ft) <EstimateHelp label="Eave drip LF" text="Length along the bottom horizontal edge. Drives drip edge, starter, and ice & water at eaves." /></span>
        <input v-model.number="area.eaveDripLf" class="input" type="number" min="0" step="0.1">
      </label>
      <label class="field">
        <span>Rake edge (linear ft) <EstimateHelp label="Rake drip LF" text="Length along the sloped gable edge. Drives rake drip edge." /></span>
        <input v-model.number="area.rakeDripLf" class="input" type="number" min="0" step="0.1">
      </label>
      <label class="field">
        <span>Valley (linear ft) <EstimateHelp label="Ice & water valley LF" text="Closed-valley footage on this plane receiving ice & water shield." /></span>
        <input v-model.number="area.iceWaterValleyLf" class="input" type="number" min="0" step="0.1">
      </label>
    </div>
  </div>
</template>

<style scoped>
.form-grid-three {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}
</style>
