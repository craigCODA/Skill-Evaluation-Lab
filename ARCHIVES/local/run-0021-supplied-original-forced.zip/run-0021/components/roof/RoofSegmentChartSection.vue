<script setup lang="ts">
import type { RoofProbeSegmentRow } from "~~/shared/roofProbeReport";

defineProps<{
  rows: RoofProbeSegmentRow[];
}>();
</script>

<template>
  <section class="roof-page-section segment-section">
    <div class="section-header">
      <div>
        <p class="section-eyebrow">Roof facet chart</p>
        <h2>Segment measurement review</h2>
        <p>Compare area, pitch, orientation, and confidence for every detected roof segment.</p>
      </div>
    </div>

    <div class="segment-chart">
      <div class="segment-chart-head">
        <span>Segment</span>
        <span>Area</span>
        <span>Pitch</span>
        <span>Orientation</span>
        <span>Confidence</span>
      </div>
      <div
        v-for="row in rows"
        :key="row.id"
        class="segment-row"
      >
        <strong>{{ row.label }}</strong>
        <span>{{ row.area }}</span>
        <span>{{ row.pitch }}</span>
        <span>{{ row.orientation }}</span>
        <span class="confidence-pill">{{ row.confidence }}</span>
      </div>
      <p v-if="rows.length === 0" class="empty-note">
        No roof segments returned. Manual measurement is required.
      </p>
    </div>
  </section>
</template>

<style scoped>
.roof-page-section {
  border: 1px solid;
  border-radius: 1.1rem;
  box-shadow: 0 10px 30px rgb(23 33 58 / 6%);
  display: grid;
  gap: 1rem;
  padding: 1.15rem 1.25rem;
}

.segment-section {
  background: var(--sf-surface);
  border-color: var(--sf-border);
}

.section-eyebrow {
  color: var(--sf-action);
  font-size: 0.72rem;
  font-weight: 900;
  letter-spacing: 0.08em;
  margin: 0 0 0.25rem;
  text-transform: uppercase;
}

.section-header h2 {
  margin: 0 0 0.25rem;
}

.section-header p {
  color: var(--sf-text-muted);
  margin: 0;
}

.segment-chart {
  background: white;
  border: 1px solid var(--sf-border);
  border-radius: 0.9rem;
  overflow: hidden;
}

.segment-chart-head,
.segment-row {
  display: grid;
  gap: 1rem;
  grid-template-columns: minmax(8rem, 1.2fr) repeat(4, minmax(6rem, 1fr));
  padding: 0.75rem 1rem;
}

.segment-chart-head {
  background: var(--sf-section-blue);
  color: var(--sf-text-soft);
  font-size: 0.75rem;
  font-weight: 900;
  letter-spacing: 0.05em;
  text-transform: uppercase;
}

.segment-row {
  align-items: center;
  border-top: 1px solid color-mix(in oklab, var(--sf-border) 75%, white);
  color: var(--sf-text-soft);
  font-size: 0.9rem;
}

.segment-row strong {
  color: var(--sf-text);
}

.confidence-pill {
  background: var(--sf-section-green);
  border-radius: 999px;
  color: var(--sf-success-text);
  display: inline-flex;
  font-weight: 900;
  justify-self: start;
  padding: 0.25rem 0.55rem;
}

.empty-note {
  color: var(--sf-text-muted);
  margin: 0;
  padding: 1rem;
}

@media (max-width: 760px) {
  .segment-chart-head {
    display: none;
  }

  .segment-row {
    gap: 0.35rem;
    grid-template-columns: 1fr;
  }
}
</style>
