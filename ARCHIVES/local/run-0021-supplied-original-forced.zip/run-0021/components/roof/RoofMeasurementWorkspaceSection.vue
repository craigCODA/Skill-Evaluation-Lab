<script setup lang="ts">
import type { RoofAreaShape, RoofIconMarker, RoofLineMeasurement } from "~~/shared/roofLineMeasurements";
import type { CustomerJobSummary, CustomerRecord, RoofMeasurement } from "~~/shared/types";
import type { StreetViewAvailability } from "~/composables/useRoofMeasurements";

defineProps<{
  assetCustomerJobs?: CustomerJobSummary[];
  assetCustomers?: CustomerRecord[];
  assetSelectedCustomerId?: string;
  assetSelectedJobId?: string;
  assetSaveStatus?: string;
  isCheckingStreetView?: boolean;
  isSavingAsset?: boolean;
  measurement: RoofMeasurement;
  streetViewAvailability?: StreetViewAvailability | null;
  streetViewKey?: string;
}>();

const emit = defineEmits<{
  assetCustomerSelected: [customerId: string];
  saveDrawingAsset: [payload: { jobId: string; label: string; imageDataUrl: string }];
}>();

const measuredLines = defineModel<RoofLineMeasurement[]>("lines", { required: true });
const iconMarkers = defineModel<RoofIconMarker[]>("markers", { required: true });
const areaShapes = defineModel<RoofAreaShape[]>("areaShapes", { required: true });
const activeTab = ref<"aerial" | "street-view">("aerial");
</script>

<template>
  <section v-if="measurement.imagery?.previewDataUrl" class="roof-page-section workspace-section">
    <div class="section-header">
      <div>
        <p class="section-eyebrow">Image editor + quick calculator</p>
        <h2>Draw roof line measurements</h2>
        <p>Measure ridge, hip, valley, eave, and rake lines directly on the aerial image.</p>
      </div>
    </div>

    <div class="workspace-tabs" role="tablist" aria-label="ShingleScope views">
      <button
        class="workspace-tab"
        :class="{ active: activeTab === 'aerial' }"
        type="button"
        role="tab"
        :aria-selected="activeTab === 'aerial'"
        @click="activeTab = 'aerial'"
      >
        Aerial measurement
      </button>
      <button
        class="workspace-tab"
        :class="{ active: activeTab === 'street-view' }"
        type="button"
        role="tab"
        :aria-selected="activeTab === 'street-view'"
        @click="activeTab = 'street-view'"
      >
        Street View
      </button>
    </div>

    <div v-if="activeTab === 'aerial'" class="roof-workspace">
      <RoofImageMeasurePanel
        v-model:area-shapes="areaShapes"
        v-model:markers="iconMarkers"
        v-model:lines="measuredLines"
        :asset-customer-jobs="assetCustomerJobs"
        :asset-customers="assetCustomers"
        :asset-selected-customer-id="assetSelectedCustomerId"
        :asset-selected-job-id="assetSelectedJobId"
        :asset-save-status="assetSaveStatus"
        :is-saving-asset="isSavingAsset"
        :measurement="measurement"
        @customer-selected="emit('assetCustomerSelected', $event)"
        @save-drawing-asset="emit('saveDrawingAsset', $event)"
      />

      <RoofQuickLinearCalculator
        v-model:measured-lines="measuredLines"
      />
    </div>

    <RoofStreetViewPanel
      v-else
      :address="measurement.address"
      :api-key="streetViewKey"
      :availability="streetViewAvailability"
      :is-checking="isCheckingStreetView"
      :latitude="measurement.latitude"
      :longitude="measurement.longitude"
    />
  </section>
</template>

<style scoped>
.roof-page-section {
  border: 1px solid;
  border-radius: 1.1rem;
  box-shadow: 0 10px 30px rgb(23 33 58 / 6%);
  display: grid;
  gap: 1rem;
  padding: 1.15rem 1.25rem;
}

.workspace-section {
  background: var(--sf-section-cream);
  border-color: var(--sf-section-cream-border);
}

.section-eyebrow {
  color: var(--sf-action);
  font-size: 0.72rem;
  font-weight: 900;
  letter-spacing: 0.08em;
  margin: 0 0 0.25rem;
  text-transform: uppercase;
}

.section-header h2 {
  margin: 0 0 0.25rem;
}

.section-header p {
  color: var(--sf-text-muted);
  margin: 0;
}

.workspace-tabs {
  background: color-mix(in oklab, var(--sf-section-neutral) 70%, white);
  border: 1px solid color-mix(in oklab, var(--sf-border) 70%, white);
  border-radius: 999px;
  display: flex;
  gap: 0.35rem;
  padding: 0.35rem;
  width: fit-content;
}

.workspace-tab {
  background: transparent;
  border: 0;
  border-radius: 999px;
  color: var(--sf-text-muted);
  cursor: pointer;
  font: inherit;
  font-size: 0.9rem;
  font-weight: 850;
  min-height: 2.35rem;
  padding: 0.5rem 0.95rem;
  transition:
    background-color 0.15s ease,
    color 0.15s ease,
    box-shadow 0.15s ease;
}

.workspace-tab.active {
  background: white;
  box-shadow: 0 8px 18px rgb(23 33 58 / 8%);
  color: var(--sf-text);
}

.workspace-tab:focus-visible {
  outline: 3px solid color-mix(in oklab, var(--sf-action) 24%, transparent);
  outline-offset: 2px;
}

.roof-workspace {
  align-items: start;
  display: grid;
  gap: 1.25rem;
  grid-template-columns: minmax(22rem, 31rem) minmax(18rem, 1fr);
}

.roof-workspace > :last-child {
  min-width: 0;
  width: 100%;
}

@media (max-width: 860px) {
  .workspace-tabs {
    width: 100%;
  }

  .workspace-tab {
    flex: 1 1 0;
  }

  .roof-workspace {
    grid-template-columns: 1fr;
  }
}
</style>
