<script setup lang="ts">
defineProps<{
  errorMessage: string;
  historyCount: number;
  isLoading: boolean;
}>();

const emit = defineEmits<{
  openHistory: [];
  scan: [];
}>();

const address = defineModel<string>("address", { required: true });
</script>

<template>
  <section class="roof-page-section property-section">
    <div class="section-header">
      <div>
        <p class="section-eyebrow">Property address</p>
        <h2>Start or restore a scan</h2>
        <p>Enter the property address. ShingleScope will use the best imagery available.</p>
      </div>
      <button
        type="button"
        class="button secondary"
        @click="emit('openHistory')"
      >
        History
        <span v-if="historyCount">({{ historyCount }})</span>
      </button>
    </div>

    <form class="roof-probe-form" @submit.prevent="emit('scan')">
      <label class="field roof-probe-address">
        <span>Property address</span>
        <input
          v-model="address"
          class="input"
          type="text"
          placeholder="123 Main St, Des Moines, IA"
          required
        >
      </label>

      <button class="button" type="submit" :disabled="isLoading || !address.trim()">
        {{ isLoading ? "Scanning..." : "Run ShingleScope scan" }}
      </button>
    </form>

    <p v-if="errorMessage" class="roof-probe-error">
      {{ errorMessage }}
    </p>

    <p class="muted roof-probe-note">
      Your last 30 searches, drawn lines, and results are saved in this browser for your login.
    </p>
  </section>
</template>

<style scoped>
.roof-page-section {
  border: 1px solid;
  border-radius: 1.1rem;
  box-shadow: 0 10px 30px rgb(23 33 58 / 6%);
  display: grid;
  gap: 1rem;
  padding: 1.15rem 1.25rem;
}

.property-section {
  background: var(--sf-section-sand);
  border-color: var(--sf-border-strong);
}

.section-header {
  align-items: center;
  display: grid;
  gap: 1rem;
  grid-template-columns: minmax(0, 1fr) auto;
}

.section-eyebrow {
  color: var(--sf-action);
  font-size: 0.72rem;
  font-weight: 900;
  letter-spacing: 0.08em;
  margin: 0 0 0.25rem;
  text-transform: uppercase;
}

.section-header h2 {
  margin: 0 0 0.25rem;
}

.section-header p {
  color: var(--sf-text-muted);
  margin: 0;
}

.roof-probe-form {
  align-items: end;
  display: grid;
  gap: 1rem;
  grid-template-columns: minmax(0, 1fr) auto;
}

.roof-probe-address {
  min-width: 0;
}

.roof-probe-error {
  background: var(--sf-danger-soft);
  border: 1px solid var(--sf-danger-border);
  border-radius: 0.75rem;
  color: var(--sf-danger-text);
  margin: 0;
  padding: 0.8rem 1rem;
}

.roof-probe-note {
  margin: 0;
}

@media (max-width: 860px) {
  .section-header,
  .roof-probe-form {
    align-items: stretch;
    grid-template-columns: 1fr;
  }
}
</style>
