<script setup lang="ts">
import type { RoofProbeMetaItem } from "~~/shared/roofProbeReport";

defineProps<{
  items: RoofProbeMetaItem[];
}>();
</script>

<template>
  <div class="roof-probe-meta-grid">
    <p
      v-for="item in items"
      :key="item.id"
      class="meta-chip"
      :class="{ 'is-warning': item.tone === 'warning' }"
      :title="item.tooltip"
    >
      <span>{{ item.label }}</span>
      <strong>{{ item.value }}</strong>
      <small v-if="item.badge">{{ item.badge }}</small>
    </p>
  </div>
</template>

<style scoped>
.roof-probe-meta-grid {
  display: grid;
  gap: 0.75rem;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
}

.meta-chip {
  background: var(--sf-surface);
  border: 1px solid var(--sf-border);
  border-radius: 0.75rem;
  margin: 0;
  padding: 0.75rem;
}

.meta-chip span,
.meta-chip strong {
  display: block;
}

.meta-chip span {
  color: var(--sf-text-muted);
  font-size: 0.75rem;
  font-weight: 900;
  letter-spacing: 0.03em;
  margin-bottom: 0.2rem;
  text-transform: uppercase;
}

.meta-chip strong {
  color: var(--sf-text);
  font-size: 0.95rem;
  text-transform: capitalize;
}

.meta-chip.is-warning {
  background: var(--sf-danger-soft);
  border-color: var(--sf-danger-border);
  cursor: help;
}

.meta-chip.is-warning span,
.meta-chip.is-warning strong {
  color: var(--sf-danger-text);
}

.meta-chip small {
  background: var(--sf-danger-dark);
  border-radius: 999px;
  color: white;
  display: inline-flex;
  font-size: 0.68rem;
  font-weight: 900;
  margin-top: 0.45rem;
  padding: 0.18rem 0.45rem;
  text-transform: uppercase;
}
</style>
