<script setup lang="ts">
import type { Catalog } from "~~/shared/pricebook/types"
import type { RoofArea } from "~~/shared/types"

defineProps<{ catalog: Catalog }>()
const area = defineModel<RoofArea>({ required: true })
</script>

<template>
  <div class="v2-area-section">
    <h3 class="v2-subhead">
      Slope &amp; job conditions
      <EstimateHelp
        label="Slope and conditions"
        text="Story, pitch, layers, and redeck affect labor and tearoff rates for this plane — they do not change its square footage (except footprint L×W uses pitch to adjust area)."
      />
    </h3>
    <div class="form-grid">
      <label class="field">
        <span>Story <EstimateHelp label="Story" /></span>
        <select v-model="area.story" class="input">
          <option v-for="rate in catalog.storyRates" :key="rate.key" :value="rate.key">
            {{ rate.key }}
          </option>
        </select>
      </label>
      <label class="field">
        <span>Pitch <EstimateHelp label="Pitch" /></span>
        <select v-model="area.pitch" class="input">
          <option v-for="rate in catalog.pitchRates" :key="rate.key" :value="rate.key">
            {{ rate.key }}
          </option>
        </select>
      </label>
      <label class="field">
        <span>Tearoff / layers <EstimateHelp label="Layers" /></span>
        <select v-model="area.layers" class="input">
          <option v-for="rate in catalog.tearoffRates" :key="rate.key" :value="rate.key">
            {{ rate.key }}
          </option>
        </select>
      </label>
      <label class="field">
        <span>Redeck <EstimateHelp label="Redeck" /></span>
        <select v-model="area.redeck" class="input">
          <option v-for="rate in catalog.redeckRates" :key="rate.key" :value="rate.key">
            {{ rate.key }}
          </option>
        </select>
      </label>
      <label class="field">
        <span>Access <EstimateHelp label="Access" /></span>
        <select v-model="area.access" class="input">
          <option value="Access">Access</option>
          <option value="No Access">No Access</option>
        </select>
      </label>
    </div>
  </div>
</template>
