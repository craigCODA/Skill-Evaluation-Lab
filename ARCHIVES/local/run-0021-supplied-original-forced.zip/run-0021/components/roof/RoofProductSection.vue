<script setup lang="ts">
import type { Catalog, ShingleProduct } from "~~/shared/pricebook/types"
import type { RoofingScope } from "~~/shared/types"

const roofing = defineModel<RoofingScope>({ required: true })
const { catalog } = defineProps<{ catalog: Catalog }>()

const selectedShingle = computed(() =>
  catalog.shingles.find((shingle) => shingle.id === roofing.value.shingle.productId)
)
const productType = computed({
  get: () => productTypeFromShingle(selectedShingle.value),
  set: (value: "asphalt" | "metal") => {
    selectShingle(productChoices(value)[0])
  }
})
const productManufacturers = computed(() =>
  uniqueManufacturers(productChoices(productType.value))
)
const productManufacturer = computed({
  get: () => selectedShingle.value?.manufacturer ?? productManufacturers.value[0] ?? "",
  set: (value: string) => selectShingle(productChoices(productType.value).find((s) => s.manufacturer === value))
})
const productStyles = computed(() =>
  productChoices(productType.value).filter((s) => s.manufacturer === productManufacturer.value)
)

function productChoices(type: "asphalt" | "metal") {
  return catalog.shingles.filter((s) => productTypeFromShingle(s) === type)
}

function productTypeFromShingle(shingle?: ShingleProduct) {
  return shingle?.type === "steel" ? "metal" : "asphalt"
}

function uniqueManufacturers(products: ShingleProduct[]) {
  return Array.from(new Set(products.map((p) => p.manufacturer)))
}

function selectShingle(shingle: ShingleProduct | undefined) {
  roofing.value.shingle.productId = shingle?.id ?? ""
  const nextColor = shingle?.colors.find((color) => color.id === roofing.value.shingle.colorId)
  roofing.value.shingle.colorId = nextColor?.id ?? ""
}

function onProductStyleChange(productId: string) {
  selectShingle(productStyles.value.find((shingle) => shingle.id === productId))
}

function formatMoney(value: number) {
  return value.toLocaleString(undefined, { style: "currency", currency: "USD" })
}
</script>

<template>
  <section class="card v2-card v2-section-product">
    <h2>
      Shingle product &amp; warranty
      <EstimateHelp label="Product" text="Product, color, and warranty apply to the whole job — same on every plane." />
    </h2>
    <div class="form-grid">
      <label class="field">
        <span>Product type <EstimateHelp label="Product Type" /></span>
        <select v-model="productType" class="input">
          <option value="asphalt">Asphalt shingle</option>
          <option value="metal">Metal</option>
        </select>
      </label>
      <label class="field">
        <span>Manufacturer <EstimateHelp label="Manufacturer" /></span>
        <select v-model="productManufacturer" class="input">
          <option v-for="m in productManufacturers" :key="m" :value="m">{{ m }}</option>
        </select>
      </label>
      <label class="field">
        <span>Product style <EstimateHelp label="Product Style" /></span>
        <select
          class="input"
          :value="roofing.shingle.productId"
          @change="onProductStyleChange(($event.target as HTMLSelectElement).value)"
        >
          <option value="">Select product</option>
          <option v-for="shingle in productStyles" :key="shingle.id" :value="shingle.id">
            {{ shingle.variety }} ({{ formatMoney(shingle.pricePerSquare) }}/sq)
          </option>
        </select>
      </label>
      <label class="field">
        <span>Color <EstimateHelp label="Color" /></span>
        <select v-model="roofing.shingle.colorId" class="input">
          <option value="">Select color</option>
          <option v-for="color in selectedShingle?.colors ?? []" :key="color.id" :value="color.id">
            {{ color.name }}
          </option>
        </select>
      </label>
      <label class="field">
        <span>Fastener <EstimateHelp label="Fastener" /></span>
        <select v-model="roofing.shingle.fastener" class="input">
          <option value="galvanized-6">6 galvanized nails</option>
          <option value="hand-nail-6">6 hand nails</option>
        </select>
      </label>
      <label class="field">
        <span>Warranty <EstimateHelp label="Warranty" /></span>
        <select v-model="roofing.shingle.warranty" class="input">
          <option v-for="w in catalog.warrantyUpcharges" :key="w.tier" :value="w.tier">
            {{ w.displayName }} (+{{ formatMoney(w.perSquare) }}/sq)
          </option>
        </select>
      </label>
      <label class="field">
        <span>Ridge type <EstimateHelp label="Ridge Type" /></span>
        <select v-model="roofing.ridgeStyle" class="input">
          <option value="new-standard">Standard</option>
          <option value="new-high-hip">High hip</option>
        </select>
      </label>
      <label class="field">
        <span>Starter type <EstimateHelp label="Starter Type" /></span>
        <select v-model="roofing.starterType" class="input">
          <option value="roll">Roll</option>
          <option value="preform">Preform</option>
        </select>
      </label>
    </div>
  </section>
</template>
