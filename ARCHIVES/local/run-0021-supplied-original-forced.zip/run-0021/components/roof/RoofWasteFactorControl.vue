<script setup lang="ts">
import type { RoofProbeWasteOption } from "~~/shared/roofMeasurement";

const { isSuggested, suggestedWasteFactor, wasteOptions, wastePercent } = defineProps<{
  isSuggested: boolean;
  suggestedWasteFactor: number;
  wasteOptions: RoofProbeWasteOption[];
  wastePercent: number;
}>();

const wasteFactor = defineModel<number>("wasteFactor", { required: true });

function optionLabel(option: RoofProbeWasteOption): string {
  if (option.factor === suggestedWasteFactor) {
    return `${option.label} (suggested)`;
  }
  return option.label;
}
</script>

<template>
  <section class="waste-control">
    <div>
      <p class="control-label">Waste factor</p>
      <h3>Fine tune order squares</h3>
      <p class="muted">
        Adjust the expected waste for cuts, hips, valleys, and crew preference.
      </p>
    </div>
    <label class="waste-field">
      <span>Expected waste</span>
      <select v-model.number="wasteFactor" class="input waste-select">
        <option
          v-for="option in wasteOptions"
          :key="option.id"
          :value="option.factor"
        >
          {{ optionLabel(option) }}
        </option>
      </select>
    </label>
    <div class="waste-summary">
      <strong>{{ wastePercent }}%</strong>
      <span>{{ isSuggested ? "Suggested for this roof" : "Custom waste selection" }}</span>
    </div>
  </section>
</template>

<style scoped>
.waste-control {
  align-items: center;
  background: var(--sf-surface);
  border: 1px solid var(--sf-border);
  border-radius: 1rem;
  display: grid;
  gap: 1rem;
  grid-template-columns: minmax(0, 1fr) minmax(13rem, 18rem) auto;
  padding: 1rem;
}

.waste-control h3 {
  font-size: 1rem;
  margin: 0.1rem 0 0.2rem;
}

.waste-control .muted {
  margin: 0;
}

.control-label {
  color: var(--sf-action);
  font-size: 0.72rem;
  font-weight: 900;
  letter-spacing: 0.08em;
  margin: 0;
  text-transform: uppercase;
}

.waste-field {
  display: grid;
  gap: 0.35rem;
}

.waste-field span {
  color: var(--sf-text-soft);
  font-size: 0.8rem;
  font-weight: 900;
}

.waste-select {
  font-size: 0.85rem;
  min-width: 0;
  width: 100%;
}

.waste-summary {
  background: var(--sf-action);
  border-radius: 0.85rem;
  color: var(--sf-surface);
  min-width: 8.5rem;
  padding: 0.75rem 0.9rem;
  text-align: center;
}

.waste-summary strong,
.waste-summary span {
  display: block;
}

.waste-summary strong {
  font-size: 1.4rem;
  line-height: 1;
}

.waste-summary span {
  font-size: 0.72rem;
  font-weight: 800;
  margin-top: 0.25rem;
  opacity: 0.92;
}

@media (max-width: 860px) {
  .waste-control {
    align-items: stretch;
    grid-template-columns: 1fr;
  }

  .waste-summary {
    text-align: left;
  }
}
</style>
