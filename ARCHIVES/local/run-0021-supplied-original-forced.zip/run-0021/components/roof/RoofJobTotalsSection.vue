<script setup lang="ts">
import type { RoofingScope } from "~~/shared/types"

const roofing = defineModel<RoofingScope>({ required: true })
</script>

<template>
  <section class="card v2-card v2-section-job">
    <h2>
      Whole roof totals
      <EstimateHelp
        label="Whole roof totals"
        text="Ridge and hip length apply to the entire job — enter once here, not per plane. Per-plane eave, rake, and valley edges are on each plane tab."
      />
    </h2>
    <div class="form-grid form-grid-four">
      <label class="field">
        <span>Ridge (linear ft) <EstimateHelp label="Ridge LF" /></span>
        <input v-model.number="roofing.ridgeLf" class="input" type="number" min="0" step="0.1">
      </label>
      <label class="field">
        <span>Hip (linear ft) <EstimateHelp label="Hip LF" /></span>
        <input v-model.number="roofing.hipLf" class="input" type="number" min="0" step="0.1">
      </label>
    </div>
  </section>
</template>

<style scoped>
.form-grid-four {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}
</style>
