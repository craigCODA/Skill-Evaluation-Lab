<script setup lang="ts">
import "~/assets/css/roof-image-measure-panel.css";
import type { CustomerJobSummary, CustomerRecord, RoofMeasurement } from "~~/shared/types";
import { captureRoofDrawingScreenshot } from "~/utils/captureRoofDrawingScreenshot";
import { boundsSpanFeet, croppedFrameHeightFeet, croppedFrameWidthFeet, frameDistanceFeet, frameMidpoint, previewFeetPerPixel, scaleBarWidthPercent, type FramePoint, type RoofImageryCrop } from "~~/shared/roofImageryScale";
import type { RoofAreaShape, RoofAreaShapeColor, RoofIconMarker, RoofIconMarkerType, RoofLineMeasurement, RoofLineMeasurementType } from "~~/shared/roofLineMeasurements";
import { roofAreaShapeColorMeta, roofAreaShapeColors, roofIconMarkerMeta, roofIconMarkerTypes, roofLineMeasurementTypes, roofLinePitchFactor, roofLineUsesPitch, roofPitchRiseOptions, roofLineTypeMeta } from "~~/shared/roofLineMeasurements";
import type { RoofImageryGeoref } from "~~/shared/types";

const { assetCustomerJobs = [], assetCustomers = [], assetSaveStatus = "", assetSelectedCustomerId = "", assetSelectedJobId = "", isSavingAsset = false, measurement } = defineProps<{
  assetCustomerJobs?: CustomerJobSummary[];
  assetCustomers?: CustomerRecord[];
  assetSelectedCustomerId?: string;
  assetSelectedJobId?: string;
  assetSaveStatus?: string;
  isSavingAsset?: boolean;
  measurement: RoofMeasurement;
}>();

const emit = defineEmits<{
  customerSelected: [customerId: string];
  saveDrawingAsset: [payload: {
    jobId: string;
    label: string;
    imageDataUrl: string;
  }];
}>();

const lines = defineModel<RoofLineMeasurement[]>("lines", { required: true });
const markers = defineModel<RoofIconMarker[]>("markers", { required: true });
const areaShapes = defineModel<RoofAreaShape[]>("areaShapes", { required: true });

const activeToolTab = ref<"lines" | "icons" | "areas" | "actions">("lines");
const assetCustomerId = ref("");
const assetJobId = ref("");
const assetLabel = ref("Overhead Image of Roof Plan for Crew");
watch(() => [assetSelectedCustomerId, assetSelectedJobId], ([customerId, jobId]) => {
  if (customerId) assetCustomerId.value = customerId; if (jobId) assetJobId.value = jobId;
}, { immediate: true });
const measureMode = ref(false);
const activeLineType = ref<RoofLineMeasurementType>("measurement");
const activeMarkerType = ref<RoofIconMarkerType | null>(null);
const shapeMode = ref(false);
const activeShapeColor = ref<RoofAreaShapeColor>("pink");
const activePitchRiseOver12 = ref(6);
const previewFrameRef = ref<HTMLElement | null>(null);
const measureDraft = ref<{ start: FramePoint; end: FramePoint } | null>(null);
const shapeDraft = ref<FramePoint[]>([]);
const shapeCloseHitRadius = 3;
const roofObjectMarkerTypes = roofIconMarkerTypes.filter((item) => !item.markerText);
const roofNumberMarkerTypes = roofIconMarkerTypes.filter((item) => item.markerText);
const toolTabs: { key: "lines" | "areas" | "icons" | "actions"; label: string }[] = [{ key: "lines", label: "Measure" }, { key: "areas", label: "Areas" }, { key: "icons", label: "Icons" }, { key: "actions", label: "Actions" }];
const primaryPitchRiseOver12 = computed(() => {
  return measurement.segments.find((segment) => segment.pitchRiseOver12 !== undefined)?.pitchRiseOver12;
});

watch(primaryPitchRiseOver12, (pitch) => {
  if (pitch === undefined) return;
  activePitchRiseOver12.value = nearestPitchOption(pitch);
}, { immediate: true });

const roofCrop = computed(() => {
  const outlines = measurement.imagery?.maskGeometry?.outlines ?? [];
  if (!outlines.length) return null;

  let left = 1;
  let top = 1;
  let right = 0;
  let bottom = 0;
  for (const outline of outlines) {
    left = Math.min(left, outline.boundingBox.left / 100);
    top = Math.min(top, outline.boundingBox.top / 100);
    right = Math.max(right, (outline.boundingBox.left + outline.boundingBox.width) / 100);
    bottom = Math.max(bottom, (outline.boundingBox.top + outline.boundingBox.height) / 100);
  }

  const centerX = (left + right) / 2;
  const centerY = (top + bottom) / 2;
  const padded = Math.max(right - left, bottom - top) * 1.7;
  const size = Math.min(1, Math.max(0.4, padded));
  return {
    cx: Math.min(Math.max(centerX - size / 2, 0), 1 - size),
    cy: Math.min(Math.max(centerY - size / 2, 0), 1 - size),
    size,
  };
});

const effectiveCrop = computed((): RoofImageryCrop => {
  return roofCrop.value ?? { cx: 0, cy: 0, size: 1 };
});

const previewFrameStyle = computed((): Record<string, string> => {
  const georef = measurement.imagery?.georef;
  if (!georef?.previewWidthPx || !georef?.previewHeightPx) return {};
  return {
    aspectRatio: `${georef.previewWidthPx} / ${georef.previewHeightPx}`,
  };
});

const canvasStyle = computed((): Record<string, string> => {
  const crop = effectiveCrop.value;
  if (!roofCrop.value) return {};
  return {
    transform: `scale(${1 / crop.size}) translate(${-crop.cx * 100}%, ${-crop.cy * 100}%)`,
    transformOrigin: "0 0",
  };
});

const imageryGeoref = computed((): RoofImageryGeoref | undefined => {
  if (measurement.imagery?.georef) return measurement.imagery.georef;
  const bounds = measurement.imagery?.bounds;
  if (!bounds) return undefined;
  const span = boundsSpanFeet(bounds);
  return {
    sourceWidthPx: 1,
    sourceHeightPx: 1,
    previewWidthPx: 1,
    previewHeightPx: 1,
    widthMeters: span.widthFt / 3.28084,
    heightMeters: span.heightFt / 3.28084,
    pixelSizeMeters: 0.1,
  };
});

const frameWidthFeet = computed(() => {
  const georef = imageryGeoref.value;
  if (!georef) return undefined;
  return croppedFrameWidthFeet(georef, effectiveCrop.value);
});

const frameHeightFeet = computed(() => {
  const georef = imageryGeoref.value;
  if (!georef) return undefined;
  return croppedFrameHeightFeet(georef, effectiveCrop.value);
});

const measureDraftFeet = computed(() => {
  const draft = measureDraft.value;
  const w = frameWidthFeet.value;
  const h = frameHeightFeet.value;
  if (!draft || w === undefined || h === undefined) return null;
  return frameDistanceFeet(draft.start, draft.end, w, h);
});

const scaleLegend = computed(() => {
  const widthFt = frameWidthFeet.value;
  const georef = imageryGeoref.value;
  if (!widthFt || !georef) return null;
  const barFeet = widthFt >= 25 ? 10 : 5;
  const midFeet = barFeet / 2;
  const feetPerPixel = previewFeetPerPixel(georef);
  const resolutionNote = measurement.imagery?.georef
    ? `${formatNumber(feetPerPixel.x, 2)} ft/px`
    : "estimated scale";
  return {
    barFeet,
    midFeet,
    barWidth: scaleBarWidthPercent(barFeet, widthFt),
    midWidth: scaleBarWidthPercent(midFeet, widthFt),
    note: `~${formatNumber(widthFt, 0)} ft across - ${resolutionNote}`,
  };
});

function lineColor(type: RoofLineMeasurementType): string {
  return roofLineTypeMeta(type).color;
}

function isCautionTapeLine(type: RoofLineMeasurementType): boolean {
  return type === "caution-tape";
}

function activeTypeUsesPitch(): boolean {
  return roofLineUsesPitch(activeLineType.value);
}

function activePitchFactorLabel(): string {
  return roofLinePitchFactor(activePitchRiseOver12.value).toFixed(3);
}

function formatNumber(value?: number, digits = 1): string {
  if (value === undefined) return "Not available";
  return value.toLocaleString(undefined, {
    maximumFractionDigits: digits,
    minimumFractionDigits: digits,
  });
}

function selectLineType(type: RoofLineMeasurementType) {
  activeToolTab.value = "lines";
  activeLineType.value = type;
  measureMode.value = true;
  measureDraft.value = null;
  activeMarkerType.value = null;
  shapeMode.value = false;
  shapeDraft.value = [];
}

function selectCautionTapeTool() {
  activeToolTab.value = "icons";
  activeLineType.value = "caution-tape";
  measureMode.value = true;
  measureDraft.value = null;
  activeMarkerType.value = null;
  shapeMode.value = false;
  shapeDraft.value = [];
}

function clearMeasureLines() {
  lines.value = lines.value.filter((line) => isCautionTapeLine(line.type));
  measureDraft.value = null;
}

function clearCautionTapeLines() {
  lines.value = lines.value.filter((line) => !isCautionTapeLine(line.type));
  if (isCautionTapeLine(activeLineType.value)) measureDraft.value = null;
}

function setMarkerMode(type: RoofIconMarkerType) {
  activeToolTab.value = "icons";
  activeMarkerType.value = activeMarkerType.value === type ? null : type;
  measureMode.value = false;
  measureDraft.value = null;
  shapeMode.value = false;
  shapeDraft.value = [];
}

function addMarker(point: FramePoint) {
  const type = activeMarkerType.value;
  if (!type) return;
  markers.value = [
    ...markers.value,
    {
      id: crypto.randomUUID(),
      type,
      point,
    },
  ];
}

function removeMarker(markerId: string) {
  markers.value = markers.value.filter((marker) => marker.id !== markerId);
}

function clearMarkers() {
  markers.value = [];
}

function selectAreaColor(color: RoofAreaShapeColor) {
  activeToolTab.value = "areas";
  activeShapeColor.value = color;
  shapeMode.value = true;
  activeMarkerType.value = null;
  measureMode.value = false;
  measureDraft.value = null;
}

function addShapePoint(point: FramePoint) {
  if (shapeDraft.value.length >= 3 && isClosingShape(point)) {
    finishShape();
    return;
  }
  shapeDraft.value = [...shapeDraft.value, point];
}

function isClosingShape(point: FramePoint): boolean {
  const start = shapeDraft.value[0];
  if (!start) return false;
  const dx = point.x - start.x;
  const dy = point.y - start.y;
  return Math.hypot(dx, dy) <= shapeCloseHitRadius;
}

function finishShape() {
  if (shapeDraft.value.length < 3) return;
  areaShapes.value = [
    ...areaShapes.value,
    {
      id: crypto.randomUUID(),
      color: activeShapeColor.value,
      points: shapeDraft.value,
    },
  ];
  shapeDraft.value = [];
}

function cancelShape() {
  shapeDraft.value = [];
  shapeMode.value = false;
}

function clearAreaShapes() {
  areaShapes.value = [];
  shapeDraft.value = [];
}

function pointerToFrame(event: { clientX: number; clientY: number }): FramePoint {
  const el = previewFrameRef.value;
  if (!el) return { x: 0, y: 0 };
  const rect = el.getBoundingClientRect();
  return {
    x: Math.min(100, Math.max(0, ((event.clientX - rect.left) / rect.width) * 100)),
    y: Math.min(100, Math.max(0, ((event.clientY - rect.top) / rect.height) * 100)),
  };
}

function onMeasurePointerDown(event: PointerEvent) {
  if (activeMarkerType.value) {
    event.preventDefault();
    event.stopPropagation();
    addMarker(pointerToFrame(event));
    return;
  }
  if (shapeMode.value) {
    event.preventDefault();
    event.stopPropagation();
    addShapePoint(pointerToFrame(event));
    return;
  }
  if (!measureMode.value) return;
  event.preventDefault();
  event.stopPropagation();
  const point = pointerToFrame(event);
  measureDraft.value = { start: point, end: point };
  previewFrameRef.value?.setPointerCapture(event.pointerId);
}

function onMeasurePointerMove(event: PointerEvent) {
  if (!measureDraft.value) return;
  measureDraft.value = { ...measureDraft.value, end: pointerToFrame(event) };
}

function onMeasurePointerUp(event: PointerEvent) {
  if (!measureDraft.value) return;
  previewFrameRef.value?.releasePointerCapture(event.pointerId);
  const w = frameWidthFeet.value;
  const h = frameHeightFeet.value;
  if (w !== undefined && h !== undefined) {
    const feet = frameDistanceFeet(measureDraft.value.start, measureDraft.value.end, w, h);
    if (feet >= 0.5) {
      lines.value = [
        ...lines.value,
        {
          id: crypto.randomUUID(),
          type: activeLineType.value,
          start: measureDraft.value.start,
          end: measureDraft.value.end,
          pitchRiseOver12: activeTypeUsesPitch() ? activePitchRiseOver12.value : undefined,
          feet,
        },
      ];
    }
  }
  measureDraft.value = null;
}

function measureLabelStyle(start: FramePoint, end: FramePoint): Record<string, string> {
  const mid = frameMidpoint(start, end);
  return {
    left: `${mid.x}%`,
    top: `${mid.y}%`,
    transform: "translate(-50%, -50%)",
  };
}

function markerPointStyle(point: FramePoint): Record<string, string> {
  return {
    left: `${point.x}%`,
    top: `${point.y}%`,
  };
}

function shapePoints(points: FramePoint[]): string {
  return points.map((point) => `${point.x},${point.y}`).join(" ");
}

function shapeColorValue(color: RoofAreaShapeColor): string {
  return roofAreaShapeColorMeta(color).value;
}

function shapePatternId(color: RoofAreaShapeColor): string {
  return `roof-area-pattern-${color}`;
}

function setActiveToolTab(tab: "lines" | "icons" | "areas" | "actions") {
  activeToolTab.value = tab;
  measureDraft.value = null;
  shapeDraft.value = [];
  measureMode.value = false;
  activeMarkerType.value = null;
  shapeMode.value = false;
}

async function saveDrawingAsset() {
  if (!assetJobId.value) return;
  const imageDataUrl = await captureRoofDrawingScreenshot({
    measurement,
    crop: effectiveCrop.value,
    lines: lines.value,
    markers: markers.value,
    areaShapes: areaShapes.value,
  });
  emit("saveDrawingAsset", {
    jobId: assetJobId.value,
    label: assetLabel.value,
    imageDataUrl,
  });
}

function nearestPitchOption(value: number): number {
  return roofPitchRiseOptions.reduce((nearest, option) => {
    return Math.abs(option - value) < Math.abs(nearest - value) ? option : nearest;
  }, roofPitchRiseOptions[0]);
}
</script>

<template>
  <figure class="roof-preview">
    <div
      ref="previewFrameRef"
      class="roof-preview-frame"
      :class="{ 'is-measuring': measureMode, 'is-placing-marker': activeMarkerType, 'is-drawing-shape': shapeMode }"
      :style="previewFrameStyle"
      @pointerdown="onMeasurePointerDown"
      @pointermove="onMeasurePointerMove"
      @pointerup="onMeasurePointerUp"
      @pointercancel="onMeasurePointerUp"
    >
      <div class="roof-preview-canvas" :style="canvasStyle">
        <img
          class="roof-preview-image"
          :src="measurement.imagery?.previewDataUrl"
          alt="Aerial roof preview"
        >
      </div>

      <svg
        v-if="areaShapes.length || shapeDraft.length"
        class="roof-area-layer"
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        aria-label="Shaded roof area markups"
      >
        <defs>
          <pattern
            v-for="item in roofAreaShapeColors"
            :id="shapePatternId(item.color)"
            :key="item.color"
            width="5"
            height="5"
            patternUnits="userSpaceOnUse"
            patternTransform="rotate(45)"
          >
            <line
              x1="0"
              y1="0"
              x2="0"
              y2="5"
              :stroke="item.value"
              stroke-opacity="0.55"
              stroke-width="1.2"
            />
          </pattern>
        </defs>
        <g
          v-for="shape in areaShapes"
          :key="shape.id"
          class="roof-area-shape"
        >
          <polygon
            :points="shapePoints(shape.points)"
            :fill="shapeColorValue(shape.color)"
            fill-opacity="0.2"
            :stroke="shapeColorValue(shape.color)"
          />
          <polygon
            :points="shapePoints(shape.points)"
            :fill="`url(#${shapePatternId(shape.color)})`"
          />
        </g>
        <polyline
          v-if="shapeDraft.length"
          class="roof-area-draft-line"
          :points="shapePoints(shapeDraft)"
          :stroke="shapeColorValue(activeShapeColor)"
        />
        <circle
          v-for="(point, index) in shapeDraft"
          :key="`shape-draft-${index}`"
          class="roof-area-draft-point"
          :class="{ 'is-start': index === 0 && shapeDraft.length >= 3 }"
          :cx="point.x"
          :cy="point.y"
          r="1.15"
          :fill="shapeColorValue(activeShapeColor)"
        />
      </svg>

      <svg
        v-if="lines.length || measureDraft"
        class="roof-measure-layer"
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <line
          v-for="line in lines"
          :key="line.id"
          :class="{ 'roof-caution-tape-base': isCautionTapeLine(line.type) }"
          :x1="line.start.x"
          :y1="line.start.y"
          :x2="line.end.x"
          :y2="line.end.y"
          :style="{ stroke: lineColor(line.type) }"
        />
        <line
          v-for="line in lines.filter((item) => isCautionTapeLine(item.type))"
          :key="`${line.id}-caution-dashes`"
          class="roof-caution-tape-dashes"
          :x1="line.start.x"
          :y1="line.start.y"
          :x2="line.end.x"
          :y2="line.end.y"
        />
        <line
          v-if="measureDraft"
          class="roof-measure-draft"
          :class="{ 'roof-caution-tape-base': isCautionTapeLine(activeLineType) }"
          :x1="measureDraft.start.x"
          :y1="measureDraft.start.y"
          :x2="measureDraft.end.x"
          :y2="measureDraft.end.y"
          :style="{ stroke: lineColor(activeLineType) }"
        />
        <line
          v-if="measureDraft && isCautionTapeLine(activeLineType)"
          class="roof-measure-draft roof-caution-tape-dashes"
          :x1="measureDraft.start.x"
          :y1="measureDraft.start.y"
          :x2="measureDraft.end.x"
          :y2="measureDraft.end.y"
        />
      </svg>

      <span
        v-for="line in lines.filter((item) => !isCautionTapeLine(item.type))"
        :key="`${line.id}-label`"
        class="roof-measure-label"
        :style="{
          ...measureLabelStyle(line.start, line.end),
          '--line-color': lineColor(line.type),
        }"
      >
        {{ formatNumber(line.feet, 1) }} ft
      </span>
      <span
        v-if="measureDraft && measureDraftFeet !== null && measureDraftFeet >= 0.5 && !isCautionTapeLine(activeLineType)"
        class="roof-measure-label roof-measure-label-draft"
        :style="{
          ...measureLabelStyle(measureDraft.start, measureDraft.end),
          '--line-color': lineColor(activeLineType),
        }"
      >
        {{ formatNumber(measureDraftFeet, 1) }} ft
      </span>

      <button
        v-for="marker in markers"
        :key="marker.id"
        type="button"
        class="roof-icon-marker"
        :class="{ 'is-number-marker': roofIconMarkerMeta(marker.type).markerText }"
        :style="markerPointStyle(marker.point)"
        :aria-label="`Remove ${roofIconMarkerMeta(marker.type).label} marker`"
        :title="`Remove ${roofIconMarkerMeta(marker.type).label}`"
        @click.stop="removeMarker(marker.id)"
      >
        <img
          v-if="roofIconMarkerMeta(marker.type).iconPath"
          :src="roofIconMarkerMeta(marker.type).iconPath"
          :alt="roofIconMarkerMeta(marker.type).label"
        >
        <span v-else>{{ roofIconMarkerMeta(marker.type).markerText }}</span>
      </button>

      <div
        v-if="scaleLegend"
        class="roof-scale-legend"
        aria-label="Photo scale in feet"
      >
        <div
          class="roof-scale-bar"
          :style="{ width: `${scaleLegend.barWidth}%` }"
        >
          <span
            class="roof-scale-tick roof-scale-tick-mid"
            :style="{ left: `${scaleLegend.midWidth}%` }"
          />
        </div>
        <div class="roof-scale-labels">
          <span>0</span>
          <span>{{ scaleLegend.midFeet }} ft</span>
          <span>{{ scaleLegend.barFeet }} ft</span>
        </div>
        <p class="roof-scale-note">{{ scaleLegend.note }}</p>
      </div>

    </div>

    <div class="roof-preview-toolbar">
      <div class="roof-tool-tabs" role="tablist" aria-label="Drawing tools">
        <button
          v-for="tab in toolTabs"
          :key="tab.key"
          type="button"
          class="roof-tool-tab"
          :class="{ 'is-active': activeToolTab === tab.key }"
          role="tab"
          :aria-selected="activeToolTab === tab.key"
          @click="setActiveToolTab(tab.key)"
        >
          {{ tab.label }}
        </button>
      </div>

      <div v-if="activeToolTab === 'lines'" class="roof-tool-panel">
        <div class="roof-line-type-picker" aria-label="Line type">
        <button
          v-for="item in roofLineMeasurementTypes.filter((lineType) => !isCautionTapeLine(lineType.type))"
          :key="item.type"
          type="button"
          class="roof-line-type"
          :class="{ 'is-active': activeLineType === item.type }"
          :style="{ '--line-color': item.color }"
          @click="selectLineType(item.type)"
        >
          {{ item.label }}
        </button>
        </div>

        <label v-if="activeTypeUsesPitch()" class="roof-line-pitch-picker">
          <span>{{ roofLineTypeMeta(activeLineType).label }} pitch</span>
          <select v-model.number="activePitchRiseOver12">
            <option
              v-for="pitch in roofPitchRiseOptions"
              :key="pitch"
              :value="pitch"
            >
              {{ pitch }}:12
            </option>
          </select>
          <small>x{{ activePitchFactorLabel() }}</small>
        </label>

        <div class="roof-tool-actions" aria-label="Line actions">
          <button
            v-if="lines.some((line) => !isCautionTapeLine(line.type))"
            type="button"
            class="button secondary"
            @click="clearMeasureLines"
          >
            Clear lines
          </button>
        </div>
      </div>

      <div v-if="activeToolTab === 'icons'" class="roof-tool-panel">
        <div class="roof-icon-type-picker" aria-label="Markers">
          <div class="roof-icon-section roof-icon-section-safety">
            <span class="roof-icon-section-label">Site safety</span>
            <div class="roof-icon-options">
              <button
                type="button"
                class="roof-icon-type is-caution-tape"
                :class="{ 'is-active': measureMode && isCautionTapeLine(activeLineType) }"
                @click="selectCautionTapeTool"
              >
                <span class="roof-caution-tape-option" />
                Draw caution tape
              </button>
            </div>
          </div>

          <div class="roof-icon-section">
            <span class="roof-icon-section-label">Roof markers</span>
            <div class="roof-icon-options">
              <button
                v-for="item in roofObjectMarkerTypes"
                :key="item.type"
                type="button"
                class="roof-icon-type"
                :class="{ 'is-active': activeMarkerType === item.type }"
                @click="setMarkerMode(item.type)"
              >
                <img v-if="item.iconPath" :src="item.iconPath" alt="">
                {{ item.label }}
              </button>
            </div>
          </div>

          <div class="roof-icon-section">
            <span class="roof-icon-section-label">Number labels</span>
            <div class="roof-icon-options roof-icon-number-options">
              <button
                v-for="item in roofNumberMarkerTypes"
                :key="item.type"
                type="button"
                class="roof-icon-type roof-icon-number-type"
                :class="{ 'is-active': activeMarkerType === item.type }"
                @click="setMarkerMode(item.type)"
              >
                <span class="roof-icon-number-option">{{ item.markerText }}</span>
                {{ item.label }}
              </button>
            </div>
          </div>
        </div>

        <div class="roof-tool-actions" aria-label="Marker actions">
          <button
            v-if="markers.length"
            type="button"
            class="button secondary"
            @click="clearMarkers"
          >
            Clear icons
          </button>
          <button
            v-if="lines.some((line) => isCautionTapeLine(line.type))"
            type="button"
            class="button secondary"
            @click="clearCautionTapeLines"
          >
            Clear caution tape
          </button>
        </div>
      </div>

      <div v-if="activeToolTab === 'areas'" class="roof-tool-panel">
        <div class="roof-area-tool" aria-label="Shape fills">
        <button
          v-for="item in roofAreaShapeColors"
          :key="item.color"
          type="button"
          class="roof-area-color"
          :class="{ 'is-active': activeShapeColor === item.color }"
          :style="{ '--shape-color': item.value }"
          :aria-label="`${item.label} area color`"
          @click="selectAreaColor(item.color)"
        />
        </div>

        <div class="roof-tool-actions" aria-label="Area actions">
        <button
          v-if="shapeMode && shapeDraft.length"
          type="button"
          class="button secondary"
          @click="cancelShape"
        >
          Cancel shape
        </button>
        <button
          v-if="areaShapes.length"
          type="button"
          class="button secondary"
          @click="clearAreaShapes"
        >
          Clear areas
        </button>
        </div>
      </div>

      <RoofDrawingActionsPanel
        v-if="activeToolTab === 'actions'"
        v-model:customer-id="assetCustomerId"
        v-model:job-id="assetJobId"
        v-model:label="assetLabel"
        :customers="assetCustomers"
        :jobs="assetCustomerJobs"
        :is-saving="isSavingAsset"
        :save-status="assetSaveStatus"
        @customer-selected="emit('customerSelected', $event)"
        @save="saveDrawingAsset"
      />
    </div>

    <figcaption v-if="measureMode && isCautionTapeLine(activeLineType)">
      Click and drag on the photo to draw caution tape.
    </figcaption>
    <figcaption v-else-if="measureMode">
      Pick a line type, then click and drag on the photo. Measurements are added to the calculator.
    </figcaption>
    <figcaption v-else-if="activeMarkerType">
      Click the aerial photo to place {{ roofIconMarkerMeta(activeMarkerType).label.toLowerCase() }} icons. Click an icon to remove it.
    </figcaption>
    <figcaption v-else-if="shapeMode">
      Click points to outline an area, then click the first point again to close it. Use Clear areas to remove finished areas.
    </figcaption>
  </figure>
</template>

