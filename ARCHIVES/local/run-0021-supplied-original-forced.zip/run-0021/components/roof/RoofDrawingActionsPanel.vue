<script setup lang="ts">
import type { CustomerJobSummary, CustomerRecord } from "~~/shared/types"

const { customers, jobs } = defineProps<{
  customers: CustomerRecord[]
  jobs: CustomerJobSummary[]
  isSaving?: boolean
  saveStatus?: string
}>()

const selectedCustomerId = defineModel<string>("customerId", { required: true })
const selectedJobId = defineModel<string>("jobId", { required: true })
const assetLabel = defineModel<string>("label", { required: true })

const emit = defineEmits<{
  customerSelected: [customerId: string]
  save: []
}>()

function handleCustomerChange() {
  selectedJobId.value = ""
  emit("customerSelected", selectedCustomerId.value)
}

function jobWorkLabel(job: CustomerJobSummary): string {
  if (job.estimateType === "temporary-repair") return "Temporary repair"
  if (job.estimateType === "roof-proposal" || job.status === "roof-proposal") return "Roof proposal"
  return job.status.replace(/-/g, " ")
}
</script>

<template>
  <div class="roof-actions-panel">
    <div>
      <p class="roof-actions-title">Send drawing to customer job</p>
      <p class="roof-actions-copy">
        Save the current drawing as a job asset so it appears in the customer file.
      </p>
    </div>

    <label class="roof-actions-field">
      <span>Customer</span>
      <select v-model="selectedCustomerId" @change="handleCustomerChange">
        <option value="">Select customer...</option>
        <option v-for="customer in customers" :key="customer.id" :value="customer.id">
          {{ customer.displayName || customer.customer.companyName || customer.customer.firstName || "Unnamed customer" }}
        </option>
      </select>
    </label>

    <label class="roof-actions-field">
      <span>Job</span>
      <select v-model="selectedJobId" :disabled="!selectedCustomerId || !jobs.length">
        <option value="">{{ selectedCustomerId ? "Select job..." : "Select a customer first" }}</option>
        <option v-for="job in jobs" :key="job.id" :value="job.id">
          {{ job.number || jobWorkLabel(job) }} - {{ job.status }}
        </option>
      </select>
    </label>

    <label class="roof-actions-field">
      <span>
        Asset Label
        <button
          class="roof-actions-help"
          type="button"
          aria-describedby="asset-label-help-tooltip"
          aria-label="Asset label help"
        >
          ?
          <span id="asset-label-help-tooltip" class="roof-actions-help-tooltip" role="tooltip">
            Use a detailed name that says what this image is and who it is for. Example: Overhead Image of Roof Plan for Crew.
          </span>
        </button>
      </span>
      <input
        v-model="assetLabel"
        type="text"
        placeholder="Overhead Image of Roof Plan for Crew"
        title="Use a detailed name that says what this image is and who it is for."
      >
      <small>Example: Overhead Image of Roof Plan for Crew</small>
    </label>

    <div class="roof-tool-actions">
      <button
        class="button"
        type="button"
        :disabled="!selectedJobId || isSaving"
        @click="emit('save')"
      >
        {{ isSaving ? "Saving..." : "Save to job" }}
      </button>
      <span v-if="saveStatus" class="roof-actions-status">{{ saveStatus }}</span>
    </div>
  </div>
</template>
