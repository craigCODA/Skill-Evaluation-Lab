<script setup lang="ts">
import type { RoofArea } from "~~/shared/types"
import { roofAreaSquares, WASTE_PRESETS } from "~~/shared/roofArea"

const area = defineModel<RoofArea>({ required: true })

const summary = computed(() => roofAreaSquares(area.value))

onMounted(() => {
  if (!area.value.sizeInputMode) area.value.sizeInputMode = "squares"
  if (!area.value.dimensionBasis) area.value.dimensionBasis = "surface"
})

function setWastePreset(percent: number) {
  area.value.wastePercent = percent
}
</script>

<template>
  <div class="v2-area-section">
    <h3 class="v2-subhead">
      Plane size
      <EstimateHelp
        label="Plane size"
        text="Enter what you have from a measurement report (squares or sq ft) or measure length × width on site. Linear feet for drip edge and valleys go in the Edges section — not here."
      />
    </h3>

    <fieldset class="size-mode-fieldset">
      <legend class="sr-only">How are you entering this plane's size?</legend>
      <label class="size-mode-option">
        <input v-model="area.sizeInputMode" type="radio" value="squares">
        <span>I have squares <span class="muted">(EagleView / report)</span></span>
      </label>
      <label class="size-mode-option">
        <input v-model="area.sizeInputMode" type="radio" value="sqft">
        <span>I have sq ft <span class="muted">(report)</span></span>
      </label>
      <label class="size-mode-option">
        <input v-model="area.sizeInputMode" type="radio" value="dimensions">
        <span>Measure L × W <span class="muted">(on site)</span></span>
      </label>
    </fieldset>

    <div v-if="area.sizeInputMode === 'squares'" class="form-grid">
      <label class="field">
        <span>Roofing squares <EstimateHelp label="Squares" text="1 square = 100 sq ft of roof surface. Use the facet area from your report before waste." /></span>
        <input v-model.number="area.inputSquares" class="input" type="number" min="0" step="0.1">
      </label>
    </div>

    <div v-else-if="area.sizeInputMode === 'sqft'" class="form-grid">
      <label class="field">
        <span>Surface sq ft <EstimateHelp label="Surface sq ft" text="Total sloped roof surface for this plane, before waste." /></span>
        <input v-model.number="area.inputSurfaceSqft" class="input" type="number" min="0" step="1">
      </label>
    </div>

    <div v-else class="dimensions-layout">
      <div class="dimensions-fields">
        <label class="field dimension-field">
          <span>Length (ridge to eave, along slope) <EstimateHelp label="Slope length" text="Measure along the roof surface from the ridge down to the eave — not horizontal footprint." /></span>
          <input v-model.number="area.rafterFt" class="input" type="number" min="0" step="0.1">
        </label>
        <label class="field dimension-field">
          <span>Width (along the eave) <EstimateHelp label="Plane width" text="The span along the bottom edge of this roof plane — not drip-edge linear feet." /></span>
          <input v-model.number="area.eaveFt" class="input" type="number" min="0" step="0.1">
        </label>
      </div>
      <fieldset class="dimension-basis-fieldset">
        <legend>Measured as</legend>
        <label class="size-mode-option">
          <input v-model="area.dimensionBasis" type="radio" value="surface">
          <span>On the roof surface</span>
        </label>
        <label class="size-mode-option">
          <input v-model="area.dimensionBasis" type="radio" value="footprint">
          <span>Horizontal footprint <span class="muted">(pitch adjusts area)</span></span>
        </label>
      </fieldset>
    </div>

    <div class="waste-row">
      <label class="field waste-field">
        <span>Waste <EstimateHelp label="Waste percent" text="Added on top of surface area for cuts, hips, and valleys. 10% simple gable, 12% hips, 15% complex." /></span>
        <input v-model.number="area.wastePercent" class="input" type="number" min="0" step="1">
      </label>
      <div class="waste-presets">
        <button
          v-for="preset in WASTE_PRESETS"
          :key="preset.id"
          class="button secondary"
          type="button"
          @click="setWastePreset(preset.percent)"
        >
          {{ preset.label }}
        </button>
      </div>
    </div>

    <p class="size-summary" aria-live="polite">
      <strong>{{ summary.surfaceSqft.toFixed(0) }} sq ft</strong>
      → {{ summary.squaresBeforeWaste.toFixed(2) }} squares
      → <strong>{{ summary.squaresWithWaste.toFixed(2) }} squares with waste</strong>
    </p>
  </div>
</template>

<style scoped>
.dimensions-layout {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.dimensions-fields {
  align-items: end;
  display: grid;
  gap: 1rem;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.dimension-field > span {
  display: block;
  min-height: 2.75em;
}

.size-mode-fieldset,
.dimension-basis-fieldset {
  border: none;
  margin: 0 0 1rem;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.dimension-basis-fieldset {
  margin-bottom: 0;
}

.dimension-basis-fieldset legend {
  color: var(--sf-text-muted);
  font-size: 0.85rem;
  font-weight: 800;
  margin-bottom: 0.35rem;
}

.size-mode-option {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
}

.waste-row {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-end;
  gap: 0.75rem 1rem;
  margin-top: 0.5rem;
}

.waste-field {
  min-width: 7rem;
}

.waste-presets {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.size-summary {
  margin: 1rem 0 0;
  padding: 0.75rem 1rem;
  background: var(--sf-surface-subtle);
  border-radius: 8px;
  font-size: 0.95rem;
}

.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  border: 0;
}
</style>
