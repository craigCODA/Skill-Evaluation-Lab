<script setup lang="ts">
import type { RoofProbeStat } from "~~/shared/roofProbeReport";

defineProps<{
  stats: RoofProbeStat[];
}>();
</script>

<template>
  <div class="roof-probe-stats">
    <div
      v-for="stat in stats"
      :key="stat.id"
      class="stat-card"
      :class="{ 'is-order': stat.id === 'order-squares' }"
    >
      <p class="stat-label">{{ stat.label }}</p>
      <div class="stat-value">{{ stat.value }}</div>
      <p v-if="stat.note" class="stat-note">{{ stat.note }}</p>
    </div>
  </div>
</template>

<style scoped>
.roof-probe-stats {
  display: grid;
  gap: 0.9rem;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
}

.stat-card {
  background: var(--sf-section-cream);
  border: 1px solid var(--sf-section-cream-border);
  border-radius: 0.85rem;
  padding: 1rem;
}

.stat-card.is-order {
  background: var(--sf-section-green);
  border-color: var(--sf-section-green-border);
}

.stat-label {
  color: var(--sf-text-muted);
  font-size: 0.78rem;
  font-weight: 900;
  letter-spacing: 0.04em;
  margin: 0 0 0.25rem;
  text-transform: uppercase;
}

.stat-value {
  color: var(--sf-text);
  font-size: 1.65rem;
  font-weight: 900;
  line-height: 1;
}

.stat-note {
  color: var(--sf-action);
  font-size: 0.8rem;
  font-weight: 800;
  margin: 0.4rem 0 0;
}
</style>
