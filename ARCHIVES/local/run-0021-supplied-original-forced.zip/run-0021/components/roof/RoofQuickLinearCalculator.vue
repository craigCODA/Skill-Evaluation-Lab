<script setup lang="ts">
import type {
  RoofLineMeasurement,
  RoofLineMeasurementType,
} from "~~/shared/roofLineMeasurements";
import {
  roofLineAdjustedFeet,
  roofLineMeasurementTotals,
  roofLineMeasurementTypes,
  roofLinePitchFactor,
  roofLineUsesPitch,
  roofPitchRiseOptions,
  roofLineTypeMeta,
} from "~~/shared/roofLineMeasurements";

const measuredLines = defineModel<RoofLineMeasurement[]>("measuredLines", { required: true });

const fields = [
  { key: "ridge", label: "Ridge", hint: "Peak lines along the top" },
  { key: "hip", label: "Hip", hint: "Sloped outer corners" },
  { key: "valley", label: "Valley", hint: "Inner roof creases" },
  { key: "eave", label: "Eave", hint: "Bottom horizontal edges" },
  { key: "rake", label: "Rake", hint: "Sloped gable edges" },
] as const;

type LineKey = Extract<RoofLineMeasurementType, (typeof fields)[number]["key"]>;

const lines = reactive<Record<LineKey, number>>({
  ridge: 0,
  hip: 0,
  valley: 0,
  eave: 0,
  rake: 0,
});

const measuredTotals = computed(() => roofLineMeasurementTotals(measuredLines.value));
const measuredRoofLines = computed(() =>
  measuredLines.value.filter((line) => line.type !== "caution-tape"),
);

const combinedTotals = computed(() => {
  return fields.reduce(
    (totals, field) => {
      totals[field.key] = (lines[field.key] || 0) + (measuredTotals.value[field.key] || 0);
      return totals;
    },
    {} as Record<LineKey, number>,
  );
});

const totalLinearFt = computed(() =>
  fields.reduce((sum, field) => sum + (combinedTotals.value[field.key] || 0), 0),
);

const dripEdgeFt = computed(() => combinedTotals.value.eave + combinedTotals.value.rake);
const simpleMeasurementFt = computed(() => measuredTotals.value.measurement || 0);

function reset() {
  for (const field of fields) lines[field.key] = 0;
}

function formatFeet(value: number): string {
  return value.toLocaleString(undefined, {
    maximumFractionDigits: 1,
    minimumFractionDigits: value % 1 === 0 ? 0 : 1,
  });
}

function totalFor(type: RoofLineMeasurementType): number {
  if (type === "measurement") return measuredTotals.value.measurement || 0;
  if (type === "caution-tape") return measuredTotals.value["caution-tape"] || 0;
  return combinedTotals.value[type] || 0;
}

function updateLinePitch(lineId: string, pitchRiseOver12?: number) {
  measuredLines.value = measuredLines.value.map((line) => {
    if (line.id !== lineId) return line;
    return {
      ...line,
      pitchRiseOver12,
    };
  });
}

function onPitchChange(lineId: string, event: Event) {
  const value = event.target instanceof HTMLSelectElement ? event.target.value : "";
  updateLinePitch(lineId, value ? Number(value) : undefined);
}

function removeLine(lineId: string) {
  measuredLines.value = measuredLines.value.filter((line) => line.id !== lineId);
}

function clearLines() {
  measuredLines.value = measuredLines.value.filter((line) => line.type === "caution-tape");
}

function adjustedFeet(line: RoofLineMeasurement): number {
  return roofLineAdjustedFeet(line);
}

function pitchFactorLabel(line: RoofLineMeasurement): string {
  if (line.pitchRiseOver12 === undefined) return "plan";
  return `x${roofLinePitchFactor(line.pitchRiseOver12).toFixed(3)}`;
}
</script>

<template>
  <section class="roof-quick-calc">
    <div class="roof-quick-calc-header">
      <h3>Quick calculator</h3>
      <p class="muted">
        Measure lines on the photo, or use the scale bar to estimate, then enter feet here.
      </p>
    </div>

    <div class="roof-quick-calc-fields">
      <label v-for="field in fields" :key="field.key" class="field roof-quick-field">
        <span>
          {{ field.label }}
          <em
            v-if="measuredTotals[field.key]"
            class="roof-quick-measured"
          >
            +{{ formatFeet(measuredTotals[field.key]) }} measured
          </em>
          <em v-else class="roof-quick-hint">{{ field.hint }}</em>
        </span>
        <div class="roof-quick-input-wrap">
          <input
            v-model.number="lines[field.key]"
            class="input"
            type="number"
            min="0"
            step="1"
            placeholder="0"
          >
          <span class="roof-quick-unit">ft</span>
        </div>
      </label>
    </div>

    <div v-if="measuredRoofLines.length" class="roof-measured-lines">
      <div class="roof-measured-lines-header">
        <strong>Drawn lines</strong>
        <button type="button" @click="clearLines">Clear</button>
      </div>
      <ul>
        <li
          v-for="line in measuredRoofLines"
          :key="line.id"
          :style="{ '--line-color': roofLineTypeMeta(line.type).color }"
        >
          <span>
            <i />
            {{ roofLineTypeMeta(line.type).label }}
          </span>
          <div class="roof-measured-line-length">
            <strong>{{ formatFeet(adjustedFeet(line)) }} ft</strong>
            <small v-if="roofLineUsesPitch(line.type)">
              {{ formatFeet(line.feet) }} plan - {{ pitchFactorLabel(line) }}
            </small>
          </div>
          <select
            v-if="roofLineUsesPitch(line.type)"
            :value="line.pitchRiseOver12 ?? ''"
            aria-label="Pitch adjustment"
            @change="onPitchChange(line.id, $event)"
          >
            <option value="">Plan only</option>
            <option
              v-for="pitch in roofPitchRiseOptions"
              :key="pitch"
              :value="pitch"
            >
              {{ pitch }}:12
            </option>
          </select>
          <button
            type="button"
            :aria-label="`Remove ${roofLineTypeMeta(line.type).label} line`"
            @click="removeLine(line.id)"
          >
            x
          </button>
        </li>
      </ul>
    </div>

    <div class="roof-quick-totals">
      <div
        v-for="item in roofLineMeasurementTypes.filter((lineType) => lineType.countsTowardRoofTotal)"
        :key="item.type"
        class="roof-quick-total-row"
        :style="{ '--line-color': item.color }"
      >
        <span><i /> {{ item.label }}</span>
        <strong>{{ formatFeet(totalFor(item.type)) }} ft</strong>
      </div>
      <div class="roof-quick-total-row">
        <span>Total linear</span>
        <strong>{{ formatFeet(totalLinearFt) }} ft</strong>
      </div>
      <div class="roof-quick-total-row">
        <span>Drip edge (eave + rake)</span>
        <strong>{{ formatFeet(dripEdgeFt) }} ft</strong>
      </div>
      <div class="roof-quick-total-row">
        <span>Ridge cap (ridge)</span>
        <strong>{{ formatFeet(combinedTotals.ridge) }} ft</strong>
      </div>
      <div v-if="simpleMeasurementFt" class="roof-quick-total-row">
        <span>Simple measurements</span>
        <strong>{{ formatFeet(simpleMeasurementFt) }} ft</strong>
      </div>
    </div>

    <button type="button" class="button secondary roof-quick-reset" @click="reset">
      Clear manual entries
    </button>
  </section>
</template>

<style scoped>
.roof-quick-calc {
  background: var(--sf-section-cream);
  border: 1px solid var(--sf-border);
  border-radius: 0.85rem;
  display: grid;
  font-size: 0.78rem;
  gap: 0.8rem;
  min-width: 0;
  padding: 0.9rem;
  position: sticky;
  top: 1rem;
  width: 100%;
}

.roof-quick-calc-header h3 {
  font-size: 0.9rem;
  margin: 0 0 0.25rem;
}

.roof-quick-calc-header .muted {
  font-size: 0.7rem;
  line-height: 1.35;
  margin: 0;
}

.roof-quick-calc-fields {
  display: grid;
  gap: 0.65rem;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.roof-quick-field span {
  display: block;
  font-size: 0.72rem;
  font-weight: 700;
  margin-bottom: 0.2rem;
}

.roof-quick-hint {
  color: var(--sf-text-muted);
  display: none;
}

.roof-quick-measured {
  color: var(--sf-action);
  display: block;
  font-size: 0.68rem;
  font-style: normal;
  font-weight: 800;
  margin-top: 0.1rem;
}

.roof-quick-input-wrap {
  align-items: center;
  display: flex;
  gap: 0.35rem;
}

.roof-quick-input-wrap .input {
  flex: 1;
  font-size: 0.78rem;
  min-width: 0;
  padding: 0.35rem 0.45rem;
}

.roof-quick-unit {
  color: var(--sf-text-muted);
  font-size: 0.78rem;
  font-weight: 700;
  min-width: 1rem;
}

.roof-measured-lines {
  border-top: 1px solid var(--sf-border);
  display: grid;
  gap: 0.55rem;
  padding-top: 0.75rem;
}

.roof-measured-lines-header {
  align-items: center;
  display: flex;
  justify-content: space-between;
}

.roof-measured-lines-header button,
.roof-measured-lines li button {
  background: transparent;
  border: 0;
  color: var(--sf-action);
  cursor: pointer;
  font: inherit;
  font-size: 0.72rem;
  font-weight: 900;
  padding: 0;
}

.roof-measured-lines ul {
  display: grid;
  gap: 0.35rem;
  list-style: none;
  margin: 0;
  max-height: 12rem;
  overflow: auto;
  padding: 0;
}

.roof-measured-lines li {
  align-items: center;
  background: var(--sf-surface);
  border: 1px solid color-mix(in oklab, var(--sf-border) 75%, white);
  border-radius: 0.5rem;
  display: grid;
  gap: 0.35rem;
  grid-template-columns: minmax(4rem, 0.8fr) minmax(5.5rem, 1fr) auto auto;
  padding: 0.35rem 0.45rem;
}

.roof-measured-lines li span,
.roof-quick-total-row span {
  align-items: center;
  display: inline-flex;
  gap: 0.35rem;
  min-width: 0;
}

.roof-measured-lines i,
.roof-quick-total-row i {
  background: var(--line-color);
  border: 1px solid rgb(23 33 58 / 18%);
  border-radius: 999px;
  display: inline-block;
  flex: 0 0 auto;
  height: 0.55rem;
  width: 0.55rem;
}

.roof-measured-line-length {
  display: grid;
  gap: 0.05rem;
  justify-items: end;
}

.roof-measured-line-length small {
  color: var(--sf-text-muted);
  font-size: 0.65rem;
  font-weight: 700;
  white-space: nowrap;
}

.roof-measured-lines select {
  border: 1px solid var(--sf-border);
  border-radius: 999px;
  color: var(--sf-text);
  font: inherit;
  font-size: 0.72rem;
  font-weight: 800;
  max-width: 5.1rem;
  padding: 0.2rem 0.35rem;
}

.roof-quick-totals {
  border-top: 1px solid var(--sf-border);
  display: grid;
  gap: 0.45rem;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  padding-top: 0.65rem;
}

.roof-quick-total-row {
  align-items: baseline;
  background: var(--sf-surface);
  border: 1px solid color-mix(in oklab, var(--sf-border) 75%, white);
  border-radius: 0.5rem;
  display: flex;
  justify-content: space-between;
  gap: 0.4rem;
  padding: 0.4rem 0.5rem;
}

.roof-quick-total-row span {
  color: var(--sf-text-soft);
  font-size: 0.76rem;
  line-height: 1.25;
}

.roof-quick-total-row strong {
  color: var(--sf-text);
  font-size: 0.8rem;
  white-space: nowrap;
}

.roof-quick-reset {
  font-size: 0.78rem;
  justify-self: start;
  padding: 0.45rem 0.65rem;
}

@media (max-width: 1120px) {
  .roof-quick-calc-fields,
  .roof-quick-totals {
    grid-template-columns: 1fr;
  }
}
</style>
