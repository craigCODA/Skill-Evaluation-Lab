<template>
  <section class="roof-page-section title-section">
    <p class="section-eyebrow">Powered by Shingle.Show</p>
    <h1>ShingleScope Roof Scan</h1>
    <p>
      Search a property, review aerial measurements, draw roof line items, estimate ventilation,
      and turn roof geometry into practical takeoff numbers.
    </p>
  </section>
</template>

<style scoped>
.roof-page-section {
  border: 1px solid;
  border-radius: 1.1rem;
  box-shadow: 0 10px 30px rgb(23 33 58 / 6%);
  padding: 1.15rem 1.25rem;
}

.title-section {
  background: var(--sf-section-blue);
  border-color: var(--sf-section-blue-border);
}

.section-eyebrow {
  color: var(--sf-action);
  font-size: 0.72rem;
  font-weight: 900;
  letter-spacing: 0.08em;
  margin: 0 0 0.35rem;
  text-transform: uppercase;
}

h1 {
  margin: 0 0 0.4rem;
}

p {
  color: var(--sf-text-soft);
  margin: 0;
  max-width: 58rem;
}
</style>
