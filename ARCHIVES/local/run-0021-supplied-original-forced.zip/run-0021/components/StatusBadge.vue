<script setup lang="ts">
import { estimateStatusStyle } from "~~/shared/estimateStatus"

const { status } = defineProps<{
  status: string
}>()

const { formatStatus } = useFormatters()
const style = computed(() => estimateStatusStyle(status))
</script>

<template>
  <span class="badge" :class="style.badgeClass">{{ formatStatus(status) }}</span>
</template>
