<script setup lang="ts">
import type { CompanyLocation } from "~~/shared/types"
import { SUPPORTED_STATE_OPTIONS } from "~~/shared/companyLocation"
import { newCompanyLocation } from "~~/shared/company"

const locations = defineModel<CompanyLocation[]>({ required: true })

function addLocation() {
  locations.value = [...locations.value, newCompanyLocation()]
}

function removeLocation(id: string) {
  locations.value = locations.value.filter((location) => location.id !== id)
}
</script>

<template>
  <section class="card">
    <div class="section-head">
      <div>
        <h2>Office locations</h2>
        <p class="muted location-help">
          Add an office for each state you work in. Contracts use the location that matches the
          job state on the estimate.
        </p>
      </div>
      <button class="button secondary" type="button" @click="addLocation">
        + Add location
      </button>
    </div>

    <p v-if="locations.length === 0" class="muted">
      No locations yet. Add at least one office for the states where you write contracts.
    </p>

    <article
      v-for="(location, index) in locations"
      :key="location.id"
      class="location-card"
    >
      <div class="location-card-head">
        <h3>Location {{ index + 1 }}</h3>
        <button
          class="button secondary"
          type="button"
          @click="removeLocation(location.id)"
        >
          Remove
        </button>
      </div>

      <div class="form-grid">
        <label class="field">
          <span>Label</span>
          <input v-model="location.label" class="input" type="text" placeholder="Iowa office">
        </label>
        <label class="field">
          <span>State</span>
          <select v-model="location.state" class="input">
            <option value="">Select state...</option>
            <option
              v-for="option in SUPPORTED_STATE_OPTIONS"
              :key="option.code"
              :value="option.code"
            >
              {{ option.name }}
            </option>
          </select>
        </label>
        <label class="field">
          <span>Address line 1</span>
          <input v-model="location.address1" class="input" type="text">
        </label>
        <label class="field">
          <span>Address line 2</span>
          <input v-model="location.address2" class="input" type="text">
        </label>
        <label class="field">
          <span>City</span>
          <input v-model="location.city" class="input" type="text">
        </label>
        <label class="field">
          <span>ZIP</span>
          <input v-model="location.zip" class="input" type="text">
        </label>
        <label class="field">
          <span>Phone</span>
          <input v-model="location.phone" class="input" type="tel">
        </label>
        <label class="field">
          <span>Office phone</span>
          <input v-model="location.officePhone" class="input" type="tel">
        </label>
      </div>
    </article>
  </section>
</template>

<style scoped>
.section-head {
  align-items: flex-start;
  display: flex;
  gap: 1rem;
  justify-content: space-between;
}

.location-help {
  margin: 0.35rem 0 0;
  max-width: 36rem;
}

.location-card {
  border-top: 1px solid var(--sf-border);
  margin-top: 1rem;
  padding-top: 1rem;
}

.location-card-head {
  align-items: center;
  display: flex;
  gap: 1rem;
  justify-content: space-between;
  margin-bottom: 0.75rem;
}

.location-card-head h3 {
  font-size: 1rem;
  margin: 0;
}

.form-grid {
  display: grid;
  gap: 1rem;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
}

@media (max-width: 860px) {
  .section-head {
    align-items: stretch;
    flex-direction: column;
  }

  .location-card-head {
    align-items: stretch;
    flex-direction: column;
  }
}
</style>
