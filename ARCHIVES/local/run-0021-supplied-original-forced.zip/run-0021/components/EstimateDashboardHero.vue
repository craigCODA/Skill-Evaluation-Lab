<script setup lang="ts">
defineProps<{
  stats: Array<{
    id: string;
    label: string;
    value: number | string;
    tone?: "blue" | "green" | "tan" | "neutral";
  }>;
}>();

const emit = defineEmits<{
  create: [];
}>();
</script>

<template>
  <section class="estimate-hero-section">
    <div class="estimate-hero-copy">
      <p class="section-eyebrow">Estimates</p>
      <h1>Saved Estimates</h1>
      <p>
        Review saved roof estimates, continue drafts, and open customer-ready contracts when the scope is ready.
      </p>
      <button class="button estimate-hero-action" type="button" @click="emit('create')">
        New Estimate
      </button>
    </div>

    <div class="estimate-hero-stats" aria-label="Estimate summary">
      <div
        v-for="stat in stats"
        :key="stat.id"
        class="estimate-hero-stat"
        :class="`is-${stat.tone ?? 'neutral'}`"
      >
        <span>{{ stat.label }}</span>
        <strong>{{ stat.value }}</strong>
      </div>
    </div>
  </section>
</template>

<style scoped>
.estimate-hero-section {
  background: var(--sf-section-blue);
  border: 1px solid var(--sf-section-blue-border);
  border-radius: 1.1rem;
  box-shadow: 0 10px 30px rgb(23 33 58 / 6%);
  display: grid;
  gap: 1.25rem;
  grid-template-columns: minmax(0, 1.1fr) minmax(18rem, 0.9fr);
  padding: 1.25rem;
}

.section-eyebrow {
  color: var(--sf-action);
  font-size: 0.72rem;
  font-weight: 900;
  letter-spacing: 0.08em;
  margin: 0 0 0.35rem;
  text-transform: uppercase;
}

.estimate-hero-copy h1 {
  font-size: clamp(1.9rem, 4vw, 2.65rem);
  line-height: 1.05;
  margin: 0 0 0.55rem;
}

.estimate-hero-copy p {
  color: var(--sf-text-soft);
  margin: 0;
  max-width: 44rem;
}

.estimate-hero-action {
  margin-top: 1rem;
}

.estimate-hero-stats {
  display: grid;
  gap: 0.75rem;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.estimate-hero-stat {
  border: 1px solid;
  border-radius: 0.9rem;
  padding: 0.9rem;
}

.estimate-hero-stat.is-blue {
  background: var(--sf-section-blue);
  border-color: var(--sf-section-blue-border);
}

.estimate-hero-stat.is-green {
  background: var(--sf-section-green);
  border-color: var(--sf-section-green-border);
}

.estimate-hero-stat.is-tan {
  background: var(--sf-section-cream);
  border-color: var(--sf-section-cream-border);
}

.estimate-hero-stat.is-neutral {
  background: var(--sf-surface);
  border-color: var(--sf-border);
}

.estimate-hero-stat span,
.estimate-hero-stat strong {
  display: block;
}

.estimate-hero-stat span {
  color: var(--sf-text-muted);
  font-size: 0.74rem;
  font-weight: 900;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.estimate-hero-stat strong {
  color: var(--sf-text);
  font-size: 1.65rem;
  line-height: 1;
  margin-top: 0.35rem;
}

@media (max-width: 860px) {
  .estimate-hero-section {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 560px) {
  .estimate-hero-stats {
    grid-template-columns: 1fr;
  }

  .estimate-hero-action {
    justify-content: center;
    width: 100%;
  }
}
</style>
