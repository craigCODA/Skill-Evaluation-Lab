<script setup lang="ts">
import { ESTIMATE_STATUS_ORDER, estimateStatusStyle } from "~~/shared/estimateStatus"

const { presentStatuses } = defineProps<{
  presentStatuses?: string[]
}>()

const legendStatuses = computed(() => {
  if (presentStatuses?.length) {
    return ESTIMATE_STATUS_ORDER.filter((status) => presentStatuses.includes(status))
  }
  return ESTIMATE_STATUS_ORDER
})
</script>

<template>
  <div class="estimate-status-legend" aria-label="Estimate status colors">
    <span
      v-for="status in legendStatuses"
      :key="status"
      class="estimate-status-legend-item"
    >
      <span
        class="estimate-status-legend-swatch"
        :style="{ backgroundColor: estimateStatusStyle(status).swatch }"
      />
      {{ estimateStatusStyle(status).label }}
    </span>
  </div>
</template>

<style scoped>
.estimate-status-legend {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem 1rem;
  margin-bottom: 1rem;
}

.estimate-status-legend-item {
  align-items: center;
  color: var(--sf-text-muted);
  display: inline-flex;
  font-size: 0.82rem;
  font-weight: 700;
  gap: 0.4rem;
}

.estimate-status-legend-swatch {
  border: 1px solid rgb(23 33 58 / 12%);
  border-radius: 4px;
  flex-shrink: 0;
  height: 0.85rem;
  width: 0.85rem;
}
</style>
