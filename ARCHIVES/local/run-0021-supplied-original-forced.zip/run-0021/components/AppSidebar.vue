<script setup lang="ts">
import { buildAppNavSections } from "~~/shared/appNav"

const route = useRoute()
const { isConfigured, logout, isAdmin, currentUser } = useAuth()
const { can, refreshAccountContext } = useAccount()
const menuOpen = ref(false)

await refreshAccountContext().catch(() => undefined)

const navSections = computed(() =>
  buildAppNavSections({
    isAdmin: isAdmin.value,
    can
  })
)

function closeMenu() {
  menuOpen.value = false
}

function toggleMenu() {
  menuOpen.value = !menuOpen.value
}

watch(() => route.path, () => {
  closeMenu()
})

watch(menuOpen, (open) => {
  if (!import.meta.client) return
  document.body.style.overflow = open ? "hidden" : ""
})

onBeforeUnmount(() => {
  if (!import.meta.client) return
  document.body.style.overflow = ""
})
</script>

<template>
  <button
    v-if="menuOpen"
    type="button"
    class="app-sidebar-backdrop"
    aria-label="Close menu"
    @click="closeMenu"
  />

  <aside class="app-sidebar" :class="{ 'is-open': menuOpen }">
    <div class="app-sidebar-top">
      <div class="app-sidebar-brand">
        <BrandLogo size="sm" alt="ShingleFile" />
        <p class="muted app-sidebar-tagline">Roofing estimate workspace</p>
      </div>
      <button
        type="button"
        class="app-menu-toggle"
        :aria-expanded="menuOpen"
        aria-controls="app-primary-nav"
        @click="toggleMenu"
      >
        <span class="sr-only">Toggle menu</span>
        <span class="app-menu-icon" aria-hidden="true" />
      </button>
    </div>

    <nav id="app-primary-nav" class="app-nav" aria-label="Primary navigation">
      <div
        v-for="section in navSections"
        :key="section.id"
        :class="section.label ? 'app-nav-section' : 'app-nav-primary'"
      >
        <p v-if="section.label" class="app-nav-section-label">{{ section.label }}</p>
        <NuxtLink
          v-for="item in section.items"
          :key="item.id"
          v-slot="{ href, navigate, isActive, isExactActive }"
          :to="item.to"
          custom
        >
          <a
            :href="href"
            :class="{ 'router-link-active': item.exact ? isExactActive : isActive }"
            @click="(event) => { navigate(event); closeMenu() }"
          >
            {{ item.label }}
          </a>
        </NuxtLink>
      </div>
    </nav>

    <div class="app-sidebar-user">
      <p v-if="currentUser.email" class="muted">Signed in as {{ currentUser.email }}</p>
      <button v-if="isConfigured" class="button secondary" type="button" @click="logout">
        Log out
      </button>
    </div>
  </aside>
</template>

<style scoped>
.sr-only {
  border: 0;
  clip: rect(0, 0, 0, 0);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

.app-menu-icon,
.app-menu-icon::before,
.app-menu-icon::after {
  background: currentColor;
  border-radius: 1px;
  display: block;
  height: 2px;
  width: 1.25rem;
}

.app-menu-icon {
  position: relative;
}

.app-menu-icon::before,
.app-menu-icon::after {
  content: "";
  left: 0;
  position: absolute;
}

.app-menu-icon::before {
  top: -6px;
}

.app-menu-icon::after {
  top: 6px;
}
</style>
