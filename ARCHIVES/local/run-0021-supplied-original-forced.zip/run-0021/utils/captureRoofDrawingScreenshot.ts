import type { RoofMeasurement } from "~~/shared/types"
import type {
  RoofAreaShape,
  RoofIconMarker,
  RoofLineMeasurement
} from "~~/shared/roofLineMeasurements"
import {
  roofAreaShapeColorMeta,
  roofIconMarkerMeta,
  roofLineTypeMeta
} from "~~/shared/roofLineMeasurements"
import type { RoofImageryCrop } from "~~/shared/roofImageryScale"

type CaptureRoofDrawingScreenshotInput = {
  measurement: RoofMeasurement
  crop: RoofImageryCrop
  lines: RoofLineMeasurement[]
  markers: RoofIconMarker[]
  areaShapes: RoofAreaShape[]
}

export async function captureRoofDrawingScreenshot(input: CaptureRoofDrawingScreenshotInput): Promise<string> {
  const imageDataUrl = input.measurement.imagery?.previewDataUrl
  if (!imageDataUrl) throw new Error("No aerial image is available to capture.")

  const image = await loadImage(imageDataUrl)
  const width = 1200
  const height = Math.max(600, Math.round(width * (image.height / image.width)))
  const canvas = document.createElement("canvas")
  canvas.width = width
  canvas.height = height

  const ctx = canvas.getContext("2d")
  if (!ctx) throw new Error("Drawing capture is not supported in this browser.")

  drawCroppedImage(ctx, image, input.crop, width, height)
  drawAreaShapes(ctx, input.areaShapes, width, height)
  drawLines(ctx, input.lines, width, height)
  await drawMarkers(ctx, input.markers, width, height)

  return canvas.toDataURL("image/png")
}

function drawCroppedImage(
  ctx: CanvasRenderingContext2D,
  image: HTMLImageElement,
  crop: RoofImageryCrop,
  width: number,
  height: number
) {
  const sx = image.width * crop.cx
  const sy = image.height * crop.cy
  const sw = image.width * crop.size
  const sh = image.height * crop.size
  ctx.drawImage(image, sx, sy, sw, sh, 0, 0, width, height)
}

function drawAreaShapes(
  ctx: CanvasRenderingContext2D,
  shapes: RoofAreaShape[],
  width: number,
  height: number
) {
  for (const shape of shapes) {
    if (shape.points.length < 3) continue
    const color = roofAreaShapeColorMeta(shape.color).value
    ctx.save()
    ctx.beginPath()
    shape.points.forEach((point, index) => {
      const x = percentX(point.x, width)
      const y = percentY(point.y, height)
      if (index === 0) ctx.moveTo(x, y)
      else ctx.lineTo(x, y)
    })
    ctx.closePath()
    ctx.fillStyle = withAlpha(color, 0.22)
    ctx.strokeStyle = color
    ctx.lineWidth = 4
    ctx.fill()
    ctx.stroke()
    ctx.clip()
    ctx.strokeStyle = withAlpha(color, 0.45)
    ctx.lineWidth = 2
    for (let x = -height; x < width + height; x += 24) {
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x + height, height)
      ctx.stroke()
    }
    ctx.restore()
  }
}

function drawLines(
  ctx: CanvasRenderingContext2D,
  lines: RoofLineMeasurement[],
  width: number,
  height: number
) {
  for (const line of lines) {
    const x1 = percentX(line.start.x, width)
    const y1 = percentY(line.start.y, height)
    const x2 = percentX(line.end.x, width)
    const y2 = percentY(line.end.y, height)
    const isCautionTape = line.type === "caution-tape"

    ctx.save()
    ctx.lineCap = "round"
    if (isCautionTape) {
      ctx.strokeStyle = "#f8d313"
      ctx.lineWidth = 12
      drawLine(ctx, x1, y1, x2, y2)
      ctx.strokeStyle = "#111827"
      ctx.lineWidth = 4
      ctx.setLineDash([16, 16])
      drawLine(ctx, x1, y1, x2, y2)
    } else {
      ctx.strokeStyle = roofLineTypeMeta(line.type).color
      ctx.lineWidth = 6
      drawLine(ctx, x1, y1, x2, y2)
      drawLineLabel(ctx, `${line.feet.toFixed(1)} ft`, (x1 + x2) / 2, (y1 + y2) / 2, ctx.strokeStyle)
    }
    ctx.restore()
  }
}

async function drawMarkers(
  ctx: CanvasRenderingContext2D,
  markers: RoofIconMarker[],
  width: number,
  height: number
) {
  for (const marker of markers) {
    const meta = roofIconMarkerMeta(marker.type)
    const x = percentX(marker.point.x, width)
    const y = percentY(marker.point.y, height)
    if (meta.iconPath) {
      await drawIconMarker(ctx, meta.iconPath, x, y)
      continue
    }
    drawNumberMarker(ctx, meta.markerText || "", x, y)
  }
}

async function drawIconMarker(ctx: CanvasRenderingContext2D, iconPath: string, x: number, y: number) {
  const icon = await loadImage(iconPath)
  const size = 36
  ctx.save()
  ctx.shadowColor = "rgb(0 0 0 / 65%)"
  ctx.shadowBlur = 4
  ctx.shadowOffsetY = 2
  ctx.globalAlpha = 0.9
  ctx.drawImage(icon, x - size / 2, y - size / 2, size, size)
  ctx.restore()
}

function drawNumberMarker(ctx: CanvasRenderingContext2D, label: string, x: number, y: number) {
    ctx.save()
    ctx.fillStyle = "rgb(23 33 58 / 86%)"
    ctx.strokeStyle = "rgb(255 255 255 / 78%)"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.arc(x, y, 18, 0, Math.PI * 2)
    ctx.fill()
    ctx.stroke()
    ctx.fillStyle = "#ffffff"
    ctx.font = "700 16px sans-serif"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(label, x, y + 1)
    ctx.restore()
}

function drawLine(ctx: CanvasRenderingContext2D, x1: number, y1: number, x2: number, y2: number) {
  ctx.beginPath()
  ctx.moveTo(x1, y1)
  ctx.lineTo(x2, y2)
  ctx.stroke()
}

function drawLineLabel(
  ctx: CanvasRenderingContext2D,
  label: string,
  x: number,
  y: number,
  color: string | CanvasGradient | CanvasPattern
) {
  ctx.font = "700 18px sans-serif"
  const metrics = ctx.measureText(label)
  const paddingX = 10
  const boxWidth = metrics.width + paddingX * 2
  const boxHeight = 30
  ctx.fillStyle = "#ffffff"
  ctx.strokeStyle = color
  ctx.lineWidth = 3
  ctx.beginPath()
  ctx.roundRect(x - boxWidth / 2, y - boxHeight / 2, boxWidth, boxHeight, 14)
  ctx.fill()
  ctx.stroke()
  ctx.fillStyle = "#111827"
  ctx.textAlign = "center"
  ctx.textBaseline = "middle"
  ctx.fillText(label, x, y + 1)
}

function percentX(value: number, width: number): number {
  return (value / 100) * width
}

function percentY(value: number, height: number): number {
  return (value / 100) * height
}

function withAlpha(hex: string, alpha: number): string {
  if (!hex.startsWith("#") || hex.length !== 7) return hex
  const r = Number.parseInt(hex.slice(1, 3), 16)
  const g = Number.parseInt(hex.slice(3, 5), 16)
  const b = Number.parseInt(hex.slice(5, 7), 16)
  return `rgba(${r}, ${g}, ${b}, ${alpha})`
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image()
    image.onload = () => resolve(image)
    image.onerror = () => reject(new Error("Drawing image could not be loaded."))
    image.src = src
  })
}
