export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "manageSubAccounts", "Customer account admin access required")
  return listCustomerAccountSubAccounts(user)
})
