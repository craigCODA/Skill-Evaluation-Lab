import {
  isAssignableCustomerAccountRole,
  type AssignableCustomerAccountRole
} from "~~/shared/accountPermissions"

export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const subAccountId = getRouterParam(event, "subAccountId")
  const body = await readBody<{ role?: AssignableCustomerAccountRole }>(event)

  if (!subAccountId) {
    throw createError({ statusCode: 400, statusMessage: "Sub-account id is required" })
  }
  if (!isAssignableCustomerAccountRole(body?.role)) {
    throw createError({ statusCode: 400, statusMessage: "Invalid team role" })
  }

  return updateCustomerAccountSubAccountRole(user, subAccountId, body.role)
})
