export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "editContractSetup", "Contract setup access required")
  return getContractConfig(context.customerAccount.id)
})
