import type { AccountDashboard } from "~~/shared/types"

export default defineEventHandler(async (event): Promise<AccountDashboard> => {
  const user = getCurrentUser(event)
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "viewAccountStatistics")

  const canListCustomers = contextHasCapability(context, "editCustomers")
    || contextHasCapability(context, "viewEstimates")
    || contextHasCapability(context, "manageJobAssets")
  const canListEstimates = contextHasCapability(context, "viewEstimates")

  const [subAccounts, customers, estimates] = await Promise.all([
    contextHasCapability(context, "manageSubAccounts")
      ? listCustomerAccountSubAccounts(user)
      : Promise.resolve([context.subAccount]),
    canListCustomers ? listCustomers(user) : Promise.resolve([]),
    canListEstimates ? listEstimates(user) : Promise.resolve([])
  ])

  return {
    customerAccountId: context.customerAccount.id,
    customerAccountName: context.customerAccount.name,
    subAccountId: context.subAccount.id,
    canSeeAllCustomerAccountWork: context.canSeeAllCustomerAccountWork,
    totalSubAccounts: subAccounts.length,
    totalCustomers: customers.length,
    totalEstimates: estimates.length,
    totalContracts: estimates.filter((estimate) => estimate.contractKind).length,
    draftEstimates: estimates.filter((estimate) => estimate.status === "draft").length,
    signedEstimates: estimates.filter((estimate) => estimate.status === "signed").length,
    completeEstimates: estimates.filter((estimate) => estimate.status === "complete").length
  }
})
