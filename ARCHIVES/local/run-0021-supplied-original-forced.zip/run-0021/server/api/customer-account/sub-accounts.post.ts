import {
  isAssignableCustomerAccountRole,
  type AssignableCustomerAccountRole
} from "~~/shared/accountPermissions"

export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const body = await readBody<{
    email?: string
    name?: string
    password?: string
    role?: AssignableCustomerAccountRole
    title?: string
  }>(event)

  if (!body?.email || !body?.password || !body?.role) {
    throw createError({
      statusCode: 400,
      statusMessage: "Email, password, and role are required"
    })
  }
  if (!isAssignableCustomerAccountRole(body.role)) {
    throw createError({ statusCode: 400, statusMessage: "Invalid team role" })
  }

  return createCustomerAccountSubAccount(user, {
    email: body.email,
    name: body.name ?? "",
    password: body.password,
    role: body.role,
    title: body.title
  })
})
