import { buildRoleCapabilityMatrix } from "~~/shared/accountPermissions"

export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const body = await readBody(event)
  const roleCapabilities = await updateCustomerAccountRoleCapabilities(user, body)
  return {
    roleCapabilities,
    roles: buildRoleCapabilityMatrix(roleCapabilities)
  }
})
