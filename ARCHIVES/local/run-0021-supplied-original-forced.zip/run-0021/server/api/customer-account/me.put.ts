export default defineEventHandler(async (event) => {
  const body = await readBody<{ name?: string, title?: string }>(event)
  return updateCurrentSubAccount(getCurrentUser(event), body)
})
