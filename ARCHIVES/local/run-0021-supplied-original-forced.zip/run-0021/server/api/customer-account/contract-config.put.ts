import type { CompanyContractConfig } from "~~/shared/contracts/modules"

export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const body = await readBody<Partial<CompanyContractConfig>>(event)
  return saveContractConfig(user, body ?? {})
})
