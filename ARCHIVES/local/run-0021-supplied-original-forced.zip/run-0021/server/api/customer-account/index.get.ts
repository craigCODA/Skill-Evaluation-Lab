export default defineEventHandler(async (event) => {
  const context = await getCustomerAccountContext(getCurrentUser(event))
  return {
    customerAccount: context.customerAccount,
    subAccount: context.subAccount,
    canSeeAllCustomerAccountWork: context.canSeeAllCustomerAccountWork,
    capabilities: context.capabilities,
    role: context.subAccount.role
  }
})
