import {
  ACCOUNT_CAPABILITIES,
  ACCOUNT_CAPABILITY_LABELS,
  buildRoleCapabilityMatrix,
  readCompanyRoleCapabilities
} from "~~/shared/accountPermissions"

export default defineEventHandler(async (event) => {
  const context = await getCustomerAccountContext(getCurrentUser(event))
  assertAccountCapability(context, "manageSubAccounts", "Customer account admin access required")

  const overrides = readCompanyRoleCapabilities(context.customerAccount.roleCapabilities)

  return {
    capabilities: ACCOUNT_CAPABILITIES.map((id) => ({
      id,
      label: ACCOUNT_CAPABILITY_LABELS[id]
    })),
    roles: buildRoleCapabilityMatrix(overrides),
    roleCapabilities: overrides ?? null
  }
})
