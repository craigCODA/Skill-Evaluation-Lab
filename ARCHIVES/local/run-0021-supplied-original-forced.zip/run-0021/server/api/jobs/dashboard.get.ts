export default defineEventHandler(async (event) => estimateDashboard(getCurrentUser(event)))
