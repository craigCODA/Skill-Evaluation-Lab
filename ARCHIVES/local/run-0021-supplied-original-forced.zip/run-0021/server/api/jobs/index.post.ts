import type { Job } from "~~/shared/types"

export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const body = await readBody<Job>(event)

  if (!body?.id) {
    throw createError({ statusCode: 400, statusMessage: "Estimate id is required" })
  }

  requireSavableEstimate(body)

  if (await resolveAccountJob(body.id, user)) {
    throw createError({ statusCode: 409, statusMessage: "Estimate already exists" })
  }

  return createEstimate(body, user)
})
