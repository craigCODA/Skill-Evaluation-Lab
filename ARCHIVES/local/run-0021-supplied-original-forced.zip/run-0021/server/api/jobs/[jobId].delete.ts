export default defineEventHandler(async (event) => {
  const jobId = getRouterParam(event, "jobId")

  if (!jobId || !await deleteDraftEstimate(jobId, getCurrentUser(event))) {
    throw createError({
      statusCode: 403,
      statusMessage: "Only draft estimates can be removed"
    })
  }

  return { id: jobId }
})
