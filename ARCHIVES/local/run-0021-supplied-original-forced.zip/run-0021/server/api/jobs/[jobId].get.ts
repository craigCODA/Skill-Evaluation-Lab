export default defineEventHandler(async (event) => {
  const jobId = getRouterParam(event, "jobId")
  const estimate = jobId ? await getEstimate(jobId, getCurrentUser(event)) : undefined

  if (!estimate) {
    throw createError({
      statusCode: 404,
      statusMessage: "Estimate not found"
    })
  }

  return estimate
})
