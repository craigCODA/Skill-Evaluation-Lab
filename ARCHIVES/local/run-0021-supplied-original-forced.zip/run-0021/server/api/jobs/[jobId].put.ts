import type { Job } from "~~/shared/types"

export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const jobId = getRouterParam(event, "jobId")
  const body = await readBody<Job>(event)

  if (!jobId || body.id !== jobId) {
    throw createError({
      statusCode: 400,
      statusMessage: "Estimate id mismatch"
    })
  }

  requireSavableEstimate(body)

  if (!await resolveAccountJob(jobId, user)) {
    throw createError({
      statusCode: 404,
      statusMessage: "Estimate not found"
    })
  }

  return updateEstimate(body, user)
})
