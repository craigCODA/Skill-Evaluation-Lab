import type { DrawingScreenshotAssetMetadata, JobAssetKind } from "~~/shared/types"

export default defineEventHandler(async (event) => {
  const jobId = getRouterParam(event, "jobId")
  if (!jobId) {
    throw createError({ statusCode: 400, statusMessage: "Job id is required" })
  }

  const body = await readBody<{
    label?: string
    description?: string
    kind?: JobAssetKind
    imageDataUrl?: string
    metadata?: DrawingScreenshotAssetMetadata
  }>(event)

  if (!body.imageDataUrl) {
    throw createError({ statusCode: 400, statusMessage: "Image is required" })
  }

  return createJobAsset({
    jobId,
    label: body.label || "Drawing screenshot",
    description: body.description,
    kind: body.kind || "drawing-screenshot",
    imageDataUrl: body.imageDataUrl,
    metadata: body.metadata
  }, getCurrentUser(event))
})
