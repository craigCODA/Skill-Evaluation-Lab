import { calculateRoofingEstimate } from "~~/shared/calculator/calculateEstimate"
import { buildProposalDocuments } from "~~/shared/contracts/proposalDocuments"

export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "viewContracts")

  const jobId = getRouterParam(event, "jobId")
  const estimate = jobId ? await resolveAccountJob(jobId, user) : undefined

  if (!jobId || !estimate?.scope.roofing) {
    throw createError({
      statusCode: 404,
      statusMessage: "Estimate with roofing scope not found"
    })
  }

  const ownerId = await getEstimateOwnerId(jobId, user) ?? user.sub
  const catalog = await getEditableCatalog(ownerId)
  const companyProfile = await getCompanyProfile(ownerId)
  const platformProfile = await getPlatformProfile()
  const roofingTotals = calculateRoofingEstimate({
    roofing: estimate.scope.roofing,
    catalog,
    permit: estimate.permit,
    extras: estimate.extras
  })

  return buildProposalDocuments({
    job: estimate,
    catalog,
    companyProfile,
    platformProfile,
    roofingTotals
  })
})
