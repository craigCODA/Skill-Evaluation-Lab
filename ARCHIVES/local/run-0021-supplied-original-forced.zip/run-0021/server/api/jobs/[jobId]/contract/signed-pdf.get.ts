export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const jobId = getRouterParam(event, "jobId")
  if (!jobId) {
    throw createError({ statusCode: 400, statusMessage: "Job id is required" })
  }
  const query = getQuery(event)
  return getJobContractSignedPdfDataUrl(jobId, user, query.recipeKind)
})
