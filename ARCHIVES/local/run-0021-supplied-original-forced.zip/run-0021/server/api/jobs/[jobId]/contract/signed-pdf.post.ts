export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const jobId = getRouterParam(event, "jobId")
  if (!jobId) {
    throw createError({ statusCode: 400, statusMessage: "Job id is required" })
  }
  const body = await readBody<{
    recipeKind?: string
    fileName?: string
    dataUrl?: string
  }>(event)

  if (!body?.dataUrl) {
    throw createError({ statusCode: 400, statusMessage: "PDF data is required" })
  }

  return uploadJobContractSignedPdf(jobId, user, {
    recipeKind: body.recipeKind,
    fileName: body.fileName || "signed-contract.pdf",
    dataUrl: body.dataUrl
  })
})
