export default defineEventHandler(async (event) => {
  const jobId = getRouterParam(event, "jobId")
  if (!jobId) {
    throw createError({ statusCode: 400, statusMessage: "Job id is required" })
  }
  return listJobAssets(jobId, getCurrentUser(event))
})
