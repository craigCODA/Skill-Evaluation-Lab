export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const jobId = getRouterParam(event, "jobId")
  if (!jobId) {
    throw createError({ statusCode: 400, statusMessage: "Job id is required" })
  }
  const body = await readBody<{ recipeKind?: string } | null>(event).catch(() => null)
  return markJobContractSigned(jobId, user, body?.recipeKind)
})
