import { activeRecipeKinds } from "~~/shared/contracts/modules"

export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const jobId = getRouterParam(event, "jobId")
  if (!jobId) {
    throw createError({ statusCode: 400, statusMessage: "Job id is required" })
  }
  const context = await getCustomerAccountContext(user)
  const [bundle, config] = await Promise.all([
    getJobContractBundle(jobId, user),
    getContractConfig(context.customerAccount.id)
  ])
  return {
    bundle,
    enabledRecipes: config.enabledRecipes,
    activeRecipeKinds: activeRecipeKinds(config)
  }
})
