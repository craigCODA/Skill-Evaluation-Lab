export default defineEventHandler(async (event) => createDraftEstimate(getCurrentUser(event)))
