export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  return getCompanyProfile(user.sub)
})
