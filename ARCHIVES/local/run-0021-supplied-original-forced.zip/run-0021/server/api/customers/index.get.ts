export default defineEventHandler(async (event) => listCustomers(getCurrentUser(event)))
