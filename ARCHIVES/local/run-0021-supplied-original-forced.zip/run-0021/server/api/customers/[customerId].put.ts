import type { Customer } from "~~/shared/types"

export default defineEventHandler(async (event) => {
  const customerId = getRouterParam(event, "customerId")
  if (!customerId) {
    throw createError({ statusCode: 400, statusMessage: "Customer id is required" })
  }

  const customer = await updateCustomer(
    customerId,
    await readBody<Partial<Customer>>(event),
    getCurrentUser(event)
  )
  if (!customer) {
    throw createError({ statusCode: 404, statusMessage: "Customer not found" })
  }
  return customer
})
