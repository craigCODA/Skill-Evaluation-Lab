export default defineEventHandler(async (event) => {
  const customerId = getRouterParam(event, "customerId")
  const customer = customerId ? await getCustomerFile(customerId, getCurrentUser(event)) : null
  if (!customer) {
    throw createError({ statusCode: 404, statusMessage: "Customer not found" })
  }
  return customer
})
