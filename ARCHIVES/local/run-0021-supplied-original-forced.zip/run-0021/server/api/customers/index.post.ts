import type { Customer } from "~~/shared/types"

export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const body = await readBody<Partial<Customer>>(event)
  return createCustomer(body, user)
})
