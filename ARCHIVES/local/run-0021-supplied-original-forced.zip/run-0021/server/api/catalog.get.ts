export default defineEventHandler(async (event) => getEditableCatalog(getCurrentUser(event).sub))
