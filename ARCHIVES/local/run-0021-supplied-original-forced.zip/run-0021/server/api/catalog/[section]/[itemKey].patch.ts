import type { Catalog } from "~~/shared/pricebook/types"

export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const section = getRouterParam(event, "section") as keyof Catalog | undefined
  const itemKey = getRouterParam(event, "itemKey")
  const patch = await readBody<Record<string, unknown>>(event)

  if (!section || !itemKey) {
    throw createError({ statusCode: 400, statusMessage: "Catalog section and item key are required" })
  }

  return updateCatalogItem(section, decodeURIComponent(itemKey), patch, user)
})
