export default defineEventHandler(async (event) => {
  const assetId = getRouterParam(event, "assetId")
  if (!assetId) {
    throw createError({ statusCode: 400, statusMessage: "Asset id is required" })
  }

  const body = await readBody<{ description?: string }>(event)
  const asset = await updateJobAssetDescription(assetId, body.description ?? "", getCurrentUser(event))
  if (!asset) {
    throw createError({ statusCode: 404, statusMessage: "Asset not found" })
  }

  return asset
})
