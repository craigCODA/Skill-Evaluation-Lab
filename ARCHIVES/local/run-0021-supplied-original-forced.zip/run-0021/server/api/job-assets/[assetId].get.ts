export default defineEventHandler(async (event) => {
  const assetId = getRouterParam(event, "assetId")
  if (!assetId) {
    throw createError({ statusCode: 400, statusMessage: "Asset id is required" })
  }

  const image = await getJobAssetImage(assetId, getCurrentUser(event))
  if (!image) {
    throw createError({ statusCode: 404, statusMessage: "Asset not found" })
  }

  return image
})
