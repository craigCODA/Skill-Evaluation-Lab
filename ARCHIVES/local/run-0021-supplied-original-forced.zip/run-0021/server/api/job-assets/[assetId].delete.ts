export default defineEventHandler(async (event) => {
  const assetId = getRouterParam(event, "assetId")
  if (!assetId) {
    throw createError({ statusCode: 400, statusMessage: "Asset id is required" })
  }

  const deleted = await deleteJobAsset(assetId, getCurrentUser(event))
  if (!deleted) {
    throw createError({ statusCode: 404, statusMessage: "Asset not found" })
  }

  return { ok: true }
})
