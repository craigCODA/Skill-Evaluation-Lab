import { z } from "zod";
import { normalizeRoofProbeAddress, parseRoofProbeAddressInput } from "~~/shared/roofProbeAddress";

const RoofProbeSchema = z.object({
  address: z.string().trim().min(5),
  requiredQuality: z.enum(["HIGH", "MEDIUM", "LOW"]).default("LOW"),
});

export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "useRoofProbe")
  const body = await readBody(event);
  const result = RoofProbeSchema.safeParse(body ?? {});
  if (!result.success) {
    throw createError({
      statusCode: 400,
      statusMessage: result.error.issues[0]?.message || "Invalid roof probe request",
    });
  }
  const input = result.data;
  const parsedAddress = parseRoofProbeAddressInput(input.address);
  const addressKey = normalizeRoofProbeAddress(parsedAddress.address);
  if (!addressKey) {
    throw createError({
      statusCode: 400,
      statusMessage: "Invalid roof probe address",
    });
  }

  if (!parsedAddress.forceRefresh) {
    const cached = await getCachedRoofProbeMeasurement(addressKey);
    if (cached) return cached;
  }

  const measurement = await queryGoogleSolarRoofProbe({
    address: parsedAddress.address,
    requiredQuality: input.requiredQuality,
  });
  return saveRoofProbeMeasurement({
    addressKey,
    measurement,
    cacheStatus: parsedAddress.forceRefresh ? "refreshed" : "miss",
  });
});
