import type { CompanyProfile } from "~~/shared/types"

export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "editCompanyProfile")
  const body = await readBody<Partial<CompanyProfile>>(event)
  return saveCompanyProfile(user.sub, body ?? {})
})
