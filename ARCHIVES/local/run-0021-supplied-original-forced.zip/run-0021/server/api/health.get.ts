export default defineEventHandler(() => ({
  ok: true,
  service: "shinglefile",
  awsRegion: process.env.NUXT_PUBLIC_AWS_REGION ?? "us-west-1"
}))
