import { z } from "zod";

type GoogleStreetViewMetadataResponse = {
  status: string;
  pano_id?: string;
  copyright?: string;
  date?: string;
};

const StreetViewQuerySchema = z.object({
  latitude: z.coerce.number().min(-90).max(90),
  longitude: z.coerce.number().min(-180).max(180),
});

export default defineEventHandler(async (event) => {
  const user = getCurrentUser(event)
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "useRoofProbe")
  const result = StreetViewQuerySchema.safeParse(getQuery(event));
  if (!result.success) {
    throw createError({
      statusCode: 400,
      statusMessage: result.error.issues[0]?.message || "Invalid Street View request",
    });
  }

  const key = useRuntimeConfig().googleSolarApiKey;
  if (!key) {
    throw createError({
      statusCode: 503,
      statusMessage: "Street View provider is not configured",
    });
  }

  const params = new URLSearchParams({
    key,
    location: `${result.data.latitude},${result.data.longitude}`,
    radius: "500",
    source: "outdoor",
  });

  const metadata = await $fetch<GoogleStreetViewMetadataResponse>(
    `https://maps.googleapis.com/maps/api/streetview/metadata?${params}`,
  ).catch((error: unknown) => {
    const message = error instanceof Error ? error.message : "Street View lookup failed";
    throw createError({
      statusCode: 502,
      statusMessage: message,
    });
  });

  return {
    available: metadata.status === "OK",
    status: metadata.status,
    panoId: metadata.pano_id,
    imageDate: metadata.date,
    copyright: metadata.copyright,
  };
});
