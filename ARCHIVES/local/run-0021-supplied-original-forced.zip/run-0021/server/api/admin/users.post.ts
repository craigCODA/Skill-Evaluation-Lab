import type { AccountRole } from "~~/shared/types"

export default defineEventHandler(async (event) => {
  requireAdmin(event)
  const body = await readBody<{ email?: string, name?: string, password?: string, role?: AccountRole }>(event)

  if (!body?.email || !body?.password) {
    throw createError({ statusCode: 400, statusMessage: "Email and password are required" })
  }

  return createUser({
    email: body.email,
    name: body.name ?? "",
    password: body.password,
    role: body.role === "admin" ? "admin" : "customer"
  })
})
