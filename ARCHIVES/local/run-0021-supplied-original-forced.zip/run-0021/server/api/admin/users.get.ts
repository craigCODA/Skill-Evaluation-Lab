import type { AccountSummary } from "~~/shared/types"

export default defineEventHandler(async (event): Promise<AccountSummary[]> => {
  requireAdmin(event)
  const users = await listUsers()

  return Promise.all(users.map(async (user) => ({
    userId: user.userId,
    email: user.email,
    name: user.name,
    role: user.role,
    createdAt: user.createdAt,
    companyName: (await getCompanyProfile(user.userId)).companyName
  })))
})
