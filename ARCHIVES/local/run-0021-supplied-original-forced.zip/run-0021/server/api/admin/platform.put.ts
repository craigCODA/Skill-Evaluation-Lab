import type { CompanyProfile } from "~~/shared/types"

export default defineEventHandler(async (event) => {
  requireAdmin(event)
  const body = await readBody<Partial<CompanyProfile>>(event)
  return savePlatformProfile(body ?? {})
})
