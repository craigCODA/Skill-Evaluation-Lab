export default defineEventHandler(async (event) => {
  const admin = requireAdmin(event)
  const userId = getRouterParam(event, "userId")
  if (!userId) {
    throw createError({ statusCode: 400, statusMessage: "userId is required" })
  }

  const decoded = decodeURIComponent(userId)
  if (decoded === admin.sub) {
    throw createError({ statusCode: 400, statusMessage: "You cannot delete your own account" })
  }

  await deleteUser(decoded)
  await deleteCompanyProfile(decoded)
  return { ok: true }
})
