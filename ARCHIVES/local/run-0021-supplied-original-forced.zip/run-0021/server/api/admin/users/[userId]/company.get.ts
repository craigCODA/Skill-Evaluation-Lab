export default defineEventHandler(async (event) => {
  requireAdmin(event)
  const userId = getRouterParam(event, "userId")
  if (!userId) {
    throw createError({ statusCode: 400, statusMessage: "userId is required" })
  }

  return getCompanyProfile(decodeURIComponent(userId))
})
