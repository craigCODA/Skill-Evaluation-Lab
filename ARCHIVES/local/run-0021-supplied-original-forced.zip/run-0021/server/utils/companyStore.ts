import type { CompanyProfile } from "~~/shared/types"
import { eq } from "drizzle-orm"
import {
  newCompanyProfile,
  newPlatformProfile,
  normalizeCompanyProfile,
  PLATFORM_PROFILE_ID,
} from "~~/shared/company"

const memoryProfiles = new Map<string, CompanyProfile>()

export async function getCompanyProfile(userId: string): Promise<CompanyProfile> {
  if (useMemoryCompany()) {
    const stored = memoryProfiles.get(userId)
    return stored
      ? withId(normalizeCompanyProfile(stored), userId)
      : withId(newCompanyProfile(), userId)
  }

  const rows = await useDatabase()
    .select()
    .from(schema.companyProfile)
    .where(eq(schema.companyProfile.id, userId))
    .limit(1)

  const stored = rows[0]?.bodyJson
  return stored
    ? withId(normalizeCompanyProfile(stored), userId)
    : withId(newCompanyProfile(), userId)
}

export async function saveCompanyProfile(userId: string, input: Partial<CompanyProfile>): Promise<CompanyProfile> {
  const next = withId(normalizeCompanyProfile(input), userId)
  next.updatedAt = new Date().toISOString()

  if (useMemoryCompany()) {
    memoryProfiles.set(userId, next)
    return next
  }

  await useDatabase()
    .insert(schema.companyProfile)
    .values({ id: userId, bodyJson: next, updatedAt: new Date(next.updatedAt) })
    .onConflictDoUpdate({
      target: schema.companyProfile.id,
      set: { bodyJson: next, updatedAt: new Date(next.updatedAt) }
    })

  return next
}

export async function getPlatformProfile(): Promise<CompanyProfile> {
  const stored = normalizeCompanyProfile(await getCompanyProfile(PLATFORM_PROFILE_ID))
  const defaults = newPlatformProfile()
  return {
    ...defaults,
    ...stored,
    id: PLATFORM_PROFILE_ID,
    companyName: stored.companyName?.trim() || defaults.companyName,
    legalName: stored.legalName?.trim() || defaults.legalName,
    website: stored.website?.trim() || defaults.website,
    email: stored.email?.trim() || defaults.email,
    phone: stored.phone?.trim() || defaults.phone,
    officePhone: stored.officePhone?.trim() || defaults.officePhone,
    logoUrl: stored.logoUrl?.trim() || defaults.logoUrl,
  }
}

export async function savePlatformProfile(input: Partial<CompanyProfile>): Promise<CompanyProfile> {
  return saveCompanyProfile(PLATFORM_PROFILE_ID, input)
}

export async function deleteCompanyProfile(userId: string): Promise<void> {
  if (useMemoryCompany()) {
    memoryProfiles.delete(userId)
    return
  }

  await useDatabase()
    .delete(schema.companyProfile)
    .where(eq(schema.companyProfile.id, userId))
}

function withId(profile: CompanyProfile, userId: string): CompanyProfile {
  return { ...profile, id: userId }
}

function useMemoryCompany(): boolean {
  return !hasDatabaseUrl() && process.env.NODE_ENV !== "production"
}
