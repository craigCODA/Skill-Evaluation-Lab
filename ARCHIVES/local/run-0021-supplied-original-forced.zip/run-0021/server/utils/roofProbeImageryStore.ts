import { GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import type { RoofMeasurement } from "~~/shared/types";

type StoredRoofProbeImagery = {
  measurement: RoofMeasurement;
  previewImageKey?: string;
  maskImageKey?: string;
};

type ParsedDataUrl = {
  contentType: string;
  body: Buffer;
};

let s3Client: S3Client | null = null;

export async function storeRoofProbeImagery(input: {
  addressKey: string;
  measurement: RoofMeasurement;
}): Promise<StoredRoofProbeImagery> {
  const imagery = input.measurement.imagery;
  if (!imagery) {
    return { measurement: input.measurement };
  }

  const preview = imagery.previewDataUrl ? parseDataUrl(imagery.previewDataUrl) : null;
  const mask = imagery.maskDataUrl ? parseDataUrl(imagery.maskDataUrl) : null;
  const prefix = imageryKeyPrefix(input.addressKey, input.measurement.id);
  const previewImageKey = preview ? `${prefix}/preview.png` : undefined;
  const maskImageKey = mask ? `${prefix}/mask.png` : undefined;

  await Promise.all([
    previewImageKey && preview ? putImage(previewImageKey, preview) : Promise.resolve(),
    maskImageKey && mask ? putImage(maskImageKey, mask) : Promise.resolve(),
  ]);

  return {
    measurement: {
      ...input.measurement,
      imagery: {
        ...imagery,
        previewDataUrl: undefined,
        maskDataUrl: undefined,
      },
    },
    previewImageKey,
    maskImageKey,
  };
}

export async function hydrateRoofProbeImagery(input: {
  measurement: RoofMeasurement;
  previewImageKey?: string | null;
  maskImageKey?: string | null;
}): Promise<RoofMeasurement> {
  if (!input.measurement.imagery) return input.measurement;

  const [previewDataUrl, maskDataUrl] = await Promise.all([
    input.previewImageKey ? getImageDataUrl(input.previewImageKey) : Promise.resolve(undefined),
    input.maskImageKey ? getImageDataUrl(input.maskImageKey) : Promise.resolve(undefined),
  ]);

  return {
    ...input.measurement,
    imagery: {
      ...input.measurement.imagery,
      previewDataUrl,
      maskDataUrl,
    },
  };
}

function s3(): S3Client {
  if (s3Client) return s3Client;
  s3Client = new S3Client({ region: useRuntimeConfig().public.awsRegion });
  return s3Client;
}

function imageryBucket(): string {
  const bucket = useRuntimeConfig().roofProbeImageryBucket || process.env.ROOF_PROBE_IMAGERY_BUCKET;
  if (!bucket) {
    throw createError({
      statusCode: 500,
      statusMessage: "Roof imagery storage is not configured",
    });
  }
  return bucket;
}

function parseDataUrl(dataUrl: string): ParsedDataUrl {
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) {
    throw createError({
      statusCode: 500,
      statusMessage: "Roof imagery data is not a valid data URL",
    });
  }

  return {
    contentType: match[1] ?? "image/png",
    body: Buffer.from(match[2] ?? "", "base64"),
  };
}

async function putImage(key: string, image: ParsedDataUrl): Promise<void> {
  await s3().send(new PutObjectCommand({
    Bucket: imageryBucket(),
    Key: key,
    Body: image.body,
    ContentType: image.contentType,
  }));
}

async function getImageDataUrl(key: string): Promise<string> {
  const response = await s3().send(new GetObjectCommand({
    Bucket: imageryBucket(),
    Key: key,
  }));
  const body = response.Body as { transformToByteArray?: () => Promise<Uint8Array> } | undefined;
  if (!body?.transformToByteArray) {
    throw createError({
      statusCode: 502,
      statusMessage: "Stored roof imagery could not be read",
    });
  }

  const bytes = await body.transformToByteArray();
  const contentType = response.ContentType || "image/png";
  return `data:${contentType};base64,${Buffer.from(bytes).toString("base64")}`;
}

function imageryKeyPrefix(addressKey: string, measurementId: string): string {
  const safeAddressKey = encodeURIComponent(addressKey).replace(/%20/g, "+");
  return `roof-probe/${safeAddressKey}/${measurementId}`;
}
