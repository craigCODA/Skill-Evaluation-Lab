import type { Job } from "~~/shared/types"
import { estimateValidationIssues } from "~~/shared/validation"

/** Reject API writes until the estimate has the minimum required fields. */
export function requireSavableEstimate(job: Job): void {
  const issues = estimateValidationIssues(job)
  if (issues.length > 0) {
    throw createError({
      statusCode: 400,
      statusMessage: issues.map((issue) => issue.message).join(", ")
    })
  }
}
