const XAI_BASE_URL = "https://api.x.ai/v1";

// Locking the framing (1:1, no reframe) keeps Grok's output aligned with the
// aerial so our projected segment markers still land in the right place.
const ROOF_LINE_PROMPT = [
  "Add only thin, bright yellow outline lines on top of this exact aerial photo.",
  "Trace the roof perimeter and every internal ridge, hip, and valley of the main",
  "central house so each separate roof plane is clearly outlined.",
  "CRITICAL: do not zoom, crop, pan, rotate, or reframe. Keep the composition,",
  "position, scale, and dimensions pixel-identical to the input.",
  "Change nothing else in the photo; only add the yellow lines.",
].join(" ");

type GrokEditResponse = {
  data?: Array<{ b64_json?: string; url?: string }>;
};

/**
 * Sends the aerial preview to Grok Imagine image-edit and returns a data URL of
 * the same frame with yellow roof facet lines drawn. Best-effort: returns
 * undefined on any failure so the caller can fall back to the plain aerial.
 */
export async function drawRoofLinesWithGrok(input: {
  imageDataUrl: string;
  apiKey: string;
}): Promise<string | undefined> {
  const response = await $fetch<GrokEditResponse>(`${XAI_BASE_URL}/images/edits`, {
    method: "POST",
    timeout: 18000,
    headers: {
      Authorization: `Bearer ${input.apiKey}`,
      "Content-Type": "application/json",
    },
    body: {
      model: "grok-imagine-image-quality",
      prompt: ROOF_LINE_PROMPT,
      response_format: "b64_json",
      aspect_ratio: "1:1",
      resolution: "1k",
      image: { type: "image_url", url: input.imageDataUrl },
    },
  });

  const item = response.data?.[0];
  if (item?.b64_json) {
    return `data:image/png;base64,${item.b64_json}`;
  }
  if (item?.url) {
    const buffer = await $fetch<ArrayBuffer>(item.url, {
      responseType: "arrayBuffer",
      timeout: 10000,
    });
    return `data:image/png;base64,${Buffer.from(buffer).toString("base64")}`;
  }
  return undefined;
}
