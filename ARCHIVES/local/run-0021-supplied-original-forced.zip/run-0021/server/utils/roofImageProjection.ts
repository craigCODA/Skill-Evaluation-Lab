import proj4 from "proj4";
import type { LatLng, RoofBoundingBox, RoofMaskPoint } from "~~/shared/types";

/**
 * Maps geographic coordinates onto the displayed roof image using the image's
 * own projected CRS (Google Solar GeoTIFFs are UTM/metres, not degrees), so
 * segment markers and boxes line up with the same pixels as the roof mask.
 */
export type RoofImageProjection = {
  pointToPercent(point: LatLng): RoofMaskPoint;
  boxToPercentRect(box: RoofBoundingBox): {
    left: number;
    top: number;
    width: number;
    height: number;
  };
};

export function buildImageProjection(input: {
  epsg?: number;
  bbox: number[];
}): RoofImageProjection | undefined {
  const definition = utmDefinition(input.epsg);
  const [minX, minY, maxX, maxY] = input.bbox;
  if (
    !definition ||
    minX === undefined ||
    minY === undefined ||
    maxX === undefined ||
    maxY === undefined ||
    maxX === minX ||
    maxY === minY
  ) {
    return undefined;
  }

  const transform = proj4("WGS84", definition);
  const originX = minX;
  const originY = maxY;
  const spanX = maxX - minX;
  const spanY = maxY - minY;

  function pointToPercent(point: LatLng): RoofMaskPoint {
    const [easting, northing] = transform.forward([point.longitude, point.latitude]);
    return {
      x: clamp(((easting - originX) / spanX) * 100),
      y: clamp(((originY - northing) / spanY) * 100),
    };
  }

  return {
    pointToPercent,
    boxToPercentRect(box: RoofBoundingBox) {
      const corners = [
        pointToPercent(box.sw),
        pointToPercent(box.ne),
        pointToPercent({ latitude: box.sw.latitude, longitude: box.ne.longitude }),
        pointToPercent({ latitude: box.ne.latitude, longitude: box.sw.longitude }),
      ];
      const xs = corners.map((corner) => corner.x);
      const ys = corners.map((corner) => corner.y);
      const left = Math.min(...xs);
      const top = Math.min(...ys);
      return {
        left,
        top,
        width: Math.max(...xs) - left,
        height: Math.max(...ys) - top,
      };
    },
  };
}

function utmDefinition(epsg?: number): string | undefined {
  if (epsg === undefined) return undefined;
  if (epsg >= 32601 && epsg <= 32660) {
    return `+proj=utm +zone=${epsg - 32600} +datum=WGS84 +units=m +no_defs`;
  }
  if (epsg >= 32701 && epsg <= 32760) {
    return `+proj=utm +zone=${epsg - 32700} +south +datum=WGS84 +units=m +no_defs`;
  }
  return undefined;
}

export function readTiffEpsg(
  geoKeys: Record<string, unknown> | null | undefined,
): number | undefined {
  const value = geoKeys?.ProjectedCSTypeGeoKey;
  return typeof value === "number" ? value : undefined;
}

const METERS_PER_DEGREE_LAT = 111_320;

/** Ground span of a GeoTIFF bounding box (UTM metres or geographic degrees). */
export function tiffExtentMeters(
  bbox: number[],
  epsg?: number,
): { widthMeters: number; heightMeters: number } | undefined {
  if (bbox.length < 4) return undefined;
  const minX = bbox[0];
  const minY = bbox[1];
  const maxX = bbox[2];
  const maxY = bbox[3];
  if (
    minX === undefined ||
    minY === undefined ||
    maxX === undefined ||
    maxY === undefined
  ) {
    return undefined;
  }

  if (utmDefinition(epsg)) {
    const widthMeters = Math.abs(maxX - minX);
    const heightMeters = Math.abs(maxY - minY);
    if (widthMeters > 0 && heightMeters > 0) {
      return { widthMeters, heightMeters };
    }
    return undefined;
  }

  if (
    Math.abs(minX) <= 180 &&
    Math.abs(maxX) <= 180 &&
    Math.abs(minY) <= 90 &&
    Math.abs(maxY) <= 90
  ) {
    const lat = (minY + maxY) / 2;
    const mPerLng = METERS_PER_DEGREE_LAT * Math.cos((lat * Math.PI) / 180);
    const widthMeters = Math.abs(maxX - minX) * mPerLng;
    const heightMeters = Math.abs(maxY - minY) * METERS_PER_DEGREE_LAT;
    if (widthMeters > 0 && heightMeters > 0) {
      return { widthMeters, heightMeters };
    }
  }

  return undefined;
}

/** Convert a GeoTIFF bounding box to WGS84 lat/lng for map links. */
export function tiffBoundsToLatLng(
  bbox: number[],
  epsg?: number,
): RoofBoundingBox | undefined {
  if (bbox.length < 4) return undefined;
  const minX = bbox[0];
  const minY = bbox[1];
  const maxX = bbox[2];
  const maxY = bbox[3];
  if (
    minX === undefined ||
    minY === undefined ||
    maxX === undefined ||
    maxY === undefined
  ) {
    return undefined;
  }

  const definition = utmDefinition(epsg);
  if (definition) {
    const transform = proj4("WGS84", definition);
    const sw = transform.inverse([minX, minY]);
    const ne = transform.inverse([maxX, maxY]);
    const west = sw[0];
    const south = sw[1];
    const east = ne[0];
    const north = ne[1];
    if (
      west === undefined ||
      south === undefined ||
      east === undefined ||
      north === undefined
    ) {
      return undefined;
    }
    return {
      sw: { latitude: south, longitude: west },
      ne: { latitude: north, longitude: east },
    };
  }

  if (
    Math.abs(minX) <= 180 &&
    Math.abs(maxX) <= 180 &&
    Math.abs(minY) <= 90 &&
    Math.abs(maxY) <= 90
  ) {
    return {
      sw: { latitude: minY, longitude: minX },
      ne: { latitude: maxY, longitude: maxX },
    };
  }

  return undefined;
}

function clamp(value: number): number {
  return Math.max(0, Math.min(100, value));
}
