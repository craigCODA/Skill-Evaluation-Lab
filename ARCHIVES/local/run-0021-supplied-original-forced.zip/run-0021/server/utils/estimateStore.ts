import type { Job } from "~~/shared/types"
import { and, desc, eq, or } from "drizzle-orm"
import { formatCustomerName } from "~~/shared/customer"
import { newDraftJob } from "~~/shared/job"
import { seedEstimate } from "~~/shared/seedEstimate"
import { DEV_ADMIN_SUB, type CurrentUser } from "./auth"
import { assertAccountCapability } from "./accountPermissions"
import { getCustomerAccountContext, type CustomerAccountContext } from "./customerAccountAccess"
import { customerCanReadJob } from "./customerStore"

/** Estimates are owned by a single user; admins can read every owner's estimates. */
type OwnedEstimate = { ownerId: string, job: Job }

let memoryEstimates: OwnedEstimate[] = [{ ownerId: DEV_ADMIN_SUB, job: seedEstimate() }]
let warnedAboutMemoryStore = false

function ownsOrAdmin(user: CurrentUser, ownerId: string): boolean {
  return user.isAdmin || ownerId === user.sub
}

export async function listEstimates(user: CurrentUser) {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "viewEstimates")
  if (useMemoryStore()) {
    return memoryEstimates
      .filter((record) => canReadEstimateRecord(record, user, context))
      .map((record) => record.job)
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
      .map(toMemoryListItem)
  }

  const db = useDatabase()
  const rows = await db
    .select()
    .from(schema.jobs)
    .where(context.canSeeAllCustomerAccountWork
      ? or(
          eq(schema.jobs.customerAccountId, context.customerAccount.id),
          eq(schema.jobs.ownerId, user.sub)
        )
      : or(
          and(
            eq(schema.jobs.customerAccountId, context.customerAccount.id),
            eq(schema.jobs.createdBySubAccountId, context.subAccount.id)
          ),
          eq(schema.jobs.ownerId, user.sub)
        ))
    .orderBy(desc(schema.jobs.updatedAt))
    .limit(100)

  return rows
    .map(toListItem)
}

export async function getEstimate(jobId: string, user: CurrentUser): Promise<Job | null> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "viewEstimates")
  return findAccountJob(jobId, user, context)
}

/**
 * Resolve a job for account-scoped workflows that are not estimate viewing
 * (e.g. job assets for installers). Checks ownership only.
 */
export async function resolveAccountJob(jobId: string, user: CurrentUser): Promise<Job | null> {
  const context = await getCustomerAccountContext(user)
  return findAccountJob(jobId, user, context)
}

export async function getEstimateOwnerId(jobId: string, user: CurrentUser): Promise<string | null> {
  const context = await getCustomerAccountContext(user)
  if (useMemoryStore()) {
    const record = memoryEstimates.find((estimate) => estimate.job.id === jobId)
    if (!record || !canReadEstimateRecord(record, user, context)) return null
    return record.ownerId
  }

  const row = await useDatabase()
    .select({
      ownerId: schema.jobs.ownerId,
      customerAccountId: schema.jobs.customerAccountId,
      createdBySubAccountId: schema.jobs.createdBySubAccountId
    })
    .from(schema.jobs)
    .where(eq(schema.jobs.id, jobId))
    .limit(1)

  const found = row[0]
  if (!found || !canReadPersistedJob(found, user, context)) return null
  return found.ownerId
}

export async function createEstimate(job: Job, user: CurrentUser): Promise<Job> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "editEstimates")
  const customerRecord = await ensureCustomerForJob(job.customer, user)
  const next = withCustomerLinks(job, context, customerRecord.id)

  if (useMemoryStore()) {
    memoryEstimates = [{ ownerId: user.sub, job: next }, ...memoryEstimates]
    return next
  }

  const db = useDatabase()
  await db.insert(schema.jobs).values(serializeJob(next, user.sub))
  return next
}

export async function createDraftEstimate(user: CurrentUser): Promise<Job> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "editEstimates")
  if (useMemoryStore()) {
    const draft = withCustomerLinks(newDraftJob(), context)
    memoryEstimates = [{ ownerId: user.sub, job: draft }, ...memoryEstimates]
    return draft
  }

  const db = useDatabase()
  const draft = withCustomerLinks(newDraftJob(), context)
  await db.insert(schema.jobs).values(serializeJob(draft, user.sub))
  return draft
}

export async function updateEstimate(job: Job, user: CurrentUser): Promise<Job> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "editEstimates")
  const customerRecord = await ensureCustomerForJob(job.customer, user)
  const next = withCustomerLinks(job, context, customerRecord.id)
  if (useMemoryStore()) {
    memoryEstimates = memoryEstimates.map((estimate) =>
      estimate.job.id === next.id ? { ...estimate, job: next } : estimate
    )
    return next
  }

  const db = useDatabase()
  await db
    .update(schema.jobs)
    .set({
      customerAccountId: next.customerAccountId ?? "",
      createdBySubAccountId: next.createdBySubAccountId ?? "",
      customerId: next.customerId ?? "",
      status: next.status,
      customerName: formatCustomerName(next.customer),
      bodyJson: next,
      updatedAt: new Date(next.updatedAt)
    })
    .where(user.isAdmin
      ? eq(schema.jobs.id, next.id)
      : and(eq(schema.jobs.id, next.id), eq(schema.jobs.ownerId, user.sub)))

  return next
}

export async function deleteDraftEstimate(jobId: string, user: CurrentUser): Promise<boolean> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "editEstimates")
  const existing = await findAccountJob(jobId, user, context)
  if (!existing || existing.status !== "draft") return false

  if (useMemoryStore()) {
    memoryEstimates = memoryEstimates.filter((estimate) => estimate.job.id !== jobId)
    return true
  }

  const db = useDatabase()
  await db.delete(schema.jobs).where(eq(schema.jobs.id, jobId))
  return true
}

export async function estimateDashboard(user: CurrentUser) {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "viewEstimates")
  if (useMemoryStore()) {
    const rows = memoryEstimates
      .filter((record) => canReadEstimateRecord(record, user, context))
      .map((record) => record.job)
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
    const byStatus = rows.reduce<Record<string, number>>((acc, estimate) => {
      acc[estimate.status] = (acc[estimate.status] ?? 0) + 1
      return acc
    }, {})

    return {
      totalJobs: rows.length,
      draftJobs: byStatus.draft ?? 0,
      roofProposalJobs: byStatus["roof-proposal"] ?? 0,
      temporaryRepairJobs: byStatus["temporary-repair"] ?? 0,
      proposedJobs: byStatus.proposed ?? 0,
      signedJobs: byStatus.signed ?? 0,
      completeJobs: byStatus.complete ?? 0,
      recentJobs: rows.slice(0, 5).map(toMemoryListItem)
    }
  }

  const db = useDatabase()
  const rows = await db
    .select()
    .from(schema.jobs)
    .where(context.canSeeAllCustomerAccountWork
      ? or(
          eq(schema.jobs.customerAccountId, context.customerAccount.id),
          eq(schema.jobs.ownerId, user.sub)
        )
      : or(
          and(
            eq(schema.jobs.customerAccountId, context.customerAccount.id),
            eq(schema.jobs.createdBySubAccountId, context.subAccount.id)
          ),
          eq(schema.jobs.ownerId, user.sub)
        ))
    .orderBy(desc(schema.jobs.updatedAt))
  const byStatus = rows.reduce<Record<string, number>>((acc, row) => {
    acc[row.status] = (acc[row.status] ?? 0) + 1
    return acc
  }, {})
  const recentJobs = rows.slice(0, 5).map(toListItem)

  return {
    totalJobs: rows.length,
    draftJobs: byStatus.draft ?? 0,
    roofProposalJobs: byStatus["roof-proposal"] ?? 0,
    temporaryRepairJobs: byStatus["temporary-repair"] ?? 0,
    proposedJobs: byStatus.proposed ?? 0,
    signedJobs: byStatus.signed ?? 0,
    completeJobs: byStatus.complete ?? 0,
    recentJobs
  }
}

async function findAccountJob(
  jobId: string,
  user: CurrentUser,
  context: CustomerAccountContext
): Promise<Job | null> {
  if (useMemoryStore()) {
    const record = memoryEstimates.find((estimate) => estimate.job.id === jobId)
    if (!record || !canReadEstimateRecord(record, user, context)) return null
    return record.job
  }

  const db = useDatabase()
  const row = await db
    .select()
    .from(schema.jobs)
    .where(eq(schema.jobs.id, jobId))
    .limit(1)

  const found = row[0]
  if (!found || !canReadPersistedJob(found, user, context)) return null
  return found.bodyJson
}

function serializeJob(job: Job, ownerId: string) {
  return {
    id: job.id,
    ownerId,
    customerAccountId: job.customerAccountId ?? "",
    createdBySubAccountId: job.createdBySubAccountId ?? "",
    customerId: job.customerId ?? "",
    status: job.status,
    customerName: formatCustomerName(job.customer),
    bodyJson: job,
    createdAt: new Date(job.createdAt),
    updatedAt: new Date(job.updatedAt)
  }
}

function withCustomerLinks(
  job: Job,
  context: Awaited<ReturnType<typeof getCustomerAccountContext>>,
  customerId = job.customerId || job.customer.id
): Job {
  return {
    ...job,
    customerAccountId: context.customerAccount.id,
    createdBySubAccountId: job.createdBySubAccountId || context.subAccount.id,
    customerId,
    customer: {
      ...job.customer,
      id: customerId
    },
    updatedAt: new Date().toISOString()
  }
}

function canReadEstimateRecord(
  record: OwnedEstimate,
  user: CurrentUser,
  context: Awaited<ReturnType<typeof getCustomerAccountContext>>
): boolean {
  if (record.job.customerAccountId) {
    return customerCanReadJob(context, record.job)
  }
  return ownsOrAdmin(user, record.ownerId)
}

function canReadPersistedJob(
  row: {
    ownerId: string
    customerAccountId?: string
    createdBySubAccountId?: string
  },
  user: CurrentUser,
  context: Awaited<ReturnType<typeof getCustomerAccountContext>>
): boolean {
  if (row.customerAccountId) return customerCanReadJob(context, row)
  return ownsOrAdmin(user, row.ownerId)
}

function useMemoryStore(): boolean {
  if (hasDatabaseUrl()) return false

  if (process.env.NODE_ENV === "production") {
    throw createError({
      statusCode: 500,
      statusMessage: "DATABASE_URL is required"
    })
  }

  if (!warnedAboutMemoryStore) {
    console.warn("[database] DATABASE_URL not set; using in-memory estimate store.")
    warnedAboutMemoryStore = true
  }

  return true
}

function toMemoryListItem(estimate: Job) {
  return {
    id: estimate.id,
    status: estimate.status,
    customerName: formatCustomerName(estimate.customer),
    displayName: formatCustomerName(estimate.customer),
    companyName: estimate.customer.companyName ?? "",
    firstName: estimate.customer.firstName ?? "",
    lastName: estimate.customer.lastName ?? "",
    address1: estimate.customer.address1,
    address2: estimate.customer.address2 ?? "",
    city: estimate.customer.city,
    state: estimate.customer.state,
    zip: estimate.customer.zip,
    address: formatAddress(estimate),
    createdAt: estimate.createdAt,
    updatedAt: estimate.updatedAt,
    ...contractForEstimate(estimate, estimate.status)
  }
}

function toListItem(row: { id: string, status: string, bodyJson: Job, createdAt: Date, updatedAt: Date }) {
  const estimate = row.bodyJson
  return {
    id: row.id,
    status: row.status,
    customerName: formatCustomerName(estimate.customer),
    displayName: formatCustomerName(estimate.customer),
    companyName: estimate.customer.companyName ?? "",
    firstName: estimate.customer.firstName ?? "",
    lastName: estimate.customer.lastName ?? "",
    address1: estimate.customer.address1,
    address2: estimate.customer.address2 ?? "",
    city: estimate.customer.city,
    state: estimate.customer.state,
    zip: estimate.customer.zip,
    address: formatAddress(estimate),
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
    ...contractForEstimate(estimate, row.status)
  }
}

function formatAddress(estimate: Job): string {
  const customer = estimate.customer
  const cityLine = [
    customer.city,
    [customer.state, customer.zip].filter(Boolean).join(" ")
  ].filter(Boolean).join(", ")

  return [customer.address1, customer.address2, cityLine].filter(Boolean).join(", ")
}

function contractForEstimate(estimate: Job, status: string) {
  const type = estimate.estimateType
    ?? (status === "roof-proposal" || status === "temporary-repair" ? status : undefined)

  if (type === "temporary-repair") {
    return { contractKind: type, contractLabel: "Contracts" }
  }
  if (type === "roof-proposal" && estimate.scope.roofing) {
    return { contractKind: type, contractLabel: "Contracts" }
  }
  return {}
}
