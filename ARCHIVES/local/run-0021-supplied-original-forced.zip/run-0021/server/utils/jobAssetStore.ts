import { and, desc, eq } from "drizzle-orm"
import { DeleteObjectCommand, GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3"
import type { DrawingScreenshotAssetMetadata, Job, JobAsset, JobAssetKind } from "~~/shared/types"
import { newId } from "~~/shared/ids"
import type { CurrentUser } from "./auth"
import { assertAccountCapability, contextHasCapability } from "./accountPermissions"
import type { CustomerAccountContext } from "./customerAccountAccess"

type ParsedDataUrl = {
  contentType: string
  body: Buffer
}

type CreateJobAssetInput = {
  jobId: string
  label: string
  description?: string
  kind: JobAssetKind
  imageDataUrl: string
  metadata?: DrawingScreenshotAssetMetadata
}

let s3Client: S3Client | null = null
let memoryAssets: JobAsset[] = []
const memoryAssetImages = new Map<string, string>()

export async function listJobAssets(jobId: string, user: CurrentUser): Promise<JobAsset[]> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "manageJobAssets")
  const job = await resolveAccountJob(jobId, user)
  if (!job || !canReadJobAssetJob(job, context)) return []

  if (useMemoryStore()) {
    return memoryAssets
      .filter((asset) => asset.jobId === jobId && canReadJobAsset(asset, context))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  }

  const rows = await useDatabase()
    .select()
    .from(schema.jobAssets)
    .where(and(
      eq(schema.jobAssets.jobId, jobId),
      eq(schema.jobAssets.customerAccountId, context.customerAccount.id)
    ))
    .orderBy(desc(schema.jobAssets.createdAt))

  return rows.map((row) => row.bodyJson).filter((asset) => canReadJobAsset(asset, context))
}

export async function listJobAssetsForCustomer(customerId: string, user: CurrentUser): Promise<Record<string, JobAsset[]>> {
  const context = await getCustomerAccountContext(user)
  if (!contextHasCapability(context, "manageJobAssets")) return {}

  if (useMemoryStore()) {
    return groupAssetsByJob(memoryAssets.filter((asset) =>
      asset.customerId === customerId && canReadJobAsset(asset, context)
    ))
  }

  const rows = await useDatabase()
    .select()
    .from(schema.jobAssets)
    .where(context.canSeeAllCustomerAccountWork
      ? and(
          eq(schema.jobAssets.customerAccountId, context.customerAccount.id),
          eq(schema.jobAssets.customerId, customerId)
        )
      : and(
          eq(schema.jobAssets.customerAccountId, context.customerAccount.id),
          eq(schema.jobAssets.customerId, customerId),
          eq(schema.jobAssets.createdBySubAccountId, context.subAccount.id)
        ))
    .orderBy(desc(schema.jobAssets.createdAt))

  return groupAssetsByJob(rows.map((row) => row.bodyJson))
}

export async function createJobAsset(input: CreateJobAssetInput, user: CurrentUser): Promise<JobAsset> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "manageJobAssets")
  const job = await resolveAccountJob(input.jobId, user)
  if (!job || !canReadJobAssetJob(job, context)) {
    throw createError({ statusCode: 404, statusMessage: "Job not found" })
  }
  if (!job.customerId) {
    throw createError({ statusCode: 400, statusMessage: "Job is not linked to a customer" })
  }

  const now = new Date().toISOString()
  const image = parseDataUrl(input.imageDataUrl)
  const assetId = newId()
  const imageKey = jobAssetImageKey({
    customerAccountId: context.customerAccount.id,
    customerId: job.customerId,
    jobId: job.id,
    assetId
  })
  const asset: JobAsset = {
    id: assetId,
    customerAccountId: context.customerAccount.id,
    createdBySubAccountId: job.createdBySubAccountId || context.subAccount.id,
    customerId: job.customerId,
    jobId: job.id,
    kind: input.kind,
    label: input.label.trim() || "Drawing screenshot",
    description: input.description?.trim(),
    contentType: image.contentType,
    imageKey,
    metadata: input.metadata,
    createdAt: now,
    updatedAt: now
  }

  if (useMemoryStore()) {
    memoryAssets = [asset, ...memoryAssets]
    memoryAssetImages.set(imageKey, input.imageDataUrl)
    return asset
  }

  await putImage(imageKey, image)
  await useDatabase()
    .insert(schema.jobAssets)
    .values(serializeJobAsset(asset))

  return asset
}

export async function getJobAssetImage(assetId: string, user: CurrentUser): Promise<{ asset: JobAsset, dataUrl: string } | null> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "manageJobAssets")
  const asset = await getJobAsset(assetId, context)
  if (!asset) return null

  if (useMemoryStore()) {
    const dataUrl = memoryAssetImages.get(asset.imageKey)
    return dataUrl ? { asset, dataUrl } : null
  }

  return {
    asset,
    dataUrl: await getImageDataUrl(asset.imageKey)
  }
}

export async function deleteJobAsset(assetId: string, user: CurrentUser): Promise<boolean> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "manageJobAssets")
  const asset = await getJobAsset(assetId, context)
  if (!asset) return false

  if (useMemoryStore()) {
    memoryAssets = memoryAssets.filter((item) => item.id !== assetId)
    memoryAssetImages.delete(asset.imageKey)
    return true
  }

  await deleteImage(asset.imageKey)
  await useDatabase()
    .delete(schema.jobAssets)
    .where(eq(schema.jobAssets.id, assetId))
  return true
}

export async function updateJobAssetDescription(assetId: string, description: string, user: CurrentUser): Promise<JobAsset | null> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "manageJobAssets")
  const existing = await getJobAsset(assetId, context)
  if (!existing) return null

  const next: JobAsset = {
    ...existing,
    description: description.trim(),
    updatedAt: new Date().toISOString()
  }

  if (useMemoryStore()) {
    memoryAssets = memoryAssets.map((asset) => asset.id === assetId ? next : asset)
    return next
  }

  await useDatabase()
    .update(schema.jobAssets)
    .set({
      bodyJson: next,
      updatedAt: new Date(next.updatedAt)
    })
    .where(eq(schema.jobAssets.id, assetId))
  return next
}

async function getJobAsset(assetId: string, context: CustomerAccountContext): Promise<JobAsset | null> {
  if (useMemoryStore()) {
    return memoryAssets.find((asset) => asset.id === assetId && canReadJobAsset(asset, context)) ?? null
  }

  const row = (await useDatabase()
    .select()
    .from(schema.jobAssets)
    .where(eq(schema.jobAssets.id, assetId))
    .limit(1))[0]
  if (!row || !canReadJobAsset(row.bodyJson, context)) return null
  return row.bodyJson
}

function canReadJobAsset(asset: JobAsset, context: CustomerAccountContext): boolean {
  return asset.customerAccountId === context.customerAccount.id
    && ownsCustomerAccountWork(context, asset.createdBySubAccountId)
}

function canReadJobAssetJob(job: Job, context: CustomerAccountContext): boolean {
  return Boolean(job.customerAccountId && job.customerId)
    && job.customerAccountId === context.customerAccount.id
    && ownsCustomerAccountWork(context, job.createdBySubAccountId || "")
}

function groupAssetsByJob(assets: JobAsset[]): Record<string, JobAsset[]> {
  return assets.reduce<Record<string, JobAsset[]>>((acc, asset) => {
    acc[asset.jobId] = [...(acc[asset.jobId] ?? []), asset]
    return acc
  }, {})
}

function serializeJobAsset(asset: JobAsset) {
  return {
    id: asset.id,
    customerAccountId: asset.customerAccountId,
    createdBySubAccountId: asset.createdBySubAccountId,
    customerId: asset.customerId,
    jobId: asset.jobId,
    kind: asset.kind,
    label: asset.label,
    contentType: asset.contentType,
    imageKey: asset.imageKey,
    bodyJson: asset,
    createdAt: new Date(asset.createdAt),
    updatedAt: new Date(asset.updatedAt)
  }
}

function parseDataUrl(dataUrl: string): ParsedDataUrl {
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/)
  if (!match) {
    throw createError({ statusCode: 400, statusMessage: "Asset image is not a valid data URL" })
  }
  return {
    contentType: match[1] ?? "image/png",
    body: Buffer.from(match[2] ?? "", "base64")
  }
}

async function putImage(key: string, image: ParsedDataUrl): Promise<void> {
  await s3().send(new PutObjectCommand({
    Bucket: assetBucket(),
    Key: key,
    Body: image.body,
    ContentType: image.contentType
  }))
}

async function getImageDataUrl(key: string): Promise<string> {
  const response = await s3().send(new GetObjectCommand({
    Bucket: assetBucket(),
    Key: key
  }))
  const body = response.Body as { transformToByteArray?: () => Promise<Uint8Array> } | undefined
  if (!body?.transformToByteArray) {
    throw createError({ statusCode: 502, statusMessage: "Stored asset image could not be read" })
  }

  const bytes = await body.transformToByteArray()
  const contentType = response.ContentType || "image/png"
  return `data:${contentType};base64,${Buffer.from(bytes).toString("base64")}`
}

async function deleteImage(key: string): Promise<void> {
  await s3().send(new DeleteObjectCommand({
    Bucket: assetBucket(),
    Key: key
  }))
}

function s3(): S3Client {
  if (s3Client) return s3Client
  s3Client = new S3Client({ region: useRuntimeConfig().public.awsRegion })
  return s3Client
}

function assetBucket(): string {
  const bucket = useRuntimeConfig().roofProbeImageryBucket || process.env.ROOF_PROBE_IMAGERY_BUCKET
  if (!bucket) {
    throw createError({ statusCode: 500, statusMessage: "Asset storage is not configured" })
  }
  return bucket
}

function jobAssetImageKey(input: {
  customerAccountId: string
  customerId: string
  jobId: string
  assetId: string
}): string {
  return `job-assets/${input.customerAccountId}/${input.customerId}/${input.jobId}/${input.assetId}.png`
}

function useMemoryStore(): boolean {
  if (hasDatabaseUrl()) return false
  if (process.env.NODE_ENV === "production") {
    throw createError({ statusCode: 500, statusMessage: "DATABASE_URL is required" })
  }
  return true
}
