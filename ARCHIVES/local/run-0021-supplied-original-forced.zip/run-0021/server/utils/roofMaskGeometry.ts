import { fromArrayBuffer } from "geotiff";
import { buildImageProjection, readTiffEpsg } from "./roofImageProjection";
import type { RoofImageProjection } from "./roofImageProjection";
import type {
  LatLng,
  RoofMaskGeometry,
  RoofMaskOutline,
  RoofMaskPoint,
  RoofSegment,
} from "~~/shared/types";

export async function analyzeMaskLayer(
  maskUrl: string,
  apiKey: string,
  segments: RoofSegment[],
  targetPoint: LatLng,
): Promise<RoofMaskGeometry> {
  const image = await fetchTiffImage(maskUrl, apiKey);
  const width = image.getWidth();
  const height = image.getHeight();
  const maxWidth = 640;
  const scale = Math.max(1, Math.ceil(width / maxWidth));
  const previewWidth = Math.max(1, Math.floor(width / scale));
  const previewHeight = Math.max(1, Math.floor(height / scale));
  const rasters = await image.readRasters({
    interleave: true,
    width: previewWidth,
    height: previewHeight,
  });
  const mask = new Uint8Array(previewWidth * previewHeight);
  let maskPixels = 0;

  for (let index = 0; index < mask.length; index += 1) {
    if (Number(rasters[index] ?? 0) > 0) {
      mask[index] = 1;
      maskPixels += 1;
    }
  }

  if (!maskPixels) {
    throw createError({
      statusCode: 502,
      statusMessage: "Roof mask did not include usable pixels",
    });
  }

  const projection = buildImageProjection({
    epsg: readTiffEpsg(image.getGeoKeys()),
    bbox: image.getBoundingBox(),
  });
  const targetPixel = projection
    ? percentToMaskPixel(projection.pointToPercent(targetPoint), previewWidth, previewHeight)
    : undefined;
  const outlines = selectTargetOutlines(
    extractMaskOutlines(mask, previewWidth, previewHeight),
    targetPixel,
    previewWidth,
    previewHeight,
  );
  const segmentValidations = validateSegmentsAgainstMask({
    height: previewHeight,
    mask,
    outlines,
    projection,
    segments,
    width: previewWidth,
  });

  const targetCoverage = outlines.reduce((sum, outline) => sum + outline.areaPercent, 0);

  return {
    outlines,
    segmentValidations,
    maskCoveragePercent: roundTo(targetCoverage, 4),
    notes: maskGeometryNotes(outlines, segmentValidations),
  };
}

async function fetchTiffImage(urlValue: string, apiKey: string) {
  const url = new URL(urlValue);
  url.searchParams.set("key", apiKey);
  const response = await fetch(url);
  if (!response.ok) {
    throw createError({
      statusCode: 502,
      statusMessage: "Roof mask download failed",
    });
  }

  const tiff = await fromArrayBuffer(await response.arrayBuffer());
  return tiff.getImage();
}

function extractMaskOutlines(
  mask: Uint8Array,
  width: number,
  height: number,
): RoofMaskOutline[] {
  const componentMap = new Int32Array(mask.length);
  const outlines: RoofMaskOutline[] = [];
  let componentId = 0;

  for (let index = 0; index < mask.length; index += 1) {
    if (!mask[index] || componentMap[index]) continue;
    componentId += 1;
    const pixels = collectMaskComponent({
      componentId,
      componentMap,
      height,
      mask,
      startIndex: index,
      width,
    });
    if (pixels.length < 20) continue;
    outlines.push(maskComponentOutline({
      componentId,
      componentMap,
      height,
      pixels,
      width,
    }));
  }

  return outlines
    .sort((left, right) => right.areaPixels - left.areaPixels)
    .slice(0, 5);
}

function selectTargetOutlines(
  outlines: RoofMaskOutline[],
  targetPixel?: { x: number; y: number },
  width = 1,
  height = 1,
): RoofMaskOutline[] {
  const fallback = outlines[0];
  if (!fallback) return [];
  if (!targetPixel) return [fallback];

  const targetPoint = {
    x: ((targetPixel.x + 0.5) / width) * 100,
    y: ((targetPixel.y + 0.5) / height) * 100,
  };
  const selected = outlines
    .map((outline) => ({
      outline,
      distance: distanceToOutline(targetPoint, outline),
    }))
    .sort((left, right) => left.distance - right.distance)[0]?.outline;

  return selected ? [selected] : [fallback];
}

function distanceToOutline(
  point: { x: number; y: number },
  outline: RoofMaskOutline,
): number {
  const centerX = outline.centroid.x;
  const centerY = outline.centroid.y;
  const targetX = point.x;
  const targetY = point.y;
  return (centerX - targetX) ** 2 + (centerY - targetY) ** 2;
}

function collectMaskComponent(input: {
  componentId: number;
  componentMap: Int32Array;
  height: number;
  mask: Uint8Array;
  startIndex: number;
  width: number;
}): number[] {
  const queue = [input.startIndex];
  const pixels: number[] = [];
  input.componentMap[input.startIndex] = input.componentId;

  for (let cursor = 0; cursor < queue.length; cursor += 1) {
    const index = queue[cursor];
    if (index === undefined) continue;
    pixels.push(index);
    const x = index % input.width;
    const y = Math.floor(index / input.width);
    const neighbors = [
      x > 0 ? index - 1 : -1,
      x < input.width - 1 ? index + 1 : -1,
      y > 0 ? index - input.width : -1,
      y < input.height - 1 ? index + input.width : -1,
    ];

    for (const neighbor of neighbors) {
      if (neighbor < 0 || !input.mask[neighbor] || input.componentMap[neighbor]) continue;
      input.componentMap[neighbor] = input.componentId;
      queue.push(neighbor);
    }
  }

  return pixels;
}

function maskComponentOutline(input: {
  componentId: number;
  componentMap: Int32Array;
  height: number;
  pixels: number[];
  width: number;
}): RoofMaskOutline {
  let minX = input.width;
  let minY = input.height;
  let maxX = 0;
  let maxY = 0;
  let totalX = 0;
  let totalY = 0;
  const pathSegments: string[] = [];

  for (const index of input.pixels) {
    const x = index % input.width;
    const y = Math.floor(index / input.width);
    minX = Math.min(minX, x);
    minY = Math.min(minY, y);
    maxX = Math.max(maxX, x);
    maxY = Math.max(maxY, y);
    totalX += x + 0.5;
    totalY += y + 0.5;
    appendMaskPixelEdges({
      componentId: input.componentId,
      componentMap: input.componentMap,
      height: input.height,
      pathSegments,
      width: input.width,
      x,
      y,
    });
  }

  const areaPixels = input.pixels.length;
  return {
    id: `mask-outline-${input.componentId}`,
    path: pathSegments.join(" "),
    areaPixels,
    areaPercent: roundTo(areaPixels / (input.width * input.height), 4),
    centroid: {
      x: roundTo((totalX / areaPixels / input.width) * 100, 2),
      y: roundTo((totalY / areaPixels / input.height) * 100, 2),
    },
    boundingBox: {
      left: roundTo((minX / input.width) * 100, 2),
      top: roundTo((minY / input.height) * 100, 2),
      width: roundTo(((maxX - minX + 1) / input.width) * 100, 2),
      height: roundTo(((maxY - minY + 1) / input.height) * 100, 2),
    },
  };
}

function appendMaskPixelEdges(input: {
  componentId: number;
  componentMap: Int32Array;
  height: number;
  pathSegments: string[];
  width: number;
  x: number;
  y: number;
}): void {
  const left = input.x;
  const right = input.x + 1;
  const top = input.y;
  const bottom = input.y + 1;
  const hasLeft = input.x > 0 &&
    input.componentMap[input.y * input.width + input.x - 1] === input.componentId;
  const hasRight = input.x < input.width - 1 &&
    input.componentMap[input.y * input.width + input.x + 1] === input.componentId;
  const hasTop = input.y > 0 &&
    input.componentMap[(input.y - 1) * input.width + input.x] === input.componentId;
  const hasBottom = input.y < input.height - 1 &&
    input.componentMap[(input.y + 1) * input.width + input.x] === input.componentId;

  if (!hasTop) input.pathSegments.push(maskEdgePath(left, top, right, top, input.width, input.height));
  if (!hasRight) input.pathSegments.push(maskEdgePath(right, top, right, bottom, input.width, input.height));
  if (!hasBottom) input.pathSegments.push(maskEdgePath(right, bottom, left, bottom, input.width, input.height));
  if (!hasLeft) input.pathSegments.push(maskEdgePath(left, bottom, left, top, input.width, input.height));
}

function maskEdgePath(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  width: number,
  height: number,
): string {
  return [
    "M",
    roundTo((x1 / width) * 100, 2),
    roundTo((y1 / height) * 100, 2),
    "L",
    roundTo((x2 / width) * 100, 2),
    roundTo((y2 / height) * 100, 2),
  ].join(" ");
}

function validateSegmentsAgainstMask(input: {
  height: number;
  mask: Uint8Array;
  outlines: RoofMaskOutline[];
  projection?: RoofImageProjection;
  segments: RoofSegment[];
  width: number;
}): RoofMaskGeometry["segmentValidations"] {
  return input.segments.map((segment, index) => {
    const anchor = segment.center ?? segmentBoundingBoxCenter(segment);
    const projected = anchor && input.projection
      ? input.projection.pointToPercent(anchor)
      : undefined;
    const centerPixel = projected
      ? percentToMaskPixel(projected, input.width, input.height)
      : undefined;
    const centerInsideMask = centerPixel
      ? isMaskPixel(input.mask, input.width, input.height, centerPixel.x, centerPixel.y)
      : false;
    const marker = projected ??
      distributedFallbackMarker(input.outlines, index, input.segments.length);
    const box = segment.boundingBox && input.projection
      ? input.projection.boxToPercentRect(segment.boundingBox)
      : undefined;

    return {
      segmentId: segment.id,
      centerInsideMask,
      marker,
      box,
      boundingBoxOverlapRatio: undefined,
      notes: segmentMaskNotes({
        centerInsideMask,
        hasAnchor: Boolean(projected),
        hasProviderCenter: Boolean(segment.center),
      }),
    };
  });
}

function percentToMaskPixel(
  point: RoofMaskPoint,
  width: number,
  height: number,
): { x: number; y: number } {
  return {
    x: Math.round((point.x / 100) * (width - 1)),
    y: Math.round((point.y / 100) * (height - 1)),
  };
}

function segmentBoundingBoxCenter(segment: RoofSegment): RoofSegment["center"] {
  const box = segment.boundingBox;
  if (!box) return undefined;
  return {
    latitude: (box.sw.latitude + box.ne.latitude) / 2,
    longitude: (box.sw.longitude + box.ne.longitude) / 2,
  };
}

function isMaskPixel(
  mask: Uint8Array,
  width: number,
  height: number,
  x: number,
  y: number,
): boolean {
  if (x < 0 || y < 0 || x >= width || y >= height) return false;
  return Boolean(mask[y * width + x]);
}

function distributedFallbackMarker(
  outlines: RoofMaskOutline[],
  index: number,
  total: number,
): RoofMaskPoint {
  const outline = outlines[0];
  if (!outline) return { x: 50, y: 50 };
  const ratio = total <= 1 ? 0.5 : index / (total - 1);
  return {
    x: roundTo(clamp(outline.boundingBox.left + outline.boundingBox.width * (0.25 + ratio * 0.5)), 2),
    y: outline.centroid.y,
  };
}

function segmentMaskNotes(input: {
  centerInsideMask: boolean;
  hasAnchor: boolean;
  hasProviderCenter: boolean;
}): string[] {
  const notes: string[] = [];
  if (!input.hasAnchor) {
    notes.push("Provider segment did not include enough geometry to place it on the preview.");
    return notes;
  }
  if (!input.hasProviderCenter) {
    notes.push("Provider segment center was inferred from its bounding box.");
  }
  if (!input.centerInsideMask) {
    notes.push("Provider segment center sits outside the traced roof mask.");
  }
  return notes;
}

function maskGeometryNotes(
  outlines: RoofMaskOutline[],
  validations: RoofMaskGeometry["segmentValidations"],
): string[] {
  const notes: string[] = [];
  if (outlines.length > 1) {
    notes.push("Roof mask contains multiple disconnected regions.");
  }
  const missingGeometry = validations.some((validation) =>
    validation.notes.some((note) => note.includes("did not include enough geometry")),
  );
  if (missingGeometry) {
    notes.push("Provider did not include enough segment geometry to place all facets on the preview.");
  }
  const outsideCount = validations.filter((validation) => !validation.centerInsideMask).length;
  if (outsideCount > 0) {
    notes.push(
      `${outsideCount} of ${validations.length} segment center${outsideCount === 1 ? "" : "s"} fall outside the traced roof mask.`,
    );
  }
  if (!notes.length) {
    notes.push("All provider segment centers fall inside the traced roof mask.");
  }
  return notes;
}

function roundTo(value: number, digits: number): number {
  const multiplier = 10 ** digits;
  return Math.round(value * multiplier) / multiplier;
}

function clamp(value: number): number {
  return Math.max(0, Math.min(100, value));
}
