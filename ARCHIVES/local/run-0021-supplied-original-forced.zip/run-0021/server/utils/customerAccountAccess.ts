import type { CustomerAccount, CustomerAccountRole, SubAccount } from "~~/shared/types"
import {
  capabilitiesForAccountUser,
  isAssignableCustomerAccountRole,
  normalizeCompanyRoleCapabilities,
  normalizeCustomerAccountRole,
  readCompanyRoleCapabilities,
  seesAllAccountWork,
  type AccountCapability,
  type AssignableCustomerAccountRole
} from "~~/shared/accountPermissions"
import { eq } from "drizzle-orm"
import { DEV_ADMIN_SUB, type CurrentUser } from "./auth"
import { assertAccountCapability } from "./accountPermissions"
import { passwordPolicyError } from "~~/shared/passwordPolicy"
import { createUser } from "./userDirectory"

export type CustomerAccountContext = {
  customerAccount: CustomerAccount
  subAccount: SubAccount
  canSeeAllCustomerAccountWork: boolean
  isPlatformAdmin: boolean
  capabilities: AccountCapability[]
}

export type CreateCustomerAccountSubAccountInput = {
  email: string
  name: string
  password: string
  role: AssignableCustomerAccountRole
  title?: string
}

/** In-memory sub-accounts when DATABASE_URL is unset (local only). */
const memorySubAccounts: SubAccount[] = []
/** In-memory company accounts (role capability overrides) when DATABASE_URL is unset. */
const memoryCustomerAccounts = new Map<string, CustomerAccount>()

export function defaultCustomerAccountId(user: CurrentUser): string {
  return `customer-account:${user.sub}`
}

export function defaultSubAccountId(user: CurrentUser): string {
  return user.isAdmin ? `sub-account:${DEV_ADMIN_SUB}` : `sub-account:${user.sub}`
}

export function ownsCustomerAccountWork(context: CustomerAccountContext, createdBySubAccountId: string): boolean {
  return context.canSeeAllCustomerAccountWork || createdBySubAccountId === context.subAccount.id
}

export async function listCustomerAccountSubAccounts(user: CurrentUser): Promise<SubAccount[]> {
  const context = await getCustomerAccountContext(user)
  if (!context.canSeeAllCustomerAccountWork) return [context.subAccount]
  if (!hasDatabaseUrl()) {
    return memorySubAccountsForAccount(context.customerAccount.id, context.subAccount)
  }

  const rows = await useDatabase()
    .select()
    .from(schema.subAccounts)
    .where(eq(schema.subAccounts.customerAccountId, context.customerAccount.id))

  return rows.map((row) => withNormalizedRole(row.bodyJson))
}

export async function createCustomerAccountSubAccount(
  user: CurrentUser,
  input: CreateCustomerAccountSubAccountInput
): Promise<SubAccount> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "manageSubAccounts", "Customer account admin access required")

  const email = input.email.trim().toLowerCase()
  const name = input.name.trim() || email
  const password = input.password
  const role = input.role
  const title = input.title?.trim() || ""

  if (!email || !password) {
    throw createError({ statusCode: 400, statusMessage: "Email and password are required" })
  }
  if (!isAssignableCustomerAccountRole(role)) {
    throw createError({ statusCode: 400, statusMessage: "Invalid team role" })
  }
  const policyError = passwordPolicyError(password)
  if (policyError) {
    throw createError({ statusCode: 400, statusMessage: policyError })
  }

  if (await findSubAccountByEmail(email)) {
    throw createError({ statusCode: 409, statusMessage: "A team member with this email already exists" })
  }

  const directoryUser = await createUser({
    email,
    name,
    password,
    role: "customer"
  })

  if (await findSubAccountByUserId(directoryUser.userId)) {
    throw createError({ statusCode: 409, statusMessage: "This user is already linked to a company account" })
  }

  const now = new Date().toISOString()
  const subAccount: SubAccount = {
    id: `sub-account:${directoryUser.userId}`,
    customerAccountId: context.customerAccount.id,
    userId: directoryUser.userId,
    email,
    name,
    title,
    role,
    createdAt: now,
    updatedAt: now
  }

  if (!hasDatabaseUrl()) {
    memorySubAccounts.push(subAccount)
    return subAccount
  }

  await useDatabase()
    .insert(schema.subAccounts)
    .values({
      id: subAccount.id,
      customerAccountId: subAccount.customerAccountId,
      userId: subAccount.userId,
      email: subAccount.email,
      name: subAccount.name,
      role: subAccount.role,
      bodyJson: subAccount,
      createdAt: new Date(subAccount.createdAt),
      updatedAt: new Date(subAccount.updatedAt)
    })

  return subAccount
}

export async function updateCustomerAccountSubAccountRole(
  user: CurrentUser,
  subAccountId: string,
  role: AssignableCustomerAccountRole
): Promise<SubAccount> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "manageSubAccounts", "Customer account admin access required")

  if (!isAssignableCustomerAccountRole(role)) {
    throw createError({ statusCode: 400, statusMessage: "Invalid team role" })
  }
  if (subAccountId === context.subAccount.id) {
    throw createError({ statusCode: 400, statusMessage: "You cannot change your own role" })
  }

  const existing = await findSubAccountById(subAccountId)
  if (!existing || existing.customerAccountId !== context.customerAccount.id) {
    throw createError({ statusCode: 404, statusMessage: "Team member not found" })
  }

  if (
    existing.role === "customer-account-admin"
    && role !== "customer-account-admin"
    && !(await hasOtherAccountAdmin(context.customerAccount.id, existing.id))
  ) {
    throw createError({
      statusCode: 400,
      statusMessage: "Cannot remove the last account admin"
    })
  }

  const next: SubAccount = {
    ...withNormalizedRole(existing),
    role,
    updatedAt: new Date().toISOString()
  }

  if (!hasDatabaseUrl()) {
    const index = memorySubAccounts.findIndex((item) => item.id === subAccountId)
    if (index >= 0) memorySubAccounts[index] = next
    return next
  }

  await useDatabase()
    .update(schema.subAccounts)
    .set({
      role: next.role,
      bodyJson: next,
      updatedAt: new Date(next.updatedAt)
    })
    .where(eq(schema.subAccounts.id, subAccountId))

  return next
}

export async function updateCurrentSubAccount(
  user: CurrentUser,
  input: { name?: string, title?: string }
): Promise<SubAccount> {
  const context = await getCustomerAccountContext(user)
  const now = new Date().toISOString()
  const next: SubAccount = {
    ...context.subAccount,
    name: input.name?.trim() || context.subAccount.name,
    title: input.title?.trim() || "",
    updatedAt: now
  }

  if (!hasDatabaseUrl()) {
    upsertMemorySubAccount(next)
    return next
  }

  await useDatabase()
    .update(schema.subAccounts)
    .set({
      name: next.name,
      bodyJson: next,
      updatedAt: new Date(next.updatedAt)
    })
    .where(eq(schema.subAccounts.id, next.id))

  return next
}

export async function updateCustomerAccountRoleCapabilities(
  user: CurrentUser,
  input: unknown
): Promise<Record<AssignableCustomerAccountRole, AccountCapability[]>> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "manageSubAccounts", "Customer account admin access required")

  const roleCapabilities = normalizeCompanyRoleCapabilities(input)
  const nextAccount: CustomerAccount = {
    ...context.customerAccount,
    roleCapabilities,
    updatedAt: new Date().toISOString()
  }

  if (!hasDatabaseUrl()) {
    memoryCustomerAccounts.set(nextAccount.id, nextAccount)
    return roleCapabilities
  }

  await useDatabase()
    .update(schema.customerAccounts)
    .set({
      bodyJson: nextAccount,
      updatedAt: new Date(nextAccount.updatedAt)
    })
    .where(eq(schema.customerAccounts.id, nextAccount.id))

  return roleCapabilities
}

export async function getCustomerAccountContext(user: CurrentUser): Promise<CustomerAccountContext> {
  if (!hasDatabaseUrl()) return memoryCustomerAccountContext(user)

  const db = useDatabase()
  const existingSubAccount = (await db
    .select()
    .from(schema.subAccounts)
    .where(eq(schema.subAccounts.userId, user.sub))
    .limit(1))[0]

  if (existingSubAccount) {
    const accountRow = (await db
      .select()
      .from(schema.customerAccounts)
      .where(eq(schema.customerAccounts.id, existingSubAccount.customerAccountId))
      .limit(1))[0]

    if (!accountRow) {
      throw createError({ statusCode: 403, statusMessage: "Customer account not found" })
    }

    return buildContext(user, accountRow.bodyJson, existingSubAccount.bodyJson)
  }

  return createDefaultCustomerAccountContext(user)
}

async function createDefaultCustomerAccountContext(user: CurrentUser): Promise<CustomerAccountContext> {
  const now = new Date().toISOString()
  const accountId = defaultCustomerAccountId(user)
  const subAccountId = defaultSubAccountId(user)
  const account: CustomerAccount = {
    id: accountId,
    name: user.isAdmin ? "Hahn Roofing" : `${user.name || user.email || "Customer"} Account`,
    adminUserId: user.sub,
    createdAt: now,
    updatedAt: now
  }
  const subAccount: SubAccount = {
    id: subAccountId,
    customerAccountId: accountId,
    userId: user.sub,
    email: user.email,
    name: user.name || user.email,
    role: "customer-account-admin",
    createdAt: now,
    updatedAt: now
  }

  const db = useDatabase()
  await db
    .insert(schema.customerAccounts)
    .values({
      id: account.id,
      name: account.name,
      adminUserId: account.adminUserId,
      bodyJson: account,
      createdAt: new Date(account.createdAt),
      updatedAt: new Date(account.updatedAt)
    })
    .onConflictDoNothing()

  await db
    .insert(schema.subAccounts)
    .values({
      id: subAccount.id,
      customerAccountId: subAccount.customerAccountId,
      userId: subAccount.userId,
      email: subAccount.email,
      name: subAccount.name,
      role: subAccount.role,
      bodyJson: subAccount,
      createdAt: new Date(subAccount.createdAt),
      updatedAt: new Date(subAccount.updatedAt)
    })
    .onConflictDoNothing()

  return buildContext(user, account, subAccount)
}

function memoryCustomerAccountContext(user: CurrentUser): CustomerAccountContext {
  const invited = memorySubAccounts.find((item) => item.userId === user.sub)
  if (invited) {
    const fallback: CustomerAccount = {
      id: invited.customerAccountId,
      name: "Company Account",
      adminUserId: invited.customerAccountId.replace(/^customer-account:/, "") || user.sub,
      createdAt: invited.createdAt,
      updatedAt: invited.updatedAt
    }
    const account = memoryCustomerAccounts.get(invited.customerAccountId) ?? fallback
    if (!memoryCustomerAccounts.has(invited.customerAccountId)) {
      memoryCustomerAccounts.set(invited.customerAccountId, account)
    }
    return buildContext(user, account, invited)
  }

  const now = new Date().toISOString()
  const accountId = defaultCustomerAccountId(user)
  let account = memoryCustomerAccounts.get(accountId)
  if (!account) {
    account = {
      id: accountId,
      name: user.isAdmin ? "Hahn Roofing" : `${user.name || user.email || "Customer"} Account`,
      adminUserId: user.sub,
      createdAt: now,
      updatedAt: now
    }
    memoryCustomerAccounts.set(accountId, account)
  }

  const subAccount: SubAccount = {
    id: defaultSubAccountId(user),
    customerAccountId: account.id,
    userId: user.sub,
    email: user.email,
    name: user.name || user.email,
    role: "customer-account-admin",
    createdAt: account.createdAt,
    updatedAt: account.updatedAt
  }
  upsertMemorySubAccount(subAccount)
  return buildContext(user, account, subAccount)
}

function buildContext(
  user: CurrentUser,
  customerAccount: CustomerAccount,
  subAccount: SubAccount
): CustomerAccountContext {
  const normalized = withNormalizedRole(subAccount)
  const role = normalized.role
  const roleCapabilities = readCompanyRoleCapabilities(customerAccount.roleCapabilities)
  const account: CustomerAccount = {
    ...customerAccount,
    roleCapabilities
  }
  return {
    customerAccount: account,
    subAccount: normalized,
    isPlatformAdmin: user.isAdmin,
    canSeeAllCustomerAccountWork: user.isAdmin || seesAllAccountWork(role),
    capabilities: capabilitiesForAccountUser({
      isPlatformAdmin: user.isAdmin,
      role,
      roleCapabilities
    })
  }
}

function withNormalizedRole(subAccount: SubAccount): SubAccount {
  const role: CustomerAccountRole = normalizeCustomerAccountRole(subAccount.role)
  if (role === subAccount.role) return subAccount
  return { ...subAccount, role }
}

async function findSubAccountByEmail(email: string): Promise<SubAccount | null> {
  const normalized = email.trim().toLowerCase()
  if (!hasDatabaseUrl()) {
    return memorySubAccounts.find((item) => item.email.toLowerCase() === normalized) ?? null
  }

  const row = (await useDatabase()
    .select()
    .from(schema.subAccounts)
    .where(eq(schema.subAccounts.email, normalized))
    .limit(1))[0]
  if (row) return row.bodyJson

  // Legacy rows may store mixed-case email on the column
  const rows = await useDatabase().select().from(schema.subAccounts)
  return rows
    .map((item) => item.bodyJson)
    .find((item) => item.email.toLowerCase() === normalized) ?? null
}

async function findSubAccountByUserId(userId: string): Promise<SubAccount | null> {
  if (!hasDatabaseUrl()) {
    return memorySubAccounts.find((item) => item.userId === userId) ?? null
  }

  const row = (await useDatabase()
    .select()
    .from(schema.subAccounts)
    .where(eq(schema.subAccounts.userId, userId))
    .limit(1))[0]
  return row?.bodyJson ?? null
}

async function findSubAccountById(subAccountId: string): Promise<SubAccount | null> {
  if (!hasDatabaseUrl()) {
    return memorySubAccounts.find((item) => item.id === subAccountId) ?? null
  }

  const row = (await useDatabase()
    .select()
    .from(schema.subAccounts)
    .where(eq(schema.subAccounts.id, subAccountId))
    .limit(1))[0]
  return row?.bodyJson ?? null
}

async function hasOtherAccountAdmin(customerAccountId: string, exceptSubAccountId: string): Promise<boolean> {
  const members = !hasDatabaseUrl()
    ? memorySubAccounts.filter((item) => item.customerAccountId === customerAccountId)
    : (await useDatabase()
        .select()
        .from(schema.subAccounts)
        .where(eq(schema.subAccounts.customerAccountId, customerAccountId)))
        .map((row) => row.bodyJson)

  return members.some((item) =>
    item.id !== exceptSubAccountId
    && normalizeCustomerAccountRole(item.role) === "customer-account-admin"
  )
}

function memorySubAccountsForAccount(customerAccountId: string, self: SubAccount): SubAccount[] {
  const others = memorySubAccounts.filter((item) =>
    item.customerAccountId === customerAccountId && item.id !== self.id
  )
  return [self, ...others].map(withNormalizedRole)
}

function upsertMemorySubAccount(subAccount: SubAccount): void {
  const index = memorySubAccounts.findIndex((item) => item.id === subAccount.id)
  if (index >= 0) memorySubAccounts[index] = subAccount
  else memorySubAccounts.push(subAccount)
}
