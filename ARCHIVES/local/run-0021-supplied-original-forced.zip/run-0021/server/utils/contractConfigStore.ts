import {
  newCompanyContractConfig,
  normalizeCompanyContractConfig,
  type CompanyContractConfig
} from "~~/shared/contracts/modules"
import { eq } from "drizzle-orm"
import type { CurrentUser } from "./auth"
import { assertAccountCapability } from "./accountPermissions"

const memoryConfigs = new Map<string, CompanyContractConfig>()

export async function getContractConfig(
  customerAccountId: string
): Promise<CompanyContractConfig> {
  if (!hasDatabaseUrl()) {
    return memoryConfigs.get(customerAccountId)
      ?? newCompanyContractConfig(customerAccountId)
  }

  const row = (await useDatabase()
    .select()
    .from(schema.contractConfigs)
    .where(eq(schema.contractConfigs.customerAccountId, customerAccountId))
    .limit(1))[0]

  if (!row) return newCompanyContractConfig(customerAccountId)
  return normalizeCompanyContractConfig(customerAccountId, row.bodyJson)
}

export async function getContractConfigForUser(user: CurrentUser): Promise<CompanyContractConfig> {
  const context = await getCustomerAccountContext(user)
  return getContractConfig(context.customerAccount.id)
}

export async function saveContractConfig(
  user: CurrentUser,
  input: Partial<CompanyContractConfig>
): Promise<CompanyContractConfig> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "editContractSetup", "Contract setup access required")

  const next = normalizeCompanyContractConfig(context.customerAccount.id, {
    ...input,
    customerAccountId: context.customerAccount.id,
    updatedAt: new Date().toISOString()
  })

  if (!hasDatabaseUrl()) {
    memoryConfigs.set(next.customerAccountId, next)
    return next
  }

  await useDatabase()
    .insert(schema.contractConfigs)
    .values({
      customerAccountId: next.customerAccountId,
      bodyJson: next,
      updatedAt: new Date(next.updatedAt)
    })
    .onConflictDoUpdate({
      target: schema.contractConfigs.customerAccountId,
      set: {
        bodyJson: next,
        updatedAt: new Date(next.updatedAt)
      }
    })

  return next
}
