import { and, desc, eq } from "drizzle-orm"
import type { Customer, CustomerFile, CustomerJobSummary, CustomerRecord } from "~~/shared/types"
import { formatCustomerName, newCustomer } from "~~/shared/customer"
import { newId } from "~~/shared/ids"
import type { CurrentUser } from "./auth"
import { assertAccountCapability, contextHasCapability } from "./accountPermissions"
import {
  getCustomerAccountContext,
  ownsCustomerAccountWork,
  type CustomerAccountContext
} from "./customerAccountAccess"

type CustomerInput = Partial<Customer> & {
  id?: string
}

let memoryCustomers: CustomerRecord[] = []

function canAccessCustomers(context: CustomerAccountContext): boolean {
  return contextHasCapability(context, "editCustomers")
    || contextHasCapability(context, "viewEstimates")
    || contextHasCapability(context, "manageJobAssets")
}

export async function listCustomers(user: CurrentUser): Promise<CustomerRecord[]> {
  const context = await getCustomerAccountContext(user)
  if (!canAccessCustomers(context)) {
    assertAccountCapability(context, "editCustomers")
  }

  if (useMemoryStore()) {
    return memoryCustomers
      .filter((customer) => canReadCustomer(context, customer))
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
  }

  const rows = await useDatabase()
    .select()
    .from(schema.customers)
    .where(context.canSeeAllCustomerAccountWork
      ? eq(schema.customers.customerAccountId, context.customerAccount.id)
      : and(
          eq(schema.customers.customerAccountId, context.customerAccount.id),
          eq(schema.customers.createdBySubAccountId, context.subAccount.id)
        ))
    .orderBy(desc(schema.customers.updatedAt))

  return rows.map((row) => row.bodyJson)
}

export async function getCustomerFile(customerId: string, user: CurrentUser): Promise<CustomerFile | null> {
  const context = await getCustomerAccountContext(user)
  if (!canAccessCustomers(context)) {
    assertAccountCapability(context, "editCustomers")
  }
  const customer = await getCustomerRecord(customerId, context)
  if (!customer) return null
  const [jobs, assetsByJob] = await Promise.all([
    listCustomerJobs(customer.id, user),
    listJobAssetsForCustomer(customer.id, user)
  ])
  return {
    ...customer,
    jobs: jobs.map((job) => ({ ...job, assets: assetsByJob[job.id] ?? [] }))
  }
}

export async function getCustomerRecordById(customerId: string, user: CurrentUser): Promise<CustomerRecord | null> {
  const context = await getCustomerAccountContext(user)
  if (!canAccessCustomers(context)) {
    assertAccountCapability(context, "editCustomers")
  }
  return getCustomerRecord(customerId, context)
}

export async function createCustomer(input: CustomerInput, user: CurrentUser): Promise<CustomerRecord> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "editCustomers")
  const now = new Date().toISOString()
  const customer = normalizeCustomerInput(input)
  const record: CustomerRecord = {
    id: input.id || customer.id || newId(),
    customerAccountId: context.customerAccount.id,
    createdBySubAccountId: context.subAccount.id,
    customer: {
      ...customer,
      id: input.id || customer.id || newId()
    },
    displayName: formatCustomerName(customer),
    address: formatCustomerAddress(customer),
    createdAt: now,
    updatedAt: now
  }
  record.customer.id = record.id

  if (useMemoryStore()) {
    memoryCustomers = [record, ...memoryCustomers.filter((customerRecord) => customerRecord.id !== record.id)]
    return record
  }

  await useDatabase()
    .insert(schema.customers)
    .values(serializeCustomer(record))
  return record
}

export async function updateCustomer(customerId: string, input: CustomerInput, user: CurrentUser): Promise<CustomerRecord | null> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "editCustomers")
  const existing = await getCustomerRecord(customerId, context)
  if (!existing) return null

  const nextCustomer = {
    ...existing.customer,
    ...input,
    id: existing.id
  }
  const next: CustomerRecord = {
    ...existing,
    customer: nextCustomer,
    displayName: formatCustomerName(nextCustomer),
    address: formatCustomerAddress(nextCustomer),
    updatedAt: new Date().toISOString()
  }

  if (useMemoryStore()) {
    memoryCustomers = memoryCustomers.map((customer) => customer.id === customerId ? next : customer)
    return next
  }

  await useDatabase()
    .update(schema.customers)
    .set({
      displayName: next.displayName,
      address: next.address,
      bodyJson: next,
      updatedAt: new Date(next.updatedAt)
    })
    .where(eq(schema.customers.id, customerId))

  return next
}

export async function ensureCustomerForJob(customer: Customer, user: CurrentUser): Promise<CustomerRecord> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "editCustomers")
  const existing = customer.id ? await getCustomerRecord(customer.id, context) : null
  if (existing) return await updateCustomer(existing.id, customer, user) ?? existing
  return createCustomer(customer, user)
}

export async function listCustomerJobs(customerId: string, user: CurrentUser): Promise<CustomerJobSummary[]> {
  const context = await getCustomerAccountContext(user)

  if (useMemoryStore()) {
    return []
  }

  const rows = await useDatabase()
    .select()
    .from(schema.jobs)
    .where(context.canSeeAllCustomerAccountWork
      ? and(
          eq(schema.jobs.customerAccountId, context.customerAccount.id),
          eq(schema.jobs.customerId, customerId)
        )
      : and(
          eq(schema.jobs.customerAccountId, context.customerAccount.id),
          eq(schema.jobs.customerId, customerId),
          eq(schema.jobs.createdBySubAccountId, context.subAccount.id)
        ))
    .orderBy(desc(schema.jobs.updatedAt))

  return rows.map((row) => ({
    id: row.id,
    customerId: row.customerId,
    customerAccountId: row.customerAccountId,
    createdBySubAccountId: row.createdBySubAccountId,
    number: row.bodyJson.number,
    estimateType: row.bodyJson.estimateType,
    estimator: row.bodyJson.estimator,
    displayName: formatCustomerName(row.bodyJson.customer),
    address: formatCustomerAddress(row.bodyJson.customer),
    status: row.status,
    ...contractForCustomerJob(row.bodyJson, row.status),
    assets: [],
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
    proposedAt: row.bodyJson.proposedAt,
    signedAt: row.bodyJson.signedAt
  }))
}

export function customerCanReadJob(context: CustomerAccountContext, job: {
  customerAccountId?: string
  createdBySubAccountId?: string
}): boolean {
  const jobCustomerAccountId = job.customerAccountId
  if (!jobCustomerAccountId) return false
  const jobSubAccountId = job.createdBySubAccountId || ""
  return jobCustomerAccountId === context.customerAccount.id && ownsCustomerAccountWork(context, jobSubAccountId)
}

function canReadCustomer(context: CustomerAccountContext, customer: CustomerRecord): boolean {
  return customer.customerAccountId === context.customerAccount.id
    && ownsCustomerAccountWork(context, customer.createdBySubAccountId)
}

async function getCustomerRecord(customerId: string, context: CustomerAccountContext): Promise<CustomerRecord | null> {
  if (useMemoryStore()) {
    return memoryCustomers.find((customer) => customer.id === customerId && canReadCustomer(context, customer)) ?? null
  }

  const row = (await useDatabase()
    .select()
    .from(schema.customers)
    .where(eq(schema.customers.id, customerId))
    .limit(1))[0]
  if (!row || !canReadCustomer(context, row.bodyJson)) return null
  return row.bodyJson
}

function normalizeCustomerInput(input: CustomerInput): Customer {
  return {
    ...newCustomer(""),
    ...input,
    id: input.id || newId()
  }
}

function serializeCustomer(record: CustomerRecord) {
  return {
    id: record.id,
    customerAccountId: record.customerAccountId,
    createdBySubAccountId: record.createdBySubAccountId,
    displayName: record.displayName,
    address: record.address,
    bodyJson: record,
    createdAt: new Date(record.createdAt),
    updatedAt: new Date(record.updatedAt)
  }
}

function formatCustomerAddress(customer: Customer): string {
  const cityLine = [
    customer.city,
    [customer.state, customer.zip].filter(Boolean).join(" ")
  ].filter(Boolean).join(", ")
  return [customer.address1, customer.address2, cityLine].filter(Boolean).join(", ")
}

function contractForCustomerJob(job: { estimateType?: "roof-proposal" | "temporary-repair", scope?: { roofing?: unknown } }, status: string) {
  const type = job.estimateType
    ?? (status === "roof-proposal" || status === "temporary-repair" ? status : undefined)
  if (type === "temporary-repair") return { contractKind: type, contractLabel: "Contracts" }
  if (type === "roof-proposal" && job.scope?.roofing) return { contractKind: type, contractLabel: "Contracts" }
  return {}
}

function useMemoryStore(): boolean {
  if (hasDatabaseUrl()) return false
  if (process.env.NODE_ENV === "production") {
    throw createError({
      statusCode: 500,
      statusMessage: "DATABASE_URL is required"
    })
  }
  return true
}
