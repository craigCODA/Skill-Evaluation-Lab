import type { AccountRole } from "~~/shared/types"
import {
  PASSWORD_POLICY_DESCRIPTION,
  passwordPolicyError
} from "~~/shared/passwordPolicy"
import {
  AdminAddUserToGroupCommand,
  AdminCreateUserCommand,
  AdminDeleteUserCommand,
  AdminGetUserCommand,
  AdminSetUserPasswordCommand,
  CognitoIdentityProviderClient,
  ListUsersCommand,
  ListUsersInGroupCommand,
  type UserType
} from "@aws-sdk/client-cognito-identity-provider"

export type DirectoryUser = {
  userId: string
  email: string
  name: string
  role: AccountRole
  createdAt: string
}

export type CreateUserInput = {
  email: string
  name: string
  password: string
  role: AccountRole
}

let memoryUsers: DirectoryUser[] | null = null
let cognitoClient: CognitoIdentityProviderClient | null = null

export async function listUsers(): Promise<DirectoryUser[]> {
  if (!useCognitoDirectory()) return [...devUsers()]

  const client = useCognito()
  const poolId = poolIdOrThrow()

  const adminRes = await client.send(
    new ListUsersInGroupCommand({ UserPoolId: poolId, GroupName: "admin" })
  )
  const admins = new Set(
    (adminRes.Users ?? []).map((user) => attr(user, "sub")).filter(Boolean) as string[]
  )

  const res = await client.send(new ListUsersCommand({ UserPoolId: poolId, Limit: 60 }))
  return (res.Users ?? []).map((user) => toDirectoryUser(user, admins))
}

export async function createUser(input: CreateUserInput): Promise<DirectoryUser> {
  const policyError = passwordPolicyError(input.password)
  if (policyError) {
    throw createError({ statusCode: 400, statusMessage: policyError })
  }

  const email = input.email.trim().toLowerCase()
  const name = input.name.trim() || email

  if (!useCognitoDirectory()) {
    const user: DirectoryUser = {
      userId: `dev:${email}`,
      email,
      name,
      role: input.role,
      createdAt: new Date().toISOString()
    }
    memoryUsers = [...devUsers().filter((existing) => existing.email !== email), user]
    return user
  }

  const client = useCognito()
  const poolId = poolIdOrThrow()
  let createdNewUser = false

  try {
    try {
      await client.send(new AdminCreateUserCommand({
        UserPoolId: poolId,
        Username: email,
        MessageAction: "SUPPRESS",
        UserAttributes: [
          { Name: "email", Value: email },
          { Name: "email_verified", Value: "true" },
          { Name: "name", Value: name }
        ]
      }))
      createdNewUser = true
    } catch (error) {
      if (cognitoErrorName(error) !== "UsernameExistsException") {
        throwMappedCognitoError(error)
      }
      // Incomplete invites leave a Cognito user behind; finish setup below.
    }

    await client.send(new AdminSetUserPasswordCommand({
      UserPoolId: poolId,
      Username: email,
      Password: input.password,
      Permanent: true
    }))

    await client.send(new AdminAddUserToGroupCommand({
      UserPoolId: poolId,
      Username: email,
      GroupName: input.role
    }))

    const got = await client.send(new AdminGetUserCommand({
      UserPoolId: poolId,
      Username: email
    }))
    const userId = got.UserAttributes?.find((entry) => entry.Name === "sub")?.Value
    if (!userId) {
      throw createError({ statusCode: 500, statusMessage: "Created user is missing identity" })
    }

    return {
      userId,
      email,
      name,
      role: input.role,
      createdAt: got.UserCreateDate?.toISOString() ?? new Date().toISOString()
    }
  } catch (error) {
    if (createdNewUser) {
      await client.send(new AdminDeleteUserCommand({
        UserPoolId: poolId,
        Username: email
      })).catch(() => undefined)
    }
    if (isHttpError(error)) throw error
    throwMappedCognitoError(error)
  }
}

export async function deleteUser(userId: string): Promise<void> {
  if (!useCognitoDirectory()) {
    memoryUsers = devUsers().filter((user) => user.userId !== userId)
    return
  }

  await useCognito().send(
    new AdminDeleteUserCommand({ UserPoolId: poolIdOrThrow(), Username: userId })
  )
}

function toDirectoryUser(user: UserType, admins: Set<string>): DirectoryUser {
  const sub = attr(user, "sub") ?? user.Username ?? ""
  return {
    userId: sub,
    email: attr(user, "email") ?? user.Username ?? "",
    name: attr(user, "name") ?? "",
    role: admins.has(sub) ? "admin" : "customer",
    createdAt: user.UserCreateDate?.toISOString() ?? ""
  }
}

function attr(user: UserType | undefined, name: string): string | undefined {
  return user?.Attributes?.find((entry) => entry.Name === name)?.Value
}

function useCognitoDirectory(): boolean {
  return Boolean(useRuntimeConfig().cognitoUserPoolId)
}

function poolIdOrThrow(): string {
  const poolId = useRuntimeConfig().cognitoUserPoolId
  if (!poolId) {
    throw createError({ statusCode: 500, statusMessage: "COGNITO_USER_POOL_ID is required" })
  }
  return String(poolId)
}

function useCognito(): CognitoIdentityProviderClient {
  if (!cognitoClient) cognitoClient = new CognitoIdentityProviderClient({})
  return cognitoClient
}

function cognitoErrorName(error: unknown): string {
  if (!error || typeof error !== "object") return ""
  return "name" in error && typeof error.name === "string" ? error.name : ""
}

function cognitoErrorMessage(error: unknown): string {
  if (!error || typeof error !== "object") return "User directory error"
  return "message" in error && typeof error.message === "string"
    ? error.message
    : "User directory error"
}

function isHttpError(error: unknown): boolean {
  return Boolean(
    error
    && typeof error === "object"
    && "statusCode" in error
    && typeof error.statusCode === "number"
  )
}

function throwMappedCognitoError(error: unknown): never {
  const name = cognitoErrorName(error)
  const message = cognitoErrorMessage(error)

  if (name === "InvalidPasswordException") {
    throw createError({
      statusCode: 400,
      statusMessage: PASSWORD_POLICY_DESCRIPTION
    })
  }
  if (name === "UsernameExistsException") {
    throw createError({
      statusCode: 409,
      statusMessage: "A user with this email already exists"
    })
  }
  if (name === "InvalidParameterException") {
    throw createError({ statusCode: 400, statusMessage: message })
  }

  throw createError({ statusCode: 502, statusMessage: message })
}

function devUsers(): DirectoryUser[] {
  if (!memoryUsers) {
    const now = new Date().toISOString()
    memoryUsers = [
      { userId: "dev:admin@example.com", email: "admin@example.com", name: "Admin", role: "admin", createdAt: now },
      { userId: "dev:customer1@example.com", email: "customer1@example.com", name: "James", role: "customer", createdAt: now },
      { userId: "dev:customer2@example.com", email: "customer2@example.com", name: "Robert", role: "customer", createdAt: now }
    ]
  }
  return memoryUsers
}
