import { eq } from "drizzle-orm";
import type { RoofMeasurement } from "~~/shared/types";
import { hydrateRoofProbeImagery, storeRoofProbeImagery } from "./roofProbeImageryStore";

export type RoofProbeCacheStatus = "hit" | "miss" | "refreshed";

export type RoofProbeResponse = {
  measurement: RoofMeasurement;
  cacheStatus: RoofProbeCacheStatus;
  refreshedAt: string;
};

export async function getCachedRoofProbeMeasurement(
  addressKey: string,
): Promise<RoofProbeResponse | null> {
  const row = (await useDatabase()
    .select()
    .from(schema.roofProbeMeasurements)
    .where(eq(schema.roofProbeMeasurements.addressKey, addressKey))
    .limit(1))[0];

  if (!row) return null;

  await useDatabase()
    .update(schema.roofProbeMeasurements)
    .set({ lastRequestedAt: new Date() })
    .where(eq(schema.roofProbeMeasurements.addressKey, addressKey));

  return {
    measurement: await hydrateRoofProbeImagery({
      measurement: row.bodyJson,
      previewImageKey: row.previewImageKey,
      maskImageKey: row.maskImageKey,
    }),
    cacheStatus: "hit",
    refreshedAt: row.refreshedAt.toISOString(),
  };
}

export async function saveRoofProbeMeasurement(input: {
  addressKey: string;
  measurement: RoofMeasurement;
  cacheStatus: Exclude<RoofProbeCacheStatus, "hit">;
}): Promise<RoofProbeResponse> {
  const stored = await storeRoofProbeImagery({
    addressKey: input.addressKey,
    measurement: input.measurement,
  });
  const now = new Date();

  await useDatabase()
    .insert(schema.roofProbeMeasurements)
    .values({
      addressKey: input.addressKey,
      displayAddress: input.measurement.address,
      latitude: input.measurement.latitude,
      longitude: input.measurement.longitude,
      imageryDate: input.measurement.imagery?.imageryDate,
      imageryQuality: input.measurement.imagery?.imageryQuality ?? "UNKNOWN",
      provider: input.measurement.source.provider,
      previewImageKey: stored.previewImageKey,
      maskImageKey: stored.maskImageKey,
      bodyJson: stored.measurement,
      createdAt: new Date(input.measurement.createdAt),
      updatedAt: now,
      refreshedAt: now,
      lastRequestedAt: now,
    })
    .onConflictDoUpdate({
      target: schema.roofProbeMeasurements.addressKey,
      set: {
        displayAddress: input.measurement.address,
        latitude: input.measurement.latitude,
        longitude: input.measurement.longitude,
        imageryDate: input.measurement.imagery?.imageryDate,
        imageryQuality: input.measurement.imagery?.imageryQuality ?? "UNKNOWN",
        provider: input.measurement.source.provider,
        previewImageKey: stored.previewImageKey,
        maskImageKey: stored.maskImageKey,
        bodyJson: stored.measurement,
        updatedAt: now,
        refreshedAt: now,
        lastRequestedAt: now,
      },
    });

  return {
    measurement: await hydrateRoofProbeImagery({
      measurement: stored.measurement,
      previewImageKey: stored.previewImageKey,
      maskImageKey: stored.maskImageKey,
    }),
    cacheStatus: input.cacheStatus,
    refreshedAt: now.toISOString(),
  };
}
