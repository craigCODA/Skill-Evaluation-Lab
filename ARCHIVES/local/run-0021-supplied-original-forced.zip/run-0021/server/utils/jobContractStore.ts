import { calculateRoofingEstimate } from "~~/shared/calculator/calculateEstimate"
import {
  activeRecipeKinds,
  composeTradeContract,
  newJobContractSnapshotId,
  parseContractRecipeKind,
  type ContractRecipeKind,
  type JobContractBundle,
  type JobContractPair,
  type JobContractSignedPdf,
  type JobContractSnapshot
} from "~~/shared/contracts/modules"
import { CONTRACT_RECIPE_KINDS } from "~~/shared/contracts/modules"
import { DeleteObjectCommand, GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3"
import { and, eq } from "drizzle-orm"
import type { CurrentUser } from "./auth"
import { assertAccountCapability } from "./accountPermissions"
import { getContractConfig } from "./contractConfigStore"

const memorySnapshots = new Map<string, JobContractSnapshot>()
const memoryPdfs = new Map<string, string>()
let s3Client: S3Client | null = null

function memoryKey(jobId: string, status: JobContractSnapshot["status"], recipeKind: ContractRecipeKind) {
  return `${jobId}:${recipeKind}:${status}`
}

function emptyBundle(): JobContractBundle {
  return {
    roofing: { unsigned: null, signed: null },
    gutters: { unsigned: null, signed: null },
    siding: { unsigned: null, signed: null }
  }
}

async function listSnapshotsForJob(jobId: string): Promise<JobContractSnapshot[]> {
  if (!hasDatabaseUrl()) {
    return [...memorySnapshots.values()].filter((item) => item.jobId === jobId)
  }

  const rows = await useDatabase()
    .select()
    .from(schema.jobContracts)
    .where(eq(schema.jobContracts.jobId, jobId))

  return rows.map((row) => normalizeSnapshot(row.bodyJson))
}

function normalizeSnapshot(snapshot: JobContractSnapshot): JobContractSnapshot {
  return {
    ...snapshot,
    recipeKind: parseContractRecipeKind(snapshot.recipeKind)
  }
}

function toBundle(snapshots: JobContractSnapshot[]): JobContractBundle {
  const bundle = emptyBundle()
  for (const snapshot of snapshots) {
    const kind = parseContractRecipeKind(snapshot.recipeKind)
    if (snapshot.status === "signed") bundle[kind].signed = snapshot
    else bundle[kind].unsigned = snapshot
  }
  return bundle
}

export async function getJobContractBundle(
  jobId: string,
  user: CurrentUser
): Promise<JobContractBundle> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "viewContracts")

  const job = await resolveAccountJob(jobId, user)
  if (!job) {
    throw createError({ statusCode: 404, statusMessage: "Estimate not found" })
  }

  return toBundle(await listSnapshotsForJob(jobId))
}

export async function regenerateJobContract(
  jobId: string,
  user: CurrentUser,
  recipeKindInput: unknown = "roofing"
): Promise<JobContractSnapshot> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "viewContracts")
  const recipeKind = parseContractRecipeKind(recipeKindInput)

  const job = await resolveAccountJob(jobId, user)
  if (!job) {
    throw createError({ statusCode: 404, statusMessage: "Estimate not found" })
  }
  if (recipeKind === "roofing" && !job.scope.roofing) {
    throw createError({
      statusCode: 404,
      statusMessage: "Estimate with roofing scope not found"
    })
  }

  const config = await getContractConfig(context.customerAccount.id)
  if (!activeRecipeKinds(config).includes(recipeKind)) {
    throw createError({
      statusCode: 400,
      statusMessage: `${recipeKind} contracts are disabled for this company`
    })
  }

  const ownerId = await getEstimateOwnerId(jobId, user) ?? user.sub
  const catalog = await getEditableCatalog(ownerId)
  const companyProfile = await getCompanyProfile(ownerId)
  const platformProfile = await getPlatformProfile()
  const roofingTotals = job.scope.roofing
    ? calculateRoofingEstimate({
      roofing: job.scope.roofing,
      catalog,
      permit: job.permit,
      extras: job.extras
    })
    : null

  const composed = composeTradeContract({
    job,
    catalog,
    roofingTotals,
    companyProfile,
    platformProfile,
    config,
    recipeKind
  })

  const existing = (await listSnapshotsForJob(jobId)).find((item) =>
    item.status === "unsigned" && parseContractRecipeKind(item.recipeKind) === recipeKind
  )
  const snapshot: JobContractSnapshot = {
    id: existing?.id ?? newJobContractSnapshotId(),
    jobId,
    customerAccountId: context.customerAccount.id,
    recipeKind,
    status: "unsigned",
    composed,
    generatedAt: composed.generatedAt,
    signedPdf: existing?.signedPdf
  }

  await upsertSnapshot(snapshot)
  return snapshot
}

export async function markJobContractSigned(
  jobId: string,
  user: CurrentUser,
  recipeKindInput: unknown = "roofing"
): Promise<JobContractSnapshot> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "viewContracts")
  const recipeKind = parseContractRecipeKind(recipeKindInput)

  const job = await resolveAccountJob(jobId, user)
  if (!job) {
    throw createError({ statusCode: 404, statusMessage: "Estimate not found" })
  }

  let unsigned = (await listSnapshotsForJob(jobId)).find((item) =>
    item.status === "unsigned" && parseContractRecipeKind(item.recipeKind) === recipeKind
  )
  if (!unsigned) {
    unsigned = await regenerateJobContract(jobId, user, recipeKind)
  }

  const signedAt = new Date().toISOString()
  const signed: JobContractSnapshot = {
    ...unsigned,
    id: newJobContractSnapshotId(),
    status: "signed",
    signedAt,
    signedPdf: unsigned.signedPdf
  }

  if (!hasDatabaseUrl()) {
    for (const [key, value] of memorySnapshots) {
      if (
        value.jobId === jobId
        && value.status === "signed"
        && parseContractRecipeKind(value.recipeKind) === recipeKind
      ) {
        memorySnapshots.delete(key)
      }
    }
  } else {
    const existingSigned = (await listSnapshotsForJob(jobId)).filter((item) =>
      item.status === "signed" && parseContractRecipeKind(item.recipeKind) === recipeKind
    )
    for (const item of existingSigned) {
      await useDatabase()
        .delete(schema.jobContracts)
        .where(eq(schema.jobContracts.id, item.id))
    }
  }

  await upsertSnapshot(signed)
  return signed
}

export async function uploadJobContractSignedPdf(
  jobId: string,
  user: CurrentUser,
  input: {
    recipeKind?: unknown
    fileName: string
    dataUrl: string
  }
): Promise<JobContractSnapshot> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "viewContracts")
  const recipeKind = parseContractRecipeKind(input.recipeKind)

  const job = await resolveAccountJob(jobId, user)
  if (!job) {
    throw createError({ statusCode: 404, statusMessage: "Estimate not found" })
  }

  let signed = (await listSnapshotsForJob(jobId)).find((item) =>
    item.status === "signed" && parseContractRecipeKind(item.recipeKind) === recipeKind
  )
  if (!signed) {
    signed = await markJobContractSigned(jobId, user, recipeKind)
  }

  const parsed = parsePdfDataUrl(input.dataUrl)
  const key = signedPdfKey({
    customerAccountId: context.customerAccount.id,
    jobId,
    snapshotId: signed.id
  })

  if (signed.signedPdf?.key && signed.signedPdf.key !== key) {
    await deletePdf(signed.signedPdf.key).catch(() => undefined)
  }

  await putPdf(key, parsed)

  const signedPdf: JobContractSignedPdf = {
    key,
    fileName: input.fileName.trim() || "signed-contract.pdf",
    contentType: parsed.contentType,
    size: parsed.body.byteLength,
    uploadedAt: new Date().toISOString()
  }

  const next: JobContractSnapshot = {
    ...signed,
    signedPdf,
    signedAt: signed.signedAt || signedPdf.uploadedAt
  }
  await upsertSnapshot(next)
  return next
}

export async function getJobContractSignedPdfDataUrl(
  jobId: string,
  user: CurrentUser,
  recipeKindInput: unknown = "roofing"
): Promise<{ snapshot: JobContractSnapshot, dataUrl: string }> {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "viewContracts")
  const recipeKind = parseContractRecipeKind(recipeKindInput)

  const signed = (await listSnapshotsForJob(jobId)).find((item) =>
    item.status === "signed" && parseContractRecipeKind(item.recipeKind) === recipeKind
  )
  if (!signed?.signedPdf?.key) {
    throw createError({ statusCode: 404, statusMessage: "Signed PDF not found" })
  }

  return {
    snapshot: signed,
    dataUrl: await getPdfDataUrl(signed.signedPdf.key)
  }
}

export function listActiveRecipeKindsForConfig(
  // convenience for pages
  configEnabled: Record<ContractRecipeKind, boolean> | undefined
): ContractRecipeKind[] {
  return CONTRACT_RECIPE_KINDS.filter((kind) => kind === "roofing" || configEnabled?.[kind] !== false)
}

async function upsertSnapshot(snapshot: JobContractSnapshot): Promise<void> {
  const recipeKind = parseContractRecipeKind(snapshot.recipeKind)
  const normalized = { ...snapshot, recipeKind }

  if (!hasDatabaseUrl()) {
    for (const [key, value] of memorySnapshots) {
      if (
        value.jobId === normalized.jobId
        && value.status === normalized.status
        && parseContractRecipeKind(value.recipeKind) === recipeKind
      ) {
        memorySnapshots.delete(key)
      }
    }
    memorySnapshots.set(memoryKey(normalized.jobId, normalized.status, recipeKind), normalized)
    return
  }

  const db = useDatabase()
  const existingRows = await db
    .select()
    .from(schema.jobContracts)
    .where(and(
      eq(schema.jobContracts.jobId, normalized.jobId),
      eq(schema.jobContracts.status, normalized.status)
    ))

  const existing = existingRows.find((row) =>
    parseContractRecipeKind(row.bodyJson.recipeKind) === recipeKind
  )

  if (existing) {
    await db
      .update(schema.jobContracts)
      .set({
        id: normalized.id,
        customerAccountId: normalized.customerAccountId,
        bodyJson: normalized,
        generatedAt: new Date(normalized.generatedAt),
        signedAt: normalized.signedAt ? new Date(normalized.signedAt) : null,
        updatedAt: new Date()
      })
      .where(eq(schema.jobContracts.id, existing.id))
    return
  }

  await db.insert(schema.jobContracts).values({
    id: normalized.id,
    jobId: normalized.jobId,
    customerAccountId: normalized.customerAccountId,
    status: normalized.status,
    bodyJson: normalized,
    generatedAt: new Date(normalized.generatedAt),
    signedAt: normalized.signedAt ? new Date(normalized.signedAt) : null,
    updatedAt: new Date()
  })
}

function parsePdfDataUrl(dataUrl: string): { contentType: string, body: Buffer } {
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/)
  if (!match) {
    throw createError({ statusCode: 400, statusMessage: "PDF is not a valid data URL" })
  }
  const contentType = match[1] ?? "application/pdf"
  if (!contentType.includes("pdf")) {
    throw createError({ statusCode: 400, statusMessage: "Only PDF uploads are supported" })
  }
  const body = Buffer.from(match[2] ?? "", "base64")
  if (body.byteLength > 15 * 1024 * 1024) {
    throw createError({ statusCode: 400, statusMessage: "PDF must be 15MB or smaller" })
  }
  return { contentType, body }
}

function signedPdfKey(input: {
  customerAccountId: string
  jobId: string
  snapshotId: string
}): string {
  return `job-contracts/${input.customerAccountId}/${input.jobId}/${input.snapshotId}.pdf`
}

async function putPdf(key: string, file: { contentType: string, body: Buffer }): Promise<void> {
  if (!hasDatabaseUrl()) {
    memoryPdfs.set(key, `data:${file.contentType};base64,${file.body.toString("base64")}`)
    return
  }
  await s3().send(new PutObjectCommand({
    Bucket: assetBucket(),
    Key: key,
    Body: file.body,
    ContentType: file.contentType
  }))
}

async function getPdfDataUrl(key: string): Promise<string> {
  if (!hasDatabaseUrl()) {
    const dataUrl = memoryPdfs.get(key)
    if (!dataUrl) throw createError({ statusCode: 404, statusMessage: "Signed PDF not found" })
    return dataUrl
  }
  const response = await s3().send(new GetObjectCommand({
    Bucket: assetBucket(),
    Key: key
  }))
  const body = response.Body as { transformToByteArray?: () => Promise<Uint8Array> } | undefined
  if (!body?.transformToByteArray) {
    throw createError({ statusCode: 502, statusMessage: "Stored PDF could not be read" })
  }
  const bytes = await body.transformToByteArray()
  const contentType = response.ContentType || "application/pdf"
  return `data:${contentType};base64,${Buffer.from(bytes).toString("base64")}`
}

async function deletePdf(key: string): Promise<void> {
  if (!hasDatabaseUrl()) {
    memoryPdfs.delete(key)
    return
  }
  await s3().send(new DeleteObjectCommand({
    Bucket: assetBucket(),
    Key: key
  }))
}

function s3(): S3Client {
  if (!s3Client) s3Client = new S3Client({ region: useRuntimeConfig().public.awsRegion })
  return s3Client
}

function assetBucket(): string {
  const bucket = useRuntimeConfig().roofProbeImageryBucket || process.env.ROOF_PROBE_IMAGERY_BUCKET
  if (!bucket) {
    throw createError({ statusCode: 500, statusMessage: "Asset storage is not configured" })
  }
  return bucket
}
