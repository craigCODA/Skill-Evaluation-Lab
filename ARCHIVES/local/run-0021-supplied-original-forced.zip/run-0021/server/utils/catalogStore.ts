import type { Catalog } from "~~/shared/pricebook/types"
import { and, eq, sql } from "drizzle-orm"
import { loadCatalog } from "~~/shared/pricebook"
import type { CurrentUser } from "./auth"
import { assertAccountCapability } from "./accountPermissions"

type CatalogSection = keyof Catalog
type CatalogItem = Catalog[CatalogSection][number]

/** Each user edits their own price book; keyed by owner in both stores. */
const memoryCatalogs = new Map<string, Catalog>()

/** Fill empty shingle color lists from the bundled catalog (DB may have been seeded earlier). */
function enrichShingleColors(catalog: Catalog): Catalog {
  const baseById = new Map(loadCatalog().shingles.map((item) => [item.id, item]))
  return {
    ...catalog,
    shingles: catalog.shingles.map((item) => {
      if (item.colors?.length) return item
      const base = baseById.get(item.id)
      if (!base?.colors?.length) return item
      return { ...item, colors: base.colors }
    })
  }
}

export async function getEditableCatalog(ownerId: string): Promise<Catalog> {
  if (useMemoryCatalog()) {
    let catalog = memoryCatalogs.get(ownerId)
    if (!catalog) {
      catalog = loadCatalog()
      memoryCatalogs.set(ownerId, catalog)
    }
    return enrichShingleColors(catalog)
  }

  await seedCatalogIfEmpty(ownerId)
  const rows = await useDatabase()
    .select()
    .from(schema.catalogItems)
    .where(eq(schema.catalogItems.ownerId, ownerId))
  const catalog = emptyCatalog()

  for (const row of rows) {
    const section = row.section as CatalogSection
    if (section in catalog) {
      catalog[section].push(row.bodyJson as never)
    }
  }

  return enrichShingleColors(catalog)
}

export async function updateCatalogItem(
  section: CatalogSection,
  itemKey: string,
  patch: Record<string, unknown>,
  user: CurrentUser
) {
  const context = await getCustomerAccountContext(user)
  assertAccountCapability(context, "editCatalog")

  const catalog = await getEditableCatalog(user.sub)
  const row = catalog[section].find((item) => catalogItemKey(item) === itemKey)
  if (!row) {
    throw createError({ statusCode: 404, statusMessage: "Catalog item not found" })
  }

  const next = { ...row, ...patch } as CatalogItem
  if (useMemoryCatalog()) {
    memoryCatalogs.set(user.sub, replaceCatalogItem(catalog, section, itemKey, next))
    return next
  }

  await useDatabase()
    .update(schema.catalogItems)
    .set({ bodyJson: next, updatedAt: new Date() })
    .where(and(
      eq(schema.catalogItems.ownerId, user.sub),
      eq(schema.catalogItems.section, section),
      eq(schema.catalogItems.itemKey, itemKey)
    ))

  return next
}

export function catalogItemKey(item: CatalogItem): string {
  if ("id" in item && typeof item.id === "string") return item.id
  if ("tier" in item && typeof item.tier === "string") return item.tier
  if ("key" in item && typeof item.key === "string") return item.key
  throw new Error("Catalog item does not have a stable key")
}

function useMemoryCatalog(): boolean {
  return !hasDatabaseUrl() && process.env.NODE_ENV !== "production"
}

async function seedCatalogIfEmpty(ownerId: string) {
  const [result] = await useDatabase()
    .select({ count: sql<number>`count(*)::int` })
    .from(schema.catalogItems)
    .where(eq(schema.catalogItems.ownerId, ownerId))

  if ((result?.count ?? 0) > 0) return

  const catalog = loadCatalog()
  const rows = Object.entries(catalog).flatMap(([section, items]) =>
    items.map((item) => ({
      ownerId,
      section,
      itemKey: catalogItemKey(item as CatalogItem),
      bodyJson: item
    }))
  )

  if (rows.length > 0) {
    await useDatabase().insert(schema.catalogItems).values(rows)
  }
}

function emptyCatalog(): Catalog {
  return Object.fromEntries(
    Object.keys(loadCatalog()).map((section) => [section, []])
  ) as unknown as Catalog
}

function replaceCatalogItem(catalog: Catalog, section: CatalogSection, itemKey: string, next: CatalogItem) {
  return {
    ...catalog,
    [section]: catalog[section].map((item) => catalogItemKey(item) === itemKey ? next : item)
  }
}
