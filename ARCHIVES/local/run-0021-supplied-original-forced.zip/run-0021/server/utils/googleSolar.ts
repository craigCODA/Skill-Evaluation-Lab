import type { GoogleSolarBuildingInsights } from "~~/shared/roofMeasurement";
import {
  normalizeGoogleSolarMeasurement,
} from "~~/shared/roofMeasurement";
import { analyzeMaskLayer } from "./roofMaskGeometry";
// import { drawRoofLinesWithGrok } from "./grokRoofLines";
import { fromArrayBuffer } from "geotiff";
import { PNG } from "pngjs";
import { buildImageryGeoref } from "~~/shared/roofImageryGeoref";
import {
  readTiffEpsg,
  tiffBoundsToLatLng,
  tiffExtentMeters,
} from "./roofImageProjection";
import type {
  LatLng,
  RoofBoundingBox,
  RoofImageryQuality,
  RoofMeasurement,
  RoofMeasurementElevationAnalysis,
  RoofMeasurementImagery,
  RoofMeasurementLayerType,
  RoofSegment,
} from "~~/shared/types";

const DATA_LAYER_PIXEL_SIZE_METERS = 0.1;

type RoofProbeInput = {
  address: string;
  requiredQuality: "HIGH" | "MEDIUM" | "LOW";
};

type GeocodeResponse = {
  status: string;
  error_message?: string;
  results?: Array<{
    formatted_address?: string;
    geometry?: {
      location?: {
        lat?: number;
        lng?: number;
      };
    };
  }>;
};

type GoogleSolarDataLayers = {
  imageryDate?: GoogleDate;
  imageryProcessedDate?: GoogleDate;
  imageryQuality?: string;
  dsmUrl?: string;
  rgbUrl?: string;
  maskUrl?: string;
  annualFluxUrl?: string;
  monthlyFluxUrl?: string;
  hourlyShadeUrls?: string[];
};

type GoogleDate = {
  year?: number;
  month?: number;
  day?: number;
};

export async function queryGoogleSolarRoofProbe(
  input: RoofProbeInput,
): Promise<RoofMeasurement> {
  const apiKey = googleSolarApiKey();
  const geocode = await geocodeAddress(input.address, apiKey);
  const buildingInsights = await fetchBuildingInsights({
    latitude: geocode.latitude,
    longitude: geocode.longitude,
    requiredQuality: input.requiredQuality,
    apiKey,
  });
  const measurement = normalizeGoogleSolarMeasurement({
    address: geocode.formattedAddress || input.address,
    latitude: geocode.latitude,
    longitude: geocode.longitude,
    buildingInsights,
  });
  const imagery = await fetchMeasurementImagery({
    latitude: geocode.latitude,
    longitude: geocode.longitude,
    requiredQuality: input.requiredQuality,
    apiKey,
    segments: measurement.segments,
    targetPoint: googleSolarCenter(buildingInsights) ?? {
      latitude: geocode.latitude,
      longitude: geocode.longitude,
    },
  });

  return {
    ...measurement,
    imagery: imagery
      ? {
          ...imagery,
          bounds: imagery.bounds ?? boundsFromSegments(measurement.segments),
        }
      : undefined,
  };
}

function googleSolarApiKey(): string {
  const key = useRuntimeConfig().googleSolarApiKey;
  if (!key) {
    throw createError({
      statusCode: 503,
      statusMessage: "Roof imagery provider is not configured",
    });
  }
  return key;
}

async function geocodeAddress(
  address: string,
  apiKey: string,
): Promise<{ latitude: number; longitude: number; formattedAddress: string }> {
  const params = new URLSearchParams({ address, key: apiKey });
  const response = await $fetch<GeocodeResponse>(
    `https://maps.googleapis.com/maps/api/geocode/json?${params}`,
  ).catch((error: unknown) => {
    const message = error instanceof Error
      ? error.message
      : "Roof address lookup failed";
    throw createError({
      statusCode: 502,
      statusMessage: sanitizeGoogleError(message),
    });
  });

  if (response.status !== "OK") {
    throw createError({
      statusCode: 422,
      statusMessage: response.error_message || `Geocoding failed: ${response.status}`,
    });
  }

  const result = response.results?.[0];
  const location = result?.geometry?.location;
  if (typeof location?.lat !== "number" || typeof location.lng !== "number") {
    throw createError({
      statusCode: 422,
      statusMessage: "Geocoding did not return a latitude and longitude",
    });
  }

  return {
    latitude: location.lat,
    longitude: location.lng,
    formattedAddress: result?.formatted_address || address,
  };
}

async function fetchBuildingInsights(input: {
  latitude: number;
  longitude: number;
  requiredQuality: "HIGH" | "MEDIUM" | "LOW";
  apiKey: string;
}): Promise<GoogleSolarBuildingInsights> {
  const params = new URLSearchParams({
    "location.latitude": String(input.latitude),
    "location.longitude": String(input.longitude),
    requiredQuality: input.requiredQuality,
    key: input.apiKey,
  });

  return $fetch<GoogleSolarBuildingInsights>(
    `https://solar.googleapis.com/v1/buildingInsights:findClosest?${params}`,
  ).catch((error: unknown) => {
    const message = error instanceof Error
      ? error.message
      : "Roof measurement lookup failed";
    throw createError({
      statusCode: 502,
      statusMessage: sanitizeGoogleError(message),
    });
  });
}

async function fetchMeasurementImagery(input: {
  latitude: number;
  longitude: number;
  requiredQuality: "HIGH" | "MEDIUM" | "LOW";
  apiKey: string;
  segments: RoofSegment[];
  targetPoint: LatLng;
}): Promise<RoofMeasurementImagery | undefined> {
  const layers = await fetchDataLayers(input).catch(() => null);
  if (!layers) return undefined;

  const preview = layers.rgbUrl
    ? await renderRgbPreview(layers.rgbUrl, input.apiKey).catch(() => undefined)
    : undefined;
  const imageBounds = preview?.bounds ?? boundsFromSegments(input.segments);
  const maskDataUrl = layers.maskUrl
    ? await renderMaskOverlay(layers.maskUrl, input.apiKey).catch(() => undefined)
    : undefined;
  const maskGeometry = layers.maskUrl
    ? await analyzeMaskLayer(
        layers.maskUrl,
        input.apiKey,
        input.segments,
        input.targetPoint,
      ).catch(() => undefined)
    : undefined;
  const elevation = layers.dsmUrl
    ? await analyzeDsmLayer(layers.dsmUrl, layers.maskUrl, input.apiKey).catch(() => undefined)
    : undefined;

  // Optional Grok pass: send the aerial preview to xAI for yellow facet lines.
  // Disabled for now — scans render the plain Google Solar aerial instead.
  // To re-enable: uncomment import + block below, add xaiApiKey() helper, and use:
  //   previewDataUrl: linedDataUrl ?? preview?.dataUrl
  /*
  const grokKey = xaiApiKey();
  const linedDataUrl = preview?.dataUrl && grokKey
    ? await drawRoofLinesWithGrok({
        imageDataUrl: preview.dataUrl,
        apiKey: grokKey,
      }).catch(() => undefined)
    : undefined;
  */

  return {
    previewDataUrl: preview?.dataUrl,
    maskDataUrl,
    imageryDate: formatGoogleDate(layers.imageryDate),
    imageryProcessedDate: formatGoogleDate(layers.imageryProcessedDate),
    imageryQuality: normalizeImageryQuality(layers.imageryQuality),
    bounds: imageBounds,
    georef: preview?.georef,
    maskGeometry,
    elevation,
    availableLayers: availableLayerTypes(layers),
  };
}

function googleSolarCenter(
  buildingInsights: GoogleSolarBuildingInsights,
): LatLng | undefined {
  const center = buildingInsights.center;
  if (
    typeof center?.latitude !== "number" ||
    typeof center.longitude !== "number"
  ) {
    return undefined;
  }
  return {
    latitude: center.latitude,
    longitude: center.longitude,
  };
}

async function fetchDataLayers(input: {
  latitude: number;
  longitude: number;
  requiredQuality: "HIGH" | "MEDIUM" | "LOW";
  apiKey: string;
}): Promise<GoogleSolarDataLayers> {
  const params = new URLSearchParams({
    "location.latitude": String(input.latitude),
    "location.longitude": String(input.longitude),
    radiusMeters: "30",
    view: "FULL_LAYERS",
    requiredQuality: input.requiredQuality,
    pixelSizeMeters: String(DATA_LAYER_PIXEL_SIZE_METERS),
    key: input.apiKey,
  });

  return $fetch<GoogleSolarDataLayers>(
    `https://solar.googleapis.com/v1/dataLayers:get?${params}`,
  ).catch((error: unknown) => {
    const message = error instanceof Error
      ? error.message
      : "Roof imagery layers lookup failed";
    throw createError({
      statusCode: 502,
      statusMessage: sanitizeGoogleError(message),
    });
  });
}

async function renderRgbPreview(
  rgbUrl: string,
  apiKey: string,
): Promise<{
  dataUrl: string;
  bounds?: RoofBoundingBox;
  georef?: ReturnType<typeof buildImageryGeoref>;
}> {
  const url = new URL(rgbUrl);
  url.searchParams.set("key", apiKey);
  const response = await fetch(url);
  if (!response.ok) {
    throw createError({
      statusCode: 502,
      statusMessage: "Roof imagery download failed",
    });
  }

  const tiff = await fromArrayBuffer(await response.arrayBuffer());
  const image = await tiff.getImage();
  const width = image.getWidth();
  const height = image.getHeight();
  const bbox = image.getBoundingBox();
  const epsg = readTiffEpsg(image.getGeoKeys());
  const samples = image.getSamplesPerPixel();
  const maxWidth = 640;
  const scale = Math.max(1, Math.ceil(width / maxWidth));
  const previewWidth = Math.max(1, Math.floor(width / scale));
  const previewHeight = Math.max(1, Math.floor(height / scale));
  const rasters = await image.readRasters({
    interleave: true,
    width: previewWidth,
    height: previewHeight,
  });
  const png = new PNG({ width: previewWidth, height: previewHeight });

  for (let index = 0, pixel = 0; index < previewWidth * previewHeight; index += 1, pixel += 4) {
    const source = index * samples;
    const red = Number(rasters[source] ?? 0);
    const green = Number(rasters[source + 1] ?? red);
    const blue = Number(rasters[source + 2] ?? red);
    png.data[pixel] = red;
    png.data[pixel + 1] = green;
    png.data[pixel + 2] = blue;
    png.data[pixel + 3] = 255;
  }

  const georef = buildImageryGeoref({
    bbox,
    epsg,
    sourceWidthPx: width,
    sourceHeightPx: height,
    previewWidthPx: previewWidth,
    previewHeightPx: previewHeight,
    pixelSizeMeters: DATA_LAYER_PIXEL_SIZE_METERS,
    extentMeters: tiffExtentMeters(bbox, epsg),
  });

  return {
    dataUrl: `data:image/png;base64,${PNG.sync.write(png).toString("base64")}`,
    bounds: tiffBoundsToLatLng(bbox, epsg) ?? normalizeTiffBounds(bbox),
    georef,
  };
}

async function renderMaskOverlay(maskUrl: string, apiKey: string): Promise<string> {
  const url = new URL(maskUrl);
  url.searchParams.set("key", apiKey);
  const response = await fetch(url);
  if (!response.ok) {
    throw createError({
      statusCode: 502,
      statusMessage: "Roof mask download failed",
    });
  }

  const tiff = await fromArrayBuffer(await response.arrayBuffer());
  const image = await tiff.getImage();
  const width = image.getWidth();
  const height = image.getHeight();
  const maxWidth = 640;
  const scale = Math.max(1, Math.ceil(width / maxWidth));
  const previewWidth = Math.max(1, Math.floor(width / scale));
  const previewHeight = Math.max(1, Math.floor(height / scale));
  const rasters = await image.readRasters({
    interleave: true,
    width: previewWidth,
    height: previewHeight,
  });
  const png = new PNG({ width: previewWidth, height: previewHeight });

  for (let index = 0, pixel = 0; index < previewWidth * previewHeight; index += 1, pixel += 4) {
    const value = Number(rasters[index] ?? 0);
    const alpha = value > 0 ? 105 : 0;
    png.data[pixel] = 120;
    png.data[pixel + 1] = 205;
    png.data[pixel + 2] = 255;
    png.data[pixel + 3] = alpha;
  }

  return `data:image/png;base64,${PNG.sync.write(png).toString("base64")}`;
}

async function analyzeDsmLayer(
  dsmUrl: string,
  maskUrl: string | undefined,
  apiKey: string,
): Promise<RoofMeasurementElevationAnalysis> {
  const dsmImage = await fetchTiffImage(dsmUrl, apiKey);
  const width = dsmImage.getWidth();
  const height = dsmImage.getHeight();
  const dsmRaster = await dsmImage.readRasters({ interleave: true });
  const maskRaster = maskUrl
    ? await fetchMaskRaster(maskUrl, apiKey, width, height).catch(() => undefined)
    : undefined;
  const values: number[] = [];

  for (let index = 0; index < width * height; index += 1) {
    if (maskRaster && Number(maskRaster[index] ?? 0) <= 0) continue;
    const value = Number(dsmRaster[index]);
    if (!Number.isFinite(value) || Math.abs(value) > 10000) continue;
    values.push(value);
  }

  if (!values.length) {
    throw createError({
      statusCode: 502,
      statusMessage: "Roof elevation layer did not include usable height samples",
    });
  }

  values.sort((left, right) => left - right);
  const minHeightMeters = values[0] ?? 0;
  const maxHeightMeters = values[values.length - 1] ?? minHeightMeters;
  const meanHeightMeters = values.reduce((total, value) => total + value, 0) / values.length;
  const p05 = percentile(values, 0.05);
  const p95 = percentile(values, 0.95);
  const highOutlierMeters = maxHeightMeters - p95;
  const lowOutlierMeters = p05 - minHeightMeters;
  const possibleObstruction = highOutlierMeters > 1.2 || lowOutlierMeters > 1.2;
  const notes = elevationNotes({
    highOutlierMeters,
    lowOutlierMeters,
    possibleObstruction,
    sampleCount: values.length,
    typicalHeightRangeMeters: p95 - p05,
  });

  return {
    sampleCount: values.length,
    minHeightMeters: roundTo(minHeightMeters, 2),
    maxHeightMeters: roundTo(maxHeightMeters, 2),
    meanHeightMeters: roundTo(meanHeightMeters, 2),
    heightRangeMeters: roundTo(maxHeightMeters - minHeightMeters, 2),
    typicalHeightRangeMeters: roundTo(p95 - p05, 2),
    highOutlierMeters: roundTo(highOutlierMeters, 2),
    lowOutlierMeters: roundTo(lowOutlierMeters, 2),
    possibleObstruction,
    notes,
  };
}

async function fetchTiffImage(urlValue: string, apiKey: string) {
  const url = new URL(urlValue);
  url.searchParams.set("key", apiKey);
  const response = await fetch(url);
  if (!response.ok) {
    throw createError({
      statusCode: 502,
      statusMessage: "Roof elevation download failed",
    });
  }

  const tiff = await fromArrayBuffer(await response.arrayBuffer());
  return tiff.getImage();
}

async function fetchMaskRaster(
  maskUrl: string,
  apiKey: string,
  width: number,
  height: number,
) {
  const maskImage = await fetchTiffImage(maskUrl, apiKey);
  return maskImage.readRasters({
    interleave: true,
    width,
    height,
  });
}

function availableLayerTypes(layers: GoogleSolarDataLayers): RoofMeasurementLayerType[] {
  return [
    layers.rgbUrl ? "rgb" : null,
    layers.dsmUrl ? "dsm" : null,
    layers.maskUrl ? "mask" : null,
    layers.annualFluxUrl ? "annual_flux" : null,
    layers.monthlyFluxUrl ? "monthly_flux" : null,
    layers.hourlyShadeUrls?.length ? "hourly_shade" : null,
  ].filter((layer): layer is RoofMeasurementLayerType => layer !== null);
}

function normalizeImageryQuality(value?: string): RoofImageryQuality {
  if (value === "HIGH" || value === "MEDIUM" || value === "LOW") return value;
  return "UNKNOWN";
}

function formatGoogleDate(value?: GoogleDate): string | undefined {
  if (!value?.year || !value.month || !value.day) return undefined;
  return [
    value.year,
    String(value.month).padStart(2, "0"),
    String(value.day).padStart(2, "0"),
  ].join("-");
}

function normalizeTiffBounds(bounds: number[]): RoofBoundingBox | undefined {
  if (bounds.length < 4 || bounds.some((value) => typeof value !== "number")) {
    return undefined;
  }
  const west = bounds[0];
  const south = bounds[1];
  const east = bounds[2];
  const north = bounds[3];
  if (
    west === undefined ||
    south === undefined ||
    east === undefined ||
    north === undefined
  ) {
    return undefined;
  }
  if (Math.abs(west) > 180 || Math.abs(east) > 180) return undefined;
  if (Math.abs(south) > 90 || Math.abs(north) > 90) return undefined;
  return {
    sw: { latitude: south, longitude: west },
    ne: { latitude: north, longitude: east },
  };
}

function percentile(values: number[], ratio: number): number {
  if (!values.length) return 0;
  const index = Math.min(
    values.length - 1,
    Math.max(0, Math.round((values.length - 1) * ratio)),
  );
  return values[index] ?? 0;
}

function elevationNotes(input: {
  highOutlierMeters: number;
  lowOutlierMeters: number;
  possibleObstruction: boolean;
  sampleCount: number;
  typicalHeightRangeMeters: number;
}): string[] {
  const notes: string[] = [];
  if (input.sampleCount < 250) {
    notes.push("Elevation sample count is low, so manual review is recommended.");
  }
  if (input.typicalHeightRangeMeters > 4) {
    notes.push("Elevation data shows meaningful roof-height variation that can help validate pitch assumptions.");
  } else {
    notes.push("Elevation data is relatively consistent across the masked roof area.");
  }
  if (input.possibleObstruction) {
    notes.push("Localized height outliers may indicate trees, equipment, or another obstruction near the roof.");
  }
  if (!notes.length) {
    notes.push("Elevation data did not add any immediate review flags.");
  }
  return notes;
}

function roundTo(value: number, digits: number): number {
  const multiplier = 10 ** digits;
  return Math.round(value * multiplier) / multiplier;
}

function boundsFromSegments(
  segments: RoofMeasurement["segments"],
): RoofBoundingBox | undefined {
  const boxes = segments
    .map((segment) => segment.boundingBox)
    .filter((box): box is RoofBoundingBox => Boolean(box));
  if (!boxes.length) return undefined;

  const south = Math.min(...boxes.map((box) => box.sw.latitude));
  const west = Math.min(...boxes.map((box) => box.sw.longitude));
  const north = Math.max(...boxes.map((box) => box.ne.latitude));
  const east = Math.max(...boxes.map((box) => box.ne.longitude));
  const latitudePadding = Math.max((north - south) * 0.55, 0.00004);
  const longitudePadding = Math.max((east - west) * 0.55, 0.00004);

  return {
    sw: {
      latitude: south - latitudePadding,
      longitude: west - longitudePadding,
    },
    ne: {
      latitude: north + latitudePadding,
      longitude: east + longitudePadding,
    },
  };
}

function sanitizeGoogleError(message: string): string {
  return message.replace(/key=[^&\s"]+/g, "key=[redacted]");
}
