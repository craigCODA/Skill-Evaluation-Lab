import type { H3Event } from "h3"

export type CurrentUser = {
  sub: string
  email: string
  name: string
  groups: string[]
  isAdmin: boolean
}

const ADMIN_GROUP = "admin"
const DEV_ADMIN_EMAIL = "admin@example.com"

/** Owner id used by the in-memory dev seed (matches the dev admin's sub). */
export const DEV_ADMIN_SUB = `dev:${DEV_ADMIN_EMAIL}`

/**
 * Resolve the caller's identity. In the deployed Lambda the API Gateway JWT
 * authorizer has already validated the token, so we trust the decoded claims.
 * Locally (no Cognito) we fall back to a dev admin, overridable per-request
 * with an `x-dev-user-email` header for role testing.
 */
export function getCurrentUser(event: H3Event): CurrentUser {
  const token = bearerToken(event)
  if (token) {
    const claims = decodeJwt(token)
    if (claims?.sub) {
      const groups = normalizeGroups(claims["cognito:groups"])
      return {
        sub: String(claims.sub),
        email: String(claims.email ?? ""),
        name: String(claims.name ?? ""),
        groups,
        isAdmin: groups.includes(ADMIN_GROUP)
      }
    }
  }

  if (process.env.NODE_ENV !== "production") {
    const email = getHeader(event, "x-dev-user-email") || DEV_ADMIN_EMAIL
    const isAdmin = email === DEV_ADMIN_EMAIL
    return {
      sub: `dev:${email}`,
      email,
      name: isAdmin ? "Admin" : email,
      groups: [isAdmin ? ADMIN_GROUP : "customer"],
      isAdmin
    }
  }

  throw createError({ statusCode: 401, statusMessage: "Unauthorized" })
}

export function requireAdmin(event: H3Event): CurrentUser {
  const user = getCurrentUser(event)
  if (!user.isAdmin) {
    throw createError({ statusCode: 403, statusMessage: "Admin access required" })
  }
  return user
}

function bearerToken(event: H3Event): string | null {
  const header = getHeader(event, "authorization")
  if (!header) return null
  const match = header.match(/^Bearer\s+(.+)$/i)
  return match?.[1] ?? null
}

function decodeJwt(token: string): Record<string, unknown> | null {
  const segment = token.split(".")[1]
  if (!segment) return null
  try {
    const payload = segment.replace(/-/g, "+").replace(/_/g, "/")
    const json = Buffer.from(payload, "base64").toString("utf8")
    return JSON.parse(json) as Record<string, unknown>
  } catch {
    return null
  }
}

function normalizeGroups(value: unknown): string[] {
  if (Array.isArray(value)) return value.map(String)
  if (typeof value === "string" && value) return [value]
  return []
}
