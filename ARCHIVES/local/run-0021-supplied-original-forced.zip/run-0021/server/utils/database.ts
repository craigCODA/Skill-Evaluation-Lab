import { drizzle } from "drizzle-orm/postgres-js"
import postgres from "postgres"
import * as schema from "../db/schema"

let db: ReturnType<typeof drizzle<typeof schema>> | null = null

export function hasDatabaseUrl() {
  return Boolean(useRuntimeConfig().databaseUrl)
}

export function useDatabase() {
  if (db) return db

  const config = useRuntimeConfig()
  if (!config.databaseUrl) {
    throw createError({
      statusCode: 500,
      statusMessage: "DATABASE_URL is required"
    })
  }

  const client = postgres(config.databaseUrl, {
    max: 1,
    prepare: false
  })

  db = drizzle(client, { schema })
  return db
}

export { schema }
