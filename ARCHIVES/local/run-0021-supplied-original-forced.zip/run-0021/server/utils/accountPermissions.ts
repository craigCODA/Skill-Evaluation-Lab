import {
  accountUserHasCapability,
  readCompanyRoleCapabilities,
  type AccountCapability
} from "~~/shared/accountPermissions"
import type { CustomerAccountContext } from "./customerAccountAccess"

/** Throw 403 when the current account context lacks a capability. */
export function assertAccountCapability(
  context: CustomerAccountContext,
  capability: AccountCapability,
  statusMessage = "Access denied: insufficient permissions"
): void {
  if (contextHasCapability(context, capability)) return
  throw createError({ statusCode: 403, statusMessage })
}

export function contextHasCapability(
  context: CustomerAccountContext,
  capability: AccountCapability
): boolean {
  return accountUserHasCapability({
    isPlatformAdmin: context.isPlatformAdmin,
    role: context.subAccount.role,
    capability,
    roleCapabilities: readCompanyRoleCapabilities(context.customerAccount.roleCapabilities)
  })
}
