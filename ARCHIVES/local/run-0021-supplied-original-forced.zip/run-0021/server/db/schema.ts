import { doublePrecision, jsonb, pgTable, primaryKey, text, timestamp } from "drizzle-orm/pg-core"
import type { Catalog } from "~~/shared/pricebook/types"
import type { CompanyContractConfig, JobContractSnapshot } from "~~/shared/contracts/modules"
import type { CompanyProfile, CustomerAccount, CustomerRecord, Job, JobAsset, RoofMeasurement, SubAccount } from "~~/shared/types"

export const customerAccounts = pgTable("customer_accounts", {
  id: text("id").primaryKey(),
  name: text("name").notNull().default(""),
  adminUserId: text("admin_user_id").notNull().default(""),
  bodyJson: jsonb("body_json").$type<CustomerAccount>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow()
})

export type CustomerAccountRow = typeof customerAccounts.$inferSelect
export type NewCustomerAccountRow = typeof customerAccounts.$inferInsert

export const subAccounts = pgTable("sub_accounts", {
  id: text("id").primaryKey(),
  customerAccountId: text("customer_account_id").notNull().default(""),
  userId: text("user_id").notNull().default(""),
  email: text("email").notNull().default(""),
  name: text("name").notNull().default(""),
  role: text("role").notNull().default("sub-account"),
  bodyJson: jsonb("body_json").$type<SubAccount>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow()
})

export type SubAccountRow = typeof subAccounts.$inferSelect
export type NewSubAccountRow = typeof subAccounts.$inferInsert

export const customers = pgTable("customers", {
  id: text("id").primaryKey(),
  customerAccountId: text("customer_account_id").notNull().default(""),
  createdBySubAccountId: text("created_by_sub_account_id").notNull().default(""),
  displayName: text("display_name").notNull().default(""),
  address: text("address").notNull().default(""),
  bodyJson: jsonb("body_json").$type<CustomerRecord>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow()
})

export type CustomerRow = typeof customers.$inferSelect
export type NewCustomerRow = typeof customers.$inferInsert

export const jobs = pgTable("jobs", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull().default(""),
  customerAccountId: text("customer_account_id").notNull().default(""),
  createdBySubAccountId: text("created_by_sub_account_id").notNull().default(""),
  customerId: text("customer_id").notNull().default(""),
  status: text("status").notNull(),
  customerName: text("customer_name").notNull().default(""),
  bodyJson: jsonb("body_json").$type<Job>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow()
})

export type JobRow = typeof jobs.$inferSelect
export type NewJobRow = typeof jobs.$inferInsert

export const jobAssets = pgTable("job_assets", {
  id: text("id").primaryKey(),
  customerAccountId: text("customer_account_id").notNull().default(""),
  createdBySubAccountId: text("created_by_sub_account_id").notNull().default(""),
  customerId: text("customer_id").notNull().default(""),
  jobId: text("job_id").notNull().default(""),
  kind: text("kind").notNull().default("image"),
  label: text("label").notNull().default(""),
  contentType: text("content_type").notNull().default("image/png"),
  imageKey: text("image_key").notNull().default(""),
  bodyJson: jsonb("body_json").$type<JobAsset>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow()
})

export type JobAssetRow = typeof jobAssets.$inferSelect
export type NewJobAssetRow = typeof jobAssets.$inferInsert

export const catalogItems = pgTable("catalog_items", {
  ownerId: text("owner_id").notNull().default(""),
  section: text("section").notNull(),
  itemKey: text("item_key").notNull(),
  bodyJson: jsonb("body_json").$type<Catalog[keyof Catalog][number]>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow()
}, (table) => [
  primaryKey({ columns: [table.ownerId, table.section, table.itemKey] })
])

export type CatalogItemRow = typeof catalogItems.$inferSelect
export type NewCatalogItemRow = typeof catalogItems.$inferInsert

export const companyProfile = pgTable("company_profile", {
  id: text("id").primaryKey(),
  bodyJson: jsonb("body_json").$type<CompanyProfile>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow()
})

export type CompanyProfileRow = typeof companyProfile.$inferSelect
export type NewCompanyProfileRow = typeof companyProfile.$inferInsert

export const roofProbeMeasurements = pgTable("roof_probe_measurements", {
  addressKey: text("address_key").primaryKey(),
  displayAddress: text("display_address").notNull(),
  latitude: doublePrecision("latitude").notNull(),
  longitude: doublePrecision("longitude").notNull(),
  imageryDate: text("imagery_date"),
  imageryQuality: text("imagery_quality").notNull().default("UNKNOWN"),
  provider: text("provider").notNull().default("unknown"),
  previewImageKey: text("preview_image_key"),
  maskImageKey: text("mask_image_key"),
  bodyJson: jsonb("body_json").$type<RoofMeasurement>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  refreshedAt: timestamp("refreshed_at", { withTimezone: true }).notNull().defaultNow(),
  lastRequestedAt: timestamp("last_requested_at", { withTimezone: true }).notNull().defaultNow()
})

export type RoofProbeMeasurementRow = typeof roofProbeMeasurements.$inferSelect
export type NewRoofProbeMeasurementRow = typeof roofProbeMeasurements.$inferInsert

/** Per-company modular contract recipe + editable module copy. */
export const contractConfigs = pgTable("contract_configs", {
  customerAccountId: text("customer_account_id").primaryKey(),
  bodyJson: jsonb("body_json").$type<CompanyContractConfig>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow()
})

export type ContractConfigRow = typeof contractConfigs.$inferSelect
export type NewContractConfigRow = typeof contractConfigs.$inferInsert

/**
 * Generated contract snapshots for a job.
 * Keep at most one unsigned and one signed row per job (enforced in store).
 */
export const jobContracts = pgTable("job_contracts", {
  id: text("id").primaryKey(),
  jobId: text("job_id").notNull().default(""),
  customerAccountId: text("customer_account_id").notNull().default(""),
  status: text("status").notNull().default("unsigned"),
  bodyJson: jsonb("body_json").$type<JobContractSnapshot>().notNull(),
  generatedAt: timestamp("generated_at", { withTimezone: true }).notNull().defaultNow(),
  signedAt: timestamp("signed_at", { withTimezone: true }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow()
})

export type JobContractRow = typeof jobContracts.$inferSelect
export type NewJobContractRow = typeof jobContracts.$inferInsert
